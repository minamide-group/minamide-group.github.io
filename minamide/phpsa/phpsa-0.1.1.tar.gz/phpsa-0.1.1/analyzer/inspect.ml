open Support
open Il

let inspect program = 
  let unknown_tbl = Hashtbl.create 49 in
  let unknown_class_tbl = Hashtbl.create 49 in
  let valid = ref true in
  let invalidate () = valid := false in

  let functions_tbl = program.functions in 
  let check_function s =
    if not (Hashtbl.mem functions_tbl s) then 
      (Hashtbl.replace unknown_tbl s.name (); invalidate ()) in

  let classes_tbl = program.classes in 
  let check_class s =
    if not (Hashtbl.mem classes_tbl s) then 
      (Hashtbl.replace unknown_class_tbl s (); invalidate ()) in

  let rec eval e =
    match e with 
      Prim (NewObj cname, es, i) -> check_class cname; eval_list es
    | Prim (p, es, i) -> eval_list es
    | App (s, es, x) -> eval_list es
    | e -> ()
  and eval_list es =
    List.iter eval es 
  and eval_lv lv =
    match lv with 
    | LArray2 (lv, e) -> eval e
    | _ -> () in

  let rec exec s =
    match s with
    | FunCall (xs, s, es, b, bs) -> eval_list es; check_function s
    | ClassMethodCall (xs, cname, mname, es, r, bs) -> eval_list es; check_class cname
    | MethodCall (xs, e, mname, es, r, bs) -> eval_list es
    | LocalFun (x, xs, b) -> exec_block b
    | DrefAssign (x, e) -> eval e
    | RefAssign (lv1, lv2)  -> 	eval_lv lv1; eval_lv lv2
    | Assign (x, e) -> eval e
    | ExpSt e -> eval e
    | Define (x,e) -> eval e
    | _ -> ()
  and exec_block s =
    match s with 
    | If (e, x1, s1, x2, s2) -> 
	eval e; exec_block s1; exec_block s2
    | Switch (e, x, cs) -> 
	let exec_case (g, y, b) = exec_block b in
	eval e;
	List.iter exec_case cs
    | Seq (s,b) -> exec s; exec_block b
    | LocalCall (x, es) -> eval_list es
    | Return es -> eval_list es
    | _ -> () in

  let main_f b = exec_block b in
  let function_f (x, xs, b, zs, r) = exec_block b in
  let class_f (s, xs, ms) =
    let exec_method (x, xs, this, b, zs, r) = exec_block b in
    List.iter exec_method ms in
  iter_program main_f function_f class_f program;
  if not (!valid) then 
    (if Hashtbl.length unknown_tbl > 0 then Format.printf "Unspecified functions:@.";
     Hashtbl.iter (fun k _ -> Format.printf "%s@." k) unknown_tbl;
     if Hashtbl.length unknown_class_tbl > 0 then Format.printf "Unspecified classes:@.";
     Hashtbl.iter (fun k _ -> Format.printf "%s@." k) unknown_class_tbl;
     failwith "Give specification for the functions and classes above")   
