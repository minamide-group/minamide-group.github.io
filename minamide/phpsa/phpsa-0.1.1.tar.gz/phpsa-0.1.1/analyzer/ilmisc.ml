(*
 * PHP string analyzer
 * Copyright (C) 2006 Yasuhiko Minamide
 *)
open Support
open Il

type ilenv = 
    { fun_env : (var, function_decl) Hashtbl.t;
      classes : (string, class_decl) Hashtbl.t;
      lfun_env : (var, var list) Hashtbl.t;
      class_env : (var, (var * var) StringMap.t * var * var * var) Hashtbl.t;
      classmethod_env : (var * var, method_decl) Hashtbl.t; 
      method_env : (var, var * method_decl) Hashtbl.t; }

let rec fenv_of_stmt lfun_env s =
  match s with 
  | LocalFun (x, xs, b) -> 
      Hashtbl.add lfun_env x xs;
      fenv_of_block lfun_env b
  | s -> ()
and fenv_of_block lfun_env s =
  match s with 
  | If (e, x1, s1, x2, s2) -> 
      fenv_of_block lfun_env s1;
      fenv_of_block lfun_env s2
  | Switch (e, x, cs) -> 
      let fenv_of_case (g, y, b) = fenv_of_block lfun_env b in
      List.iter fenv_of_case cs
  | Seq (s,b) -> 
      fenv_of_stmt lfun_env s;
      fenv_of_block lfun_env b
  | s -> () 


let fenv_of s = 
  let lfun_env = Hashtbl.create 49 in
  fenv_of_block lfun_env s;
  lfun_env

let fenv_of_program program =
  let lfun_env = Hashtbl.create 49 in
  let class_env = Hashtbl.create 49 in
  let method_env = Hashtbl.create 49 in
  let classmethod_env = Hashtbl.create 49 in
  let function_f (x, xs, b, ys, r) = fenv_of_block lfun_env b in
  let class_f (cname, xs, ms) =
    Hashtbl.add class_env cname
      (List.fold_left (fun env (x,_) -> 
	StringMap.add x (fresh_var (), fresh_var ()) env) 
	 StringMap.empty xs, fresh_var (), fresh_var (), fresh_var ());
    List.iter 
      (fun ((x, xs, this, b, ys, r) as m) ->
	fenv_of_block lfun_env b;
	Hashtbl.add method_env x (cname, m);
	Hashtbl.add classmethod_env (cname,x) m) ms in
  let main_f b = fenv_of_block lfun_env b in
  iter_program main_f function_f class_f program;
  { fun_env = program.Il.functions; 
    classes = program.Il.classes;
    lfun_env = lfun_env;
    class_env = class_env;
    classmethod_env = classmethod_env;
    method_env = method_env}

let stdclass_of ilenv = 
  match Hashtbl.find_all ilenv.classes "stdclass" with
      [(cid,_,_)] -> cid
    | [] -> failwith "no StdClass"
    | _ -> failwith "more than one definitions of StdClass"

let fun_env_find x ilenv = Hashtbl.find_all ilenv.fun_env x 
let find_objectmethod ilenv cname mname = 
  Hashtbl.find ilenv.classmethod_env (cname, mname)
let find_classmethod ilenv cname mname = 
  let cs = Hashtbl.find_all ilenv.classes cname in
  List.fold_left (fun ms (c,_,_) ->
    try 
      find_objectmethod ilenv c mname::ms
    with Not_found -> ms) [] cs
let find_method ilenv mname = 
  Hashtbl.find_all ilenv.method_env mname
let find_class ilenv cname =
  Hashtbl.find ilenv.class_env cname
let find_stdclass ilenv = find_class ilenv (stdclass_of ilenv) 
  
let rec ovars s =
  let rec ovars_stmt (ovars, avars) s =
    match s with 
      LocalFun (x, xs, b) -> ovars_block (ovars, avars) b
    | Assert (_, x, _) -> if (!Options.assert_mode) then (x::ovars, avars) else (ovars, avars) 
    | s -> (ovars, avars)
  and ovars_block (ovars, avars) s =
    match s with 
    | If (e, x1, s1, x2, s2) -> ovars_block (ovars_block (ovars, avars) s1) s2
    | Switch (e, x, cs) ->
	let ovars_case (ovars, avars) (g, y, b) = ovars_block (ovars, avars) b in
	let (ovars, avars) = List.fold_left ovars_case (ovars, avars) cs in
	(ovars, VarSet.add x avars)
    | Seq (s,b) -> ovars_block (ovars_stmt (ovars, avars) s) b
    | Stop (_, Some x) -> if not (!Options.assert_mode) then (x::ovars, avars) else (ovars, avars) 
    | s -> (ovars, avars) in
  let function_f vs (x, xs, b, zs, _) = ovars_block vs b in
  let class_f vs (cname, xs, ms) =
    List.fold_left 
      (fun vs (x, xs, this, b, ys, r) -> ovars_block vs b)
      vs ms  in
  let (ovars, avars) = fold_program ovars_block function_f class_f s ([], VarSet.empty) in
  ovars, VarSet.elements avars




