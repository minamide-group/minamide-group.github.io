let opt_specfile = ref (None : string option)
let opt_ispecfile = ref (None : string option)
let opt_ofile = ref (None : string option)
let nexamples = ref 0
let mode = ref true
let matching_mode = ref false
let simplify_mode = ref false
let symeval_mode = ref false
let localsymeval_mode = ref false
let tagchecking_mode = ref false
let validate_mode = ref false
let validate_attribute_mode = ref false
let exit_analysis_mode = ref false
let check_depth = ref false
let trace_mode = ref false
let enable_inline = ref Support.StringSet.empty
let libs = ref ([]:string list)
let include_path = ref ([]:string list)
let enable_deadelim = ref false
let enable_fullinline = ref false
let maxsize = ref 100
let debug_level = ref 0
let xml_mode = ref false
let loop_max = ref 10
let phpfilefilter = ref "/.*\\.(php|inc|js)/"
let dtdstrict = ref false
let dtdfile = ref "xhtml1-transitional.dtd"
let short_open_tag = ref false
let assert_mode = ref false

let phpsa_dir = 
  try Sys.getenv "PHPSA_HOME" 
  with Not_found -> failwith "Please set the environment variable PHPSA_HOME."

let dtd_dir = Filename.concat phpsa_dir "dtd"
let test_dir = Filename.concat phpsa_dir "tests"
let lib_dir = Filename.concat phpsa_dir "lib"

let show n f  = if !debug_level >= n then 
  (Format.printf "@."; f Format.std_formatter; Format.printf "@.")

let notice f  = show 0 f



