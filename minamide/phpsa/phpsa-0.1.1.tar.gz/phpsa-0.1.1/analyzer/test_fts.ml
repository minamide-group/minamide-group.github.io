open Support
open Flbasics
open Fts
open OUnit

let tcs = []

let css_equal css1 css2 = 
  List.sort compare css1 = List.sort compare css2

let string_of_css css = 
  Format.fprintf Format.str_formatter "%a" (Basic.print_list "\n" pp_charlist) css;
  Format.flush_str_formatter ()

let run_test endmark (fa, str, strs) =
  let cs = explode str in
  let cs = if endmark then cs@[Fts.mark_char] else cs in
  let sss = Ft.output fa cs in
  let css = List.map (List.map (function Cfg.Terminal x -> x | _ -> failwith "ss2cs")) sss in
  let css' = List.map explode strs in
  assert_equal ~cmp:css_equal ~printer:string_of_css ~msg:str css' css 

let test_cases1 = 
  ["trim_ft", false,
   [(trim_ft sp, "  aaa bbb ", ["aaa bbb"])];
   "ltrim_ft", false,
   [(ltrim_ft sp, "  aaa bbb  ", ["aaa bbb  "])];
   "rtrim_ft", false,
   [(rtrim_ft sp,  "  aaa bbb  ", ["  aaa bbb"])];
   "ucfirst_ft", false,
   [(ucfirst_ft,  "abc", ["Abc"]);
    (ucfirst_ft,  "Abc", ["Abc"])];
   "ucword_ft", false,
   [(ucword_ft,  "abc xyz", ["Abc Xyz"]);
    (ucword_ft,  "Abc Xyz", ["Abc Xyz"])];
   "string_ft", false,
   [(string_ft (explode "ab") [Cfg.Terminal 'x'], "aababaab",  ["axxax"]);
    (string_ft (explode "ab") [Cfg.Terminal 'x'], "ababaab",  ["xxax"]);
    (string_ft (explode "ab") [Cfg.Terminal 'x'], "ababaabb",  ["xxaxb"])];
   "strstr_ft", false,
   [(strstr_ft false ['@'], "user@example.com", ["@example.com"]);
    (strstr_ft false ['A'; 'b'], "xAaBc", ["aBc"])];
   "explode1_ft", false,
   [(explode_ft1 [':'; ':'], "a::b::ccc",["a::b::ccc"; "b::ccc"; "ccc"]);
    (explode_ft1 [':'; ':'], "a::b::",["a::b::"; "b::"; ""]);
    (explode_ft1 [':'; ':'], "::b::ccc",["::b::ccc"; "b::ccc"; "ccc"]);
    (explode_ft1 [':'; ':'], "a::b:::ccc",["a::b:::ccc"; "b:::ccc"; ":ccc"])];
   "explode2_ft", false,
   [(explode_ft2 [':'; ':'], "aa::",["aa"]);
    (explode_ft2 [':'; ':'], "aa::b",["aa"]);
    (explode_ft2 [':'; ':'], "aa:::b",["aa"]);
    (explode_ft2 [':'; ':'], "aaa",["aaa"]);
    (explode_ft2 [':'; ':'], "aaa:",["aaa:"]);
    (explode_ft2 [':'; ':'], ":aaa",[":aaa"]);
    (explode_ft2 [':'; ':'], "::aaa",[""])];
   "strings_ft", false,
   [(strings_ft [("abc", "A"); ("abde", "BB")], "abcaabdef", ["AaBBf"])];
   "strings_ft_endmark_ft", true,
   [(strings_ft_endmark [("abc", "A"); ("abde", "BB")], "abcaabdef", ["AaBBf"])];
   "substr", false,
   [(append_cut_ft (Some 3) (skip_ft (Some 2)), "abcdefg", ["cde"]);
    (append_cut_ft (Some 3) (skip_ft None), "abcde", ["abc"; "bcd"; "cde"; "de"; "e"; ""]);
    (append_cut_ft None (skip_ft (Some 2)), "abcdefg", [""; "c"; "cd"; "cde"; "cdef"; "cdefg"]);
    (append_id_ft (skip_ft (Some 2)), "abcdefg", ["cdefg"]);
    (append_id_ft (skip_ft None), "abcde", ["abcde"; "bcde"; "cde"; "de"; "e"; ""])]; 
   "prefix_ft", false,
   [(prefix_ft, "012", [""; "0"; "01"; "012"])];
   "strip_tags_ft", false,
   [(strip_tags_ft, "<<aa>>>>",[">>>"; ">>"; ">"; ""]);
    (strip_tags_ft, "<aa><bb>>",[">"; ""])];
   "pad_ft", true,
   [(pad_ft '0' 4, "",["0000"]);
    (pad_ft '0' 4, "1",["1000"]);
    (pad_ft '0' 4, "1111",["1111"]);
    (pad_ft '0' 4, "123456",["123456"])];
   "base64encode_ft", true,
   [(base64encode_ft, "abc", ["YWJj"]);
    (base64encode_ft, "abcd", ["YWJjZA=="]);
    (base64encode_ft, "abcde", ["YWJjZGU="]);];
   "base64decode_ft", false,
   [(base64dencode_ft, "YWJj", ["abc"]);
    (base64dencode_ft, "YWJjZA==", ["abcd"]);
    (base64dencode_ft, "YWJjZGU=", ["abcde"])];
   "rawurlencode_ft", false,
   [(rawurldecode_ft, "%3F%2A%28%29", ["?*()"])];
   "urlencode_ft", false,
   [(urldecode_ft, "%3F%2A%28%29+%29", ["?*() )"])];
   "str_pad_ft", true, 
   [(str_pad_ft ['a'; 'b'] 4, "",["abab"]);
    (str_pad_ft ['a'; 'b'] 4, "1",["1aba"]);
    (str_pad_ft ['a'; 'b'] 4, "1111",["1111"]);
    (str_pad_ft ['a'; 'b'] 4, "123456",["123456"])];
   "chunk_split_ft", false,
   [(chunk_split_ft 2 ['x'], "abcdef",["abxcdxefx"])];
   "nth_mark_ft", true,
   [(nth_mark_ft 0 'x', "abc",["xabc"^String.make 1 Fts.mark_char]);
    (nth_mark_ft 2 'x', "abc",["abxc"^String.make 1 Fts.mark_char])];
   "str_split_ft", false,
   [(str_split_ft 1, "abc",["a";"b";"c"]);
    (str_split_ft 2, "abc",["ab";"c"]);
    (str_split_ft 2, "abcd",["ab";"cd"])];
   "str_split_approx_ft", false,
   [(str_split_approx_ft, "abc",["a";"b";"c"; "ab"; "bc"; "abc"])];
   "wordwrap_ft", true,
   [(wordwrap_ft 3 (Cfg.Terminal 'x') false, "abc d ef",["abcxdxef"]);   
    (wordwrap_ft 3 (Cfg.Terminal 'x') false, "a de ef",["axdexef"]);   
    (wordwrap_ft 4 (Cfg.Terminal 'x') false, "abc d e",["abcxd e"]);   
    (wordwrap_ft 4 (Cfg.Terminal 'x') false, "abc d ef",["abcxdxef"]);   
    (wordwrap_ft 4 (Cfg.Terminal 'x') false, "abc   d ef",["abc x dxef"]);   
    (wordwrap_ft 4 (Cfg.Terminal 'x') false, "abc\nde",["abc\nde"]);   
    (wordwrap_ft 4 (Cfg.Terminal 'x') false, "abc\nde fg",["abc\ndexfg"]);   
    (wordwrap_ft 4 (Cfg.Terminal 'x') false, "abc\n  de fg",["abc\n xdexfg"]);   
    (wordwrap_ft 4 (Cfg.Terminal 'x') true, "abcdef",["abcdxef"]);   
    (wordwrap_ft 4 (Cfg.Terminal 'x') true, "abc  abcdef",["abc xabcdxef"]);   
    (wordwrap_ft 4 (Cfg.Terminal 'x') true, "abc  abcdefghi",["abc xabcdxefghxi"]);   
    (wordwrap_ft 4 (Cfg.Terminal 'x') false, "abc  ab   cdef",["abc xab  xcdef"])];   
   "wordwrap_approx_ft", false,
   [(wordwrap_approx_ft (Cfg.Terminal 'x'), "abc d ef",["abc d ef"; "abcxd ef"; "abc dxef"; "abcxdxef"])];
   "wordwrap_strict_approx_ft", true, 
   [(wordwrap_strict_approx_ft (Cfg.Terminal 'x'), "abc", ["abc"; "axbc"; "axbxc"; "abxc"])];
   "soundex1_ft", false,
   [(soundex1_ft, "BCD", ["B23"])];
   "soundex2_ft", true,
   [(soundex2_ft, "B23", ["B230"]);
    (soundex2_ft, "", [""]);
    (soundex2_ft, "B", ["B000"])];
   "multiline_rtrim_ft", false,
   [(multiline_rtrim_ft, "abc", ["abc"]);
    (multiline_rtrim_ft, "abc  ", ["abc"]);
    (multiline_rtrim_ft, "abc  \n", ["abc\n"])];
   "remove_soft_linebreak_ft", false,
   [(remove_soft_linebreak_ft, "abc=\r\nde", ["abcde"]);
    (remove_soft_linebreak_ft, "abc =", ["abc "]);
    (remove_soft_linebreak_ft, "abc=\n\rde", ["abc\rde"])];
   "quoted_printable_decode_ft", false,
   [(quoted_printable_decode_ft, "=5b=5B=55", ["[[U"]);
    (quoted_printable_decode_ft, "=5 =5B =55", ["=5 [ U"])];
   "stripcslashes_ft", true,
   [(stripcslashes_ft, "\\x55\\100", ["U@"]);
    (stripcslashes_ft, "\\", ["\\"]);
    (stripcslashes_ft, "\\x", ["x"]);
    (stripcslashes_ft, "\\rab\ncd", ["\rab\ncd"])];
   "strtok_ft", false,
   [(strtok_ft [' '], "abc def  gh", ["abc"; "def"; "gh"; ""]);
    (strtok_ft ['x';'y'], "abcxdefxygh", ["abc"; "def"; "gh"; ""])];
   "first_char_ft", false,
   [(first_char_ft, "abc", ["a"]);
    (first_char_ft, "", [""])];
   "string_update_ft", false,
   [(string_update_ft (Cfg.Terminal 'x'), "abc", ["abc"; "xbc"; "axc"; "abx"])];
   "remove_attributes_ft", false,
   [(remove_attributes_ft, "<input  /><span style=\"font-weight:bold; font-size: 13px;\">", ["<input/><span>"])];
   "strict_remove_attributes_ft", false,  
   [(strict_remove_attributes_ft, 
    "<input  /><span style=\"font-weight:bold; font-size: 13px;\">", ["<input/><span>"])];
   "remove_nontag_ft", false,
   [(remove_nontag_ft, "<abc>abc</de>%%<fg/>**", ["<abc></de><fg/>"])];
   "extract_tags_ft", false,
   [(extract_tags_ft, "<abc></de><fg/>", ["abc"; "de"; "fg"])];
   "cut_ft", false,
   [(cut_ft "<!--" "-->", "01<!--234-->56<!--234\n-->", ["01<!---->56<!---->"])];
   "cut_comment_ft", false,
   [(cut_comment_ft "<!--" "-->", "01<!--234-->56<!--234\n-->", ["0156"])];
   "nl2br_ft", true,
   [(nl2br_ft, "ab\ncd", ["ab<br />\ncd"]);
    (nl2br_ft, "ab\rcd", ["ab<br />\rcd"]);
    (nl2br_ft, "ab\r\ncd", ["ab<br />\r\ncd"]);
    (nl2br_ft, "ab\n\rcd", ["ab<br />\n\rcd"]);
    (nl2br_ft, "ab\n\ncd", ["ab<br />\n<br />\ncd"])];
   "filter_element_ft", false,
   [(filter_element_ft "abc", "abc  xyz = 'aaa'",["xyz = 'aaa'"]);
    (filter_element_ft "abcc", "abc  xyz",[])];
   "extract_element_names_ft", false,
   [(extract_attribute_names_ft, "abc = 'xyz' xyz = \"aaa\"",["abc"; "xyz"])]
 ]

let tcs = List.fold_left (fun tcs (name, endmark, ts) -> 
  let t = name >:: fun _ -> List.iter (run_test endmark) ts in
  t :: tcs) tcs test_cases1 

let str2cfg str =
   let cs = explode str in
   let x = fresh_var () in
   Cfg.create_from_lists [x] [(x, [cs2ss cs])] x 

let test_cases2 = 
  ["quoted_printable_decode",
   [(quoted_printable_decode, "=5b=5B=55", ["[[U"]);
    (quoted_printable_decode, "=5 =5B =55", ["=5 [ U"]);
    (quoted_printable_decode, "=5 =5B =55=", ["=5 [ U"]);
    (quoted_printable_decode, "=5b=5B=55=\n=55", ["[[UU"]);
    (quoted_printable_decode, "=5b=5B=55=\r\n=55", ["[[UU"]);
    (quoted_printable_decode, "=5b=5B=55=\n\r=55", ["[[U\rU"])];
   "soundex",
   [(soundex, "BCD", ["B230"])];
   "substr_replace",
   [(substr_replace (Cfg.Terminal 'x') 2 None, "abcde", ["abx"]);
    (substr_replace (Cfg.Terminal 'x') 2 (Some 2), "abcde", ["abxe"])];
 ]

let check_cfg str strs cfg =
  let cfg = cfg_simplify cfg in
  let cfg = chain_elim cfg in
  let ss = words_of_cfg cfg in
  let ss' = List.map explode strs in
  assert_equal ~cmp:css_equal ~printer:string_of_css ~msg:str ss' ss 

let run_test  (f, str, strs) =
  let cfg = str2cfg str in
  let cfg' = f cfg in
  check_cfg str strs cfg'

let tcs = List.fold_left (fun tcs (name, ts) -> 
  let t = name >:: fun _ -> List.iter run_test ts in
  t :: tcs) tcs test_cases2

let test_cases3 = 
  ["preg_replace",
   [(preg_replace, "/ab/", "x",  "aababaab", ["axxax"]);
    (preg_replace, "/ab/", "x",  "ababaab",  ["xxax"]);
    (preg_replace, "/ab/", "x",  "ababaabb",  ["xxaxb"]);
    (preg_replace, "/(ab)+/", "x",  "ababab",  ["x"; "xx"; "xxx"]); 
    (preg_replace, "/(ab)+/U", "x",  "ababab",  ["xxx"]);
    (preg_replace, "/(ab*)(cdd)/", "\\1x\\2",  "acddyabbcdd", ["axcddyaxcdd"; "axcddyabbxcdd"; "abbxcddyaxcdd"; "abbxcddyabbxcdd"]); 
    (preg_replace, "/ab$/", "x",  "abab", ["abx"]);
    (preg_replace, "/^(ab)*$/", "x",  "abab", ["x"]);
    (preg_replace, "/(ab)*$/", "x",  "ccababab", ["ccx"]) ;
    (preg_replace, "/^ab/", "x", "abab", ["xab"]);
    (preg_replace, "/^(ab)*/", "x", "abab", ["xabab"; "xab"; "x"]);
    (preg_replace, "/^(ab)*/U", "x",  "abab", ["xabab"]);
    (preg_replace, "/^(ab)*$/m", "x",  "ab\nabab", ["x\nx"]);
    (preg_replace, "/ab/i", "x",  "ABabaaAbaB", ["xxaaxx"]);
    (preg_replace, "/<br \\/>/", "<br />",  "x", ["x"])]; 
   "ereg_replace ",
   [(ereg_replace true, "ab", "x",  "aabAbaab", ["axAbax"]); 
    (ereg_replace false, "ab", "x",  "aababaab", ["axxax"]); 
    (ereg_replace true, "(ab)+", "x",  "ababab",  ["x"; "xx"; "xxx"]); 
    (ereg_replace true, "[[:space:]]", "x", "abc  de fg",  ["abcxxdexfg"]); 
    (ereg_replace true, "[[:space:]]+", "x", "abc  de fg",  ["abcxdexfg"; "abcxxdexfg"]); 
    (ereg_replace false, "[ab]c", "x", "aBcd",  ["axd"]);
    (ereg_replace true, "(ab)*$", "x",  "ccababab", ["ccx"]) ; 
    (preg_replace, "/^a/", "x", "ab", ["xb"]);
    (ereg_replace true, "^a", "x",  "ab", ["xb"]) ;
    (ereg_replace true, "^(ab)*$", "x",  "abab", ["x"]); 
    (ereg_replace true, "^(ab)*", "x", "abab", ["xabab"; "xab"; "x"]); 
  ]; 
   ]

let run_test  (replace, pattern, replacement, str, strs) =
  let cfg = str2cfg str in
  let {Cfg.prod = p2; Cfg.start = x2} = str2cfg replacement in
  let cfg' = replace cfg (explode pattern) (x2,p2) in
  check_cfg str strs cfg'

let tcs = List.fold_left (fun tcs (name, ts) -> 
  let t = name >:: fun _ -> List.iter run_test ts in
  t :: tcs) tcs test_cases3

let test_cases4 = 
  ["preg_match",
   [(preg_match true, "/^[a-z][a-z]$/", "ab",  ["ab"]);
    (preg_match true, "/^[a-z][a-z]$/", "00",  []);
    (preg_match true, "/^[a-z]{3}$/", "abc",  ["abc"]);
    (preg_match true, "/^[a-z]{3}$/", "abcd",  []);
    (preg_match false, "/^[a-z][a-z]$/", "ab",  []);
    (preg_match false, "/^[a-z][a-z]$/", "00",  ["00"]);
    (preg_match false, "/^[a-z]{3}$/", "abc",  []);
    (preg_match false, "/^[a-z]{3}$/", "abcd",  ["abcd"]);
    (preg_match true, "/[a-z]{3}/", "abcd",  ["abcd"]);
    (preg_match false, "/[a-z]{3}/", "abcd",  []);
    (preg_match true, "/[A-Z]{3}/", "abcd",  []);
    (preg_match true, "/[A-Z]{3}/i", "abcd",  ["abcd"])];
   "preg_match_array",
   [(preg_match_array, "/[a-z][a-z]/", "abcd",  ["ab"; "bc"; "cd"]);
    (preg_match_array, "/^[a-z][a-z]/", "abcd",  ["ab"]);
    (preg_match_array, "/a/", "ABCD",  []);
    (preg_match_array, "/^[a-z][a-z]$/", "abcd",  []);
    (preg_match_array, "/([a-z])[a-z]/", "abcd",  ["a"; "b"; "c"; "ab"; "bc"; "cd"])];
   "preg_split",
   [(preg_split, "/[\\s,]+/", "abc  de,fg",  [""; "abc"; " de"; "de"; "fg"])]; 
   (* "" and " de" are included due to approximation *)
   "ereg",
   [(ereg true true, "^[a-z][a-z]$", "ab",  ["ab"]);
    (ereg true true, "^[a-z][a-z]$", "00",  []);
    (ereg true true, "^[a-z]{3}$", "abc",  ["abc"]);
    (ereg true true, "^[a-z]{3}$", "abcd",  []);
    (ereg true false, "^[a-z][a-z]$", "ab",  []);
    (ereg true false, "^[a-z][a-z]$", "00",  ["00"]);
    (ereg true false, "^[a-z]{3}$", "abc",  []);
    (ereg true false, "^[a-z]{3}$", "abcd",  ["abcd"]);
    (ereg true true, "[a-z][a-z]", "ab",  ["ab"]);
    (ereg true true, "[a-z][a-z]", "00",  []);
    (ereg true false, "[a-z][a-z]", "ab",  []);
    (ereg true false, "[a-z][a-z]", "00",  ["00"]);
    (ereg true true, "[A-Z][A-Z][A-Z]", "abcd",  ["abcd"])];
   "ereg_array", 
   [(ereg_array false, "[a-z][a-z]", "abcd",  ["ab"; "bc"; "cd"]);
    (ereg_array false, "a", "ABCD",  []);
    (ereg_array false, "([a-z])[a-z]", "abcd",  ["a"; "b"; "c"; "ab"; "bc"; "cd"]);
    (ereg_array true, "a", "ABCD",  ["A"]);
    (ereg_array true, "^[a-z][a-z]", "abcd",  ["ab"]);
    (ereg_array true, "^[a-z][a-z]$", "abcd",  []);];
   ]

let run_test  (regop, pattern, str, strs) =
  let cfg = str2cfg str in
  let cfg' = regop cfg (explode pattern) in
  check_cfg str strs cfg'

let tcs = List.fold_left (fun tcs (name, ts) -> 
  let t = name >:: fun _ -> List.iter run_test ts in
  t :: tcs) tcs test_cases4

let suite = "Fts" >::: tcs

let _ =
  run_test_tt_main suite
