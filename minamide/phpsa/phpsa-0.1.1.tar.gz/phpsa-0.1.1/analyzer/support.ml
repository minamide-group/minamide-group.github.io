(*
 * PHP string analyzer
 * Copyright (C) 2006 Yasuhiko Minamide
 *)

module StringSet =
  Set.Make(struct 
    type t = string
    let compare = compare
  end)

module StringMap =
  Map.Make(struct 
    type t = string
    let compare = compare
  end)

module StringStringMap =
  Map.Make(struct 
    type t = string * string
    let compare = compare
  end)

type var = {name:string; id:int; scope: bool}
     (* scope : true when the scope is global *)

module VarMap =
  Map.Make(struct 
    type t = var
    let compare = compare
  end)

module VarSet =
  Set.Make(struct 
    type t = var
    let compare = compare
  end)

let string_of_var {name=name; id=id; scope = scope } = 
  let s = if scope then "G" else "" in
  s^name^string_of_int id

let pp_var fmt {name=name; id=id; scope = scope } = 
  let s = if scope then "G" else "" in
  Format.fprintf fmt "%s%s%d" s name id
  

let current_id = ref 0;;
let fresh_id () =
  current_id := !current_id + 1;
  !current_id;;

(* let fvar name = {name=name; id= -1; scope = true}  *)
let rename_var var = { var with id=fresh_id ()}
let fresh_var () = {name="$$"; id =fresh_id (); scope = false }
let fresh_topvar () = {name="$$"; id =fresh_id (); scope = true }
let fresh_var_of scope name = {name=name; id=fresh_id (); scope = scope}

let fresh_fid name = fresh_var_of true name

let pp_charlist fmt cs  = Basic.print_list "" Format.pp_print_char fmt cs

let print_charlist cs =
  Format.printf "%s@." 
    (String.concat "" (List.map (String.make 1) cs))

let string_fold_right f s b =
 let rec g b i = if i >= 0 then g (f (String.get s i) b) (i - 1)
                            else b in
  g b (String.length s - 1)

let explode s = string_fold_right (fun x b -> x::b) s []

let implode cs =
  let n = List.length cs in
  let s = String.create n in
  let rec loop i cs = 
    match cs with
      [] -> () 
    | c::cs -> String.set s i c; loop (i+1) cs in
  loop 0 cs; s
 
let pp_seq f ff ss = Basic.print_list "," f ff ss

let option_map f x =
  match x with
    Some y -> Some (f y)
  | None -> None

