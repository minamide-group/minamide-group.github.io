(*
 * PHP string analyzer
 * Copyright (C) 2006 Yasuhiko Minamide
 *)
open Flbasics

let test_cases = 
  ["arrayinit.php", false, [""; "a"; "b"; "c"], None;
   "arrayinit2.php", false, [""; "a"; "b"; "c"], Some [""; "a"];
   "ref.php", false, ["abc"], None;
   "passing-ref.php", false, ["x"; "z"], None;
   "return-ref.php",false, ["a"; "b"], None;
   "return-ref2.php",false, ["bbb"], None;
   "return-ref3.php",false, ["a"; "b"; ""], None;
   "return-ref4.php",false, ["a"; "Object"], None;
   "pif.php", false, ["abc"; "xyz"], None;
   "switch.php", false, ["AB"; "B"; "DC"; "C"], None;
   "cond-function.php", false, ["abc"; "xyz"], None;
   "lift.php", false, ["xyz"], None;
   "incompatible-funcall.php", true, ["abc"], None;
   "string-concat-assignment.php", false, ["abczz"; "aaazz"], None;
   "class.php", false, ["aabb"; "bb"], None;
   "constructor.php", false, ["aa"; ""], None;
   "classmethod.php", false, ["bbbb"], None;
   "super.php", false, ["barfooabc"], None;
   "uninitialized.php", false, ["ab"], None;
   "nonarray.php", false, ["abc"], None;
   "ref-globals.php", false, ["yyy"], None;
   "null-globals.php", false, [""; "abc"], None;
   "ref-fun-globals.php", false, ["xxxyyy"], None;
   "lvarvar.php", false, [""; "abc"], Some ["abc"];
   "ref-global.php", false, ["abc"; "yyy"], None;
   "unset.php", false, ["abc-";], None;
(*   "call-user-func.php", false, ["foo";], None;
   "call-user-func2.php", false, [""; "foo";], None;
   "call-user-func-array.php", false, ["foo";"fooy"; 
				       "fooz"; "fooyy"; 
				       "fooyz"; "foozy";
				       "foozz"];
   "call-user-func-array2.php", false, [""; "foo";"fooy"; 
					"fooz"; "fooyy"; 
					"fooyz"; "foozy";
					"foozz"]; *)
   "varargs.php", false, [""; "abc"; "xyz"], None;
   "varargs2.php", false, [""; "abc"; "xyz"], None;
   "varfunc.php", false, ["foo"; "bar"], None;
   "array_change_key_case.php", false, ["2"; "abc"; "xyz"; "ABC"; "XYZ"], None;
   "get_class.php", false, [""; "abc"], None;
   "get_parent_class.php", false, [""; "a"; "b"; "stdclass"], None;
   "global.php", false, ["abc"], None;
   "globals-array.php", false, ["abc"], None;
   "instance-var.php", false, ["xxx"], None; 
   "methods.php", false, ["A"], None;
   "preg_match_all.php", false, [""; "abc"; "aac"], None;
   "preg_match_all2.php", false, [""; "ab"; "bc"; "cd"; "a"; "b"; "c"], None;
   "refthis.php", false, ["xxx"], None;
   "string-ref.php", false, [""; "a"; "b"; "c"], None;
   "varnew.php", false, ["xyz"], None;
   "reinclude.php", false, [""; "abc"], None;
   "stringconv.php", false, ["ARRAY"], None;
   "htmlentities.php", false, ["&quote;'&quote;&#039;\"'"], None;
   "lexermode.php", false, ["abc\n"], None;
   "quote.php", false, [""; "abc"], None;
   "wordwrap.php", false, ["abc x dxef"; "abc x dyef"; "abc y dxef"; "abc y dyef"], None;
   "wordwrap2.php", false, ["abc xabcdxef"], None;
   "str_replace.php", false, ["aaxxxaxxxc"], None;
   "str_replace2.php", false, [""; "xxx"; "aaxxxaxxxc"], None; 
   "str_replace3.php", false, ["foo"; "1"; "bar"], None; 
   "substr.php", false, [""; "a"; "b"; "c"; "d"; "e"], None;
   "subclass.php", false, ["bbarfoo"], None;
 ] 

let test1 fmt (srcfile, exit_analysis_mode, strs, ostrs) =  
  let strs =
    match (ostrs, !Options.symeval_mode && !Options.localsymeval_mode) with
      Some strs, true -> strs
    | _ -> strs in
  let () = Options.exit_analysis_mode := exit_analysis_mode in
  let () = Format.printf "Testing %s@." srcfile in
  let cfg = Analyze.analyze [srcfile] in
  let ss = words_of_cfg cfg in
  let ss' = List.map Support.explode strs in
  let condition = List.sort compare ss = List.sort compare ss' in
  if condition then Format.fprintf fmt "%s: OK@." srcfile
  else (Format.fprintf fmt "%s: FAIL@.%a@." srcfile
	  (Basic.print_list "\n" 
	     (Basic.print_list "" Format.pp_print_char)) ss)

let test2 fmt (srcfile, reg_str) =  
  let () = Format.printf "Testing %s@." srcfile in
  let cfg = Analyze.analyze [srcfile] in
  let fa_prog = Fa.minimize (Cfg2fa.cfg2fa Charset.charset cfg) in
  let r =  Pregparser.parse_reg reg_str in
  let nfa_spec = Reg2fa.reg2nfa Charset.charset r in
  let fa_spec = Fa.minimize nfa_spec in 
  let condition = Fa.dfa_equal fa_prog fa_spec in
  if condition then Format.fprintf fmt "%s: OK@." srcfile
  else (Format.fprintf fmt "%s: FAIL@.%s@." srcfile reg_str)

let test_cases2 =
  ["for.php", "/(ab)*/";
   "for2.php", "/(abx*)*/";
   "for3.php", "/(ab|x)*/";
   "while.php", "/(ab)*/";
   "dowhile.php", "/(ab)+/";
   "foreach.php", "/((a|b)(xx|yy|))*/";
   "function.php", "/(abc)*/";
   "string-update.php", "/abc|xbc|axc|abx|abc *x/";
  ]

let test_cases3 = 
  ["approx.php", ["01"; "x0y1z"; "xx0yy1zz"]; ]

let test3 fmt (srcfile, ss) =  
  let () = Format.printf "Testing %s@." srcfile in
  let cfg = Analyze.analyze [srcfile] in
  let check1 s =
    let fa = Flbasics.string_fa s in
    not (Fa_cfg.is_disjoint fa cfg) in
  let condition = List.for_all check1 ss in
  if condition then Format.fprintf fmt "%s: OK@." srcfile
  else (Format.fprintf fmt "%s: FAIL@." srcfile)

let test () = 
  let () = Sys.chdir Options.test_dir in
  let buf = Buffer.create 1000 in
  let fmt = Format.formatter_of_buffer buf in
  Format.printf "Tests@.";
  List.iter (test1 fmt) test_cases ;
  List.iter (test2 fmt) test_cases2;
  List.iter (test3 fmt) test_cases3;
  let () = Format.fprintf fmt "@.Tests with localsymeval and symeval@." in  
  Options.symeval_mode := true;
  Options.localsymeval_mode := true;
  List.iter (test1 fmt) test_cases ;
  Buffer.output_buffer stdout buf 




