open Il
open Support
open Ilmisc
open Dominator

let exec lfun_env z env s = 

  let extend x e env = 
    match e with
      Var y -> (x,y)::env
    | _ -> (x,z)::env in

  let rec extend_list xs vs env = 
    match xs, vs with
      [], [] -> env
    | x::xs, v::vs -> extend_list xs vs (extend x v env)
    | _ -> failwith "extend_list" in

  let rec exec_block env s =
    match s with 
    | If (e, _, b1, _, b2) -> 
	exec_block (exec_block env b1) b2
    | Switch (e, x, cs) ->
	let exec_case env (g, y, b) = exec_block env b in
	List.fold_left exec_case env cs
    | LocalCall (x, es) -> 
	let ys = Hashtbl.find lfun_env x in
	extend_list ys es env
    | Seq (LocalFun (x, xs, b1), b2) -> 
	exec_block (exec_block env b1) b2
    | Seq (s,b) -> exec_block env b
    |  _ -> env in
  exec_block env s

let fill_htbl htbl size x =
  if Hashtbl.mem htbl x then size
  else 
    let () = Hashtbl.add htbl x size in size+1

let mk_graph z env =
  let fmap = Hashtbl.create 1000 in 
  let size = fill_htbl fmap 0 z in
  let size = List.fold_left 
      (fun size (x, y) -> 
	let size = fill_htbl fmap size x in
	fill_htbl fmap size y) size env in
  let garray = Array.make size (fresh_var ()) in
  let () = Hashtbl.iter (fun x i -> garray.(i) <- x) fmap in
  let graph = Array.make size [] in
  let graph' = Array.make size [] in
  List.iter 
    (fun (x, y) -> 
      let yi = Hashtbl.find fmap y in
      let xi = Hashtbl.find fmap x in
      add_edge yi xi graph;
      add_edge xi yi graph')
    env;
  graph, graph', fmap, garray

let print_nodeset s = List.iter (fun x -> print_int x) s

let print_dominatormap g = Array.iteri 
    (fun x s -> print_int x; print_nodeset s ;print_string "\n") g

let rec pdrop lfun_env s =
  let z = fresh_var () in
  let env = exec lfun_env z [] s in 
  let graph, graph', fmap, garray = mk_graph z env in
  let () = Array.iteri (fun x y ->
    match y with
      [] -> if x <> 0 then  (add_edge 0 x graph; add_edge x 0 graph')
    | _ -> ()) graph' in

  let domtree = Dominator.dominators' graph graph' in

  let rec find_index i =
    let j = domtree.(i) in
    if j = 0 then i else find_index j in

  let rec find_index i =
    let j = domtree.(i) in
    if j = 0 then i else 
    let j = find_index j in
    domtree.(i) <- j; j in

  let find x =
    let i = Hashtbl.find fmap x in
    let j = find_index i in
    if i = j then None else Some (garray.(j))in 

  let drop_var x =
    try 
      match find x with
	Some y -> y
      | None -> x 
    with _ -> x in

  let rec drop_exp e =
    match e with 
      Var x -> Var (drop_var x)
    | Dref (x,y) -> Dref (drop_var x, y)
    | Prim (p, es, i) -> Prim (p, drop_exp_list es, i)
    | App (s, es, x) -> App (s, drop_exp_list es, x)
    | Int _ | Float _ | String _ | Bool _ | Const _ 
    | Null | Vspec _  | ConstExp _ -> e
  and drop_exp_list es =
    List.map drop_exp es in

  let rec drop_lv lv =
    match lv with 
      LVar x -> LVar (drop_var x)
    | LArray1 lv -> LArray1 (drop_var lv)
    | LArray2 (lv, e) -> LArray2 (drop_var lv, drop_exp e)
    | LObjRef (lv, m) -> LObjRef (drop_var lv, m) in

  let rec drop_stmt s =
    match s with 
(*    | Function (x, xs, b, ys, r) -> 
	Function (x, xs, pdrop lfun_env b, ys, r)
    | Class (s, xs, ms) -> 
	Class (s, xs, List.map (fun (s, xs, this, b, ys, r) -> 
	  (s, xs, this, pdrop lfun_env b, ys, r)) ms) *)
    | LocalFun (x, xs, b) -> 
	let xs = 
	  List.filter 
	    (fun x -> 
	      try
		(match find x with
		  None -> true 
		| Some _ -> false)
	      with Not_found -> true) xs in
	LocalFun (x, xs, drop_block b)
    | FunCall (xs, s, es, r, bs) ->
      FunCall (xs, s, drop_exp_list es, r, bs)
    | ClassMethodCall (xs, cname, mname, es, r, bs) ->
      ClassMethodCall (xs, cname, mname, drop_exp_list es, r, bs)
    | MethodCall (xs, e, mname, es, r, bs) ->
      MethodCall (xs, drop_var e, mname, drop_exp_list es, r, bs)
    | Assign (x, e) -> Assign (drop_var x, drop_exp e)
    | Define (x, e) -> Define (x, drop_exp e)
    | ExpSt e -> ExpSt (drop_exp e)
    | DrefAssign (x, e) -> 
	DrefAssign (drop_var x, drop_exp e)
    | RefAssign (lv1, lv2) -> RefAssign (drop_lv lv1, drop_lv lv2)
    | Echo e -> Echo (drop_exp e)
    | Assert (e, x, s) -> Assert (drop_exp e, x, s)
    | Unset _ -> failwith "Unset"
  and drop_block s =
    match s with 
    | If (e, x1,s1,x2,s2) -> 
	If (drop_exp e, x1, drop_block s1, x2, drop_block s2)
    | Switch (e, x, cs) ->
	let drop_case (g, y, b) = (g, y, drop_block b) in
	Switch (drop_exp e, x, List.map drop_case cs)
    | LocalCall (x, xs) -> 
	let xs = drop_exp_list xs in
	let ys = Hashtbl.find lfun_env x in
	let yxs = List.combine ys xs in
	let yxs = List.filter 
	    (fun (y,x) -> match find y with
	      None -> true 
	    | Some _ -> false) yxs in
	LocalCall (x, List.map snd yxs)
    | Seq (s,b) -> Seq (drop_stmt s, drop_block b) 
    | Stop (i,optx) -> 
	Stop (i, match optx with
	  None -> None
	| Some x -> Some (drop_var x))
    | Return es -> Return (drop_exp_list es) in 
  drop_block  s

let pdrop s =
  let lfun_env = Ilmisc.fenv_of s in
  pdrop lfun_env s

let pdrop program =
  let function_f (x, xs, b, ys, r) = (x, xs, pdrop b, ys, r) in
  let class_f (s, xs, ms)  =
    (s, xs, List.map (fun (s, xs, this, b, ys, r) -> (s, xs, this, pdrop b, ys, r)) ms) in
  map_program pdrop function_f class_f program

