(*
 * PHP string analyzer
 * Copyright (C) 2006 Yasuhiko Minamide
 *)
open Abssyn
open Support

let ndir dir =
  let cwd = Sys.getcwd () in
  let () = Sys.chdir dir in
  let dir = Sys.getcwd () in
  let () = Sys.chdir cwd in
  dir

let nfilename filename =
  let dir = Filename.dirname filename in
  let dir = ndir dir in
  let basename = Filename.basename filename in
  Filename.concat dir basename

let level = ref 0 

let rec exec_include include_env filename topfiles dirname stmt =
  let rec eval files exp =
    let exp_desc = exp.exp_desc in
    let exp_desc, files =
      match exp_desc with
	Lvalue lv -> 
	  let lv, files = eval_lv files lv in
	  Lvalue lv, files
      | Null -> Null, files
      | Const "__FILE__" -> String filename, files
      | Const x -> Const x, files
      | Int i -> (Int i, files) 
      | Float i -> (Float i, files)
      | Bool b -> (Bool b, files)
      | String s -> (String s, files)
      | NewArray ees -> 
	  let rec eval_array_init files ees =
	    match ees with
	      [] -> ([], files)
	    | (e1, e2)::ees ->
		let (e1, files) = eval files e1 in
		let (e2, files) = eval files e2 in
		let (ees, files) = eval_array_init files ees in
		((e1,e2)::ees, files) in
	  let ees, files = eval_array_init files ees in
	  (NewArray ees, files) 
      | RefAssign (lv1, Lv lv2) -> (RefAssign (lv1,Lv lv2), files)
      | RefAssign (lv, Exp exp) -> 
	  let exp, files = eval files exp in 
	  (RefAssign (lv,Exp exp), files)
      | ListAssign (lvs, exp) -> 
	  let exp, files = eval files exp in
	  (ListAssign (lvs, exp), files)
      | LAssign (lv, exp) -> 
	  let exp, files = eval files exp in
	  LAssign (lv, exp), files
      | LOpAssign (lv, p, exp) -> 
	  let exp, files = eval files exp in
	  LOpAssign (lv, p, exp), files
      | Prim (Concat, [e1; e2]) -> 
	  let e1, files = eval files e1 in
	  let e2, files = eval files e2 in
	  (match (e1.exp_desc, e2.exp_desc) with
	    (String s1, String s2) -> (String (s1^s2), files)
	  | _ -> (Prim (Concat, [e1; e2]), files))
      | Prim (p, es) -> 
	  let es, files = eval_list files es in
	  (Prim (p, es), files)
      | ClassMethod (cname, mname, es) -> 
	  let es, files = eval_list files es in
	  (ClassMethod (cname, mname, es), files)
      | Method (e, mname, es) -> 
	  let e, files = eval files e in
	  let es, files = eval_list files es in
	  (Method (e, mname, es), files)
      | NewObj (classname, es) -> 
	  let es, files = eval_list files es in
	  (NewObj (classname, es), files)
      | UClassMethod (cname, e, es) -> 
	  let e, files = eval files e in
	  let es, files = eval_list files es in
	  (UClassMethod (cname, e, es), files)
      | UMethod (e1, e2, es) -> 
	  let e1, files = eval files e1 in
	  let e2, files = eval files e2 in
	  let es, files = eval_list files es in
	  (UMethod (e1, e2, es), files)
      | UNewObj (e, es) -> 
	  let e, files = eval files e in
	  let es, files = eval_list files es in
	  (UNewObj (e, es), files)
      | App ("dirname",[e]) -> 
	  let e, files = eval files e in
	  (match e.exp_desc with
	    String s -> (String (Filename.dirname s), files)
	  | _ -> (App ("dirname",[e]), files))
      | App (s,es) -> 
	  let es, files = eval_list files es in
	  (App (s,es), files)
      | AppVar (e, es) -> 
	  let e, files = eval files e in
	  let es, files = eval_list files es in
	  (AppVar (e, es), files)
      | FileBlock (filename, dirname, ss) -> 
	  let files = StringSet.add filename files in
	  let ss, files = exec_include include_env filename files dirname ss in
	  (FileBlock (filename, dirname, ss), files)
      | Define (s, exp) -> 
	  let exp, files = eval files exp in
	  (Define (s, exp), files)
      | StmtExp (ss, e) -> 
	  let ss, files = exec_include include_env filename files dirname ss in
	  let e, files = eval files e in
	  (StmtExp (ss, e), files)
      | IncludeExp (once, exp, expanded_files, sss) -> 
	  let try_include fatal f filename =
	    try 
	      f filename
	    with Sys_error _ -> 
	      let rec loop ds =
		match ds with
		  d::ds ->
		    (try 
		      f (Filename.concat d filename);
		    with Sys_error _ -> loop ds)
		| [] ->
		    if Filename.is_relative filename 
		    then 
		      let filename' = Filename.concat dirname filename in
		      if fatal then
			try 
			  f filename'
			with Sys_error _ -> failwith ("File not found: "^filename)
		      else 
			f filename'  
		    else raise (Sys_error "") in
	      loop (!Options.include_path) in
	  
	  let include_file filename = 
	    let raw_include_file filename =
	      let () =
		Options.show 1 (fun fmt ->
		  Format.printf "%sIncluding \"%s\".@?" 
		    (String.make (!level) ' ') filename) in
	      let ss = Parse.parse_php filename in
	      Format.printf "@."; 
	      ss ,filename in
	    let ss, filename = raw_include_file filename in
	    let () = incr level in
	    let files = StringSet.add (nfilename filename) files in
	    let dirname = Filename.dirname filename in
	    let ss, files = exec_include include_env filename files dirname ss in
	    decr level;
	    ss, filename, dirname, files in
	  let exp, files = eval files exp in
	  let sss = 
	    List.map (fun (s, ss) ->
	      let ss, files = exec_list files ss in
	      (s, ss)) sss in

	  let aloc = aloc_of_exp exp in

	  (match exp.exp_desc with
	    String s -> 
	      let () =
		Options.show 0 (fun fmt ->
		  Format.printf "%sIncluding \"%s\".@?" 
		    (String.make (!level) ' ') s) in
	      try_include true (fun filename ->
		if once && StringSet.mem (nfilename filename) files then Int 1, files
		else
		  let ss, filename, dirname, files = include_file filename in
		  FileBlock (filename, dirname, ss), files)
		s
	  | _ -> 
	      let () = Format.printf "Non-static include in %s: " filename in
	      let () = Format.printf "%a@." pp_exp exp in
	      let info = (fun fmt -> Format.fprintf fmt "include %a at %a" pp_exp exp Loc.pp_loc exp.exp_loc) in
	      let ss,_ =
		try Hashtbl.find include_env aloc.id
		with Not_found -> 
		  (Hashtbl.add include_env aloc.id
		     (Support.StringSet.empty, info);
		   Support.StringSet.empty, info) in
	      let () = StringSet.iter (fun x -> Format.printf "%s@." x) ss in
	      let sss = Support.StringSet.fold 
		  (fun s sss ->
		    if once && StringSet.mem s files then sss
		    else
		      try 
			let ss, filename,dirname,_ = try_include false include_file s in
			let () =
			  Options.show 0 (fun fmt ->
			    Format.printf "%sIncluding \"%s\".@?" 
			      (String.make (!level) ' ') filename) in
			(s, ss)::sss
		      with Sys_error _ -> Format.printf "FAILED@."; sss)
		  (Support.StringSet.diff ss expanded_files) sss in
	      let expanded_files =
		List.fold_left (fun files (s,_) -> Support.StringSet.add s files)
		  expanded_files sss in
	      IncludeExp (once, exp, expanded_files, sss), files) in
    { exp with exp_desc = exp_desc }, files 
	    
  and eval_list files es =
    let es,  files = 
      List.fold_left 
	(fun (es, files) e -> 
	  let e, files = eval files e in (e::es, files))
	([], files) es in
    (List.rev es, files) 

  and eval_lv files lv =
    let lv_desc, files =
      match lv.lvalue_desc with
	LVar x -> (LVar x, files)
      | LVarVar e -> 
	  let e, files  = eval files e in
	  LVarVar e, files
      | LArray1 lv -> 
	  let lv, files = eval_lv files lv in
	  LArray1 lv, files
      | LArray2 (lv, e) -> 
	  let lv, files = eval_lv files lv in
	  let e, files  = eval files e in
	  LArray2 (lv, e), files 
      | LObjRef (lv, s) -> 
	  let lv, files = eval_lv files lv in
	  LObjRef (lv, s), files
      | LUObjRef (lv, e) -> 
	  let lv, files = eval_lv files lv in
	  let e, files  = eval files e in
	  LUObjRef (lv, e), files
      | LStringRef (lv, e) -> 
	  let lv, files = eval_lv files lv in
	  let e, files  = eval files e in
	  LStringRef (lv, e), files in
    { lv with lvalue_desc = lv_desc }, files 

  and exec files stmt =
    let stmt_desc = stmt.stmt_desc in
    let stmt_desc, files = 
      match stmt_desc with
	BlockSt ss -> 
	  let ss, files = exec_list files ss in BlockSt ss, files
      | While (e, s) -> 
	  let _, files = eval files e in
	  let s, _ = exec files s in
	  While (e, s), files
      | DoWhile (s, e) -> 
	  let s, _ = exec files s in
	  let _, files = eval files e in
	  DoWhile (s, e), files
      | For (e1, e2, e3, s) -> 
	  let e1, files = eval_list files e1 in
	  let e2, files = eval_list files e2 in
	  let e3, _ = eval_list files e3 in
	  let s, _ =  exec files s in
	  For (e1, e2, e3, s), files
      | Foreach (e, optx, y, s) -> 
	  let e, files  = eval files e in
	  let s, _ = exec files s in
	  Foreach (e, optx, y, s), files
      | If (e, s1, s2) -> 
	  let e, files  = eval files e in
	  let s1, files1 = exec files s1 in
	  let s2, files2 = exec files s2 in
	  If (e, s1, s2), StringSet.inter files1 files2
      | Function (f, xs, s, b) -> 
	  let s,_ = exec topfiles s in
	  Function (f, xs, s, b), files
      | Switch (e, css) -> 
	  let e, files = eval files e in
	  let css = exec_clist files css in
	  Switch (e, css), files
      | ExpSt e -> 
	  let e, files = eval files e in
	  ExpSt e, files
      | Echo e -> 
	  let e, files = eval files e in
	  Echo e, files
      | Unset lv -> 
	  let lv, files = eval_lv files lv in
	  Unset lv, files
      | Skip -> Skip, files
      | Global _ -> stmt_desc, files
      | Static _ -> stmt_desc, files
      | Continue _| Break _ | Return _ | Assert (_, _) -> stmt_desc, files
      | Class (cname, parent, xs, ms) -> 
	  let exec_method (f, xs, s, r) = 
	    let s, _ = exec topfiles s in
	    (f, xs, s, r) in
	  Class (cname, parent, xs, List.map exec_method ms), files in
    { stmt with stmt_desc = stmt_desc }, files 

  and exec_list files stmts =
    match stmts with
      [] -> [], files
    | s::ss -> 
	let s, files = exec files s in
	let ss, files = exec_list files ss in
	s :: ss, files
	  
  and exec_clist files css =
    match css with
      [] -> []
    | (c,ss)::css -> 
	let ss, _ = exec_list files ss in
	let css = exec_clist files css in
	(c, ss) :: css in
  exec_list topfiles stmt

let expand include_env filename ss = 
  let dirname = Sys.getcwd () in
  let files = StringSet.singleton (nfilename filename) in
  let ss, files = exec_include include_env filename files dirname ss in ss
