type phptype =
    IntTy | BoolTy | FloatTy | StringTy | ArrayTy | ObjectTy | ResourceTy

let string_of_phptype t =
  match t with
    IntTy -> "int"
  | BoolTy -> "bool"
  | FloatTy -> "float" 
  | StringTy -> "string"
  | ArrayTy -> "array"
  | ObjectTy -> "object"
  | ResourceTy -> "resource"

let pp_phptype ff t = Format.pp_print_string ff (string_of_phptype t)
