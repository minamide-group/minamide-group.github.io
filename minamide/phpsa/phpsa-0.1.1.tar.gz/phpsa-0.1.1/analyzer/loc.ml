(*
let current_aloc = ref 0
let fresh_aloc () =
  current_aloc := !current_aloc + 1;
  !current_aloc;;

type aloc = int
*)
type aloc = Support.var
let fresh_aloc () = Support.fresh_var ()
 
type loc = 
    { aloc : aloc;
      cloc : Lexing.position }

let mkloc () =
    { aloc = fresh_aloc ();
      cloc = Parsing.symbol_start_pos ()}

let dummy_loc () =
    { aloc = fresh_aloc ();
      cloc = Lexing.dummy_pos}

let pp_loc fmt loc = 
  let pos = loc.cloc in
  Format.fprintf fmt "%s, line %d" 
    pos.Lexing.pos_fname  pos.Lexing.pos_lnum

let simple_loc loc =  
  let pos = loc.cloc in
  (Filename.basename pos.Lexing.pos_fname, 
   pos.Lexing.pos_lnum) 

