(*
 * PHP string analyzer
 * Copyright (C) 2006 Yasuhiko Minamide
 *)
open Support
open Il
 
type node = 
    MainNode 
  | FunctionNode of var
  | MethodNode of classname * methodname

let pp_node fmt n =
  match n with
    FunctionNode s -> Format.fprintf fmt "%a" pp_var s
  | MethodNode (cname, mname) -> Format.fprintf fmt "%s::%a" cname pp_var mname
  | _ -> Format.fprintf fmt "top" 

module NodeMap =
  Map.Make(struct 
    type t = node
    let compare = compare
  end)

module NodeSet =
  Set.Make(struct 
    type t = node
    let compare = compare
  end)


let empty_env =
  (NodeSet.empty, NodeMap.empty, NodeMap.empty) 

let next n env =
  try NodeMap.find n env with Not_found -> []

let extend n1 n2 (ns, g1, g2) = 
  (NodeSet.add n1 (NodeSet.add n2 ns),
   NodeMap.add n1 (n2::next n1 g1) g1,
   NodeMap.add n2 (n1::next n2 g2) g2)

let rec exec alias_env node env b = 
  let rec exec_stmt env s =
    match s with 
    | LocalFun (x, xs, b) -> exec_block env b
    | FunCall (xs, s, es, r, bs) -> extend node (FunctionNode s) env
    | ClassMethodCall (xs, cname, mname, es, r, bs) ->
	extend node (MethodNode (cname, mname)) env
    | MethodCall (xs, x, mname, es, r, bs) ->
	let ys = Alias.lookup_var alias_env (Alias.Vvar x) in
	Alias.Vset.fold
	  (fun w env ->
	    match w with
	      Alias.Vobject cname -> extend node (MethodNode (cname.name, mname)) env
	    | _ -> env) ys env
    | _ -> env
  and exec_block env s =
    match s with 
    | If (e, _,b1, _,b2) -> 
	exec_block (exec_block env b1) b2
    | Seq (s,b) -> exec_block (exec_stmt env s) b
    | _ -> env in
  exec_block env b


let exec alias_env program = 
  let function_f env (x, xs, b, ys, r) =
    exec alias_env (FunctionNode x) env b in
  let class_f env (cname, xs, ms) =
    List.fold_left (fun env (s,xs,this,b,ys,r) ->
      exec alias_env (MethodNode (cname.name, s)) env b) env ms in
  let main_f env b = exec alias_env MainNode env b in
  fold_program main_f function_f class_f program empty_env

open Absgraph
module NodeGraph =
  Make(struct 
    type t = node
    type g = NodeSet.t * node list NodeMap.t * node list NodeMap.t
    module NodeSet = NodeSet
    let nexts ((ns, g1, g2):g) (x:t) = 
      try NodeMap.find x g1 with Not_found -> []
    let nexts_r (ns, g1, g2) x =
      try NodeMap.find x g2 with Not_found -> []
    let nodes_of (ns, g1, g2) = ns
  end)


let nonrecursive_nodes_of alias_env b =
  let env = exec alias_env b in
  let _,g,_ = env in
  let scc =  NodeGraph.sc env in
  let ns = List.fold_left (fun ns sc ->
    if NodeSet.cardinal sc = 1 then
      NodeSet.add (NodeSet.choose sc) ns
    else ns) NodeSet.empty scc in
  NodeSet.filter (fun n -> not (List.mem n (next n g))) ns 

let find_fun x env =
  try 
    StringMap.find x env
  with Not_found -> []

let add_fun x d env =
  StringMap.add x (d::find_fun x env) env

let rec fenv_of program =
  let function_f env (x, xs, b, ys, r) = add_fun x.name (xs, b, ys, r) env in
  let class_f env (cname, xs, ms) =
    List.fold_left 
      (fun env (x, xs, this, b, ys, r) ->
	add_fun (cname.name^"::"^x.name) ((this,None,false)::xs, b, ys, r) env) env ms in
  let main_f env b = env in
  fold_program main_f function_f class_f program StringMap.empty


let rename vmap x =
    let x' = rename_var x in
    x', VarMap.add x x' vmap

let rename_vars vmap xs =
  List.fold_right 
    (fun x (xs', vmap) -> 
      let x', vmap  = rename vmap x in
      x'::xs', vmap) xs ([], vmap) 

let rename_fps vmap xs =
  List.fold_right 
    (fun (x,c,b) (xs', vmap) -> 
      let x', vmap  = rename vmap x in
      (x',c,b)::xs', vmap) xs ([], vmap) 

let rec c2e c = 
  match c with
    ConstInt i -> Int i, (fun b -> b)
  | ConstBool b -> Bool b, (fun b -> b) 
  | ConstFloat f -> Float f, (fun b -> b)
  | ConstString s -> String s, (fun b -> b)
  | ConstArray (ccs,_,_,_) ->
      let x = fresh_var () in
      let k = ccs2k x ccs in
      Var x, (fun b -> Seq (Assign (x, mknewarray ()), k b))
  | ConstConst x -> Const x, (fun b -> b)
  | ConstBox (c, var) -> 
      let e, k = c2e c in
      let y = fresh_var () in
      Var y, (fun b -> Seq (Assign (y, mkprim' (NewRef, [])),
			    Seq (DrefAssign (y, e),
				 k b)))
and ccs2k x ccs = 
  List.fold_right (fun (c1, c2) k ->
    let e1, k1 = c2e c1 in
    let e2, k2 = c2e c2 in
    let y = fresh_var () in
    fun b -> k1 (k2 (Seq (RefAssign (LVar y, mklarray2 (x, e1)),
			  Seq (Assign (y, e2), b))))) ccs (fun b -> b)

let eval_var vmap x =
  try VarMap.find x vmap with Not_found -> x

let rec eval vmap e =
  match e with 
    Var x -> Var (eval_var vmap x)
  | Dref (x,y) -> Dref (eval_var vmap x, fresh_var ())
  | Prim (NewArrayL _, es, i) -> failwith "inline: NewArrayL"
  | Prim (p, es, i) -> remkprim (p, eval_list vmap es, i)
  | App (s, es, i) -> remkapp (s, eval_list vmap es, i)
  | e -> e
and eval_list vmap es =
  List.map (eval vmap) es 
and eval_lv vmap lv =
  match lv with 
    LVar x -> LVar (eval_var vmap x)
  | LArray1 lv -> LArray1 (eval_var vmap lv)
  | LArray2 (lv, e) -> LArray2 (eval_var vmap lv, eval vmap e) 
  | LObjRef (lv, m) -> LObjRef (eval_var vmap lv, m)

let exec alias_env b = 
  let ns = nonrecursive_nodes_of alias_env b in
  let () = 
    Options.show 2 (fun fmt -> 
      Format.printf "Non-recursive nodes@.";
      NodeSet.iter (fun n -> Format.printf "%a@." pp_node n) ns) in
  let fenv = fenv_of b in

  let rec exec k vmap s =
    match s with 
    | LocalFun (x, xs, b) -> failwith "LocalFun"
    | DrefAssign (x, e) -> 
	DrefAssign (eval_var vmap x, eval vmap e)
    | RefAssign (lv1, lv2)  -> 
	let lv1 = eval_lv vmap lv1 in
	let lv2 = eval_lv vmap lv2 in
	RefAssign (lv1, lv2)
    | Assign (x, e) -> failwith "impossible inline"
    | ExpSt e -> ExpSt (eval vmap e)
    | FunCall (xs, s, es, b, bs) -> failwith "impossible inline"
    | ClassMethodCall (xs, cname, mname, es, r, bs) -> 
	failwith "impossible inline"
    | MethodCall (xs, e, mname, es, r, bs) -> failwith "impossible inline"
    | Define (x,e) -> Define (x, eval vmap e)
    | Echo e -> failwith "Echo"
    | Assert (e, x, s) -> Assert(eval vmap e, x, s)
    | Unset _ -> failwith "Unset"
  and exec_block k vmap s =
    match s with 
    | If (e, x1, s1, x2, s2) -> 
	If (eval vmap e, x1, exec_block k vmap s1, 
	    x2, exec_block k vmap s2)
    | Switch (e, x, cs) ->
	let exec_case (g, y, b) = (g, y, exec_block k vmap b) in
	Switch (eval vmap e, x, List.map exec_case cs) 
    | LocalCall (x, es) -> LocalCall (eval_var vmap x, eval_list vmap es)
    | Seq (LocalFun (x, xs, b0), b) ->
	let x, vmap = rename vmap x in
	let xs, vmap' = rename_vars vmap xs in
	Seq (LocalFun (x, xs, exec_block k vmap' b0), 
	     exec_block k vmap b)
    | Seq (Assign (x, e), b) ->
	let e = eval vmap e in
	let x, vmap = rename vmap x in
	Seq (Assign (x, e), exec_block k vmap b)
    | Seq (RefAssign (LVar x, lv), b) ->
	let lv = eval_lv vmap lv in
	let x, vmap = rename vmap x in
	Seq (RefAssign (LVar x, lv), exec_block k vmap b)
    | Seq (FunCall (xs, s, es, r, rs), b) ->
	let es = eval_list vmap es in
	let xs, vmap = rename_vars vmap xs in
	if NodeSet.mem (FunctionNode s) ns then
	match StringMap.find s.name fenv with
	  [(xs', b', zs', false)] -> 
	    Options.show 2 (fun fmt -> Format.printf "%s@." s.name);
	    expand k vmap (xs, es, r, rs) b (xs', b', zs')
	| _  -> Seq(FunCall (xs, s, es, r, rs), exec_block k vmap b)
	else
	  Seq (FunCall (xs, s, es, r, rs), exec_block k vmap b) 

    | Seq (ClassMethodCall (xs, cname, mname, es, r, rs), b) ->
	let es = eval_list vmap es in
	let xs, vmap = rename_vars vmap xs in
	if NodeSet.mem (MethodNode (cname, mname)) ns then
	  match StringMap.find (cname^"::"^mname.name) fenv with
	    [(xs', b', zs', false)] -> 
	      Options.show 2 (fun fmt -> Format.printf "%s::%s@." cname mname.name);
	      expand k vmap (xs, Null::es, r, rs) b (xs', b', zs')
	  | _  -> 
	      Seq (ClassMethodCall (xs, cname, mname, es, r, rs), 
		   exec_block k vmap b)
	else
	  Seq (ClassMethodCall (xs, cname, mname, es, r, rs), 
	       exec_block k vmap b)
    | Seq (MethodCall (xs, e, mname, es, r, rs), b) ->
	let ys = Alias.lookup_var alias_env (Alias.Vvar e) in
	let e = eval_var vmap e in
	let es = eval_list vmap es in
	let xs, vmap = rename_vars vmap xs in
	let cnames = 
	  Alias.Vset.fold (fun w cnames ->
	    match w with
	      Alias.Vobject cname -> cname::cnames
	    | _ -> cnames) ys [] in
	(match cnames with
	  [cname] when NodeSet.mem (MethodNode (cname.name, mname)) ns ->
	    (match StringMap.find (cname.name^"::"^mname.name) fenv with
	      [(xs', b', zs', false)] -> 
		Options.show 2 (fun fmt -> Format.printf "%a::%s@." pp_var cname mname.name);
		expand k vmap (xs, (Var e)::es, r, rs) b (xs', b', zs')  
	    | _ ->
		Seq (MethodCall (xs, e, mname, es, r, rs),
		     exec_block k vmap b))
	| _ -> 
	    Seq (MethodCall (xs, e, mname, es, r, rs),
		 exec_block k vmap b))
    | Seq (s,b) -> Seq (exec k vmap s, exec_block k vmap b) 
    | Stop (i, optx) -> 
	Stop (i, match optx with
	  None -> None
	| Some x -> Some (eval_var vmap x))
    | Return es -> k (eval_list vmap es) 
  and expand k vmap (xs, es, r, rs) b (xs', b', zs') =
    let f = fresh_var () in
    let rec process_args xs es k vmap' =
      match (xs, es) with
      | ([], _) -> k, vmap'
      |	((x, Some c,false)::xs, []) -> 
	  let x, vmap' = rename vmap' x in
	  let e, k' = c2e c in 
	  process_args xs [] 
	    (fun b -> k (k' (Seq (Assign (x, e), b)))) vmap'
      | (_, []) -> 
	  Format.printf "Inline: too few arguments@.";
	  k, vmap'
      |	((x,copt,false)::xs, e::es) -> 
	  let x, vmap' = rename vmap' x in
	  process_args xs es 
	    (fun b -> k (Seq (Assign (x, e), b))) vmap'
      |	((x,copt,true)::xs, (Var y)::es) -> 
	  let x, vmap' = rename vmap' x in
	  process_args xs es 
	    (fun b -> k (Seq (RefAssign (LVar x, LVar y), b))) vmap' 
      |	((x,copt,true)::xs, _::es) -> failwith "inline"  in
    let k', vmap' = process_args xs' es (fun b -> b) VarMap.empty in
    Seq (LocalFun (f, xs, exec_block k vmap b),
	 k' (exec_block (fun es -> LocalCall (f, es)) vmap' b'))  in

  let function_f (x, xs, b, zs, r) =
	let xs, vmap = rename_fps VarMap.empty xs in
	(x, xs, exec_block (fun es -> Return es) vmap b, zs, r) in
  let class_f (s, xs, ms) =
    let exec_method (x, xs, this, b, zs, r) =
      let this, vmap = rename VarMap.empty this in
      let xs, vmap = rename_fps vmap xs in
      (x, xs, this, exec_block (fun es -> Return es) vmap b, zs, r) in
    (s, xs, List.map exec_method ms) in
  let main_f b = exec_block (fun es -> Return es)  VarMap.empty b in
  map_program main_f function_f class_f b
  

