open Support
open Il

type node = 
    MainNode 
  | FunctionNode of var
  | MethodNode of classname * methodname

let pp_node fmt n =
  match n with
    FunctionNode s -> Format.fprintf fmt "%a" pp_var s
  | MethodNode (cname, mname) -> Format.fprintf fmt "%s::%a" cname pp_var mname
  | _ -> Format.fprintf fmt "top" 

module NodeMap =
  Map.Make(struct 
    type t = node
    let compare = compare
  end)

module NodeSet =
  Set.Make(struct 
    type t = node
    let compare = compare
  end)


let next n env =
  try NodeMap.find n env with Not_found -> []

let extend n1 n2 env = NodeMap.add n1 (n2::next n1 env) env

let rec exec alias_env node env b = 
  let rec exec_stmt env s =
    match s with 
(*    | Function (x, xs, b, ys, r) -> 
	let env = extend (FunctionNode x.name) node env in
	exec alias_env (FunctionNode x.name) env b
    | Class (cname, xs, ms) -> 
	List.fold_left (fun env (s,xs,this,b,ys,r) ->
	  let env = extend (MethodNode (cname, s)) node env in
	  exec alias_env (MethodNode (cname, s)) env b) env ms *)
    | LocalFun (x, xs, b) -> exec_block env b
    | FunCall (xs, s, es, r, bs) -> extend node (FunctionNode s) env
    | ClassMethodCall (xs, cname, mname, es, r, bs) ->
	extend node (MethodNode (cname, mname)) env
    | MethodCall (xs, x, mname, es, r, bs) ->
	let ys = Alias.lookup_var alias_env (Alias.Vvar x) in
	Alias.Vset.fold
	  (fun w env ->
	    match w with
	      Alias.Vobject cname -> extend node (MethodNode (cname.name, mname)) env
	    | _ -> env) ys env
    | _ -> env
  and exec_block env s =
    match s with 
    | If (e, _,b1, _,b2) -> 
	exec_block (exec_block env b1) b2
    | Switch (e, _, cs) ->
	let exec_case env (g, y, b) = exec_block env b in
	List.fold_left exec_case env cs
    | Seq (s,b) -> exec_block (exec_stmt env s) b
    | _ -> env in
  exec_block env b

let exec alias_env program =
  let function_f env (x, xs, b, ys, r) =
    exec alias_env (FunctionNode x) env b in
  let class_f env (cname, xs, ms) =
    List.fold_left (fun env (s,xs,this,b,ys,r) ->
      exec alias_env (MethodNode (cname.name, s)) env b) env ms in
  let main_f env b = exec alias_env MainNode env b in
  fold_program main_f function_f class_f program NodeMap.empty 

let livenodes_of alias_env b =
  let env = exec alias_env b in
  let () = 
    Options.show 1 (fun fmt ->
      NodeMap.iter (fun n ns ->
	Format.fprintf fmt "%a -> %a@." pp_node n (Basic.print_list "," pp_node) ns) env) in
  let rec dfs xs rs =
    match xs with
      [] -> rs
    | x::xs ->  if NodeSet.mem x rs then dfs xs rs
    else  dfs (next x env@xs) (NodeSet.add x rs) in
  let ns = dfs [MainNode] NodeSet.empty in
  ns

let deadelim alias_env program = 
  let ns = livenodes_of alias_env program in

  let () =
    Options.show 1 (fun fmt -> NodeSet.iter (fun n -> Format.fprintf fmt "%a@." pp_node n) ns) in

  let program =
    let function_f (x, xs, b, ys, r) = NodeSet.mem (FunctionNode x) ns in
    let class_f (cname, xs, ms) = true in
    filter_program function_f class_f program in


  let function_f (x, xs, b, ys, r) = (x, xs, b, ys, r) in
  let class_f (cname, xs, ms) =
    (cname, xs, 
     List.fold_right (fun (s,xs,this,b,ys,r) ms ->
       if NodeSet.mem (MethodNode (cname.name, s)) ns
       then (s,xs,this, b,ys,r)::ms else ms) ms []) in
  let main_f b = b in
  map_program main_f function_f class_f program

