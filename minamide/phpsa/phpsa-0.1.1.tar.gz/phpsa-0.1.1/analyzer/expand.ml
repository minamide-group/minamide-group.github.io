(*
 * PHP string analyzer
 * Copyright (C) 2006 Yasuhiko Minamide
 *)
open Abssyn
open Support

let classenv_of ss =
  let class_tbl = Hashtbl.create 49 in
  let rec classenv_of_exp exp =
    match exp.exp_desc with 
      Lvalue lv -> classenv_of_lv lv
    | Null | Int _ | Float _ | String _ | Bool _ | Const _ -> ()
    | NewObj (_, es) -> classenv_of_exp_list es
    | UNewObj (e, es) -> classenv_of_exp e; classenv_of_exp_list es 
    | NewArray ees -> classenv_of_expexp_list ees
    | Prim (p, es) -> classenv_of_exp_list es
    | App (s, es) -> classenv_of_exp_list es
    | AppVar (e, es) -> classenv_of_exp e; classenv_of_exp_list es 
    | ClassMethod (cname, mname, es) -> classenv_of_exp_list es
    | UClassMethod (cname, e, es) -> classenv_of_exp e; classenv_of_exp_list es 
    | Method (e, mname, es) -> classenv_of_exp e; classenv_of_exp_list es
    | UMethod (e1, e2, es) -> 
	classenv_of_exp e1; classenv_of_exp e2;	classenv_of_exp_list es 
    | LAssign (lv, e) -> classenv_of_lv lv; classenv_of_exp e
    | LOpAssign (lv, p, e) -> classenv_of_lv lv; classenv_of_exp e
    | ListAssign (lvs, e) ->
	List.iter
	  (fun olv -> 
	    match olv with
	      None -> ()
	    | Some lv -> classenv_of_lv lv) lvs;
	classenv_of_exp e
    | RefAssign (lv, Exp e) -> classenv_of_lv lv; classenv_of_exp e
    | RefAssign (lv1, Lv lv2) -> classenv_of_lv lv1; classenv_of_lv lv2
    | FileBlock (_, _, ss) -> classenv_of_list ss 
    | IncludeExp (once, exp, expanded_files, sss) -> 
	List.iter (fun (_, ss) -> classenv_of_list ss) sss 
    | StmtExp (ss, exp) -> classenv_of_list ss
    | Define (_, e) -> classenv_of_exp e
  and classenv_of_exp_list es = List.iter classenv_of_exp es 
  and classenv_of_expexp_list ees =
    List.iter (fun (e1,e2) -> classenv_of_exp e1; classenv_of_exp e2) ees
  and classenv_of_lv lv =
    match lv.lvalue_desc with
      LVar x -> ()
    | LVarVar e -> classenv_of_exp e
    | LArray1 lv -> classenv_of_lv lv
    | LArray2 (lv, e) -> 
	  (match lv.lvalue_desc, e.exp_desc with
	  | LVar "$GLOBALS" , String s -> ()
	  | _ -> classenv_of_lv lv; classenv_of_exp e)
    | LObjRef (lv, s) -> classenv_of_lv lv 
    | LUObjRef (lv, e) -> classenv_of_lv lv; classenv_of_exp e
    | LStringRef (lv, e) -> 
	classenv_of_lv lv; classenv_of_exp e 
  and classenv_of stmt =
    match stmt.stmt_desc with
      ExpSt e | Echo e | Return e | Assert (e, _) -> classenv_of_exp e
    | Unset lv -> ()
    | Break _ | Continue _ | Skip | Global _ | Static _ -> ()
    | BlockSt ss -> classenv_of_list ss
    | While (e,s) -> 
	classenv_of_exp e; classenv_of s
    | DoWhile (s, e) -> classenv_of_exp e; classenv_of s
    | Foreach (e,optx,y,s) -> 
	classenv_of_exp e; classenv_of s
    | For (e1, e2, e3, s) -> 
	classenv_of_exp_list e1;
	classenv_of_exp_list e2;
	classenv_of_exp_list e3;
	classenv_of s
    | If (e, s1, s2) ->
	classenv_of_exp e;
	classenv_of s1;
	classenv_of s2
    | Switch (e, css) ->
	classenv_of_exp e;
	List.iter (fun (e,ss) -> classenv_of_list ss) css
    | Function (s, xs, stmt, _) -> classenv_of stmt
    | Class (s,parent,xs,ms) -> 
	Hashtbl.add class_tbl s (parent,xs,ms);
	List.iter (fun (mname, xs, stmt, r) -> classenv_of stmt) ms 
  and classenv_of_list ss = List.iter classenv_of ss in
  classenv_of_list ss;
  class_tbl

let expand classenv stmt = 
  let find p = 
    try 
      match Hashtbl.find_all classenv p with
	[c] -> c
      | _ -> failwith ("more than one definitions of the parent class: "^p) 
    with Not_found -> failwith ("no class definition of the parent class: "^p) in

  let rec expand_exp exp =
    let exp_desc = exp.exp_desc in
    let exp_desc =
      match exp_desc with
	Lvalue lv -> Lvalue (expand_lv lv)
      | Null | Const _  | Int _ | Float _ | Bool _  | String _ -> exp_desc
      | NewArray ees -> 
	  NewArray (List.map (fun (e1,e2) -> (expand_exp e1, expand_exp e2)) ees)
      | RefAssign (x, Lv lv) -> RefAssign (x, Lv lv)
      | RefAssign (x, Exp exp) -> RefAssign (x, Exp (expand_exp exp))
      | ListAssign (xs, exp) -> ListAssign (xs, expand_exp exp)
      | LAssign (lv, exp) -> LAssign (lv, expand_exp exp)
      | LOpAssign (lv, p, exp) -> LOpAssign (lv, p, expand_exp exp)
      | Prim (p, es) -> 
	  Prim (p, expand_exp_list es)
      | ClassMethod (cname, mname, es) -> 
	  ClassMethod (cname, mname, expand_exp_list es)
      | Method (e, mname, es) -> 
	  Method (expand_exp e, mname, expand_exp_list es)
      | NewObj (classname, es) -> 
	  NewObj (classname, expand_exp_list es)
      | UClassMethod (cname, e, es) -> 
	  UClassMethod (cname, expand_exp e, expand_exp_list es)
      | UMethod (e1, e2, es) -> 
	  UMethod (e1, expand_exp e2, expand_exp_list es)
      | UNewObj (e, es) -> 
	  UNewObj (expand_exp e, expand_exp_list es)
      | App (s,es) -> App (s, expand_exp_list es)
      | AppVar (e,es) -> 
	  AppVar (expand_exp e, expand_exp_list  es) 
      | FileBlock (fname, dirname, ss) -> FileBlock (fname, dirname, List.map expand ss)
      | IncludeExp (once, exp, expanded_files, sss) -> 
	  IncludeExp (once, expand_exp exp, expanded_files, 
		      List.map (fun (str, ss) -> (str, List.map expand ss)) sss) 
      | StmtExp (ss, exp) -> StmtExp (List.map expand ss, exp) 
      | Define (s, exp) -> Define (s, expand_exp exp) in
    { exp with exp_desc = exp_desc } 
  and expand_exp_list es = List.map expand_exp es

  and expand_lv lv =
    let lv_desc =
      match lv.lvalue_desc with
	LVar x -> LVar x
      | LVarVar e -> LVarVar (expand_exp e)
      | LArray1 lv -> LArray1 (expand_lv lv)
      | LArray2 (lv, e) -> LArray2 (expand_lv lv, expand_exp e) 
      | LObjRef (lv, s) -> LObjRef (expand_lv lv, s)
      | LUObjRef (lv, e) -> LUObjRef (expand_lv lv, expand_exp e)
      | LStringRef (lv, e) -> LStringRef (expand_lv lv, expand_exp e) in
    { lv with lvalue_desc = lv_desc }

  and expand stmt =
    let stmt_desc = stmt.stmt_desc in
    let stmt_desc = 
      match stmt_desc with
	ExpSt e -> ExpSt (expand_exp e)
      | Echo e -> Echo (expand_exp e)
      | Return e -> Return (expand_exp e)
      | Assert (e, s) -> Assert (expand_exp e, s)
      | Unset lv  -> Unset (expand_lv lv) 
      | Break _ | Continue _ | Skip | Global _ | Static _ ->  stmt_desc
      | BlockSt ss -> BlockSt (List.map expand ss)
      | While (e,s) -> While (expand_exp e,expand s)
      | DoWhile (s, e) -> DoWhile (expand s, expand_exp e)
      | Foreach (e,optx,y,s) -> Foreach (expand_exp e,optx,y, expand s)
      | For (e1, e2, e3, s) -> 
	  For (expand_exp_list e1, expand_exp_list e2, expand_exp_list e3, expand s)
      | If (e, s1, s2) -> If (expand_exp e, expand s1, expand s2)
      | Switch (e, css) ->
	  let css = List.map (fun (e,ss) -> 
	    let e = 
	      match e with
		Some e -> Some (expand_exp e)
	      | None -> None in
	    (e, List.map expand ss)) css in
	  Switch (e, css)
      | Function (s, xs, stmt, b) -> Function (s, xs, expand stmt, b)
	    (* assume that class definition is not nested *)
      | Class (cname,None,xs,ms) -> 
	  let ms = List.map (fun (s,xs,stmt,r) -> (s,xs,expand stmt,r)) ms in
	  let ms = 
	    if List.exists (fun (s,xs,ss,r) -> cname = s) ms then ms 
	    else (cname, [], mkstmt Skip, false)::ms in
	  Class (cname,None,xs, ms) 
      | Class (cname,optp,xs,ms) -> 
	  let () =  Options.show 1 
	      (fun fmt -> Format.fprintf fmt "expanding %s@." cname) in
	  let merge_var x ys = if List.mem x ys then ys else x::ys in
	  let merge_method ((mname,xs,s,_) as m) ms = 
	    if List.exists (fun (mname',_,_,_) -> mname = mname') ms then ms else m::ms in
	  let rec expand_methods optp xs ms = 
	    match optp with
	      Some p ->
		let (optp', xs', ms') = find p in
		let xs = List.fold_right merge_var xs' xs in
		let ms = List.fold_right merge_method ms' ms in
		expand_methods optp' xs ms 
	    | None -> (xs, ms) in
	  let rec find_constructor optp = 
	    match optp with
	      Some p -> 
		let (optp, _, ms) = find p in
		(try Some (List.find (fun (mname, _, _, _) -> p = mname) ms)
		with Not_found -> find_constructor optp) 
	    | None -> None in
	  let xs, ms = expand_methods optp xs ms in
	  let ms = List.map (fun (s,xs,stmt,r) -> (s,xs,expand stmt,r)) ms in
	  let ms = 
	    if List.exists (fun (s,_,_,_) -> cname = s) ms then ms 
	    else 
	      match find_constructor optp with
	      | Some (_,xs,s, r) -> (cname, xs, s, r)::ms
	      | None -> (cname, [], mkstmt Skip, false)::ms in
	  Class (cname,None,xs, ms)  in
    { stmt with stmt_desc = stmt_desc } in
  expand stmt

let expand ss =
  let classenv = classenv_of ss in
  List.map (expand classenv) ss 






