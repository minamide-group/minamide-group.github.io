open Support
open Flbasics
open Fts

let test_cases1 = 
  [
   (trim_ft sp, false, "  aaa bbb ", ["aaa bbb"]);
   (ltrim_ft sp, false, "  aaa bbb  ", ["aaa bbb  "]);
   (rtrim_ft sp, false, "  aaa bbb  ", ["  aaa bbb"]);
   (ucfirst_ft, false, "abc", ["Abc"]);
   (ucfirst_ft, false, "Abc", ["Abc"]);
   (ucword_ft, false, "abc xyz", ["Abc Xyz"]);
   (ucword_ft, false, "Abc Xyz", ["Abc Xyz"]);
   (string_ft (explode "ab") [Cfg.Terminal 'x'], false, "aababaab",  ["axxax"]);
   (string_ft (explode "ab") [Cfg.Terminal 'x'], false, "ababaab",  ["xxax"]);
   (string_ft (explode "ab") [Cfg.Terminal 'x'], false, "ababaabb",  ["xxaxb"]);
   (strstr_ft false ['@'], false, "user@example.com", ["@example.com"]);
   (strstr_ft false ['A'; 'b'], false, "xAaBc", ["aBc"]);
   (explode_ft1 [':'; ':'], false, "a::b::ccc",["a::b::ccc"; "b::ccc"; "ccc"]);
   (explode_ft1 [':'; ':'], false, "a::b::",["a::b::"; "b::"; ""]);
   (explode_ft1 [':'; ':'], false, "::b::ccc",["::b::ccc"; "b::ccc"; "ccc"]);
   (explode_ft1 [':'; ':'], false, "a::b:::ccc",["a::b:::ccc"; "b:::ccc"; ":ccc"]);
   (explode_ft2 [':'; ':'], false, "aa::",["aa"]);
   (explode_ft2 [':'; ':'], false, "aa::b",["aa"]);
   (explode_ft2 [':'; ':'], false, "aa:::b",["aa"]);
   (explode_ft2 [':'; ':'], false, "aaa",["aaa"]);
   (explode_ft2 [':'; ':'], false, "aaa:",["aaa:"]);
   (explode_ft2 [':'; ':'], false, ":aaa",[":aaa"]);
   (explode_ft2 [':'; ':'], false, "::aaa",[""]);
   (strings_ft [("abc", "A"); ("abde", "BB")], false, "abcaabdef", ["AaBBf"]);
   (strings_ft_endmark [("abc", "A"); ("abde", "BB")], true, "abcaabdef", ["AaBBf"]);
   (append_cut_ft (Some 3) (skip_ft (Some 2)), false, "abcdefg", ["cde"]);
   (append_cut_ft (Some 3) (skip_ft None), false, "abcde", ["abc"; "bcd"; "cde"; "de"; "e"; ""]);
   (append_cut_ft None (skip_ft (Some 2)), false, "abcdefg", [""; "c"; "cd"; "cde"; "cdef"; "cdefg"]);
   (append_id_ft (skip_ft (Some 2)), false, "abcdefg", ["cdefg"]);
   (append_id_ft (skip_ft None), false, "abcde", ["abcde"; "bcde"; "cde"; "de"; "e"; ""]); 
   (prefix_ft, false, "012", [""; "0"; "01"; "012"]);
   (strip_tags_ft, false, "<<aa>>>>",[">>>"; ">>"; ">"; ""]);
   (strip_tags_ft, false, "<aa><bb>>",[">"; ""]);
   (pad_ft '0' 4, true, "",["0000"]);
   (pad_ft '0' 4, true, "1",["1000"]);
   (pad_ft '0' 4, true, "1111",["1111"]);
   (pad_ft '0' 4, true, "123456",["123456"]);
   (base64encode_ft, true, "abc", ["YWJj"]);
   (base64encode_ft, true, "abcd", ["YWJjZA=="]);
   (base64encode_ft, true, "abcde", ["YWJjZGU="]);
   (base64dencode_ft, false, "YWJj", ["abc"]);
   (base64dencode_ft, false, "YWJjZA==", ["abcd"]);
   (base64dencode_ft, false, "YWJjZGU=", ["abcde"]);
   (rawurldecode_ft, false, "%3F%2A%28%29", ["?*()"]);
   (urldecode_ft, false, "%3F%2A%28%29+%29", ["?*() )"]);
   (str_pad_ft ['a'; 'b'] 4, true, "",["abab"]);
   (str_pad_ft ['a'; 'b'] 4, true, "1",["1aba"]);
   (str_pad_ft ['a'; 'b'] 4, true, "1111", ["1111"]);
   (str_pad_ft ['a'; 'b'] 4, true, "123456",["123456"]);
   (chunk_split_ft 2 ['x'], false, "abcdef",["abxcdxefx"]);
   (nth_mark_ft 0 'x', true, "abc",["xabc"^String.make 1 Fts.mark_char]);
   (nth_mark_ft 2 'x', true, "abc",["abxc"^String.make 1 Fts.mark_char]);
   (str_split_ft 1, false, "abc",["a";"b";"c"]);
   (str_split_ft 2, false, "abc",["ab";"c"]);
   (str_split_ft 2, false, "abcd",["ab";"cd"]);
   (str_split_approx_ft, false, "abc",["a";"b";"c"; "ab"; "bc"; "abc"]);
   (wordwrap_ft 3 (Cfg.Terminal 'x') false, true, "abc d ef",["abcxdxef"]);   
   (wordwrap_ft 3 (Cfg.Terminal 'x') false, true, "a de ef",["axdexef"]);   
   (wordwrap_ft 4 (Cfg.Terminal 'x') false, true, "abc d e",["abcxd e"]);   
   (wordwrap_ft 4 (Cfg.Terminal 'x') false, true, "abc d ef",["abcxdxef"]);   
   (wordwrap_ft 4 (Cfg.Terminal 'x') false, true, "abc   d ef",["abc x dxef"]);   
   (wordwrap_ft 4 (Cfg.Terminal 'x') false, true, "abc\nde",["abc\nde"]);   
   (wordwrap_ft 4 (Cfg.Terminal 'x') false, true, "abc\nde fg",["abc\ndexfg"]);   
   (wordwrap_ft 4 (Cfg.Terminal 'x') false, true, "abc\n  de fg",["abc\n xdexfg"]);   
   (wordwrap_ft 4 (Cfg.Terminal 'x') true, true, "abcdef",["abcdxef"]);   
   (wordwrap_ft 4 (Cfg.Terminal 'x') true, true, "abc  abcdef",["abc xabcdxef"]);   
   (wordwrap_ft 4 (Cfg.Terminal 'x') true, true, "abc  abcdefghi",["abc xabcdxefghxi"]);   
   (wordwrap_ft 4 (Cfg.Terminal 'x') false, true, "abc  ab   cdef",["abc xab  xcdef"]);   
   (wordwrap_approx_ft (Cfg.Terminal 'x'), false, "abc d ef",["abc d ef"; "abcxd ef"; "abc dxef"; "abcxdxef"]);
   (wordwrap_strict_approx_ft (Cfg.Terminal 'x'), true, "abc", ["abc"; "axbc"; "axbxc"; "abxc"]);
   (soundex1_ft, false, "BCD", ["B23"]);
   (soundex2_ft, true, "B23", ["B230"]);
   (soundex2_ft, true, "", [""]);
   (soundex2_ft, true, "B", ["B000"]);
   (multiline_rtrim_ft, false, "abc", ["abc"]);
   (multiline_rtrim_ft, false, "abc  ", ["abc"]);
   (multiline_rtrim_ft, false, "abc  \n", ["abc\n"]);
   (remove_soft_linebreak_ft, false, "abc=\r\nde", ["abcde"]);
   (remove_soft_linebreak_ft, false, "abc =", ["abc "]);
   (remove_soft_linebreak_ft, false, "abc=\n\rde", ["abc\rde"]);
   (quoted_printable_decode_ft, false, "=5b=5B=55", ["[[U"]);
   (quoted_printable_decode_ft, false, "=5 =5B =55", ["=5 [ U"]);
   (stripcslashes_ft, true, "\\x55\\100", ["U@"]);
   (stripcslashes_ft, true, "\\", ["\\"]);
   (stripcslashes_ft, true, "\\x", ["x"]);
   (stripcslashes_ft, true, "\\rab\ncd", ["\rab\ncd"]);
   (strtok_ft [' '], false, "abc def  gh", ["abc"; "def"; "gh"; ""]);
   (strtok_ft ['x';'y'], false, "abcxdefxygh", ["abc"; "def"; "gh"; ""]);
   (first_char_ft, false, "abc", ["a"]);
   (first_char_ft, false, "", [""]);
   (string_update_ft (Cfg.Terminal 'x'), false, "abc", ["abc"; "xbc"; "axc"; "abx"]);
   (remove_attributes_ft, false, "<input  /><span style=\"font-weight:bold; font-size: 13px;\">", ["<input/><span>"]);
   (strict_remove_attributes_ft, false, 
    "<input  /><span style=\"font-weight:bold; font-size: 13px;\">", ["<input/><span>"]);
   (remove_nontag_ft, false, "<abc>abc</de>%%<fg/>**", ["<abc></de><fg/>"]);
   (extract_tags_ft, false, "<abc></de><fg/>", ["abc"; "de"; "fg"]);
   (cut_ft "<!--" "-->", false, "01<!--234-->56<!--234\n-->", ["01<!---->56<!---->"]);
   (cut_comment_ft "<!--" "-->", false, "01<!--234-->56<!--234\n-->", ["0156"]);
 ]

let run_tests name f ts =
  let run_test x =
    let condition, z, y = f x in
    if condition then Format.printf "OK@." 
    else (Format.printf "FAIL @."; 
	  Format.printf "%s@." z;
	  List.iter print_charlist y) in
  Format.printf "%s:@." name; 
  List.iter run_test ts

let () = 
  let test (fa, endmark, str, strs) =
    let str = if entmark then str^Strig.make 1 Fts.mark_char else str in
    let cs = explode str in
    let sss = Ft.output fa cs in
    let css = List.map (List.map (function Cfg.Terminal x -> x | _ -> failwith "ss2cs")) sss in
    let css' = List.map explode strs in
    let condition = List.sort compare css = List.sort compare css' in
    condition, str, css in
  run_tests "Transducers" test test_cases1

let str2cfg str =
   let cs = explode str in
   let x = fresh_var () in
   Cfg.create_from_lists [x] [(x, [cs2ss cs])] x 

let test_cases2 = 
  [(quoted_printable_decode, "=5b=5B=55", ["[[U"]);
   (quoted_printable_decode, "=5 =5B =55", ["=5 [ U"]);
   (quoted_printable_decode, "=5 =5B =55=", ["=5 [ U"]);
   (quoted_printable_decode, "=5b=5B=55=\n=55", ["[[UU"]);
   (quoted_printable_decode, "=5b=5B=55=\r\n=55", ["[[UU"]);
   (quoted_printable_decode, "=5b=5B=55=\n\r=55", ["[[U\rU"]);
   (soundex, "BCD", ["B230"]);
   (substr_replace (Cfg.Terminal 'x') 2 None, "abcde", ["abx"]);
   (substr_replace (Cfg.Terminal 'x') 2 (Some 2), "abcde", ["abxe"]);
 ]

let check_cfg str strs cfg =
  let cfg = cfg_simplify cfg in
  let cfg = chain_elim cfg in
  let ss = words_of_cfg cfg in
  let ss' = List.map explode strs in
  let condition = List.sort compare ss = List.sort compare ss' in
  condition, str, ss

let () =
  let test (f, str, strs) =
    let cfg = str2cfg str in
    let cfg' = f cfg in
    check_cfg str strs cfg' in
  run_tests "Cfg-Cfg functions" test test_cases2

let test_cases3 = 
  [(preg_replace, "/ab/", "x",  "aababaab", ["axxax"]);
   (preg_replace, "/ab/", "x",  "ababaab",  ["xxax"]);
   (preg_replace, "/ab/", "x",  "ababaabb",  ["xxaxb"]);
   (preg_replace, "/(ab)+/", "x",  "ababab",  ["x"; "xx"; "xxx"]); 
   (preg_replace, "/(ab)+/U", "x",  "ababab",  ["xxx"]);
   (preg_replace, "/(ab*)(cdd)/", "\\1x\\2",  "acddyabbcdd", ["axcddyaxcdd"; "axcddyabbxcdd"; "abbxcddyaxcdd"; "abbxcddyabbxcdd"]); 
   (preg_replace, "/ab$/", "x",  "abab", ["abx"]);
   (preg_replace, "/^(ab)*$/", "x",  "abab", ["x"]);
   (preg_replace, "/(ab)*$/", "x",  "ccababab", ["ccx"]) ;
   (preg_replace, "/^(ab)*/", "x", "abab", ["xabab"; "xab"; "x"]);
   (preg_replace, "/^(ab)*/U", "x",  "abab", ["xabab"]);
   (preg_replace, "/^(ab)*$/m", "x",  "ab\nabab", ["x\nx"]);
   (preg_replace, "/ab/i", "x",  "ABabaaAbaB", ["xxaaxx"]);
   (preg_replace, "/<br \\/>/", "<br />",  "x", ["x"]);
   (ereg_replace true, "ab", "x",  "aabAbaab", ["axAbax"]); 
   (ereg_replace false, "ab", "x",  "aababaab", ["axxax"]); 
   (ereg_replace true, "(ab)+", "x",  "ababab",  ["x"; "xx"; "xxx"]); 
   (ereg_replace true, "[[:space:]]", "x", "abc  de fg",  ["abcxxdexfg"]); 
   (ereg_replace true, "[[:space:]]+", "x", "abc  de fg",  ["abcxdexfg"; "abcxxdexfg"]); 
   (ereg_replace false, "[ab]c", "x", "aBcd",  ["axd"]); 
   ]

let () =
  let test (replace, pattern, replacement, str, strs) =
    let cfg = str2cfg str in
    let {Cfg.prod = p2; Cfg.start = x2} = str2cfg replacement in
    let cfg' = replace cfg (explode pattern) (x2,p2) in
    check_cfg str strs cfg' in
  run_tests "replacement by a regular expression" test test_cases3


let test_cases4 = 
  [(preg_match true, "/^[a-z][a-z]$/", "ab",  ["ab"]);
   (preg_match true, "/^[a-z][a-z]$/", "00",  []);
   (preg_match true, "/^[a-z]{3}$/", "abc",  ["abc"]);
   (preg_match true, "/^[a-z]{3}$/", "abcd",  []);
   (preg_match false, "/^[a-z][a-z]$/", "ab",  []);
   (preg_match false, "/^[a-z][a-z]$/", "00",  ["00"]);
   (preg_match false, "/^[a-z]{3}$/", "abc",  []);
   (preg_match false, "/^[a-z]{3}$/", "abcd",  ["abcd"]);
   (preg_match true, "/[a-z]{3}/", "abcd",  ["abcd"]);
   (preg_match false, "/[a-z]{3}/", "abcd",  []);
   (preg_match true, "/[A-Z]{3}/", "abcd",  []);
   (preg_match true, "/[A-Z]{3}/i", "abcd",  ["abcd"]);
   (preg_match_array, "/[a-z][a-z]/", "abcd",  ["ab"; "bc"; "cd"]);
   (preg_match_array, "/^[a-z][a-z]/", "abcd",  ["ab"]);
   (preg_match_array, "/a/", "ABCD",  []);
   (preg_match_array, "/^[a-z][a-z]$/", "abcd",  []);
   (preg_match_array, "/([a-z])[a-z]/", "abcd",  ["a"; "b"; "c"; "ab"; "bc"; "cd"]);
   (preg_split, "/[\\s,]+/", "abc  de,fg",  [""; "abc"; " de"; "de"; "fg"]); 
   (* "" and " de" are included due to approximation *)
   (ereg true true, "[a-z][a-z]", "ab",  ["ab"]);
   (ereg true true, "[a-z][a-z]", "00",  []);
   (ereg true false, "[a-z][a-z]", "ab",  []);
   (ereg true false, "[a-z][a-z]", "00",  ["00"]);
   (ereg true true, "[A-Z][A-Z][A-Z]", "abcd",  ["abcd"]);
   (ereg_array false, "[a-z][a-z]", "abcd",  ["ab"; "bc"; "cd"]);
   (ereg_array false, "a", "ABCD",  []);
   (ereg_array false, "([a-z])[a-z]", "abcd",  ["a"; "b"; "c"; "ab"; "bc"; "cd"]);
   (ereg_array true, "a", "ABCD",  ["A"]);
   ]

let () =
  let test (regop, pattern, str, strs) =
    let cfg = str2cfg str in
    let cfg' = regop cfg (explode pattern) in
    check_cfg str strs cfg' in
  run_tests "regop" test test_cases4

