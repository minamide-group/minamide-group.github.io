(*
 * PHP string analyzer
 * Copyright (C) 2006 Yasuhiko Minamide
 *)
open Ilextract
open Flbasics
open Phpprim
 
let size_of_prod prod =
  Cfg.Prod.fold (fun _ _ s -> s+1) prod 0 

let reachable_prod prod xs  =
  let xs = Support.VarSet.fold (fun x ys -> Cfg.Variable_set.add x.Support.id ys) xs Cfg.Variable_set.empty in
  Cfg.prod_reachable prod xs

module Rename = Cfg.Prod

let rename_rhss env rhss =
  rhs_map (fun rhs ->
    List.map (fun sym ->
      match sym with
	Cfg.Variable x -> Cfg.Variable (Rename.find x env)
      | sym -> sym) rhs) rhss 

let rename_extract x p =
  let xs = Cfg.prod_reachableVar p (Cfg.Variable_set.singleton x) in 
  let env = Cfg.Variable_set.fold (fun x env -> Rename.add x (fresh_var ()) env) xs Rename.empty in
  (Rename.find x env,
   Cfg.Prod.fold (fun k rhss p' ->
     if Cfg.Variable_set.mem k xs then
       Cfg.Prod.add (Rename.find k env) (rename_rhss env rhss) p'
     else p') p Cfg.Prod.empty )

let extract' s prod =
  let rec dfs (newprod, vs) x =
    if Cfg.Prod.mem x prod then
      let rhss = Cfg.Prod.find x prod in
      let newprod = Cfg.Prod.add x rhss newprod in
      Cfg.SententialForm_set.fold 
	(fun rhs (newprod, vs) ->
	  List.fold_left 
	    (fun (newprod, vs) s ->
	      match s with 
		Cfg.Variable y -> 
		  if Cfg.Variable_set.mem y vs then (newprod, vs)
		  else dfs (newprod, Cfg.Variable_set.add y vs) y
	      | Cfg.Terminal t -> (newprod, vs)) 
	    (newprod, vs) rhs)
	rhss (newprod, vs)
    else (newprod, vs) in
  let (newprod, vs) = 
    dfs (Cfg.Prod.empty, Cfg.Variable_set.singleton s) s in
  (s, newprod, vs)

let extract s prod = 
  let s, newprod, vs = extract' s prod in
  Cfg.create3 vs newprod s

let extract' s prod =
  let s, newprod, vs = extract' s prod in
  (s, newprod)


exception Solve of Support.var   
exception SolveWith of Support.var * Cfg.SententialForm_set.t Cfg.Prod.t

let add_endmark = Fts.add_endmark

let cfg_var x = Cfg.Variable x.Support.id

let gc_rules gccond (livevars:Support.VarSet.t) p = 
  if gccond then 
    let () =  Options.show 1 
	(fun fmt -> Format.fprintf fmt "GC %d@." (size_of_prod p)) in
    let p = reachable_prod p livevars in
    let () =  Options.show 1 
	(fun fmt -> Format.fprintf fmt "GC %d@." (size_of_prod p)) in
    p
  else p 

let basic_simplify cfg =
  let cfg = Cfg.useful cfg in
  let cfg = simplify_null cfg in
  let cfg = simplify_unitpair cfg in 
  let cfg = chain_elim cfg in 
  Cfg.useful cfg

let words_of' loc str x p =
  let cfg = Cfg.create p x in
  let cfg = Cfg.useful cfg in
  let cfg = simplify_null cfg in  
  let cfg = simplify_unitpair cfg in 
  let cfg = Cfg.useful cfg in
  let cfg = chain_elim cfg in  
  let cfg = Cfg.compact cfg in  
  let cfg = Cfg.useful cfg in
  try 
    words_of_cfg cfg
  with Infinite -> 
    Il.unsupported loc (fun fmt -> 
      Format.fprintf fmt "@.%a@.Infinite strings for %s@."
    Cfg.pp_cfg cfg str)


let count = ref 0

let merge_cfg x p cfg =
  prod_add (x, [Cfg.Variable cfg.Cfg.start]) (prod_union p cfg.Cfg.prod)

let merge_cfg_with_ft x p ft cfg =
  let cfg = Ft_cfg.inter ft cfg in 
  merge_cfg x p cfg

let trans_cfg_rule ilinfo alias_env (gccond, livevars) env scc p (x, (rhs:Support.var rhs)) =
  let x = x.Support.id in
  let () = (incr count;
	    if !count >= 100 then (count := 0; Format.printf ".@?")) in

  let check_int v =
    match v with
      Rintval n -> Some n
    | Rvar x -> 
	let vs = Alias.lookup_var alias_env (Alias.Vvar x) in
	if Alias.Vset.cardinal vs = 1 then
	  match Alias.Vset.choose vs with
	    Alias.Vintval n -> Some n
	  | _ -> None
	else
	  None 
    | _ -> None in

  let check_bool v =
    match v with
      Rboolval b -> Some b
    | Rintval n -> Some (n != 0)
    | Rnull -> Some false
    | Rvar x -> 
	(let vs = Alias.lookup_var alias_env (Alias.Vvar x) in
	match Alias.vs2absbool vs with
	  Alias.AbsTrue -> Some true
	| Alias.AbsFalse -> Some false
	| _ -> None)
    | _ -> None in


  match rhs with
    Rval (Rvar y) -> prod_add (x,[cfg_var y]) p
  | Rconcat (Rvar y,Rvar z) -> 
      prod_add (x,[cfg_var y; cfg_var z]) p
  | Rstring s -> 
      prod_add (x, Basic.string_fold_right (fun c b ->Cfg.Terminal c ::b) s []) p
  | Rregexp r -> 
      let c, p =  reg2cfg r p in prod_add (x, c) p
  | Rdtd (f, r) -> 
      let dtd = Dtdmisc.get_dtd f in
      let cfg = Dtdmisc.dtd2cfg r dtd in
      merge_cfg x p cfg
  | Rapp (s,vs,loc) -> 
      let check x = 
	try
	  List.assoc x env 
	with
	  Not_found -> 
	    if Support.VarSet.mem x scc then 
	      (Il.warning loc
		(fun fmt -> Format.fprintf fmt "approximation for cyclic constraints with %s" s);
	      if gccond then raise (SolveWith (x,p))
	      else raise (Solve x))
	    else x.Support.id in
      let () = Options.show 2 (fun fmt -> Format.printf "%s@." s) in
      (match (s, vs) with
	("strval",vs) -> 
	  List.fold_left (fun p v ->
	    match v with
	      Rvar y -> prod_add (x, [cfg_var y]) p
	    | Rother -> 
		let y', p' = top_grammar Charset.charset in
		prod_add (x, [Cfg.Variable y']) (prod_union p' p)
	    | Rbool -> 
		let p = prod_add (x, [Cfg.Terminal '1']) p in (* True *)
		prod_add (x, []) p  (* False *)
	    | Rboolval b -> 
		if b then prod_add (x, [Cfg.Terminal '1']) p (* True *)
		else prod_add (x, []) p  (* False *)
	    | Rint -> 
		let y', p' = int_grammar in
		prod_add (x, [Cfg.Variable y']) (prod_union p' p)
	    | Rnull -> 
		prod_add (x, []) p
	    | Rfloat -> 
		let ys', p' = float_grammar in
		let p = prod_add (x, ys') (prod_union p' p) in
		let y', p' = int_grammar in
		prod_add (x, [Cfg.Variable y']) (prod_union p' p)
	    | Rintval i -> 
		prod_add (x,string_fold_right (fun c b ->Cfg.Terminal c ::b) (string_of_int i) []) p
	    | Rresource -> 
		let ss = List.map (fun x -> Cfg.Terminal x) 
		    (explode "Resource id #") in
		let y', p' = nonnegative_int_grammar in
		prod_add (x, ss@[Cfg.Variable y']) (prod_union p' p)
	    | Robject -> 
		let ss = List.map (fun x -> Cfg.Terminal x) (explode "Object") in
		prod_add (x, ss) p) p vs
      | ("implode",Rvar y::vs) -> 
	  let y = check y in
	  let zs = List.map 
	      (fun v -> match v with
		Rvar z -> check z
	      | _ -> failwith "implode") vs in
	  let p = prod_add (x,[]) p in
	  List.fold_left
	    (fun p z ->
	      let z' = fresh_var () in
	      let p = prod_add (x, [Cfg.Variable z']) p in
	      let p = prod_add (z', [Cfg.Variable z]) p in
	      prod_add (z',[Cfg.Variable z'; Cfg.Variable y; Cfg.Variable z]) p)
	    p zs
      | ("http_build_query",[Rvar y; Rvar z]) -> 
	  let y = check y in
	  let z = check z in
	  let y', py' = rename_extract y p in
	  let py' = prod_homo py' urlencode in
	  let z', pz' = rename_extract z p in
	  let pz' = prod_homo pz' urlencode in
	  let x1 = fresh_var () in
	  let x2 = fresh_var () in
	  let p = prod_add (x2, [Cfg.Variable y'; Cfg.Terminal '='; Cfg.Variable z']) p in
	  let p = prod_add (x1, [Cfg.Variable x2]) p in
	  let p = prod_add (x1, [Cfg.Variable x1; Cfg.Terminal '&'; Cfg.Variable x2]) p in
	  let p = prod_add (x, []) p in
	  let p = prod_add (x, [Cfg.Variable x1]) p in
	  prod_union pz' (prod_union py' p)
      | ("explode",[Rvar x1; Rvar x2]) -> 
	  let x1,x2 = check x1, check x2 in
	  let sss = words_of' loc "explode" x1 p in
	  List.fold_left (fun p ss ->
	    let cfg = extract x2 p in
	    let cfg = 
	      Ft_cfg.inter (Fts.explode_ft1 ss) cfg in
	    merge_cfg_with_ft x p (Fts.explode_ft2 ss) cfg) p sss
      | ("str_replace",[Rvar x1; Rvar x2; Rvar x3]) -> 
	  let livevars = Support.VarSet.add x2 livevars in
	  let x1,x2,x3 = check x1, check x2, check x3 in
	  let x3', p' = extract' x3 p in			  
	  let sss = words_of' loc "str_replace" x1 p in
	  let p = gc_rules gccond livevars p in
	  List.fold_left (fun p ss ->
	    let x3', p' = 
	      match ss with
		[c] ->
		  let x3', p' = rename_extract x3' p' in
		  x3', cfg_subst p' 
		    (fun c' -> if c = c' then Cfg.Variable x2 
		    else Cfg.Terminal c') 
	      | _ -> 
		  let cfg = Cfg.create p' x3' in
		  let cfg = basic_simplify cfg in
		  let cfg = Ft_cfg.inter 
		      (Fts.string_ft ss [Cfg.Variable x2]) cfg in  
		  cfg.Cfg.start, cfg.Cfg.prod  in 
	    prod_add (x, [Cfg.Variable x3']) (prod_union p p')) p sss
      | ("sprintf",Rvar x1::xs) -> 
	  let x1 = check x1 in
	  let xs = List.map 
	      (fun s -> 
		match s with
		  Rvar x -> check x
		| _ -> failwith "sprintf") xs in
	  let sss = words_of' loc "sprintf"  x1 p in
	  List.fold_left (fun p ss -> 
	    try
	      let () = Options.show 2 
		  (fun fmt -> List.iter (fun c -> Format.fprintf fmt "%c@." c) ss) in
	      let y,p = Sprintf.fmtcs2prod ss xs p in
	      prod_add (x, [Cfg.Variable y]) p
	    with _ -> p) p sss
      | ("vsprintf",Rvar x1::xs) -> 
	  let x1 = check x1 in
	  let xs = List.map 
	      (fun s -> 
		match s with
		  Rvar x -> check x
		| _ -> failwith "vsprintf") xs in
	  let sss = words_of' loc "vsprintf" x1 p in
	  let y = fresh_var () in
	  let p = prod_add (y, List.map (fun x -> Cfg.Variable x) xs) p in
	  List.fold_left (fun p ss -> 
	    let y,p = Sprintf.fmtcs2prod_v ss y p in
	    prod_add (x, [Cfg.Variable y]) p) p sss
      | ("preg_replace",[Rvar x1; Rvar x2; Rvar x3]) -> 
	  let x1,x2,x3 = check x1, check x2, check x3 in
	  let cfg = extract x3 p in
	  let x2', p2' = extract' x2 p in
	  let sss = words_of' loc "preg_replace" x1 p in
	  let p = gc_rules gccond livevars p in
	  List.fold_left (fun p ss ->
	    let cfg = basic_simplify cfg in
	    let cfg = Fts.preg_replace cfg ss (x2',p2') in
	    merge_cfg x p cfg) p sss
      | ( ("__preg_match" | "__npreg_match" | "__preg_match_array" |
	"__ereg" | "__nereg" | "__ereg_array" | "__preg_match_all" |
	"__eregi" | "__neregi" | "__eregi_array" ) as strop,
	       [Rvar x1; Rvar x2]) -> 
		 let transform cfg ss =
		   match strop with
		     "__preg_match" -> Fts.preg_match true cfg ss 
		   | "__npreg_match" -> Fts.preg_match false cfg ss 
		   | "__preg_match_array" -> Fts.preg_match_array cfg ss
		   | "__ereg" -> Fts.ereg false true cfg ss 
		   | "__nereg" -> Fts.ereg false false cfg ss 
		   | "__ereg_array" -> Fts.ereg_array false cfg ss
		   | "__eregi" -> Fts.ereg true true cfg ss 
		   | "__neregi" -> Fts.ereg false true cfg ss 
		   | "__eregi_array" -> Fts.ereg_array true cfg ss
		   | "__preg_match_all" -> Fts.preg_match_array cfg ss 
		   | _ -> failwith "string-parameterized operations" in
		 let x1,x2 = check x1, check x2 in
		 let cfg = extract x2 p in
		 let sss = words_of' loc "reg" x1 p in
		 let p = gc_rules gccond livevars p in
		 List.fold_left (fun p ss ->
		   let cfg = basic_simplify cfg in
		   let cfg = transform cfg ss in
		   merge_cfg x p cfg) p sss
      | ("preg_split",[Rvar x1; Rvar x2]) -> 
	  let x1,x2 = check x1, check x2 in
	  let sss = words_of' loc "preg_split" x1 p in
	  List.fold_left (fun p ss ->
	    let cfg = extract x2 p in
	    let cfg = Fts.preg_split cfg ss  in
	    merge_cfg x p cfg) p sss
      | ("ereg_replace",[Rvar x1; Rvar x2; Rvar x3]) -> 
	  let x1,x2,x3 = check x1, check x2, check x3 in
	  let cfg = extract x3 p in
	  let x2', p2' = extract' x2 p in
	  let sss = words_of' loc "ereg_replace" x1 p in
	  let p = gc_rules gccond livevars p in
	  List.fold_left (fun p ss ->
	    let cfg = basic_simplify cfg in
	    let cfg = Fts.ereg_replace true cfg ss (x2',p2') in
	    merge_cfg x p cfg) p sss
      | ("eregi_replace",[Rvar x1; Rvar x2; Rvar x3]) -> 
	  let x1,x2,x3 = check x1, check x2, check x3 in
	  let cfg = extract x3 p in
	  let x2', p2' = extract' x2 p in
	  let sss = words_of' loc "eregi_replace" x1 p in
	  let p = gc_rules gccond livevars p in
	  List.fold_left (fun p ss ->
	    let cfg = basic_simplify cfg in
	    let cfg = Fts.ereg_replace false cfg ss (x2',p2') in
	    merge_cfg x p cfg) p sss
      | ("strstr",[Rvar x1; Rvar x2]) -> 
	  let x1,x2 = check x1, check x2 in
	  let sss = words_of' loc "strstr" x2 p in
	  List.fold_left (fun p ss ->
	    let cfg = extract x1 p in
	    let ft = Fts.strstr_ft true ss in
	    merge_cfg_with_ft x p ft cfg) p sss
      | ("stristr",[Rvar x1; Rvar x2]) -> 
	  let x1,x2 = check x1, check x2 in
	  let sss = words_of' loc "stristr" x2 p in
	  List.fold_left (fun p ss ->
	    let cfg = extract x1 p in
	    let ft = Fts.strstr_ft false ss in
	    merge_cfg_with_ft x p ft cfg) p sss
      | ("strrchr",[Rvar x1; Rvar x2]) -> 
	  let x1,x2 = check x1, check x2 in
	  let sss = words_of' loc "strrchr" x2 p in
	  List.fold_left (fun p ss ->
	    match ss with
	      [] -> p
	    | s::_ ->
		let cfg = extract x1 p in
		let ft = Fts.strrchr_ft s in
		merge_cfg_with_ft x p ft cfg) p sss
      | ("substr",Rvar x1::v2::vs) -> 
	  let x1 = check x1 in
	  let cfg = extract x1 p in
	  let pre_ft = match check_int v2 with
	    Some n when n >= 0 -> Fts.skip_ft (Some n)
	  | _ -> Fts.skip_ft None in
	  let ft = 
	    match vs with
	      [] -> Fts.append_id_ft pre_ft
	    | [v3] ->
		(match check_int v3 with
		  Some m when m > 0 -> Fts.append_cut_ft (Some m) pre_ft
		| _ -> Fts.append_cut_ft None pre_ft)
	    | _ -> failwith "substr" in
	  merge_cfg_with_ft x p ft cfg
      | ("str_repeat",[Rvar x1; v2]) -> 
	  let x1 = check x1 in
	  (match check_int v2 with
	    Some n ->
	      let rec repeat x i = match i with
		0 -> []
	      | i -> x::repeat x (i - 1) in 
	      prod_add (x, repeat (Cfg.Variable x1) n) p
	  | None ->
	      prod_add (x, [Cfg.Variable x; Cfg.Variable x1]) (prod_add (x, []) p))
      | ("str_pad",[Rvar x1; v2]) -> 
	  let x1 = check x1 in
	  (match check_int v2 with
	    Some n ->
	      let cfg = add_endmark (extract x1 p) in
	      let ft = Fts.pad_ft ' ' n in
	      merge_cfg_with_ft x p ft cfg
	  | None -> 
	      let x1', p' = extract' x1 p in
	      let y = fresh_var () in
	      let p' = prod_add (y, [Cfg.Variable x1']) p' in
	      let p' = prod_add (y, [Cfg.Variable y; Cfg.Terminal ' ']) p' in
	      let cfg = Cfg.create p' y in
	      merge_cfg_with_ft x p Fts.prefix_ft cfg)
      | ("str_pad",[Rvar x1; v2; Rvar x2]) -> 
	  let x1,x2 = check x1, check x2 in
	  let sss = words_of' loc "str_pad" x2 p in
	  List.fold_left (fun p ss ->
	    let x1', p' = extract' x1 p in
	    let cfg =
	      match check_int v2 with
		Some n ->
		  let cfg = add_endmark (Cfg.create p' x1') in
		  Ft_cfg.inter (Fts.str_pad_ft ss n) cfg
	      | None ->
		  let y = fresh_var () in
		  let p' = prod_add (y, [Cfg.Variable x1']) p' in
		  let p' = prod_add (y, Cfg.Variable y ::
				     List.map (fun c -> Cfg.Terminal c) ss) p' in
		  let cfg = Cfg.create p' y in
		  Ft_cfg.inter Fts.prefix_ft cfg in
	    merge_cfg x p cfg) p sss
      | ("wordwrap",Rvar x1::vs) -> 
	  let x1 = check x1 in
	  let cfg = extract x1 p in
	  let opn, s, strict =
	    match vs with
	      [] -> Some 75, Cfg.Terminal '\n', false
	    | v2::vs -> 
		match vs with
		  [] -> check_int v2, Cfg.Terminal '\n', false
		| Rvar x2::vs ->
		    (let x2 = check x2 in
		    match vs with
		      [] -> check_int v2, Cfg.Variable x2, false
		    | [v3] -> 
			(match check_bool v3 with
			  Some b -> check_int v2, Cfg.Variable x2, b
			| _ -> Il.unsupported_simple loc "wordwrap")
		    | _ -> Il.unsupported_simple loc "wordwrap")
		| _ -> Il.unsupported_simple loc "wordwrap" in
	  let cfg = 
            match opn with
	      Some n -> 
		let cfg = add_endmark cfg in
		Ft_cfg.inter (Fts.wordwrap_ft n s strict) cfg 
	    | None ->  
		if strict then 
		  let cfg = add_endmark cfg in
		  Ft_cfg.inter (Fts.wordwrap_strict_approx_ft s) cfg 
		else
		  Ft_cfg.inter (Fts.wordwrap_approx_ft s) cfg  in
	  merge_cfg x p cfg
      | ("strtok",[Rvar x1; Rvar x2]) -> 
	  let x1,x2 = check x1, check x2 in
	  let sss = words_of' loc "strtok" x2 p in
	  List.fold_left (fun p ss ->
	    let cfg = extract x1 p in
	    let ft = Fts.strtok_ft ss in
	    merge_cfg_with_ft x p ft cfg) p sss
      | ("chunk_split",[Rvar x1]) -> 
	  let x1 = check x1 in
	  let cfg = extract x1 p in
	  let ft = Fts.chunk_split_ft 76 ['\r'; '\n'] in
	  merge_cfg_with_ft x p ft cfg
      | ("chunk_split",[Rvar x1; Rintval n]) -> 
	  let x1 = check x1 in
	  let cfg = extract x1 p in
	  let ft = Fts.chunk_split_ft n ['\r'; '\n'] in
	  merge_cfg_with_ft x p ft cfg
      | ("chunk_split",[Rvar x1; Rintval n; Rvar x2]) -> 
	  let x1,x2 = check x1, check x2 in
	  let sss = words_of' loc "chunk_split" x2 p in
	  List.fold_left (fun p ss ->
	    let cfg = extract x1 p in
	    let ft = Fts.chunk_split_ft n ss in
	    merge_cfg_with_ft x p ft cfg) p sss
      | ("substr_replace",[Rvar x1; Rvar x2; Rintval n]) -> 
	  let x2 = x2.Support.id in
	  let x1 = check x1 in
	  let cfg = extract x1 p in
	  let cfg = Fts.substr_replace (Cfg.Variable x2) n None cfg in
	  merge_cfg x p cfg
      | ("substr_replace",[Rvar x1; Rvar x2; Rintval n; Rintval m]) -> 
	  let x2 = x2.Support.id in
	  let x1 = check x1 in
	  let cfg = extract x1 p in
	  let cfg = Fts.substr_replace (Cfg.Variable x2) n (Some m) cfg in
	  merge_cfg x p cfg
      | ("str_split",[Rvar x1; v2]) -> 
	  let x1 = check x1 in
	  let cfg = extract x1 p in
	  let ft = 
	    match check_int v2 with
	      Some n -> Fts.str_split_ft n
	    | None -> Fts.str_split_approx_ft in
	  merge_cfg_with_ft x p ft cfg
      | ("addcslashes",[Rvar x1; Rvar x2]) -> 
	  let x1,x2 = check x1, check x2 in
	  let sss = words_of' loc "addcslash" x2 p in
	  List.fold_left (fun p ss ->
	    let x1', p' = rename_extract x1 p in
	    let ts = Fts.parse_addcslashes ss Cfg.Terminal_set.empty in
	    let p' = prod_homo p' 
		(fun c -> if Cfg.Terminal_set.mem c ts then explode (Fts.escape_char c) else [c]) in
	    prod_add (x, [Cfg.Variable x1']) (prod_union p p')) p sss

      | ("number_format",[_; Rintval n]) -> 
	  let reg = Reg.Repetition (Reg.Plus (digit_reg, Reg.Epsilon),3,Some 3) in
	  let reg = Reg.App(reg, Reg.Star (Reg.App (Reg.Alpha ',', Reg.Repetition (digit_reg, 3, Some 3)))) in
	  let reg = Reg.App (reg, Reg.App (Reg.Alpha '.', Reg.Repetition (digit_reg, n, Some n))) in
	  let c, p =  reg2cfg reg p in 
	  prod_add (x, c) p
      | ("number_format",[_; _]) -> 
	  let reg = Reg.Repetition (Reg.Plus (digit_reg, Reg.Epsilon),3, Some 3) in
	  let reg = Reg.App(reg, Reg.Star (Reg.App (Reg.Alpha ',', Reg.Repetition (digit_reg, 3,Some 3)))) in
	  let reg = Reg.App (reg, Reg.App (Reg.Alpha '.', Reg.Star digit_reg)) in
	  let c, p =  reg2cfg reg p in 
	  prod_add (x, c) p

      | ("trim"|"ltrim"|"rtrim"|"chop" as trim,[Rvar x1; Rvar x2]) -> 
	  let x1,x2 = check x1, check x2 in
	  let sss = words_of' loc "trim" x2 p in
	  List.fold_left (fun p ss ->
	    let cfg = extract x1 p in
	    let ts = Fts.parse_addcslashes ss Cfg.Terminal_set.empty in
	    let ft = 
	      match trim with
		"trim" -> (Fts.trim_ft ts)
	      | "ltrim" -> (Fts.ltrim_ft ts)
	      | "rtrim" | "chop" -> (Fts.rtrim_ft ts)
	      | _ -> failwith "trim" in
	    merge_cfg_with_ft x p ft cfg) p sss
      | (s,[Rvar x1]) -> 
	  let x1 = check x1 in
	  (try
	    match find_stringop s with
	      OpSubst (h, rules) -> 
		let x1', p' = rename_extract x1 p in
		let p = gc_rules gccond livevars p in
		let p' = cfg_subst p' h in
		prod_add (x, [Cfg.Variable x1']) (prod_union rules (prod_union p p'))
	    | OpHomo h -> 
		let x1', p' = rename_extract x1 p in
		let p = gc_rules gccond livevars p in
		let p' = prod_homo p' h in
		prod_add (x, [Cfg.Variable x1']) (prod_union p p')
	    | OpTransducer ft ->
		let cfg = extract x1 p in
		let p = gc_rules gccond livevars p in
		merge_cfg_with_ft x p ft cfg
	    | OpTransducerEndmark ft ->
		let cfg = extract x1 p in
		let p = gc_rules gccond livevars p in
		let cfg = add_endmark cfg in
		let cfg = simplify_null cfg in
		let cfg = chain_elim cfg in
		let cfg = Cfg.useful cfg in 
		merge_cfg_with_ft x p ft cfg
	    | OpOther f ->
		let x1', p' = rename_extract x1 p in
		let cfg = f (Cfg.create p' x1') in
		merge_cfg x p cfg
	  with
	    Not_found -> 
	      Il.unsupported loc 
		(fun fmt -> Format.fprintf fmt "uarry prim : %s" s))
      | ("date",[Rvar x1;_])  -> 
	  let x1 = check x1 in
	  let x1', p' = extract' x1 p in
	  (try
	    match find_stringop "date" with
	      OpSubst (h,rules) -> 
		let p' = cfg_subst p' h in
		prod_add (x, [Cfg.Variable x1']) (prod_union rules (prod_union p p'))
	    | _ -> failwith "ophomo"
	  with
	    Not_found -> Il.impossible "no transformation for date")
      | ("__string_update",[Rvar x1; _; Rvar x3]) -> 
	  let x1,x3 = check x1, check x3 in
	  let cfg1 = extract x1 p in
	  let cfg3 = extract x3 p in
	  let cfg = Fts.string_update cfg1 cfg3  in
	  merge_cfg x p cfg
      | ("htmlentities",Rvar x1 :: v2 :: vs) -> 
	  let () =
	    if vs <> [] then
	      Il.warning loc 
		(fun fmt -> Format.fprintf fmt 
		    "the charset argument in htmlentities is not supported") in
	  let x1 = check x1 in
	  let htmlentities_rules n p =
	    let h = htmlentities_hom n in
	    let x1', p' = rename_extract x1 p in
	    let p = gc_rules gccond livevars p in
	    let p' = prod_homo p' h in
	    prod_add (x, [Cfg.Variable x1']) (prod_union p p') in
	  (match check_int v2 with
	    Some n -> htmlentities_rules n p 
	  | None ->
	      let p = htmlentities_rules 0 p in
	      let p = htmlentities_rules 2 p in
	      htmlentities_rules 3 p) 
      | ("htmlspecialchars",Rvar x1 :: v2 :: vs) -> 
	  let () =
	    if vs <> [] then
	      Il.warning loc 
		(fun fmt -> Format.fprintf fmt 
		    "the charset argument in htmlentities is not supported") in
	  let x1 = check x1 in
	  let htmlentities_rules n p =
	    let h = htmlspecialchars_hom n in
	    let x1', p' = rename_extract x1 p in
	    let p = gc_rules gccond livevars p in
	    let p' = prod_homo p' h in
	    prod_add (x, [Cfg.Variable x1']) (prod_union p p') in
	  (match check_int v2 with
	    Some n -> htmlentities_rules n p 
	  | None ->
	      let p = htmlentities_rules 0 p in
	      let p = htmlentities_rules 2 p in
	      htmlentities_rules 3 p) 
      | ("html_entity_decode",Rvar x1 :: v2 :: vs) -> 
	  let () =
	    if vs <> [] then
	      Il.warning loc 
		(fun fmt -> Format.fprintf fmt 
		    "the charset argument in html_entity_decode is not supported") in
	  let x1 = check x1 in
	  let htmlentities_rules n p =
	    let ft = html_entity_decode_transducer n in
	    let x1', p' = rename_extract x1 p in
	    let p = gc_rules gccond livevars p in
	    let cfg = Cfg.create p' x1' in
	    merge_cfg_with_ft x p ft cfg in
	  (match check_int v2 with
	    Some n -> htmlentities_rules n p 
	  | None ->
	      let p = htmlentities_rules 0 p in
	      let p = htmlentities_rules 2 p in
	      htmlentities_rules 3 p) 
      | (s,_) -> Il.unsupported_simple loc s)
  | _ -> p


let vars_of_rules_cfgx rules =
  List.fold_left 
    (fun xs (x,rhs) -> Opcfg.vars_of_rhs rhs xs)
    Support.VarSet.empty rules

(* 
 *  Transforming the components into the following form:
 *  (xs, rules, ys)
 *   wehre ys is the set of live variables.
 *) 
 
let varinfo (xs, sccs) =
  let xs = List.fold_left (fun xs x -> Support.VarSet.add x xs) Support.VarSet.empty xs in
  List.fold_left (fun (ys, sccs)  (xs,rules) ->
    let zs = vars_of_rules_cfgx rules in
    let ys' = Support.VarSet.diff (Support.VarSet.union ys zs) xs in
    (ys', (xs, rules, ys)::sccs))
    (xs, []) (List.rev sccs) 

let trans ilinfo alias_env (x, ys, g) =
  let rec approx_trans_component env p (scc, rules, xs) =
    try
      let tenv, p'  = List.fold_left 
	  (fun (env, p) (x, cs) -> 
	    let x' = fresh_var () in
	    let reg = Reg.Star (Reg.Alphalist (Cfg.Terminal_set.elements cs)) in
	    let xs,p = reg2cfg reg p in
	    ((x,x')::env, prod_add (x', xs) p)) ([],p) env in
      let p' = List.fold_left (fun p rule -> trans_cfg_rule ilinfo alias_env (false, xs) tenv scc p rule) p' rules in
      let env' =
	List.map (fun (x,cs) ->
	  let x', p'' = extract' x.Support.id p' in (x,Cfg.terminals_of_prod p'')) env in
      let b = 
	List.for_all2
	  (fun (_, cs) (_,cs') -> Cfg.Terminal_set.equal cs cs') env env' in
      if b then p' else approx_trans_component env' p (scc, rules, xs)
    with Solve x ->
      approx_trans_component ((x,Cfg.Terminal_set.empty)::env) p 
	(scc, rules, xs) in

  let trans_component p (scc, rules, xs) =
    match rules with
      [rule] -> 
	(try
	  trans_cfg_rule ilinfo alias_env (true, xs) [] scc p rule 
	with SolveWith (x,p) ->
	  approx_trans_component [(x,Cfg.Terminal_set.empty)] p 
	    (scc, rules, xs)) 
    | _ ->  
	try
	  let p' = List.fold_left (fun p rule -> trans_cfg_rule ilinfo alias_env (false, xs) [] scc p rule) p rules in
	  if size_of_prod p' > size_of_prod p + 1000 then
	    let () = Options.show 1 
		(fun fmt -> Format.fprintf fmt "GC rules@.") in
	    reachable_prod p' xs else p'
	with Solve x ->
	  approx_trans_component [(x,Cfg.Terminal_set.empty)] p 
	    (scc, rules, xs) in
  let _, g = varinfo (x::ys, g) in
  let g = List.fold_left trans_component Cfg.Prod.empty g in 
  (g, x.Support.id, List.map (fun y -> y.Support.id) ys)


