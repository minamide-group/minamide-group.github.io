(*
 * PHP string analyzer
 * Copyright (C) 2006 Yasuhiko Minamide
 *)
open Support
open Phptype
open Il
open Ilmisc

type avalue = 
    Vvar of var 
  | Varray of var * var
  | Vstring of string 
  | Vregexp of Reg.reg 
  | Vdtd of string * string
  | Vconcat of avalue * avalue
  | Vbox
  | Vint
  | Vintval of int
  | Vnull
  | Vfloat
  | Vbool
  | Vboolval of bool
  | Vresource 
  | Vobject of string
  | Vapp of string * avalue list * Loc.loc

let rec pp_value fmt v =
  match v with
    Vvar x -> pp_var fmt x
  | Varray (x,y) -> 
      Format.fprintf fmt "array(%a,%a)" pp_var x pp_var y
  | Vstring s -> Format.fprintf fmt "\"%s\"" s 
  | Vconcat (v1, v2) -> Format.fprintf fmt "%a.%a" pp_value v1 pp_value v2
  | Vapp (s, vs, _) -> Format.fprintf fmt "%s(%a)" s (Support.pp_seq pp_value) vs
  | Vint  -> Format.fprintf fmt "Vint"
  | Vfloat  -> Format.fprintf fmt "Vfloat"
  | Vbool  -> Format.fprintf fmt "Vbool"
  | Vboolval b -> Format.fprintf fmt "Vbool"
  | Vnull  -> Format.fprintf fmt "Vnull"
  | Vintval i -> Format.fprintf fmt "Vintval%d" i
  | Vregexp r -> Format.fprintf fmt "/%a/" Reg.pp_reg r
  | Vdtd (d,r) -> Format.fprintf fmt "dtd(%s,%s)" d r
  | Vbox  -> Format.fprintf fmt "Vbox"
  | Vresource  -> Format.fprintf fmt "Vresource"
  | Vobject classname -> Format.fprintf fmt "Vobject(%s)" classname

(* Constraints *)


module VASet =
  Set.Make(struct 
    type t = var * avalue
    let compare = compare
  end)


let extend x v env = VASet.add (x,v) env 

let rec extend_list xs vs env = 
  match xs, vs with
    [], [] -> env
  | x::xs, v::vs -> extend_list xs vs (extend x v env)
  | _ -> failwith "extend_list"

let rec eval_const env const =
  match const with
    ConstInt i -> (Vint, env)
  | ConstBool b -> (Vbool, env)
  | ConstFloat f -> (Vfloat, env)
  | ConstString s -> (Vstring s, env)
  | ConstArray (l, x, y, z) -> 
      let env =
	List.fold_left (fun env (a,b) ->
	  let v, env  = eval_const env a in
	  let env = extend y v env in
	  let w, env  = eval_const env b in
	  extend z w env) env l in
      (Varray (x, y), env)
  | ConstConst x -> (Vvar x, env)
  | ConstBox (c, x) -> 
      let v, env  = eval_const env c in
      let env = extend x v env in
      (Vbox, env)

let rec eval_vspec ilenv env vspec =
  match vspec with
    Valuespec.Vregexp r -> (Vregexp r, env)
  | Valuespec.Vdtd (d,r) -> (Vdtd (d,r), env)
  | Valuespec.Vint -> (Vint, env)
  | Valuespec.Vfloat -> (Vfloat, env)
  | Valuespec.Vbool -> (Vbool, env)
  | Valuespec.Vboolval b -> (Vboolval b, env)
  | Valuespec.Vresource -> (Vresource, env)
  | Valuespec.Vnull -> (Vnull, env)
  | Valuespec.Varray (vspec,x,y,z) -> 
      let v, env = eval_vspec ilenv env vspec in
      let env = extend z v env in
      let env = extend y Vint env in
      let env = extend y (Vregexp (Reg.Star Reg.Allalpha)) env in
      (Varray (x,y), env)
  | Valuespec.Varray2 (keyspec, vspec,x,y,z) -> 
      let v1, env = eval_vspec ilenv env keyspec in
      let v2, env = eval_vspec ilenv env vspec in
      let env = extend z v2 env in
      let env = extend y v1 env in
      (Varray (x,y), env)
  | Valuespec.Vor (vspec1,vspec2,x) ->
      let v1, env = eval_vspec ilenv env vspec1 in
      let env = extend x v1 env in
      let v2, env = eval_vspec ilenv env vspec2 in
      let env = extend x v2 env in
      (Vvar x, env)
  | Valuespec.Vstring -> (Vregexp (Reg.Star Reg.Allalpha), env)
  | Valuespec.Vmixed -> failwith "mixed"
  | Valuespec.Varray0 -> failwith "array0"
  | Valuespec.Vobject (vspec,x,y,z) -> 
      let v, env = eval_vspec ilenv env vspec in
      let ivenv, a, b, c = Ilmisc.find_stdclass ilenv in
      let env = extend b v env in
      let env = 
	StringMap.fold (fun m (a,b) env -> extend b v env) ivenv
	  env in
      (Vobject "stdclass", env)

let rec exec alias_env ilenv ys env s = 

  let may_array v =
    match v with
      Vvar x -> 
	Alias.Vset.exists (fun w ->
	  match w with
	    Alias.Varray _-> true
	  | _ -> false) (Alias.lookup_var alias_env (Alias.Vvar x))
    | Varray (x,y) -> true
    | _  -> false in

  let array_val_keys v (xs, ys) =
    match v with
      Vvar z ->
	Alias.Vset.fold (fun w (xs, ys) ->
	  match w with
	    Alias.Varray (x',y',_) ->  
	      (VarSet.add x' xs, VarSet.add y' ys)
	  | _ -> (xs, ys)) 
	  (Alias.lookup_var alias_env (Alias.Vvar z)) (xs, ys) 
    | Varray (x',y') -> (VarSet.add x' xs, VarSet.add y' ys)
    | _ -> (xs, ys) in

  let strval v =
    match v with
      Vstring _  | Vconcat _ | Vapp _ -> v
    | Vvar x ->
	let ws = Alias.lookup_var alias_env (Alias.Vvar x) in
	if Alias.Vset.for_all
	    (fun x -> match x with
	      Alias.Vstring | Alias.Vstringval _ -> true
	    | _ -> false) ws  then v
	else
	  Vapp ("strval",
		List.map (fun w ->
		  match w with
		    Alias.Vstring ->  v
		  | Alias.Vstringval _ ->  v
		  | Alias.Vint -> Vint
		  | Alias.Vintval i -> Vintval i
		  | Alias.Vnull -> Vnull
		  | Alias.Vfloat -> Vfloat
		  | Alias.Vbool -> Vbool
		  | Alias.Vboolval b -> Vboolval b
		  | Alias.Vresource -> Vresource
		  | Alias.Varray (x,y,_) -> Vstring "Array"
		  | Alias.Vobject cname -> Vstring "Object"
		  | Alias.Vbox _ -> Vnull
		  | _ -> failwith "strval") (Alias.Vset.elements ws),
	       Loc.dummy_loc ())
    | _ -> Vapp ("strval", [v], Loc.dummy_loc ()) in

  let rec eval env exp =
    match exp with
      Var x -> (Vvar x, env)  
    | Vspec vspec -> eval_vspec ilenv env vspec
    | Null -> (Vnull, env) 
    | Dref (x,y) -> 
	let vs = Alias.lookup_var alias_env (Alias.Vvar x) in
	let env =
	  Alias.Vset.fold
	    (fun v env ->
	      match v with
		Alias.Vbox z -> extend y (Vvar z) env
	      | _ -> env) vs env in
	(Vvar y, env)
    | Const x -> (Vvar x, env) 
    | ConstExp const -> eval_const env const
    | Int i -> (Vintval i, env)
    | Float f -> (Vfloat, env)
    | Bool b -> (Vbool, env)
    | String s -> (Vstring s, env)
    | Prim (p, es, (x,y,z,loc)) -> 
	let vs, env = eval_list env es in
	(match p with
	  Concat -> 
	    (match vs with
	      [v1; v2] -> (Vconcat (strval v1, strval v2), env)
	    | _ -> failwith "concat!")
	| Cast StringTy ->
	    (match vs with
	      [v] -> (strval v, env)
	    | _ -> failwith "(string)")
	| Cast ResourceTy -> (Vresource, env)
	| Cast ObjectTy -> 
	    (match vs with
	      [v] ->
		let env = extend x v env in
		let env = extend x (Vobject "stdclass") env in
		let ivenv, a, b, _ = Ilmisc.find_stdclass ilenv in
		let env = extend b v env in
		Vvar x, env
	    | _ -> failwith "cast object")
	| Cast ArrayTy -> 
	    (match vs with
	      [v] ->
		let w = fresh_var () in
		let env = extend x v env in
		let env = extend x (Varray (y,w)) env in
		let env = extend z v env in
		let env = extend y Vint env in
		Vvar x, env
	    | _ -> failwith "cast array")
	| Cast IntTy -> (Vint, env)
	| Mod -> (Vint, env)
	| Plus | Minus | Times -> (Vvar x, env)
	| Div -> (Vfloat, env)
	| Bitnot | Bitand | Bitor | Bitxor | Bitshiftl | Bitshiftr -> Vint, env
 	| Cast FloatTy -> (Vfloat, env)
	| Eq | Neq | Lt | Le | Gt | Ge | Not | Xor | Cast BoolTy -> (Vbool, env)
	| NewArray -> Varray (x,y), env
	| NewArrayL _ -> Varray (x,y), env
	| InitArray w -> 
	    (match vs with
	      [v] ->
		let env = extend w v env in
		let env = extend w (Varray (x,y)) env in
		Vvar w, env
	    | _ -> failwith "init_array")
	| NewObj classname -> Vobject classname, env
	| InitObj w -> 
	    (match vs with
	      [v] ->
		let env = extend x v env in
		let env = extend x (Vobject "stdclass") env in
		let env = extend y (Vobject "stdclass") env in
		Vvar x, env
	    | _ -> failwith "init_array")
	| CheckFunction _ | CheckMethod _ -> Vbool, env
	| NewRef -> (Vbox, env)
	| StringUpdate -> Vapp ("__string_update", vs, loc), env
	| ArrayDref -> 
	    let vs, env = eval_list env es in
	    (match vs with
	      [v1; v2] -> 
		let ws = Alias.lookup_var alias_env (Alias.Vvar y) in
		let env = 
		  Alias.Vset.fold (fun w env ->
		    match w with
		      Alias.Vbox w' -> extend z (Vvar w') env 
		    | _ -> env) ws env in
		(Vvar z, env)
	    | _ -> failwith "array_dref"))
    | App (s, es, (x,y,z,loc)) -> 
	(match (s, es) with
	  ("implode", [e1;e2]) | ("join", [e1;e2]) -> 
	    let v1, env = eval env e1 in
	    let v2, env = eval env e2 in
	    let xs =
	      match v2 with
		Vvar x ->
		  Alias.Vset.fold (fun w xs ->
		    match w with
		      Alias.Varray (y,_,_) -> y::xs
		    | _ -> xs) (Alias.lookup_var alias_env (Alias.Vvar x)) [] 
	      | Varray (x,_) -> [x]
	      | _ -> [] in
	    let ws = 
	      List.fold_right (fun x ws ->
		Alias.Vset.fold (fun w ws ->
		  match w with
		    Alias.Vbox z' ->  Vvar z':: ws
		  | _ -> ws) (Alias.lookup_var alias_env (Alias.Vvar x)) ws)
		xs []  in
	    (Vapp ("implode", v1::List.map strval ws, loc), env)
	| ("http_build_query", [e]) -> 
	    let v, env = eval env e in
	    let key_x = fresh_var () in
	    let value_x = fresh_var () in
	    let env =
	      match v with
		Vvar x ->
		  Alias.Vset.fold (fun w env ->
		    match w with
		      Alias.Varray (y,z,_) -> 
			let env = extend key_x (Vvar z) env in extend value_x (Vvar y) env 
		    | _ -> env) (Alias.lookup_var alias_env (Alias.Vvar x)) env
	      | Varray (y,z) -> 
		  let env = extend key_x (Vvar z) env in extend value_x (Vvar y) env 
	      | _ -> env in
	    (Vapp ("http_build_query", [Vvar key_x; Vvar value_x], loc), env)
	| ("explode", [e1;e2]) -> 
	    let v1, env = eval env e1 in
	    let v2, env = eval env e2 in
	    (Varray (x,y), extend z (Vapp ("explode", List.map strval [v1;v2], loc)) env)
	| ("preg_split", [e1;e2]) -> 
	    let v1, env = eval env e1 in
	    let v2, env = eval env e2 in
	    (Varray (x,y), extend z (Vapp ("preg_split", [strval v1; strval v2], loc)) env)
	| ("str_split", [e1]) -> 
	    let v1, env = eval env e1 in
	    (Varray (x,y), extend z (Vapp ("str_split", [strval v1; Vintval 1], loc)) env)
	| ("str_split", [e1;e2]) -> 
	    let v1, env = eval env e1 in
	    let v2, env = eval env e2 in
	    (Varray (x,y), extend z (Vapp ("str_split", [strval v1;v2], loc)) env)
	| ("array_slice", es) -> 
	    let vs, env = eval_list env es in
	    (match vs with
	      v::_ -> (v, env)
	    | _ -> failwith "array_slice")
	| ("array_chunk", es) -> 
	    let vs, env = eval_list env es in
	    (match vs with
	      [v1;v2] -> 
		let env = extend y Vint env in
		let env = extend z v1 env in
		(Varray (x,y), env)
	    | _ -> failwith "array_chunk")
	| ("array_push", es) -> 
	    let vs, env = eval_list env es in
	    (match vs with
	      [v1;v2] ->
		let env =
		  match v1 with
		    Vvar z ->
		      Alias.Vset.fold (fun w env ->
			match w with
			  Alias.Varray (x',y',_) -> extend x' v2 env
			| _ -> env) (Alias.lookup_var alias_env (Alias.Vvar z)) env 
		  | Varray (x',y') -> extend x' v2 env
		  | _ -> env in
		(Vint, env)
	    | _ -> failwith "array_push")
	| ("array_pop", es) -> 
	    let vs, env = eval_list env es in
	    (match vs with
	      [v1] -> 
		let env = 
		  Alias.Vset.fold (fun w env ->
		    match w with
		      Alias.Vbox w' -> extend z (Vvar w') env 
		    | _ -> env) (Alias.lookup_var alias_env (Alias.Vvar y)) env in
		(Vvar z, env)
	    | _ -> failwith "array_pop")
	| (("current" | "end" | "next" | "pos" | "prev" | "reset"), es) -> 
	    let vs, env = eval_list env es in
	    (match vs with
	      [v1] -> 
		let env = extend z Vbool env in
		let env = 
		  Alias.Vset.fold (fun w env ->
		    match w with
		      Alias.Vbox w' -> extend z (Vvar w') env 
		    | _ -> env) (Alias.lookup_var alias_env (Alias.Vvar y)) env in
		(Vvar z, env)
	    | _ -> failwith "array_pop")
	| ("array_values", [e]) -> 
	    let v, env = eval env e in
	    let vs =
	      match v with
		Vvar x ->
		  Alias.Vset.fold (fun w ys ->
		    match w with
		      Alias.Varray (x,_,_) -> Vvar x::ys
		    | _ -> ys) (Alias.lookup_var alias_env (Alias.Vvar x)) [] 
	      | Varray (x,y) -> [Vvar x]
	      | _ -> [] in
	    let env = List.fold_right 
		(fun v env -> extend x v env) vs env in
	    (Varray (x,y), env)
	| ("array_keys", [e]) -> 
	    let v, env = eval env e in
	    let vs =
	      match v with
		Vvar x ->
		  Alias.Vset.fold (fun w ys ->
		    match w with
		      Alias.Varray (_,y,_) -> Vvar y::ys
		    | _ -> ys) (Alias.lookup_var alias_env (Alias.Vvar x)) [] 
	      | Varray (x,y) -> [Vvar y]
	      | _ -> [] in
	    let env = List.fold_right 
		(fun v env -> extend z v env) vs env in
	    (Varray (x,y), env)
	| ("array_merge", [e1; e2]) -> 
	    let v1, env = eval env e1 in
	    let v2, env = eval env e2 in
	    let (xs, ys) = array_val_keys v1 (VarSet.empty, VarSet.empty) in
	    let (xs, ys) = array_val_keys v2 (xs, ys) in
	    let zs = 
	      VarSet.fold (fun x zs ->
		Alias.Vset.fold (fun w zs ->
		  match w with
		    Alias.Vbox z' ->  VarSet.add z' zs
		  | _ -> zs) (Alias.lookup_var alias_env (Alias.Vvar x)) zs)
		xs VarSet.empty  in
	    let env = VarSet.fold (fun z' env -> extend z (Vvar z') env)
		zs env in
	    let env = VarSet.fold (fun y' env -> extend y (Vvar y') env)
		ys env in
	    (Varray (x,y), env)

	| ("array_change_key_case", ([e]|[e; _])) -> 
	    let v, env = eval env e in
	    let vs =
	      match v with
		Vvar x ->
		  Alias.Vset.fold (fun w ys ->
		    match w with
		      Alias.Varray (x,_,_) -> Vvar x::ys
		    | _ -> ys) (Alias.lookup_var alias_env (Alias.Vvar x)) [] 
	      | Varray (x,y) -> [Vvar x]
	      | _ -> [] in
	    let env = List.fold_right 
		(fun v env -> extend x v env) vs env in
	    let vs =
	      match v with
		Vvar x ->
		  Alias.Vset.fold (fun w ys ->
		    match w with
		      Alias.Varray (_,y,_) -> Vvar y::ys
		    | _ -> ys) (Alias.lookup_var alias_env (Alias.Vvar x)) [] 
	      | Varray (x,y) -> [Vvar y]
	      | _ -> [] in
	    let env = List.fold_right 
		(fun v env -> extend y (Vapp("strtolower", [v], loc)) env) vs env in
	    let env = List.fold_right 
		(fun v env -> extend y (Vapp("strtoupper", [v], loc)) env) vs env in
	    (Varray (x,y), env) 
	| ("array_count_values", [e]) -> 
	    let v, env = eval env e in
	    let vs =
	      match v with
		Vvar x ->
		  Alias.Vset.fold (fun w ys ->
		    match w with
		      Alias.Varray (_,y,_) -> Vvar y::ys
		    | _ -> ys) (Alias.lookup_var alias_env (Alias.Vvar x)) [] 
	      | Varray (x,y) -> [Vvar y]
	      | _ -> [] in
	    let env = extend x Vint env in
	    let env = extend y Vnull env in
	    let env = List.fold_right 
		(fun v env -> extend y v env) vs env in
	    (Varray (x,y), env)

	| ("key", [e]) -> 
	    let v, env = eval env e in
	    let vs =
	      match v with
		Vvar x ->
		  Alias.Vset.fold (fun w ys ->
		    match w with
		      Alias.Varray (_,y,_) -> Vvar y::ys
		    | _ -> ys) (Alias.lookup_var alias_env (Alias.Vvar x)) [] 
	      | Varray (x,y) -> [Vvar y]
	      | _ -> [] in
	    let env = List.fold_right 
		(fun v env -> extend x v env) vs env in
	    (Vvar x, env)
	| ("key", es) -> 
	    let vs, env = eval_list env es in
	    (match vs with
	      _::v::_ ->
		let vs =
		  match v with
		    Vvar x ->
		      Alias.Vset.fold (fun w ys ->
			match w with
			  Alias.Varray (_,y,_) -> Vvar y::ys
			| _ -> ys) (Alias.lookup_var alias_env (Alias.Vvar x)) [] 
		  | Varray (x,y) -> [Vvar y]
		  | _ -> [] in
		let env = List.fold_right 
		    (fun v env -> extend x v env) vs env in
		(Vvar x, env)
	    | _ -> failwith "array_search")
	| ("each", es) -> (* NOT CORRECT *)
	    let vs, env = eval_list env es in
	    (match vs with
	      v::_ -> 
		let env = extend y (Vstring "value") env in
		let env = extend y (Vstring "key") env in
		let env = extend y Vint env in
		let (xs, ys) = array_val_keys v (VarSet.empty, VarSet.empty) in
		let zs = 
		  VarSet.fold (fun x zs ->
		    Alias.Vset.fold (fun w zs ->
		      match w with
			Alias.Vbox z' ->  VarSet.add z' zs
		      | _ -> zs) (Alias.lookup_var alias_env (Alias.Vvar x)) zs)
		    xs VarSet.empty  in
		let env = VarSet.fold (fun z' env -> extend z (Vvar z') env)
		    zs env in
		let env = VarSet.fold (fun y' env -> extend z (Vvar y') env)
		    ys env in
		(Varray (x,y), env)
	    | _ -> failwith "each")
	| ("sprintf", es) -> 
	    let vs, env = eval_list env es in
	    (Vapp ("sprintf", List.map strval vs, loc), env)
	| ("vsprintf", [e1;e2]) -> 
	    let v1, env = eval env e1 in
	    let v2, env = eval env e2 in
	    let xs =
	      match v2 with
		Vvar x ->
		  Alias.Vset.fold (fun w ys ->
		    match w with
		      Alias.Varray (y,_,_) -> y::ys
		    | _ -> ys) (Alias.lookup_var alias_env (Alias.Vvar x)) [] 
	      | Varray (x,_) -> [x]
	      | _ -> [] in
	    let ws = 
	      List.fold_right (fun x ws ->
		Alias.Vset.fold (fun w ws ->
		  match w with
		    Alias.Vbox z' ->  Vvar z':: ws
		  | _ -> ws) (Alias.lookup_var alias_env (Alias.Vvar x)) ws)
		xs []  in
	    (Vapp ("vsprintf", v1::List.map strval ws, loc), env)
	| (("__preg_match_array" | "__ereg_array" | "__eregi_array") as s, [e1;e2]) -> 
	    let v1, env = eval env e1 in
	    let v2, env = eval env e2 in
	    (Varray (x,y), extend z (Vapp (s, [strval v1; strval v2], loc)) env)

	| ("preg_match_all", [e1;e2]) ->
	    let v1, env = eval env e1 in
	    let v2, env = eval env e2 in
	    (Vint, env)
	| ("__preg_match_all", [e1;e2]) ->
	    let v1, env = eval env e1 in
	    let v2, env = eval env e2 in
	    (Varray (x,y), extend z (Vapp ("__preg_match_all", [v1;v2], loc)) env)
	| ("get_class", [e]) -> 
	    let v, env = eval env e in
	    let env =
	      match v with
		Vvar y ->
		  Alias.Vset.fold (fun w env ->
		    match w with
		      Alias.Vobject cname -> extend x (Vstring cname.name) env
		    | _ -> env) (Alias.lookup_var alias_env (Alias.Vvar y)) env
	      | Vobject cname -> extend x (Vstring cname) env 
	      | _ -> env in
	    Vvar x, env
	| ("get_parent_class", [e]) -> 
	    let v, env = eval env e in
	    let env =
	      Hashtbl.fold (fun cname _ env -> extend x (Vstring cname.name) env)
		ilenv.Ilmisc.class_env env in
	    Vvar x, env
	| (("str_replace" | "preg_replace") as s, es) -> 
	    let vs, env = eval_list env es in
	    (match vs with
	      [v1 ; v2 ; v3] ->
		if may_array v1 || may_array v2 then
		  Il.unsupported loc (fun fmt -> 
		    Format.fprintf fmt "array argument(s) in %a" Il.pp_exp exp)
		else
		  let vs,ws =
		    match v3 with
		      Vvar x ->
			Alias.Vset.fold (fun w (ys,zs) ->
			  match w with
			    Alias.Varray (x,y,_) -> (Alias.Vset.add (Alias.Vvar x) ys, Vvar y::zs)
			  | _ -> (ys, zs)) (Alias.lookup_var alias_env (Alias.Vvar x)) (Alias.Vset.empty, []) 
		    | Varray (x,y) -> Alias.Vset.singleton (Alias.Vvar x), [Vvar y] 
		    | _ -> Alias.Vset.empty, [] in
		  let env = 
		    if Alias.Vset.is_empty vs then env
		    else
		      let vs =
			Alias.Vset.fold (fun w ys ->
			  match w with
			    Alias.Vbox z -> Vvar z::ys
			  | _ -> ys) (Alias.lookup_var' alias_env vs) [] in
		      let env = List.fold_right 
			  (fun v env -> extend z (Vapp (s, [strval v1; strval v2; strval v], loc)) env) vs env in
		      List.fold_right 
			(fun v env -> extend y v env) ws env in
		  let env = extend x (Vapp (s, [strval v1; strval v2; strval v3], loc)) env in
		  (Vvar x, env)
	    | _ -> failwith ("Wrong number of arguments for "^s))
	| (s, es) -> 
	    let vs, env = eval_list env es in
	    if List.mem s Phpprim.stringops then
	      let (ts1, ts2, _) = Phpprim.find_stringop_type s in
	      let rec loop vs ts =
		match (vs, ts) with
		  ([], ts) -> []
		| (v::vs, Valuespec.Vstring::ts) -> strval v :: loop vs ts
		| (v::vs, _::ts) -> v::loop vs ts
		| _ -> failwith "too many arguments" in
	      let vs = loop vs (ts1@ts2) in
	      (Vapp (s, vs, loc), env)
	    else if List.mem s Phpprim.boolops then (Vbool, env)
	    else failwith ("ilextract: "^s))
  and eval_list env es = List.fold_right 
      (fun e (vs,env) -> 
	let v, env = eval env e in
	v::vs, env) es ([],env) in

  let eval_lv env lv =
    match lv with
      LVar x -> [Vvar x], env
    | LArray1 lv -> 
	let ys = Alias.lookup_var alias_env (Alias.Vvar lv) in
	Alias.Vset.fold
	  (fun w (ls, env) ->
	    match w with
	      Alias.Varray (y,z,_) -> 
		(Vvar y::ls, extend z Vint env)
	    | _ -> (ls, env)) ys ([], env) 
    | LArray2 (lv, e) -> 
	let v2, env = eval env e in 
	let ys = Alias.lookup_var alias_env (Alias.Vvar lv) in
	(match v2 with
	  Vstring s ->
	    Alias.Vset.fold
	      (fun w (ls, env) ->
		match w with
		  Alias.Varray (y,z,amap) when StringMap.mem s amap -> 
		    (Vvar (StringMap.find s amap)::ls, extend z v2 env)
		| Alias.Varray (y,z,_) -> (Vvar y::ls, extend z v2 env)
		| _ -> (ls, env)) ys ([], env)
	| Vvar x ->
	    let ws' = Alias.lookup_var alias_env (Alias.Vvar x) in
	    Alias.Vset.fold
	      (fun w' (ls, env) ->
		match w' with
		  Alias.Vstringval s ->
		    Alias.Vset.fold
		      (fun w (ls, env) ->
			match w with
			  Alias.Varray (y,z,amap) when StringMap.mem s amap -> 
			    (Vvar (StringMap.find s amap)::ls, extend z v2 env)
			| Alias.Varray (y,z,_) -> (Vvar y::ls, extend z v2 env)
			| _ -> (ls, env)) ys (ls, env)
		| _ ->
		    Alias.Vset.fold
		      (fun w (ls, env) ->
			match w with
			  Alias.Varray (y,z,_) -> 
			    (Vvar y::ls, extend z v2 env)
			| _ -> (ls, env)) ys (ls, env)) ws' ([], env)
	| _ -> 
	    Alias.Vset.fold
	      (fun w (ls, env) ->
		match w with
		  Alias.Varray (y,z,_) -> 
		    (Vvar y::ls, extend z v2 env)
		| _ -> (ls, env)) ys ([], env))
    | LObjRef (lv, m) -> 
	let ys = Alias.lookup_var alias_env (Alias.Vvar lv) in
	let ls =
	  Alias.Vset.fold
	    (fun w ls ->
	      match w with
		Alias.Vobject cname -> 
		  let ivenv, a, b, _ =
		    Ilmisc.find_class ilenv cname in
		  let z,_ = 
		    try StringMap.find m ivenv with Not_found -> (a,b) in
		  Vvar z::ls
	      | _ -> ls) ys [] in
	ls, env in

  let eval_lv' env lv =
    match lv with
      LVar x -> [x], env
    | LArray1 lv -> 
	let ys = Alias.lookup_var alias_env (Alias.Vvar lv) in
	Alias.Vset.fold
	  (fun w (ls, env) ->
	    match w with
	      Alias.Varray (y,z,_) -> 
		(y::ls, extend z Vint env)
	    | _ -> (ls, env)) ys ([], env)
    | LArray2 (lv, e) -> 
	let v2, env = eval env e in 
	let ys = Alias.lookup_var alias_env (Alias.Vvar lv) in
	(match v2 with
	  Vstring s ->
	    Alias.Vset.fold
	      (fun w (ls, env) ->
		match w with
		  Alias.Varray (y,z,amap) when StringMap.mem s amap -> 
		    (StringMap.find s amap::ls, extend z v2 env)
		| Alias.Varray (y,z,_) -> (y::ls, extend z v2 env)
		| _ -> (ls, env)) ys ([], env)
	| Vvar x ->
	    let ws' = Alias.lookup_var alias_env (Alias.Vvar x) in
	    Alias.Vset.fold
	      (fun w' (ls, env) ->
		match w' with
		  Alias.Vstringval s ->
		    Alias.Vset.fold
		      (fun w (ls, env) ->
			match w with
			  Alias.Varray (y,z,amap) when StringMap.mem s amap -> 
			    (StringMap.find s amap::ls, extend z v2 env)
			| Alias.Varray (y,z,_) -> (y::ls, extend z v2 env)
			| _ -> (ls, env)) ys (ls, env)
		| _ ->
		    Alias.Vset.fold
		      (fun w (ls, env) ->
			match w with
			  Alias.Varray (y,z,_) -> 
			    (y::ls, extend z v2 env)
			| _ -> (ls, env)) ys (ls, env)) ws' ([], env)
	| _ -> 
	    Alias.Vset.fold
	      (fun w (ls, env) ->
		match w with
		  Alias.Varray (y,z,_) -> 
		    (y::ls, extend z v2 env)
		| _ -> (ls, env)) ys ([], env))
    | LObjRef (lv, m) -> 
	let ys = Alias.lookup_var alias_env (Alias.Vvar lv) in
	let ls =
	  Alias.Vset.fold
	    (fun w ls ->
	      match w with
		Alias.Vobject cname -> 
		  let ivenv, a, b, _ =
		    Ilmisc.find_class ilenv cname in
		  let z,_ = 
		    try StringMap.find m ivenv with Not_found -> (a,b) in
		  z::ls
	      | _ -> ls) ys [] in
	ls, env in

  let rec extend_fparam_list s ys vs es env =
    match (ys, vs, es) with
      ([], [], []) -> env 
    | ([], _, _) -> env       (*  It is OK to supply arguments more than necessary  *)
    | ((y,_,_)::ys, v::vs, e::es) -> extend_fparam_list s ys vs es (extend y v env)
    | ((y,Some const,_)::ys, [], []) -> 
	let v, env = eval_const env const in
	extend_fparam_list s ys [] [] (extend y v env)
(*    | (_, [], []) -> failwith ("Too few arguments :"^s)  *)
    | (_, [], []) -> env
    | _ -> failwith ("extend_fparam_list"^s.name) in

  let rec exec_stmt env s =
    match s with 
    | LocalFun (x, xs, b) -> exec_block env b
    | FunCall (xs, s, es, r, bs) ->
	let vs, env = eval_list env es in
	List.fold_left (fun env (ys,_,zs,r') ->
	  let env = 
	    try
	      extend_fparam_list s ys vs es env 
	    with exn -> List.iter (fun e -> Format.printf "%a" pp_exp e) es; raise exn in
	  let xs, zs, env = 
	    match (xs, zs, r, r') with
	      (x::xs, z::zs, true, true) -> xs, zs, extend x (Vvar z) env
	    | (x::xs, z::zs, true, false)-> xs, zs, env
	    | (x::xs, z::zs, false, true) ->
		let ys = Alias.lookup_var alias_env (Alias.Vvar z) in
		let env =
		  Alias.Vset.fold
		    (fun w env ->
		      match w with
			Alias.Vbox y -> 
			  let env = extend x (Vvar y) env in env
		      | _ -> env) ys env in
		xs, zs, env
	    | _ -> xs, zs, env in
	  extend_list xs (List.map (fun x -> Vvar x) zs) env)
	  env (Ilmisc.fun_env_find s ilenv)
    | ClassMethodCall (xs, cname, mname, es, r, bs) ->
	let vs, env = eval_list env es in
	let classmethod_call (_, ys,_,_, zs,r') env = 
	let env = extend_fparam_list mname ys vs es env in
	let xs, zs, env = 
	  match (xs, zs, r, r') with
	    (x::xs, z::zs, true, true) -> xs, zs, extend x (Vvar z) env
	  | (x::xs, z::zs, true, false)-> xs, zs, env
	  | (x::xs, z::zs, false, true) ->
	      let ys = Alias.lookup_var alias_env (Alias.Vvar z) in
	      let env =
		Alias.Vset.fold
		  (fun w env ->
		    match w with
		      Alias.Vbox y -> 
			let env = extend x (Vvar y) env in env
		    | _ -> env) ys env in
		  xs, zs, env
	  | _ -> xs, zs, env in

	extend_list xs (List.map (fun x -> Vvar x) zs) env in
	List.fold_right (fun m env -> classmethod_call m env)
	  (Ilmisc.find_classmethod ilenv cname mname) env 
    | MethodCall (xs, x, mname, es, r, bs) ->
	let vs, env = eval_list env es in
	let ys = Alias.lookup_var alias_env (Alias.Vvar x) in
	Alias.Vset.fold
	  (fun w env ->
	    match w with
	      Alias.Vobject cname -> 
		(try
		  let (_, ys,this,_, zs,r') = Ilmisc.find_objectmethod ilenv cname mname in
		  let env = extend_fparam_list mname ys vs es env in
		  let env = extend this (Vobject cname.name) env in
		  let xs, zs, env = 
		    match (xs, zs, r, r') with
		      (x::xs, z::zs, true, true) -> xs, zs, extend x (Vvar z) env
		    | (x::xs, z::zs, true, false)-> xs, zs, env
		    | (x::xs, z::zs, false, true) ->
			let ys = Alias.lookup_var alias_env (Alias.Vvar z) in
			let env =
			  Alias.Vset.fold
			    (fun w env ->
			      match w with
				Alias.Vbox y -> 
				  let env = extend x (Vvar y) env in env
			      | _ -> env) ys env in
			xs, zs, env
		    | _ -> xs, zs, env in
		  extend_list xs (List.map (fun x -> Vvar x) zs) env 
		with Not_found -> env)		    
	    | _ -> env)
	  ys env
    | Assign (x, e) -> 
	let v, env = eval env e in extend x v env
    | Define (x, e) -> 
	let v, env = eval env e in extend x v env
    | ExpSt e -> 
	let v, env = eval env e in env
    | DrefAssign (x, exp) -> 
	let v, env = eval env exp in 
	let ys = Alias.lookup_var alias_env (Alias.Vvar x) in
	Alias.Vset.fold
	  (fun w env ->
	    match w with
	      Alias.Vbox y -> 
		let env = extend y v env in
		env
	    | _ -> env) ys env
    | RefAssign (LVar x, lv) -> 
	let lvs, env = eval_lv env lv in 
	List.fold_left (fun env lv -> extend x lv env) env lvs	  
    | RefAssign (x, lv) -> 
	let xs, env = eval_lv' env x in 
	let lvs, env = eval_lv env lv in 
	List.fold_left (fun env x -> 
	  List.fold_left (fun env lv -> extend x lv env) env lvs) env xs  
    | Echo e -> failwith "exec_stmt"
    | Assert (e, x, s) -> 
	let v, env = eval env e in extend x v env
    | Unset _ -> failwith "exec_stmt"
  and exec_block env s =
    match s with 
    | If (e, _,b1, _,b2) -> 
	exec_block (exec_block env b1) b2
    | Switch (e, x, cs) -> 
	let v, env = eval env e in
	let env = extend x v env in
	let exec_case env (g, y, b) = exec_block env b in
	List.fold_left exec_case env cs 
    | LocalCall (x, es) -> 
	let vs, env  = eval_list env es in
	let ys = Hashtbl.find ilenv.Ilmisc.lfun_env x in
	extend_list ys vs env
    | Seq (s,b) -> exec_block (exec_stmt env s) b
    | Stop _ -> env
    | Return es -> 
	let vs, env = eval_list env es in
	extend_list ys vs env in
  exec_block env s


let pp_constraints fmt env =
  VASet.iter (fun (x,v) -> 
    Format.fprintf fmt "%a -> %a@." pp_var x pp_value v) env

let extract ilenv alias_env env s = 
  let function_f env (x, xs, b, ys, r) = exec alias_env ilenv ys env b in
  let class_f env (cname, xs, ms) =
    let ivenv, a, b, _ = Ilmisc.find_class ilenv cname in
    let env = List.fold_left 
	(fun env (x,constopt) -> 
	  match constopt with
	    None -> env
	  | Some c -> 
	      let y, z = StringMap.find x ivenv in
	      let v, env = eval_const env c in
	      extend z v env) env xs in
    List.fold_left (fun env (s,xs,this,b,ys,r) ->
      exec alias_env ilenv ys env b) env ms in
  let main_f env s = exec alias_env ilenv [] env s in
  let env = fold_program main_f function_f class_f s env in
  Options.show 1 (fun fmt -> 
    pp_constraints fmt env);
  let ovars, avars = Ilmisc.ovars s in
  match ovars with
  | [x] -> x, avars, env
  | xs -> 
      let x = fresh_var () in
      let env = List.fold_right (fun y env -> extend x (Vvar y) env) xs env in
      x, avars, env

type 'a rhsval =
    Rvar of 'a
  | Rother 
  | Rint
  | Rnull
  | Rfloat
  | Rbool
  | Rboolval of bool
  | Rresource
  | Robject
  | Rintval of int

type 'a rhs = 
    Rval of 'a rhsval
  | Rstring of string 
  | Rregexp of Reg.reg
  | Rdtd of string * string
  | Rconcat of 'a rhsval * 'a rhsval
  | Rapp of string * 'a rhsval list * Loc.loc

let pp_rhsval fmt v =
  match v with
    Rvar x -> pp_var fmt x
  | Rint  -> Format.fprintf fmt "Int"
  | Rnull  -> Format.fprintf fmt "Null"
  | Rfloat  -> Format.fprintf fmt "Float"
  | Rintval i -> Format.fprintf fmt "Int%d" i
  | Rbool -> Format.fprintf fmt "Bool"
  | Rboolval b -> Format.fprintf fmt "Bool"
  | Rother  -> Format.fprintf fmt "Top"
  | Rresource  -> Format.fprintf fmt "Resource"
  | Robject  -> Format.fprintf fmt "Robject"

let pp_rhs fmt v =
  match v with
    Rval v -> pp_rhsval fmt v
  | Rstring s -> Format.fprintf fmt "\"%s\"" (String.escaped s)
  | Rregexp r -> Format.fprintf fmt "/%a/" Reg.pp_reg r
  | Rdtd (f,r) -> Format.fprintf fmt "dtd(%s,%s)" f r
  | Rconcat (v1, v2) -> Format.fprintf fmt "%a.%a" pp_rhsval v1 pp_rhsval v2
  | Rapp (s, vs, _) -> Format.fprintf fmt "%s(%a)" s (pp_seq pp_rhsval) vs

let rec trans g v =
  match v with
    Vvar y -> (Rval (Rvar y), g)
  | Vstring s -> (Rstring s, g)
  | Vregexp r -> (Rregexp r, g)
  | Vdtd (f,r) -> (Rdtd (f,r), g)
  | Vconcat (v1, v2) -> 
      let x1, g = trans' g v1 in
      let x2, g = trans' g v2 in
      (Rconcat (x1, x2), g)
  | Vapp (s, vs, loc) ->
      let xs, g = List.fold_right (fun v (xs,g) -> 
	let x, g = trans' g v in (x::xs, g)) vs ([],g) in
      (Rapp (s, xs, loc), g)
  | Varray _ ->  (Rval Rother, g)
  | Vbox ->  (Rval Rother, g)
  | Vint ->  (Rval Rint, g)
  | Vnull ->  (Rval Rnull, g)
  | Vfloat ->  (Rval Rfloat, g)
  | Vbool ->  (Rval Rbool, g)
  | Vboolval b ->  (Rval (Rboolval b), g)
  | Vintval i ->  (Rval (Rintval i), g)
  | Vresource ->  (Rval Rresource, g)
  | Vobject _ ->  (Rval Robject, g)
and trans' g v =
  let r, g = trans g v in
  match r with
    Rval x -> (x, g)
  | _ -> let z = fresh_var() in (Rvar z, (z,r)::g)

let extract ilenv alias_env spec s =
  let x, ys, env = extract ilenv alias_env VASet.empty s in 
  x, ys, VASet.fold (fun (x,v) grammar ->
    let r, grammar = trans grammar v in
    (x,r)::grammar) env [] 

let pp_grammar fmt env =
  List.iter (fun (x, r) ->
    Format.fprintf fmt "%a -> %a@." pp_var x pp_rhs r) env
