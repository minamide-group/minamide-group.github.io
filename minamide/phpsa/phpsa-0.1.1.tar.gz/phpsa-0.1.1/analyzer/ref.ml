open Support
open Il
open Ilmisc

(* 
 *  Precondition: all functions should be closed.
 *  Transforming a program into the form where a variable which may have
 *  aliases has a boxed representation
 *)
 
let rec extend_list bs es ys =
  match (bs, es) with
    (true::bs, Var y::es) -> extend_list bs es (VarSet.add y ys)
  | (true::bs, _::es) -> failwith "extend_list"
  | (b::bs, e::es) -> extend_list bs es ys
  | _ -> ys 

let rec refvar r xs s =
  let refvar_lv xs lv =
    match lv with
      LVar x -> VarSet.add x xs
    | _ -> xs in

  let rec refvar_stmt xs s =
    match s with 
      RefAssign (lv1, lv2) -> refvar_lv (refvar_lv xs lv1) lv2
    | Unset lv -> refvar_lv xs lv
    | LocalFun (_, _, b) -> refvar_block xs b
    | FunCall (zs, _, es, r, bs) 
    | ClassMethodCall (zs, _, _, es, r, bs) 
    | MethodCall (zs, _, _, es, r, bs) ->  
	let xs =
	  match (zs, r) with
	    (z::_, true) -> VarSet.add z xs 
	  | _ -> xs in
	extend_list bs es xs
(*    | Function (_, _, b, _, r) -> 
	if global then refvar global r xs b else xs
    | Class (s, _, ms) -> 
	let refvar_method  xs (x, _, this, b, zs, r) = refvar global r xs b in
	if global then 
	  List.fold_left (fun xs m -> refvar_method xs m) xs ms 
	else xs *)
    | _ -> xs
  and refvar_block xs s =
    match s with 
      If (e, _, s1, _, s2) -> 
	let xs = refvar_block xs s1 in
	refvar_block xs s2
    | Switch (e, _, cs) ->
      let refvar_case xs (g, y, b) = refvar_block xs b in
      List.fold_left refvar_case xs cs  
    | Seq (s, b) -> 
	let xs = refvar_stmt xs s in
	refvar_block xs b
    | Return e when r ->
	(match e with
	  Var x::_ -> VarSet.add x xs
	| _ -> failwith "nonvariable for returning reference")
    | _ -> xs  in
  refvar_block xs s

let refvar_program program =
  let function_f xs (_, _, b, _, r) = refvar r xs b in
  let class_f xs (s, _, ms) =
    let refvar_method xs (x, _, this, b, zs, r) = refvar r xs b in
    List.fold_left (fun xs m -> refvar_method xs m) xs ms in
  let main_f xs b = refvar false xs b in
  fold_program main_f function_f class_f program VarSet.empty 

let rec hil2lil vmap r s =
  let rec hil2lil_exp e =
    match e with 
      Var x -> 
	if VarSet.mem x vmap then Dref (x, fresh_var ()) else Var x
    | Prim (p, es, i) -> Prim (p, hil2lil_exp_list es, i)
    | App (s, es, x) -> App (s, hil2lil_exp_list es, x)
    | Dref _ -> failwith "ref"
    | Bool _ | String _ | Float _ | Int _ | Const _ 
    | Null | Vspec _ | ConstExp _ -> e
  and hil2lil_exp_list es = List.map hil2lil_exp es in

  let hil2lil_var x =
    if VarSet.mem x vmap 
    then 
      let y = fresh_var () in
      (y, fun b -> Seq (Assign (y, Dref (x, fresh_var ())), b))
    else (x, fun b -> b) in

  let hil2lil_lv lv =
    match lv with
      LVar x -> LVar x, (fun b -> b)
    | LArray1 lv ->  
	let lv, k = hil2lil_var lv in
	LArray1 lv, k
    | LArray2 (lv, e)  ->  
	let lv, k = hil2lil_var lv in
	LArray2 (lv, hil2lil_exp e), k
    | LObjRef (lv, m)  ->  
	let lv, k = hil2lil_var lv in
	LObjRef (lv, m), k in

  let rec hil2lil_fps bs es = 
    match (bs, es) with
      (true::bs, Var y::es) -> Var y:: hil2lil_fps bs es
    | (true::bs, _::es) -> failwith "hil2lil_fps"
    | (b::bs, e::es) -> hil2lil_exp e::hil2lil_fps bs es
    | ([], []) -> []
    | ([], es) -> hil2lil_exp_list es
    | (_, []) -> [] in

  let rec hil2lil_stmt s =
    match s with 
    | LocalFun (x, xs, b) -> 
	LocalFun (x, xs, hil2lil_block b)
    | FunCall (xs, s, es, b, bs) ->
      let es = hil2lil_fps bs es in
      FunCall (xs, s, es, b, bs)
    | ClassMethodCall (xs, cname, mname, es, r, bs) ->
      let es = hil2lil_fps bs es in
      ClassMethodCall (xs, cname, mname, es, r, bs)
    | MethodCall (xs, y, mname, es, r, bs) -> failwith "MethodCall"
(*    | MethodCall (xs, y, mname, es, r, bs) ->
      let y, k = hil2lil_var y in
      let es = hil2lil_fps bs es in
      k (MethodCall (xs, y, mname, es, r, bs)) *)
    | Assign (x, e) ->
      let e = hil2lil_exp e in
      if VarSet.mem x vmap then DrefAssign (x, e) else Assign (x, e)
    | RefAssign (x, lv) -> failwith "RefAssign"
    | Unset lv -> failwith "Unset"
    | DrefAssign _ -> failwith "DrefAssign"
    | ExpSt e -> ExpSt (hil2lil_exp e)
    | Define (x,e) -> Define (x, hil2lil_exp e)
    | Echo e -> Echo (hil2lil_exp e)
    | Assert (e, x, s) -> Assert (hil2lil_exp e, x, s)
  and hil2lil_block s =
    match s with 
    | If (e, x1, s1, x2, s2) -> 
	If (hil2lil_exp e, x1, hil2lil_block s1, x2, hil2lil_block s2)
    | Switch (e, x, cs) -> 
	let hil2lil_case (g, y, b) = (g, y, hil2lil_block b) in
	Switch (hil2lil_exp e, x, List.map hil2lil_case cs)
    | LocalCall (x, es) -> 
	LocalCall (x, hil2lil_exp_list es)
    | Seq (MethodCall (xs, y, mname, es, r, bs),b) ->
      let y, k = hil2lil_var y in
      let es = hil2lil_fps bs es in
      k (Seq (MethodCall (xs, y, mname, es, r, bs), hil2lil_block b))
    | Seq (RefAssign (lv1, lv2),b) -> 
	let lv1, k1 = hil2lil_lv lv1 in
	let lv2, k2 = hil2lil_lv lv2 in
	k1 (k2 (Seq (RefAssign (lv1, lv2), hil2lil_block b)))
    | Seq (Unset lv,b) -> 
	let lv, k = hil2lil_lv lv in
	let x = fresh_var () in
	k (Seq (Assign (x, mkprim' (NewRef, [])),
		Seq (RefAssign (lv, LVar x), hil2lil_block b)))
    | Seq (s,b) -> 
	let s = hil2lil_stmt s in
	Seq (s, hil2lil_block b) 
    | Stop (i, optx) -> Stop (i, optx)
    | Return es -> 
	let es =
	  match (es, r) with
	    ([],_) -> []
	  | (Var x::es, true) -> Var x::hil2lil_exp_list es
	  | (_::es, true) -> failwith "non variable for returning reference" 
	  | _ -> hil2lil_exp_list es in
	Return es in
  hil2lil_block s

let hil2lil_program program = 
  let hil2lil_body xs b r =
    let _ = List.fold_left (fun vs (y, _, b) ->
      if VarSet.mem y vs then failwith "duplicate formal paprameters"
      else VarSet.add y vs) VarSet.empty xs in
    let ps, ps' = 
      List.fold_left 
	(fun (ps, ps') (y, _, b) -> if b then (VarSet.add y ps, ps') 
	else (ps, VarSet.add y ps')) (VarSet.empty, VarSet.empty) xs in
    let ys = refvar r ps b in
    let b = hil2lil ys r b in
    let qs = VarSet.inter ps' ys in
    (* qs : variables which are for call-by-value and used with reference *)
    let qq' = List.map (fun q -> (q, fresh_var ())) (VarSet.elements qs) in
    let xs = List.map 
	(fun (y, copt, b) ->
	  try (List.assoc y qq', copt, b) with Not_found -> (y, copt, b))
	xs in
    let b = List.fold_left (fun b (q,q') ->
      Seq (DrefAssign (q, Var q'), b)) b qq' in
    let xs = List.map (fun (y, copt, b) ->
      let copt = 
	match (b, copt) with
	  (true, Some c) -> Some (Il.ConstBox (c, fresh_var ()))
	| _ -> copt in
      (y, copt, b)) xs in
    let b = VarSet.fold (fun x b -> Seq (Assign (x, mkprim' (NewRef, [])), b)) (VarSet.diff ys ps) b in
    (xs, b) in

  let function_f (x, xs, b, zs, r) =
    let xs, b = hil2lil_body xs b r in
    (x, xs, b, zs, r) in
  let class_f (s, xs, ms) =
    let hil2lil_method  (x, xs, this, b, zs, r) =
(*    let xs, b = hil2lil_body ((this,None,false)::xs) b r in
   (x, xs, this, b, zs, r) in *)
      match hil2lil_body ((this,None,false)::xs) b r with
	(this,_,_)::xs, b  -> (x, xs, this, b, zs, r) 
      | _ -> failwith "hil2lil_method" in 
    (s, xs, List.map hil2lil_method ms) in
  let main_f b =
    let b = program.main in
    let vmap = refvar false VarSet.empty b in
    let b = hil2lil vmap false b in
    let ys = VarSet.filter (fun x -> x.scope) vmap in
    VarSet.fold (fun x b -> Seq (Assign (x, mkprim' (NewRef, [])), b)) ys b in
  map_program main_f function_f class_f program

(* remove aliases : removing aliases of variables *)

(* 
 * This is basically available expressions analysis. 
 * Note: function calls DO preserve reference assignment except super globals.
 *       (assuming that there are no expressions in the form 
 *        $GLOBALS["abc"] =& e )
 *
 * Only the variables x and y in x =& y are considered.
 *)


let rec mayalias_stmt xs s =
  match s with 
    LocalFun (x, ys, b) -> mayalias_block xs b
  | _ -> xs
and mayalias_block xs s =
  match s with 
    Stop _ | Return _  -> xs
  | If (e, _,s1, _, s2) -> 
      let xs = mayalias_block xs s1 in
      mayalias_block xs s2
  | Switch (e, _, cs) -> 
      let mayalias_case xs (_,_,b) = mayalias_block xs b in
      List.fold_left mayalias_case xs cs 
  | LocalCall (x, es) -> xs
  | Seq (RefAssign (LVar x,y),b) -> VarSet.add x (mayalias_block xs b)
  | Seq (RefAssign (x,y),b) -> mayalias_block xs b
  | Seq (FunCall (x::_, _, _, true, _), b) 
  | Seq (ClassMethodCall (x::_, _, _, _, true, _), b)
  | Seq (MethodCall (x::_, _, _, _, true, _), b) ->
      let xs = mayalias_block xs b in
      VarSet.add x xs
  | Seq (s,b) -> 
      let xs = mayalias_stmt xs s in
      mayalias_block xs b

let rec mayalias_stmt (xs, ys) s =
  match s with 
    LocalFun (x, _, b) -> mayalias_block (xs, ys) b
  | _ -> (xs, ys)
and mayalias_block (xs,ys) s =
  match s with 
    Stop _ | Return _  -> (xs, ys)
  | If (e, _,s1, _, s2) -> 
      let (xs,ys) = mayalias_block (xs,ys) s1 in
      mayalias_block (xs,ys) s2
  | Switch (e, _, cs) -> 
      let mayalias_case (xs,ys) (_,_,b) = mayalias_block (xs,ys) b in
      List.fold_left mayalias_case (xs,ys) cs 
  | LocalCall (x, es) -> (xs, ys)
  | Seq (RefAssign (LVar x, LVar y),b) -> mayalias_block (VarSet.add x xs, VarSet.add y ys) b
  | Seq (RefAssign (x,y),b) -> mayalias_block (xs, ys) b
  | Seq (s,b) -> 
      mayalias_block (mayalias_stmt (xs,ys) s) b

let map_meet env env' =
  if env == env' then env
  else
    VarMap.fold 
      (fun x y env'' -> 
	if VarMap.mem x env' then
	  let y =
	    match (y, VarMap.find x env') with
	      (Some y, Some y') when y = y' -> Some y
	    | _ -> None in
	  VarMap.add x y env'' else VarMap.add x y env'') env env'

let rec lv_loop n xs ys old_lvmap s =
  let kill env x =
    if VarSet.mem x ys then
      VarMap.fold 
	(fun v w env -> if w = Some x then env else VarMap.add v w env) env
	VarMap.empty 
    else env in

  let env_add x v env =
    if VarSet.mem x xs then VarMap.add x v env else env in

  let rec lv_stmt lvmap s =
    match s with 
      LocalFun (x, ys, b) -> 
	let env = try VarMap.find x old_lvmap with Not_found -> VarMap.empty in
(*	Format.printf "lfun: %s@." (string_of_var x);
	VarMap.iter (fun x v -> 
	  match v with
	    Some y -> Format.printf "%s:%s," (string_of_var x)
		(string_of_var y)
	  | _ -> Format.printf "%s," (string_of_var x)) env; 
	Format.printf "@."; *)
	lv_block lvmap env b
    | _ -> lvmap
  and lv_block lvmap env s =
    match s with 
      Stop _ | Return _  -> lvmap
    | If (e, _,s1, _, s2) -> 
	let lvmap = lv_block lvmap env s1 in
	lv_block lvmap env s2
    | Switch (e, _, cs) -> 
	let lv_case lvmap (_,_,b) = lv_block lvmap env b in
	List.fold_left lv_case lvmap cs 
    | LocalCall (x, es) ->
(*	Format.printf "lcall: %s@." (string_of_var x);
	VarMap.iter (fun x v -> 
	  match v with
	    Some y -> Format.printf "%s:%s," (string_of_var x)
		(string_of_var y)
	  | _ -> Format.printf "%s," (string_of_var x)) env; 
	Format.printf "@."; *)
	let env =
	  try let env' = VarMap.find x lvmap in 
(*	  Format.printf "env'@." ;
	  VarMap.iter (fun x v -> 
	    match v with
	      Some y -> Format.printf "%s:%s," (string_of_var x)
		  (string_of_var y)
	    | _ -> Format.printf "%s," (string_of_var x)) env'; 
	  Format.printf "@."; *)
	  map_meet env env'
	  with Not_found -> env in
	VarMap.add x env lvmap
    | Seq (RefAssign (LVar x,LVar y),b) -> 
	let env = kill env x in 
(*	let v = if VarSet.mem y xs then None else Some y in *)
	let v = Some y in
   	let env = VarMap.add x v env in 
(*	Format.printf "%s =& %s@." (string_of_var x) (string_of_var y); *)
	lv_block lvmap env b
    | Seq (RefAssign (LVar x,y),b) -> 
	let env = kill env x in 
   	let env = env_add x None env in  (* Key *)
	lv_block lvmap env b
    | Seq (RefAssign (x,y),b) -> lv_block lvmap env b
    | Seq (Unset (LVar x),b) -> 
	let env = kill env x in 
   	let env = env_add x None env in  (* Key *)
	lv_block lvmap env b
    | Seq (Unset lv,b) -> lv_block lvmap env b
    | Seq (FunCall (x::_, _, _, true, _), b) 
    | Seq (ClassMethodCall (x::_, _, _, _, true, _), b)
    | Seq (MethodCall (x::_, _, _, _, true, _), b) ->
	let env = kill env x in 
   	let env = VarMap.add x None env in 
	lv_block lvmap env b
    | Seq (s,b) -> 
	let lvmap = lv_stmt lvmap s in
	lv_block lvmap env b in

  let lvmapeq lvmap1 lvmap2 =
    VarMap.equal (VarMap.equal (=)) lvmap1 lvmap2 in

  let () = 
    Options.show 2 (fun fmt -> Format.printf "LOOP! %d@." n) in
  let env = VarSet.fold (fun x env ->
    VarMap.add x None env) xs VarMap.empty in
  let lvmap = lv_block old_lvmap env s in
  if lvmapeq lvmap old_lvmap  then lvmap 
  else lv_loop (n+1) xs ys lvmap s

let lv xs ys s = lv_loop 0 xs ys VarMap.empty s 

let rec remove_aliases s =
  let (xs, ys) = mayalias_block (VarSet.empty, VarSet.empty) s in
  let lvmap = lv xs ys s in

  let rename_var vmap x =
    try VarMap.find x vmap with _ -> x in

  let rec rename_exp vmap e =
    match e with 
      Var x -> Var (rename_var vmap x)
    | Dref _ -> failwith "rename"
    | Prim (p, es, i) -> Prim (p, rename_exp_list vmap es, i)
    | App (s, es, x) -> App (s, rename_exp_list vmap es, x)
    | e -> e
  and rename_exp_list vmap es =
    List.map (rename_exp vmap) es in

  let rename_lv vmap lv =
    match lv with
      LVar x -> LVar (rename_var vmap x)
    | LArray1 lv -> LArray1 (rename_var vmap lv)
    | LArray2 (lv, e) -> LArray2 (rename_var vmap lv, rename_exp vmap e)
    | LObjRef (lv, m) -> LObjRef (rename_var vmap lv, m) in

   let mkrename env =
     VarMap.fold (fun x y vmap ->
       match y with
	 Some y -> VarMap.add x y vmap
       | _ -> vmap) env VarMap.empty in 

   let kill vmap x =
     VarMap.fold 
       (fun v w vmap -> if x = w then vmap else VarMap.add v w vmap) vmap
       VarMap.empty in

  let rec rename_stmt vmap s =
    match s with 
    | LocalFun (x, xs, b) -> 
	let vmap = 
	  try mkrename (VarMap.find x lvmap) 
	  with Not_found -> VarMap.empty in
	LocalFun (x, xs, rename_block vmap b) 
    | FunCall (xs, s, es, b, bs) ->
      let es = rename_exp_list vmap es in
      FunCall (xs, s, es, b, bs)
    | ClassMethodCall (xs, cname, mname, es, r, bs) ->
      let es = rename_exp_list vmap es in
      ClassMethodCall (xs, cname, mname, es, r, bs)
    | MethodCall (xs, e, mname, es, r, bs) ->
      let e = rename_var vmap e in
      let es = rename_exp_list vmap es in
      MethodCall (xs, e, mname, es, r, bs)
    | Assign (x, e) ->
      let e = rename_exp vmap e in
      let x = rename_var vmap x in
      Assign (x, e)
    | ExpSt e -> ExpSt (rename_exp vmap e)
    | Define (x,e) -> Define (x,rename_exp vmap e)
    | DrefAssign (x, e) -> failwith "DRefAssign"
    | RefAssign (x,y) -> failwith "RefAssign"
    | Unset x -> failwith "Unset"
    | Echo e -> Echo (rename_exp vmap e)
    | Assert (e, x, s) -> Assert (rename_exp vmap e, x, s)
  and rename_block vmap s =
    match s with 
    | If (e, x1, s1, x2, s2) -> 
	If (rename_exp vmap e, 
	    x1, rename_block vmap s1, x2, rename_block vmap s2)
    | Switch (e, x, cs) ->
	let rename_case (g, y, b) = (g, y, rename_block vmap b) in
	Switch (rename_exp vmap e, x, List.map rename_case cs)
    | LocalCall (x, es) -> 
	LocalCall (x, rename_exp_list vmap es)
    | Seq (RefAssign (LVar x,LVar y),b) -> 
	let vmap = kill vmap x in
	let vmap = VarMap.add x y vmap in
	Seq (RefAssign (LVar x,LVar y), rename_block vmap b) 
    | Seq (RefAssign (LVar x, lv),b) -> 
	let lv = rename_lv vmap lv in
   	let vmap = VarMap.remove x vmap in 
	let vmap = kill vmap x in
	Seq (RefAssign (LVar x,lv), rename_block vmap b) 
    | Seq (RefAssign (x, lv),b) -> 
	let x = rename_lv vmap x in
	let lv = rename_lv vmap lv in
	Seq (RefAssign (x,lv), rename_block vmap b) 
    | Seq (Unset (LVar x),b) -> 
   	let vmap = VarMap.remove x vmap in 
	let vmap = kill vmap x in
	Seq (Unset (LVar x), rename_block vmap b) 
    | Seq (Unset lv,b) -> 
	let lv = rename_lv vmap lv in
	Seq (Unset lv, rename_block vmap b) 
    | Seq (FunCall (x::_, _, _, true, _) as s , b) 
    | Seq (ClassMethodCall (x::_, _, _, _, true, _) as s, b)
    | Seq (MethodCall (x::_, _, _, _, true, _) as s, b) ->
	let s = rename_stmt vmap s in
	let vmap = kill vmap x in
   	let vmap = VarMap.remove x vmap in 
	Seq (s, rename_block vmap b) 
    | Seq (s,b) -> Seq (rename_stmt vmap s, rename_block vmap b) 
    | Stop (i, optx) -> 
	Stop (i, match optx with
	  None -> None
	| Some x -> Some (rename_var vmap x))
    | Return es -> Return (rename_exp_list vmap es) in
  rename_block VarMap.empty s

let remove_aliases program =
  let function_f (x, xs, b, zs, r) = (x, xs, remove_aliases b, zs, r) in
  let class_f (s, xs, ms) =
    let rename_method (x, xs, this, b, zs, r) =
      (x, xs, this, remove_aliases b, zs, r) in
    (s, xs, List.map rename_method ms) in
  map_program remove_aliases function_f class_f program

(*
 *  Removing dead reference assignments : =& 
 *)

(* 
 * The following is basically live variables analysis. 
 * However, the assignment is not considered as a killing operation.
 * It is because the analysis is to consider liveness of =& .
 *)

let rec lv_exp xs e =
  match e with 
    Var x -> VarSet.add x xs
  | Dref (x,_) -> VarSet.add x xs
  | Int _ | Float _ | String _ | Bool _ | Const _ 
  | Null | Vspec _  | ConstExp _ -> xs
  | Prim (_, es,_) | App (_, es,_) -> lv_exp_list xs es
and lv_exp_list xs es = 
  match es with
    [] -> xs
  | e::es -> lv_exp_list (lv_exp xs e) es

let rec lv_lv xs lv =
  match lv with
    LVar x -> VarSet.add x xs
  | LArray1 x -> VarSet.add x xs
  | LArray2 (x, e) -> lv_exp (VarSet.add x xs) e
  | LObjRef (x, m) -> VarSet.add x xs

let rec lv_stmt zs s =
  match s with 
    ExpSt e | Echo e | Assert (e, _,_) | Define (_,e) -> lv_exp zs e
  | DrefAssign (x, e) -> failwith "RefAssign"
  | RefAssign (x, e) -> failwith "RefAssign"
  | Unset lv -> failwith "Unset"
  | LocalFun (x, ys, b) -> failwith "LocalFun"
  | Assign (x,e) -> VarSet.add x (lv_exp zs e)
  | FunCall (xs,_,es,_,_) -> 
      List.fold_left (fun vs x -> VarSet.add x vs) (lv_exp_list zs es) xs
  | ClassMethodCall (xs,_,_,es,_,_) -> 
      List.fold_left (fun vs x -> VarSet.add x vs) (lv_exp_list zs es) xs
  | MethodCall (xs,e,_,es,_,_) -> 
      List.fold_left (fun vs x -> VarSet.add x vs) (lv_exp_list (VarSet.add e zs ) es) xs

let cflow_find x cflow =
  try VarMap.find x cflow with Not_found -> VarSet.empty 

let cflow_add x y cflow =
  VarMap.add x (VarSet.add y (cflow_find x cflow)) cflow 

let add_genkill x vs ws (genmap, killmap) = 
  Dflow.add x vs genmap, Dflow.add x ws killmap


let rec lv_block lvmap cflow z s =
  match s with 
    Stop (_, None) -> (VarSet.empty, VarSet.empty, lvmap, cflow)
  | Stop (_, Some x) -> (VarSet.singleton x, VarSet.empty, lvmap, cflow)
  | Return es -> (lv_exp_list VarSet.empty es, VarSet.empty, lvmap, cflow)
  | If (e, x1, s1, x2, s2) -> 
      let cflow = Dflow.cflow_add z x1 cflow in
      let vs1, ws1, lvmap, cflow = lv_block lvmap cflow x1 s1 in
      let lvmap = add_genkill x1 vs1 ws1 lvmap in
      let cflow = Dflow.cflow_add z x2 cflow in
      let vs2, ws2, lvmap, cflow = lv_block lvmap cflow x2 s2 in
      let lvmap = add_genkill x2 vs2 ws2 lvmap in
      (lv_exp (VarSet.union vs1 vs2) e, VarSet.empty, lvmap, cflow)
  | Switch (e, x, cs) -> 
      let lv_case (vs, lvmap, cflow) (_, x, b) =
	let cflow = Dflow.cflow_add z x cflow in
	let vs1, ws1, lvmap, cflow = lv_block lvmap cflow x b in
	let lvmap = add_genkill x vs1 ws1 lvmap in
	(VarSet.union vs vs1, lvmap, cflow) in
      let vs, lvmap, cflow = List.fold_left lv_case (VarSet.empty, lvmap, cflow) cs in
      (lv_exp vs e, VarSet.empty, lvmap, cflow)
  | LocalCall (x, es) -> 
      (lv_exp_list VarSet.empty es, VarSet.empty, lvmap, Dflow.cflow_add z x cflow)
  | Seq (RefAssign (LVar x, lv),b) -> 
      let vs, ws, lvmap, cflow = lv_block lvmap cflow z b in
      (lv_lv (VarSet.remove x vs) lv, VarSet.add x ws, lvmap, cflow)
  | Seq (RefAssign (lv1, lv2),b) -> 
      let vs, ws, lvmap, cflow = lv_block lvmap cflow z b in
      (lv_lv (lv_lv vs lv2) lv1, ws, lvmap, cflow)
  | Seq (Unset (LVar x),b) -> 
      let vs, ws, lvmap, cflow = lv_block lvmap cflow z b in
      (VarSet.remove x vs, VarSet.add x ws, lvmap, cflow)
  | Seq (Unset lv,b) -> 
      let vs, ws, lvmap, cflow = lv_block lvmap cflow z b in
      (lv_lv vs lv, ws, lvmap, cflow)
  | Seq (LocalFun (x, ys, b'), b)  -> 
      let vs, ws, lvmap, cflow = lv_block lvmap cflow z b in
      let vs', ws', lvmap, cflow  = lv_block lvmap cflow x b' in
      let vs' = List.fold_left 
	  (fun vs' y -> VarSet.remove y vs') vs' ys in
      let ws' = List.fold_left 
	  (fun ws' y -> VarSet.add y ws') ws' ys in
      (vs, ws, add_genkill x vs' ws' lvmap, cflow)
  | Seq (s,b) -> 
      let vs, ws, lvmap, cflow = lv_block lvmap cflow z b in
      (lv_stmt vs s, ws, lvmap, cflow)

let lv s =
  let z = fresh_var () in
  let cflow = Dflow.cflow_create () in
  let maps = (Dflow.create (), Dflow.create ()) in
  let vs, ws, maps, cflow = lv_block maps cflow z s in
  let genmap, killmap = add_genkill z vs ws maps in
  let (xs, _) = mayalias_block (VarSet.empty, VarSet.empty) s in
  let genmap = 
    let genmap' = Dflow.create () in 
    Hashtbl.iter (fun x ys -> Hashtbl.add genmap' x (VarSet.inter xs ys))
      genmap;
    genmap' in
  let killmap = 
    let killmap' = Dflow.create () in 
    Hashtbl.iter (fun x ys -> Hashtbl.add killmap' x (VarSet.inter xs ys))
      killmap;
    killmap' in
  Dflow.solve genmap killmap cflow z

    
let rec remove_refassignments s =
  let lvmap = lv s in

  let rec exec_block s =
    match s with 
    | If (e, x1, s1, x2, s2) -> 
	let s1, vs1 = exec_block s1 in
	let s2, vs2 = exec_block s2 in
	If (e, x1, s1, x2, s2), lv_exp (VarSet.union vs1 vs2) e
    | Switch (e, x, cs) ->
	let exec_case (g, x, b) (cs, vs) = 
	  let b, vs' = exec_block b in
	  (g, x, b)::cs, VarSet.union vs vs' in
	let cs, vs = List.fold_right exec_case cs ([], VarSet.empty) in
	Switch (e, x, cs), lv_exp vs e
    | Seq (RefAssign (LVar x,lv),b) -> 
	let b, vs = exec_block b in
	if VarSet.mem x vs || x.scope 
	then Seq (RefAssign (LVar x,lv), b), VarSet.remove x (lv_lv vs lv)
	else b, VarSet.remove x vs
    | Seq (RefAssign (lv1,lv2),b) -> 
	let b, vs = exec_block b in
	Seq (RefAssign (lv1,lv2), b), lv_lv (lv_lv vs lv1) lv2
    | Seq (Unset (LVar x),b) -> 
	let b, vs = exec_block b in
	if VarSet.mem x vs || x.scope then
	Seq (Unset (LVar x), b), VarSet.remove x vs
	else b, VarSet.remove x vs
    | Seq (Unset lv,b) -> 
	let b, vs = exec_block b in
	Seq (Unset lv, b), lv_lv vs lv
    | Seq (LocalFun (x, xs, b'), b) -> 
	let b, vs = exec_block b in
	let b', _ = exec_block b' in
	Seq (LocalFun (x, xs, b'), b), vs
    | Seq (s,b) -> 
	let b, vs = exec_block b in 
	Seq (s, b), lv_stmt vs s 
    | LocalCall (x, es) -> 
	let vs = Dflow.find x lvmap in
	s, lv_exp_list vs es
    | Stop (_, None) -> s, VarSet.empty
    | Stop (_,Some x) -> s, VarSet.singleton x
    | Return es -> s, lv_exp_list VarSet.empty es in
  let s, _ = exec_block s in
  s

let remove_refassignments program =
  let function_f (x, xs, b, zs, r) = (x, xs, remove_refassignments b, zs, r) in
  let class_f (s, xs, ms) =
    let exec_method (x, xs, this, b, zs, r) =
      (x, xs, this, remove_refassignments  b, zs, r) in
    (s, xs, List.map exec_method ms) in
  map_program remove_refassignments function_f class_f program



	
 
