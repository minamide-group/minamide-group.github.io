open Support 
open Il

let eval_var env x =
  if not (VarMap.mem x env) then failwith ("free variable"^(string_of_var x))  
  else 
    match VarMap.find x env with
      Some true ->     
	failwith ("A referece variable for non-reference"^(string_of_var x))
    | _ -> ()

let eval_refvar env x =
  if not (VarMap.mem x env) then failwith ("free variable"^(string_of_var x))  
  else 
    match VarMap.find x env with
      Some false ->
	failwith ("A non-referece variable for reference"^(string_of_var x))
    | _ -> ()

let eval_unknown_var env x =
  if not (VarMap.mem x env) then failwith ("free variable"^(string_of_var x))  

let rec eval env e =
  match e with 
    Var x -> eval_var env x 
  | Dref (x,y) -> eval_refvar env x
  | Prim (p, es, i) -> eval_list env es
  | App (s, es, x) -> eval_list env es
  | e -> ()
and eval_list env es =
  List.iter (eval env) es 
and eval_lv env lv =
  match lv with 
    LVar x -> eval_refvar env x
  | LArray1 lv -> eval_var env lv
  | LArray2 (lv, e) -> eval_var env lv; eval env e
  | LObjRef (lv, m) -> eval_var env lv

let eval' env e =
  match e with
    Var x -> eval_unknown_var env x
  | _ -> eval env e

let eval_list' env es =
  List.iter (eval' env) es

let bind x b env = 
  if VarMap.mem x env then failwith ("multiple definition"^(string_of_var x))
  else VarMap.add x b env

let bind_list env b xs =
  List.fold_left (fun env x -> bind x b env) env xs

let rec eval_fparams env bs es =
  match (bs, es) with
    ([], es) -> eval_list env es
  | (false::bs, e::es) -> eval env e; eval_fparams env bs es
  | (true::bs, Var x::es) -> eval_refvar env x; eval_fparams env bs es
  | (true::bs, _::es) -> failwith "eval_fparam"
  | (_, []) -> ()

let rec eval_rvs env bs es =
  match (bs, es) with
    ([], []) -> ()
  | (false::bs, e::es) -> eval env e; eval_rvs env bs es
  | (true::bs, Var x::es) -> eval_refvar env x; eval_rvs env bs es
  | _ -> failwith "eval_rvs"

let return_type zs r =
  match zs with
    z::zs -> r::List.map (fun z -> false) zs
  | _ -> failwith "return_type"

let rec exec_top zs env b = 
  let rec exec env s =
    match s with 
    | LocalFun (x, xs, b) -> failwith "LocalFun"
    | DrefAssign (x, e) -> 
	eval_refvar env x; eval env e
    | RefAssign (lv1, lv2)  -> 
	eval_lv env lv1; eval_lv env lv2
    | Assign (x, e) -> failwith "Assign"
    | ExpSt e -> eval env e
    | FunCall (xs, s, es, b, bs) -> failwith "FunCall"
    | ClassMethodCall (xs, cname, mname, es, r, bs) -> failwith "ClassMethodCall"
    | MethodCall (xs, e, mname, es, r, bs) -> failwith "MethodCall"
    | Define (x,e) -> eval env e
    | Echo e -> failwith "Echo"
    | Assert (e, x, s) -> eval env e
    | Unset _ -> failwith "Unset"
  and exec_block env s =
    match s with 
    | If (e, x1, s1, x2, s2) -> 
	eval env e;
	exec_block env s1;
	exec_block env s2
    | Switch (e, x, cs) -> 
	let exec_case (g, y, b) = exec_block env b in
	eval env e;
	List.iter exec_case cs
    | LocalCall (x, es) -> 
	if not (VarMap.mem x env) 
	then failwith ("free local function"^(string_of_var x));
	eval_list' env es
    | Seq (LocalFun (x, xs, b0), b) ->
	let env = bind x None env in
	(exec_block (bind_list env None xs) b0;
	 exec_block env b)
    | Seq (Assign (x, Prim (NewRef, [],_)), b) ->
	exec_block (bind x (Some true) env) b
    | Seq (Assign (x, e), b) ->
	eval env e;
	exec_block (bind x (Some false) env) b
    | Seq (FunCall (x::xs, s, es, r, bs), b) ->
	eval_fparams env bs es;
	exec_block (bind_list (bind x (Some r) env) (Some false) xs) b
    | Seq (ClassMethodCall (x::xs, cname, mname, es, r, bs), b) ->
	eval_fparams env bs es;
	exec_block (bind_list (bind x (Some r) env) (Some false) xs) b
    | Seq (MethodCall (x::xs, e, mname, es, r, bs), b) ->
	eval_fparams env bs es;
	exec_block (bind_list (bind x (Some r) env) (Some false) xs) b
    | Seq (RefAssign (LVar x, lv), b) ->
	eval_lv env lv;
	exec_block (bind x (Some true) env) b
    | Seq (s,b) -> exec env s; exec_block env b
    | Stop (i, None) -> ()
    | Stop (i, Some x) -> eval_var env x
    | Return es -> eval_rvs env zs es in
  exec_block env b

let exec program = 
  let main_f b = exec_top [] VarMap.empty b in
  let function_f (x, xs, b, zs, r) =
    let env = List.fold_left (fun env (x,_,b) -> bind x (Some b) env) VarMap.empty xs in
    exec_top (return_type zs r) env b in
  let class_f (s, xs, ms) =
    let exec_method (x, xs, this, b, zs, r) =
      let env = VarMap.add this (Some false) VarMap.empty in
      let env = List.fold_left (fun env (x,_,b) -> bind x (Some b) env) env xs in
      exec_top (return_type zs r) env b in
    List.iter exec_method ms in
  iter_program main_f function_f class_f program

