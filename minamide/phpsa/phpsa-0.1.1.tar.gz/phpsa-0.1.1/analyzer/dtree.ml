(*
 * PHP string analyzer
 * Copyright (C) 2006 Yasuhiko Minamide
 *)
module CharMap = 
  Map.Make(struct 
    type t = char
    let compare = compare
  end)

type dtree = Dt of dtree CharMap.t

let empty = Dt CharMap.empty

let rec add cs ((Dt dmap) as dtree) =
  match cs with
    [] -> dtree
  | c::cs -> 
      let dtree' = try CharMap.find c dmap with Not_found -> Dt CharMap.empty in
      Dt (CharMap.add c (add cs dtree') dmap)

let rec is_prefix (Dt dmap) cs =
  match cs with
    [] -> true
  | c::cs -> 
      try is_prefix (CharMap.find c dmap) cs 
      with Not_found -> false



  
