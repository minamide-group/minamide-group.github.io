(*
 * PHP string analyzer
 * Copyright (C) 2006 Yasuhiko Minamide
 *)
open Support

let elm2int_tbl = Hashtbl.create 49 
let elm_id = ref 0

let register_elm elm =
  if not (Hashtbl.mem elm2int_tbl elm) then 
    (Hashtbl.add elm2int_tbl elm (!elm_id);
     incr elm_id)

let elm2int elm = try Hashtbl.find elm2int_tbl elm with Not_found -> failwith elm

let head_misc = [ "SCRIPT"; "STYLE"; "META"; "LINK"; "OBJECT"]
let heading = ["H1"; "H2"; "H3"; "H4"; "H5"; "H6"]
let list = ["UL"; "OL"; "DIR"; "MENU"]
let preformatted = ["PRE"]
let fontstyle = ["TT"; "I"; "B"; "U"; "S"; "STRIKE"; "BIG"; "SMALL"]
let phrase = ["EM"; "STRONG"; "DFN"; "CODE"; "SAMP"; "KBD"; "VAR"; "CITE"; "ABBR"; "ACRONYM"]
let special = ["A"; "IMG"; "APPLET"; "OBJECT"; "FONT"; "BASEFONT"; "BR"; "SCRIPT"; 
	       "MAP"; "Q"; "SUB"; "SUP"; "SPAN"; "BDO"; "IFRAME"]
let formctrl = ["INPUT"; "SELECT"; "TEXTAREA"; "LABEL"; "BUTTON"]
let inline = fontstyle@phrase@special@formctrl
let block = ["P"]@heading@list@preformatted@
  ["DL"; "DIV"; "CENTER"; "NOSCRIPT"; "NOFRAMES"; "BLOCKQUOTE"; "FORM"; "ISINDEX"; "HR";
   "TABLE"; "FIELDSET"; "ADDRESS"]
let flow = block@inline
let pre_exclusion = ["IMG"; "OBJECT"; "APPLET"; "BIG"; "SMALL"; "SUB"; "SUP"; "FONT"; "BASEFONT"]

let allelms = flow@head_misc@
  ["DT"; "DD"; "LI"; "THEAD"; "TFOOT"; "TBODY"; "TR"; "TH"; "TD"; "COLGROUP"; "COL"; "AREA";  "PARAM"; 
   "OPTION"; "BASE";  "HTML"; "HEAD"; "TITLE"; "BODY"; "CAPTION";  "INS"; "DEL"; "LEGEND"; "OPTGROUP"]

let () = List.iter register_elm allelms 

let int2elm_tbl = Hashtbl.create 49 
let () = 
  Hashtbl.iter (fun elm n -> 
    Hashtbl.add int2elm_tbl n elm) elm2int_tbl
let int2elm i = try Hashtbl.find int2elm_tbl i with Not_found -> failwith ("int2elm"^string_of_int i)

module ElmSet = 
  Set.Make(struct
    type t = int
    let compare = compare
  end)

let elms2is elms = List.fold_left (fun is elm -> ElmSet.add (elm2int elm) is) ElmSet.empty elms

let mhead_misc = elms2is head_misc
let mheading = elms2is heading
let mlist = elms2is list
let mpreformatted = elms2is preformatted 
let mfontstyle = elms2is fontstyle 
let mphrase = elms2is phrase
let mspecial = elms2is special
let mformctrl = elms2is formctrl
let minline = elms2is inline
let mblock = elms2is block
let mflow = elms2is flow
let mallelms = elms2is allelms
let mblockarea = ElmSet.add (elm2int "AREA") mblock
let mflowparam = ElmSet.add (elm2int "PARAM") mflow
let mform = ElmSet.singleton (elm2int "FORM")
let marea = ElmSet.singleton (elm2int "AREA")
let mpre_exclusion = elms2is pre_exclusion 

(*** implementation of HTML 4.01 Transitional DTD ***)

let optional_empty_spec =
  let tbl = Hashtbl.create 49 in
  let () =
    List.iter (fun elm -> Hashtbl.add tbl (elm2int elm) ())
      ["BASEFONT"; "BR"; "AREA"; "LINK"; "IMG"; "PARAM"; 
       "HR"; "INPUT"; "COL"; "ISINDEX"; "BASE"; "META"] in
  tbl

type cmodel_elms = 
    CMEflow of ElmSet.t
  | CMEcol
  | CMEli
  | CMEtr
  | CMEthtd
  | CMEdtdd
  | CMEpcdata

type cmodel_base = 
    CMstar of cmodel_elms
  | CMplus of cmodel_elms
  | CMhead
  | CMhtml
  | CMtable
  | CMfieldset
  | CMpcdata

type cmodel = cmodel_base * ElmSet.t (* prohibited elements *)

let cmodel_spec_list =
  let empty_elms = ElmSet.empty in
  let cmflowstar_base = CMstar (CMEflow mflow) in
  let cmflowstar = (cmflowstar_base, empty_elms) in
  let cminlinestar_base = CMstar (CMEflow minline) in
  let cminlinestar = (cminlinestar_base, empty_elms) in
  ["P", true, (CMstar (CMEflow minline), empty_elms);
   "DT", true, (CMplus (CMEflow minline), empty_elms);
   "DD", true, (CMplus (CMEflow mflow), empty_elms);
   "LI", true, (CMstar (CMEflow mflow), empty_elms);
   "THEAD", true, (CMplus CMEtr, empty_elms);
   "TFOOT", true, (CMplus CMEtr, empty_elms);
   "TBODY", true, (CMplus CMEtr, empty_elms);
   "TR", true, (CMstar CMEthtd, empty_elms);
   "TH", true, cmflowstar;
   "TD", true, cmflowstar;
   "COLGROUP", true, (CMstar CMEcol, empty_elms);
   "OPTION", true, (CMpcdata, empty_elms);
   "BLOCKQUOTE", false, cmflowstar;
   "Q", false, cminlinestar;
   "PRE", false, (CMstar (CMEflow minline), mpre_exclusion);
   "INS", false, cmflowstar;
   "DEL", false, cmflowstar;
   "UL", false, (CMplus CMEli, empty_elms); 
   "OL", false, (CMplus CMEli, empty_elms);
   "DL", false, (CMplus CMEdtdd, empty_elms);
   "TABLE", false, (CMtable, empty_elms);
   "CAPTION", false, cminlinestar;
   "A", false, (cminlinestar_base, ElmSet.singleton (elm2int "A"));
   "OBJECT", false, cmflowstar;
   "MAP", false, (CMplus (CMEflow mblockarea), empty_elms); 
   "SUB", false, cminlinestar;
   "SUP", false, cminlinestar;
   "SPAN", false, cminlinestar;
   "BDO", false, cminlinestar;
   "FONT", false, cminlinestar;
   "DIV", false, cmflowstar;
   "CENTER", false, cmflowstar;
   "FORM", false, (cmflowstar_base, ElmSet.singleton (elm2int "FORM"));
   "LABEL", false, (cminlinestar_base, ElmSet.singleton (elm2int "LABEL"));
   "ADDRESS", false, cminlinestar;
   "APPLET", false, (CMstar (CMEflow mflowparam), empty_elms);
   "BUTTON", false, (cmflowstar_base,
		     ElmSet.union (elms2is ["A"; "FORM"; "ISINDEX"; "FIELDSET"; "IFRAME"]) mformctrl);
   "DIR", false, (CMplus CMEli, mblock);
   "MENU", false, (CMplus CMEli, mblock); 
   "BODY", false, cmflowstar;
   "HEAD", false, (CMhead, elms2is ["INS"; "DEL"]);
   "HTML", false, (CMhtml, elms2is ["INS"; "DEL"]);
   "TITLE", false, (CMpcdata, empty_elms);
   "SELECT", false, (CMplus (CMEflow (elms2is ["OPTGROUP"; "OPTION"])), empty_elms);
   "OPTGROUP", false, (CMplus (CMEflow (ElmSet.singleton (elm2int "OPTION"))), empty_elms);
   "FIELDSET", false, (CMfieldset, empty_elms);
   "IFRAME", false, cmflowstar;
   "LEGEND", false, cminlinestar;
   "NOFRAMES", false, cmflowstar;
   "NOSCRIPT", false, cmflowstar; 
 ] @ List.map (fun s -> (s, false, cminlinestar)) (fontstyle@phrase@heading) @
   List.map (fun s -> (s, false, (CMpcdata, empty_elms))) ["TEXTAREA"; "SCRIPT"; "STYLE"] 

let cmodel_spec =
  let tbl = Hashtbl.create 49 in
  let () = List.iter (fun (elm,_,cm) -> Hashtbl.add tbl (elm2int elm) cm) cmodel_spec_list in
  tbl

let optional_spec =
  let tbl = Hashtbl.create 49 in
  let () =
    List.iter (fun (elm, b, (cm, es)) -> 
      if b then
	let cm_elm = 
	  match cm with
	    CMstar cm_elm -> cm_elm
	  | CMplus cm_elm -> cm_elm
	  | CMpcdata -> CMEpcdata
	  | _ -> failwith "optional_spec" in
	Hashtbl.add tbl (elm2int elm) cm_elm) cmodel_spec_list in
  tbl

(*** syntatic algera ***)

type bmonoid = 
    Many | Mthtd | Mtr | Mcol | Mcolgroup | Mtbody |  Mtableelm | Mhtmlelm | Mfieldset | Mli | Mdtdd 
  | Mflow of ElmSet.t * int (* the number of occurrences of ISINDEX *)
  | Melm of string 
  | Mheadelm of bool * bool * bool (* TITLE, ISINDEX, BASE *)

type monoid = bmonoid list * ElmSet.t

let pp_elm fmt i = 
  let elm = int2elm i in
  Format.fprintf fmt "<%s>" elm

let pp_bmonoid fmt m =
  match m with
    Many -> Format.pp_print_string fmt "<any>"
  | Mthtd -> Format.pp_print_string fmt "<thtd>"
  | Mtr -> Format.pp_print_string fmt "<tr>"
  | Mcol -> Format.pp_print_string fmt "<col>"
  | Mtableelm -> Format.pp_print_string fmt "<tableelm>"
  | Mheadelm (b1, b2, b3) -> Format.fprintf fmt "<headelm%B%B%B>" b1 b2 b3
  | Mli -> Format.pp_print_string fmt "<li>"
  | Mdtdd -> Format.pp_print_string fmt "<dtdd>"
  | Mcolgroup -> Format.pp_print_string fmt "<colgroup>"
  | Mtbody -> Format.pp_print_string fmt "<tbody>"
  | Mhtmlelm -> Format.pp_print_string fmt "<htmlelm>"
  | Mfieldset -> Format.pp_print_string fmt "<fieldset>"
  | Melm elm -> Format.fprintf fmt "<%s>" elm
  | Mflow (is, i) ->
      Format.fprintf fmt "{%a}%d" (Basic.print_iter ElmSet.iter "," pp_elm) is i

let pp_monoid fmt (m,es) =
  Format.printf "[%a;%a]" (Basic.print_list "," pp_bmonoid) m
    (Basic.print_iter ElmSet.iter "," pp_elm) es

let mop1 i1 i2 = 
  let i = i1 + i2 in
  if i > 2 then 2 else i

let bmop m1 m2 =
  match m1, m2 with
  | Mflow (is1, i1), Mflow (is2, i2) -> Mflow (ElmSet.union is1 is2, mop1 i1 i2)
  | Mthtd, Mthtd -> Mthtd
  | Mtr, Mtr -> Mtr
  | Mcol, Mcol -> Mcol
  | Mli, Mli -> Mli 
  | Mcolgroup, Mcolgroup -> Mcolgroup
  | Mtbody, Mtbody -> Mtbody
  | _, _-> Many

let is_mflow m =
  match m with
    Mflow (is,_) when ElmSet.subset is mflow -> true
  | _ -> false

let is_table_elm m =
  match m with
    Melm "CAPTION" | Mcol | Mcolgroup | Melm "THEAD" |
    Melm "TFOOT" | Mtbody | Mtr -> true
  | _ -> false 

let join_table_elm ms =
  let rec state0 ms oms =
    match ms with
      [] -> Some oms
    | Melm "CAPTION"::ms -> state1 ms (Melm "CAPTION"::oms)
    | Mtr::ms -> state_0 ms oms
    | Mcol::ms -> state_1 ms (Mcol::oms)
    | _ -> state_1 ms oms
  and state_1 ms oms =
    match ms with
      [] -> Some oms
    | Mcol::ms -> state_1 ms oms
    | Mcolgroup::ms -> state3 ms (Mcolgroup::oms)
    | _ -> state4 ms oms
  and state_0 ms oms =
    match ms with
      [] -> Some (Mtr::oms)
    | Melm "TFOOT"::ms -> state6 ms (Melm "TFOOT"::Mtr::oms)
    | Mtbody::ms -> state8 ms (Mtbody::Mtr::oms)
    | Mtr::ms -> state_0 ms oms
    | _ -> None
  and state1 ms oms =
    match ms with
      [] -> Some oms
    | Mcol::ms -> state2 ms (Mcol::oms)
    | Mcolgroup::ms -> state3 ms (Mcolgroup::oms)
    | _ -> state4 ms oms
  and state2 ms oms =
    match ms with
      [] -> Some oms
    | Mcol::ms -> state2 ms oms
    | _ -> state4 ms oms
  and state3 ms oms =
    match ms with
      [] -> Some oms
    | Mcolgroup::ms -> state3 ms oms
    | _ -> state4 ms oms
  and state4 ms oms =
    match ms with
      [] -> Some oms
    | Melm "THEAD"::ms -> state5 ms (Melm "THEAD"::oms)
    | _ -> state5 ms oms
  and state5 ms oms =
    match ms with
      [] -> Some oms
    | Melm "TFOOT"::ms -> state6 ms (Melm "TFOOT"::oms)
    | _ -> state6 ms oms
  and state6 ms oms =
    match ms with
      [] -> Some oms
    | Mtbody::ms -> state8 ms (Mtbody::oms)
    | Mtr::ms -> state7 ms oms
    | _ -> None
  and state7 ms oms =
    match ms with
      [] -> Some (Mtr::oms)
    | Mtbody::ms -> state8 ms (Mtbody::oms)
    | Mtr::ms -> state7 ms oms
    | _ -> None
  and state8 ms oms =
    match ms with
      [] -> Some oms
    | Mtbody::ms -> state8 ms oms
    | Mtr::ms -> state8 ms oms
    | _ -> None in
  match state0 ms [] with
    Some ms -> Some (List.rev ms)
  | None -> None

(*** nonstrict: CAPTION?,(COL?|COLGROUP?),THEAD?,(TR?|TFOOT?) ***)
(***    strict: CAPTION?,(COL?|COLGROUP?),THEAD?,(TR|TFOOT)   ***)

let is_table_cmodel ms =
  let nonstrict = not (!Options.dtdstrict) in
  let rec state0 ms =
    match ms with
      [] -> nonstrict
    | Melm "CAPTION"::ms -> state1 ms 
    | _ -> state1 ms 
  and state1 ms =
    match ms with
      [] -> nonstrict
    | Mcol::ms -> state2 ms 
    | Mcolgroup::ms -> state3 ms
    | _ -> state4 ms 
  and state2 ms =
    match ms with
      [] -> nonstrict
    | Mcol::ms -> state2 ms
    | _ -> state4 ms
  and state3 ms =
    match ms with
      [] -> nonstrict
    | Mcolgroup::ms -> state3 ms
    | _ -> state4 ms
  and state4 ms =
    match ms with
      [] -> nonstrict
    | Melm "THEAD"::ms -> state5 ms
    | _ -> state5 ms
  and state5 ms =
    match ms with
      [] -> nonstrict
    | Melm "TFOOT"::ms -> state6 ms
    | _ -> state6 ms 
  and state6 ms  =
    match ms with
      [] -> nonstrict
    | Mtbody::ms -> state7 ms
    | Mtr::ms -> state7 ms
    | _ -> false
  and state7 ms  =
    match ms with
      [] -> true
    | Mtbody::ms -> state7 ms
    | Mtr::ms -> state7 ms
    | _ -> false in
  state0 ms

let mop' m1 m2 =
  match m1, m2 with
    [], m2 -> m2
  | m1, [] -> m1
  | [Mthtd], Mthtd::ms -> Mthtd::ms
  | [Mflow (is,i)], Mthtd::ms when ElmSet.subset is mflow -> Mflow (is,i)::Mthtd::ms
  | _, Mthtd::ms -> [Many]
  | [Mthtd], Mtr::ms -> Mthtd::Mtr::ms
  | [Mthtd], Melm "TFOOT"::ms -> Mthtd::Melm "TFOOT"::ms
  | [Mthtd], Mtbody::ms -> Mthtd::Mtbody::ms
  | [Mtr], Mtr::ms -> Mtr::ms
  | [Mflow (is,i)], Mtr::ms when ElmSet.subset is mflow -> Mflow (is,i)::Mtr::ms
  | [Mflow (is1,i1)], Mflow (is2,i2)::Mflow (is3,i3)::ms -> 
      let is = ElmSet.union is1 is2 in
      if ElmSet.subset is minline then Mflow (is, mop1 i1 i2)::Mflow (is3,i3)::ms
      else Mflow (ElmSet.union is is3, mop1 i1 (mop1 i2 i3))::ms
  | [Mflow (is1,i1)], Mflow (is2,i2)::ms -> 
      if ElmSet.subset is1 minline && ElmSet.subset is2 mblockarea then Mflow (is1,i1)::Mflow (is2,i2)::ms
      else Mflow (ElmSet.union is1 is2, mop1 i1 i2)::ms
  | [Mflow (is1, i1); Mflow (is2, i2)], Mflow (is3, i3)::Mflow (is4, i4)::ms -> 
      Mflow (ElmSet.union is1 (ElmSet.union is2 (ElmSet.union is3 is4)), mop1 i1 (mop1 i2 (mop1 i3 i4)))::ms
  | [Mflow (is1, i1); Mflow (is2,i2)], Mflow (is3,i3)::ms -> 
      if ElmSet.subset is3 mblockarea then
	Mflow (is1, i1):: Mflow (ElmSet.union is2 is3, mop1 i2 i3)::ms
      else
	Mflow (ElmSet.union is1 (ElmSet.union is2 is3), mop1 i1 (mop1 i2 i3))::ms
  | Mflow (is1,_)::_, Mflow (is3,_)::ms -> [Many]
  | [Mflow (is1, i1)], m2 when List.exists is_table_elm m2 && List.for_all is_table_elm m2 -> 
      if ElmSet.subset is1 mflow then Mflow (is1,i1)::m2 else [Many]
  | m1, m2 when List.for_all is_table_elm m1 && List.for_all is_table_elm m2 ->
      (match join_table_elm (m1@m2) with
	Some m -> m
      | _ -> [Many])
  | [Mheadelm (b11, b12, b13)], [Mheadelm (b21, b22, b23)] ->
      if (b11 && b21) || (b12 && b22) || (b13 && b23) then [Many]
      else [Mheadelm (b11 || b21, b12 || b22, b13 || b23)]
  | [Mheadelm (b1, b2, b3)], [Mflow (is,i)] | [Mflow (is,i)], [Mheadelm (b1, b2, b3)] -> 
      let b = i > 0 in
      let is = ElmSet.remove (elm2int "ISINDEX") is in
      if i = 2 || b2 && b then [Many] 
      else if ElmSet.subset is mhead_misc then [Mheadelm (b1, b2 || b, b3)] else [Many]
  | [Melm "HEAD"], [Melm "BODY"] -> [Mhtmlelm]
  | [Melm "LEGEND"], m2 when List.for_all is_mflow m2 -> [Mfieldset]
  | [Mfieldset], m2 when List.for_all is_mflow m2 -> [Mfieldset]
  | [m1'], [m2'] -> [bmop m1' m2']
  | _ -> [Many]

let mop (m1,es1) (m2,es2) = (mop' m1 m2, ElmSet.union es1 es2)

let elm2m_spec =
  let spec =
    [Mtr, ["TR"];
     Mthtd, ["TH"; "TD"];
     Mcol, ["COL"];
     Mcolgroup, ["COLGROUP"];
     Mtbody, ["TBODY"];
     Melm "CAPTION", ["CAPTION"];
     Melm "THEAD", ["THEAD"];
     Melm "TFOOT", ["TFOOT"];
     Mheadelm (true, false, false), ["TITLE"];
     Mheadelm (false, false, true), ["BASE"];
     Mli, ["LI"];
     Mdtdd, ["DT"; "DD"];
     Mflow (marea, 0), ["AREA"];
     Melm "LEGEND", ["LEGEND"];
     Melm "BODY", ["BODY"];
     Melm "HEAD", ["HEAD"]; 
     Mflow (ElmSet.singleton (elm2int "ISINDEX"), 1), ["ISINDEX"];
   ] in
  let tbl = Hashtbl.create 49 in
  let () = 
    List.iter (fun (m, elms) ->
      List.iter (fun elm -> Hashtbl.replace tbl (elm2int elm) m) elms) spec in
  let () = 
    List.iter (fun elm -> 
      if elm <> "ISINDEX" then
      let i = elm2int elm in
      Hashtbl.replace tbl i (Mflow (ElmSet.singleton i, 0))) 
      (flow@["HTML"; "INS"; "DEL"; "PARAM"; "OPTGROUP"; "OPTION"]@ head_misc)  in
  tbl

let is_empty_monoid m =
  match m with
    [] -> true
  | _ -> false

let valid_elm cm_elm bm =
  match cm_elm, bm with
    CMEflow is1, Mflow (is2,_) -> ElmSet.subset is2 is1
  | CMEcol, Mcol -> true
  | CMEli, Mli -> true
  | CMEtr, Mtr -> true
  | CMEthtd, Mthtd -> true
  | CMEdtdd, Mdtdd -> true
  | _ -> false

let valid s1 (m2, es2) =
  let cm, es = Hashtbl.find cmodel_spec s1 in
  ElmSet.is_empty (ElmSet.inter es es2) &
  match cm, m2 with
    CMstar cm_elm, _ -> List.for_all (valid_elm cm_elm) m2
  | CMplus cm_elm, _ -> 
      List.for_all (valid_elm cm_elm) m2 &&
      if !Options.dtdstrict then not (is_empty_monoid m2) else true
  | CMhead, [Mheadelm (b, _, _)] -> b
  | CMhtml, [Mhtmlelm] -> true
  | CMtable, _ -> is_table_cmodel m2
  | CMfieldset, [Mfieldset] -> true
  | CMpcdata, [] -> true
  | _ -> false

let valid_prefix s1 (m2, es2) =
  let cm_elm = Hashtbl.find optional_spec s1 in
  List.for_all (valid_elm cm_elm) m2

let elm2bm e = Hashtbl.find elm2m_spec e
  
let elm2m e = 
  let bm = elm2bm e in
  ([bm], ElmSet.singleton e)

let up e (m2, es2) = 
  let eins, edel = elm2int "INS", elm2int "DEL" in
  if e = eins || e = edel then
    (m2, ElmSet.add e es2)
  else if e = elm2int "BODY" then
    let m1, es1 = elm2m e in
    (m1, ElmSet.remove edel (ElmSet.remove eins (ElmSet.union es1 es2)))
  else
    let m1, es1 = elm2m e in
    (m1, ElmSet.union es1 es2)

let mempty = ([], ElmSet.empty)
let many = ([Many], ElmSet.empty)

(*** grammar over paired alphabet ***)

open Flbasics

let left_start = 0
let maxchars = !elm_id
let right_start = left_start + maxchars

let left_char n = Char.chr (left_start + n) 
let right_char n = Char.chr (right_start + n)
let left2right c = Char.chr (Char.code c - left_start + right_start)
let is_left_char x = 
  let c = Char.code x in
  left_start <= c && c < left_start + maxchars
let is_right_char x = 
  let c = Char.code x in
  right_start <= c && c < right_start + maxchars
let matching_chars x y =
  is_left_char x && is_right_char y && Char.code x - left_start = Char.code y - right_start
let base_of c =
  if is_left_char c then Char.code c - left_start
  else if is_right_char c then Char.code c - right_start
  else failwith "base_of"

let pp_char fmt c =
  let elm = int2elm (base_of c) in
  if is_left_char c then
    Format.fprintf fmt "<%s>" elm
  else
    Format.fprintf fmt "</%s>" elm

let is_optional_empty_char s = 
  is_left_char s &&
  Hashtbl.mem optional_empty_spec (base_of s)

let is_optional_char s = 
  is_left_char s &&
  Hashtbl.mem optional_spec (base_of s)

let parenthesis_grammar tags cfg =
  let m = List.fold_right (fun tag css -> 
    let n = elm2int (implode tag) in
    (n, tag)::css) tags [] in
  let css' = List.map (fun (n, tag) -> (['<']@tag@['>'], left_char n)) m @
    List.map (fun (n, tag) -> (['<'; '/']@tag@['>'], right_char n)) m in
  let css = List.map (fun (cs, c) -> (implode cs, [Cfg.Terminal c])) css' in
  let fa = Fts.strings_ft' css in
  let css'' = List.map (fun (cs, c) -> (c, cs)) css' in
  let h c = try List.assoc c css'' with Not_found -> [c] in
  Ft_cfg.inter fa cfg, h, m

(*** irreducible string ***)

type irrlist' = E | C of char * irrlist
and irrlist = monoid * irrlist'

let rec pp_irrlist fmt (m, ss) =
  Format.fprintf fmt "%a" pp_monoid m;
  match ss with
    E -> ()
  | C (c, il) -> 
      (Format.fprintf fmt "%a" pp_char c;
       pp_irrlist fmt il)

let tag2bm s = elm2bm (base_of s)
let tag2m s = elm2m (base_of s)
let up s (m2, es2) = up (base_of s) (m2, es2) 
let valid s1 (m2, es2) = valid (base_of s1) (m2, es2)
let valid_prefix s1 (m2, es2) = valid_prefix (base_of s1) (m2, es2)

let m_cons m1 (m2, ss) = (mop m1 m2, ss)

let m_cons_opt s ((m2,es2), ss) = 
  let m1 = tag2bm s in
  let cm_elm = Hashtbl.find optional_spec (base_of s) in
  let rec loop m2 m3 = 
    match m2 with
      [] -> [], List.rev m3
    | m2'::ms -> 
	if valid_elm cm_elm m2' then loop ms  (m2'::m3) else m2, List.rev m3  in 
  let m2, m3 = loop m2 [] in
  let m = 
    if not (!Options.dtdstrict) || valid s (m3,es2) 
    then ([m1], ElmSet.empty) else  many in
  m_cons m ((m2, es2), ss)


let irr_cons s ss =
  let ss' =
    match ss with 
      (m, E) -> 
	if is_optional_empty_char s then m_cons (tag2m s) ss
	else if is_optional_char s && not (valid_prefix s m)
	then m_cons_opt s ss else (mempty, C (s, ss))
    | (m, C (s', ss'')) -> 
	if is_optional_empty_char s then m_cons (up s m) ss
	else if matching_chars s s' then 
	  if valid s m then m_cons (up s m) ss'' else m_cons many ss''
	else if is_optional_char s then
	  if not (valid_prefix s m) then m_cons_opt s ss 
	  else if is_right_char s' then m_cons (up s m) (mempty, C (s', ss''))
	  else if not (valid_prefix s (tag2m s')) then m_cons (up s m) (mempty, C(s',ss''))
	  else (mempty, C (s, ss))
	else (mempty, C (s, ss)) in
  Options.show 1 (fun fmt -> 
    Format.printf "%a %a %a@." pp_char s pp_irrlist ss pp_irrlist ss');
  ss'

let rec irr_app ss1 ss2 =
  match ss1 with
    (m, E) -> m_cons m ss2 
  | (m, C (c, ss1')) -> m_cons m (irr_cons c (irr_app ss1' ss2))

let normalize_pword ss =
  List.fold_right irr_cons ss (mempty, E)

module IrrSet = 
  Set.Make(struct
    type t = irrlist
    let compare = compare
  end)

let irrset_cons c tss =
  IrrSet.fold (fun ts tss' ->
    IrrSet.add (irr_cons c ts) tss') tss IrrSet.empty

let irrset_app tss1 tss2 = 
  IrrSet.fold (fun ts1 tss -> 
    IrrSet.fold (fun ts2 tss -> IrrSet.add (irr_app ts1 ts2) tss) tss2 tss) tss1 
    IrrSet.empty

let is_well_formed (m, ss) =
  match (m, ss) with
    (([Many],_), E) -> false
  | (_, E) -> true
  | _ -> false

let irrmap_of cfg =
  let uv_map = Cfg.useful_with_witness cfg in
  let bound_map = Cfg.Prod.fold (fun x (ls, rs) bound_map ->
    Cfg.Prod.add x (normalize_pword ls, normalize_pword rs) bound_map) uv_map Cfg.Prod.empty in
  let rec loop irrmap =
    let newirr irrmap ss = 
      List.fold_right 
	(fun s tss -> 
	  match s with 
	    (Cfg.Terminal c) -> irrset_cons c tss 
	  | (Cfg.Variable x) -> irrset_app (Cfg.Prod.find x irrmap) tss) 
	ss (IrrSet.singleton (mempty, E)) in
    let irrmap' =
      Cfg.Prod.fold (fun x rhss irrmap ->
	let tss = Cfg.SententialForm_set.fold (fun rhs tss ->
	  IrrSet.union (newirr irrmap rhs) tss) rhss (Cfg.Prod.find x irrmap) in
	Cfg.Prod.add x tss irrmap) cfg.Cfg.prod irrmap in
    if Cfg.Prod.equal IrrSet.equal irrmap irrmap' 
    then IrrSet.for_all is_well_formed (Cfg.Prod.find cfg.Cfg.start irrmap),
      irrmap
    else if 
      Cfg.Prod.fold (fun x tss b ->
	let l, r = Cfg.Prod.find x bound_map in
	b || IrrSet.exists (fun ts -> 
	  not (is_well_formed (irr_app l (irr_app ts r)))) tss) irrmap' false then false,irrmap' else loop irrmap' in
  loop (Cfg.Prod.fold (fun x _ irrmap -> Cfg.Prod.add x IrrSet.empty irrmap)
	  cfg.Cfg.prod Cfg.Prod.empty)

(*** counter example generation ***)

module IrrMap =
  Map.Make(struct
    type t = irrlist
    let compare = compare
  end)

let irrset_app' tss1 tss2 = 
  IrrMap.fold (fun ts1 ts1' tss -> 
    IrrMap.fold (fun ts2 ts2' tss -> IrrMap.add (irr_app ts1 ts2) (ts1'@ts2') tss) tss2 tss) tss1 
    IrrMap.empty

let irrset_cons' c tss =
  IrrMap.fold (fun ts ts' tss' ->
    IrrMap.add (irr_cons c ts) (c::ts') tss') tss IrrMap.empty

exception Irrmap of char list

let unbalanced_word_of cfg =
  let uv_map = Cfg.useful_with_witness cfg in
  let bound_map = Cfg.Prod.fold (fun x (ls, rs) bound_map ->
    Cfg.Prod.add x (normalize_pword ls, normalize_pword rs) bound_map) uv_map Cfg.Prod.empty in
  let rec loop irrmap =
    let clm_union tss1 tss2 =
      IrrMap.fold (fun ts1 ts1' tss -> IrrMap.add ts1 ts1' tss) tss1 tss2 in
    let newirr irrmap ss = 
      List.fold_right 
	(fun s tss -> 
	  match s with 
	    (Cfg.Terminal c) -> irrset_cons' c tss 
	  | (Cfg.Variable x) -> irrset_app' (Cfg.Prod.find x irrmap) tss) 
	ss (IrrMap.add (mempty, E) [] IrrMap.empty) in
    let irrmap' =
      Cfg.Prod.fold (fun x rhss irrmap ->
	let tss = Cfg.SententialForm_set.fold (fun rhs tss ->
	  clm_union (newirr irrmap rhs) tss) rhss (Cfg.Prod.find x irrmap) in
	Cfg.Prod.add x tss irrmap) cfg.Cfg.prod irrmap in
    if Cfg.Prod.equal (IrrMap.equal (fun _ _ -> true)) irrmap irrmap' 
    then 
      let tss = 
	IrrMap.fold (fun x v tss -> if is_well_formed x then tss else IrrMap.add x v tss)
	  (Cfg.Prod.find cfg.Cfg.start irrmap) IrrMap.empty in
      IrrMap.iter (fun ts ts' -> raise (Irrmap ts')) tss;
      failwith "unbalanced_word_of"
    else 
      let () = Cfg.Prod.iter (fun x tss ->
	let l, r = Cfg.Prod.find x bound_map in
	IrrMap.iter (fun ts ts' -> 
	  if not (is_well_formed (irr_app l (irr_app ts r))) then
	    let l,r = Cfg.Prod.find x uv_map in
	    raise (Irrmap (l@ts'@r))) tss) irrmap'  in
      loop irrmap' in
  try
    loop (Cfg.Prod.fold (fun x _ irrmap -> Cfg.Prod.add x IrrMap.empty irrmap)
	    cfg.Cfg.prod Cfg.Prod.empty)
  with Irrmap cs -> cs

let pp_char h fmt c = pp_charlist fmt (h c)
let pp_word h fmt cs = Basic.print_list "" (pp_char h) fmt cs

open Reg

let c2reg h' c = 
  let reg0 = Star (Negalphalist ['<'; '>']) in
  let tag = h' (base_of c) in
  if is_left_char c then List.fold_right
      (fun c reg -> App (Alpha c, reg)) ('<'::tag)  (App (reg0, Alpha '>')) 
  else if is_right_char c then List.fold_right
      (fun c reg -> App (Alpha c, reg)) ('<'::'/'::tag)  (App (reg0, Alpha '>')) 
  else failwith "c2reg"

let rec mkcharlist n m =
  if n > m then [] else Char.chr n :: mkcharlist (n+1) m 

let alpha_chars =
  mkcharlist (Char.code 'a') (Char.code 'z') @
  mkcharlist (Char.code 'A') (Char.code 'Z')

let show_fullexample show_example h' cs =
  let reg0 = Star (Plus (Negalphalist ['<'], 
			 Plus (App (Alpha '<', Negalphalist ('/'::alpha_chars)),
			       App (Alpha '<', App (Alpha '/', Negalphalist alpha_chars))))) in
  let reg = 
    List.fold_right (fun x reg -> 
      let reg = App (c2reg h' x, reg) in
      App (reg0, reg)) cs reg0 in 
  show_example (case_insensitive reg)

let check_balance show_example tags cfg = 
  let tags = List.map (List.map Char.uppercase) tags in
  let cfg = 
    let p = cfg_subst (cfg.Cfg.prod) (fun c -> Cfg.Terminal (Char.uppercase c)) in
    Cfg.create3 (Cfg.vars_of cfg) p cfg.Cfg.start in 
  let () =  Options.show 1 (fun fmt -> Cfg.pp_cfg fmt cfg) in
  let cfg', h, m = parenthesis_grammar tags cfg in
  let () =  Options.show 1 (fun fmt -> Cfg.pp_cfg fmt cfg') in
  let cfg' = simplify_cfg (cfg_simplify cfg') in
  let () =  Options.show 1 (fun fmt -> Cfg.pp_cfg fmt cfg') in
  let () =  Options.show 1 (fun fmt -> 
    let cfg = Cfg.homo cfg' h in Cfg.pp_cfg fmt cfg) in
  let b,irr_map = irrmap_of cfg' in
  let () =
    Options.show 1 (fun fmt -> 
      let () = Format.printf "%s@." (Cfg.string_of_v cfg'.Cfg.start) in
      let pp_symss fmt symss =
	Basic.print_iter IrrSet.iter "|" pp_irrlist fmt symss in
      let pp_prod fmt x symss =
	Format.fprintf fmt "%s -> %a" (Cfg.string_of_v x) pp_symss symss in
      Basic.print_iter2 Cfg.Prod.iter ",@," pp_prod fmt irr_map) in
  if b then Format.printf "Valid@." 
  else 
    let () = Format.printf "Invalid@." in
    let cs = unbalanced_word_of cfg' in
    let () = Format.printf "%a@." (pp_word h) cs in
    let c2elm_tbl = Hashtbl.create 49 in
    let () = List.iter (fun (n, t) -> Hashtbl.add c2elm_tbl n t) m in
    let h' c = Hashtbl.find c2elm_tbl c in  
    show_fullexample show_example h' cs









