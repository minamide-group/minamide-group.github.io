(*
 * PHP string analyzer
 * Copyright (C) 2005, 2006 Yasuhiko Minamide
 *)
open Support
open Flbasics

let left_start = 0
let maxchars = 80
let right_start = left_start + maxchars
let neutral_start = right_start + maxchars

let left_char n = Char.chr (left_start + n) 
let right_char n = Char.chr (right_start + n)
let neutral_char n = Char.chr (neutral_start + n)
let left2neutral c = Char.chr (Char.code c - left_start + neutral_start)
let left2right c = Char.chr (Char.code c - left_start + right_start)
let neutral2left c = Char.chr (Char.code c - neutral_start + left_start)
let neutral2right c = Char.chr (Char.code c - neutral_start + right_start)
let is_left_char x = 
  let c = Char.code x in
  left_start <= c && c < left_start + maxchars
let is_right_char x = 
  let c = Char.code x in
  right_start <= c && c < right_start + maxchars
let is_neutral_char x = 
  let c = Char.code x in
  neutral_start <= c && c < neutral_start + maxchars
let matching_chars x y =
  is_left_char x && is_right_char y && Char.code x - left_start = Char.code y - right_start
let base_of c =
  if is_left_char c then Char.code c - left_start
  else if is_right_char c then Char.code c - right_start
  else if is_neutral_char c then Char.code c - neutral_start 
  else failwith "base_of"

let charset_of n = 
  let rec loop i cs =
    if i < n then 
      let cs = Charset.Charset.add (left_char i) cs in 
      let cs = Charset.Charset.add (right_char i) cs in 
      let cs = Charset.Charset.add (neutral_char i) cs in 
      loop (i+1) cs
    else cs in
  loop 0 Charset.Charset.empty 

let charset = charset_of maxchars

let is_xml_neutral cs = 
  match cs with
    '?'::_ | '!'::_ -> true
  | _  -> false

let parenthesis_grammar tags cfg =
  let m, n = List.fold_right (fun tag (css, n) -> 
    ((n, tag)::css), n+1) tags ([], 0) in
  let () = if n > maxchars then failwith "too many element types" in 
  let () = 
    Options.show 1 (fun fmt ->
      List.iter (fun (n, tag) -> Format.fprintf fmt "%s --> %c@." (implode tag) (left_char n)) m) in
  let css' = List.fold_right (fun (n, tag) css' -> 
    if is_xml_neutral tag then 
      (['<']@tag@['>'], neutral_char n)::css'
    else
      (['<']@tag@['>'], left_char n)::
      (['<'; '/']@tag@['>'], right_char n)::
      (['<'; ]@tag@['/'; '>'], neutral_char n)::css') m [] in
  let css = List.map (fun (cs, c) -> (implode cs, [Cfg.Terminal c])) css' in
  let fa = Fts.strings_ft' css in
  let css'' = List.map (fun (cs, c) -> (c, cs)) css' in
  let h c = try List.assoc c css'' with Not_found -> [c] in
  Ft_cfg.inter fa cfg, h, m, n

let irr_cons s ss =
  if is_neutral_char s then ss
  else 
    match ss with 
      [] -> [s]
    | s'::ss -> if matching_chars s s' then ss else s::s'::ss

let normalize_pword ss =
  List.fold_right irr_cons ss []

let irrset_cons c tss =
  CharListSet.fold (fun ts tss' ->
    CharListSet.add (irr_cons c ts) tss') tss CharListSet.empty

let irrset_app1 ts tss = 
  List.fold_right (fun t tss -> irrset_cons t tss) ts tss

let irrset_app tss1 tss2 = 
  CharListSet.fold (fun ts tss' -> CharListSet.union tss' (irrset_app1 ts tss2)) tss1 CharListSet.empty
      
let irrmap_of cfg =
  let uv_map = Cfg.useful_with_witness cfg in
  let bound_map = Cfg.Prod.fold (fun x (ls, rs) bound_map ->
    Cfg.Prod.add x (List.length (normalize_pword ls) + List.length (normalize_pword rs)) bound_map) uv_map Cfg.Prod.empty in
  let rec loop irrmap =
    let newirr irrmap ss = 
      List.fold_right 
	(fun s tss -> 
	  match s with 
	    (Cfg.Terminal c) -> irrset_cons c tss 
	  | (Cfg.Variable x) -> irrset_app (Cfg.Prod.find x irrmap) tss) 
	ss (CharListSet.singleton []) in
    let irrmap' =
      Cfg.Prod.fold (fun x rhss irrmap ->
	let tss = Cfg.SententialForm_set.fold (fun rhs tss ->
	  CharListSet.union (newirr irrmap rhs) tss) rhss (Cfg.Prod.find x irrmap) in
	Cfg.Prod.add x tss irrmap) cfg.Cfg.prod irrmap in
    if Cfg.Prod.equal CharListSet.equal irrmap irrmap' 
    then CharListSet.equal (CharListSet.singleton []) (Cfg.Prod.find cfg.Cfg.start irrmap),
      irrmap
    else if 
      Cfg.Prod.fold (fun x tss b ->
	b || CharListSet.exists (fun ts -> List.length ts > Cfg.Prod.find x bound_map) tss) irrmap' false then false,irrmap' else loop irrmap' in
  loop (Cfg.Prod.fold (fun x _ irrmap -> Cfg.Prod.add x CharListSet.empty irrmap)
	  cfg.Cfg.prod Cfg.Prod.empty)


let irr_app ss1 ss2 =
  List.fold_right (fun s ss -> irr_cons s ss) ss1 ss2

let irrset_app tss1 tss2 = 
  CharListSet.fold (fun ts1 tss -> 
    CharListSet.fold (fun ts2 tss -> CharListSet.add (irr_app ts1 ts2) tss) tss2 tss) tss1 CharListSet.empty

module CharListMap =
  Map.Make(struct
    type t = char list
    let compare = compare
  end)

let irrset_app' tss1 tss2 = 
  CharListMap.fold (fun ts1 ts1' tss -> 
    CharListMap.fold (fun ts2 ts2' tss -> CharListMap.add (irr_app ts1 ts2) (ts1'@ts2') tss) tss2 tss) tss1 
    CharListMap.empty

let irrset_cons' c tss =
  CharListMap.fold (fun ts ts' tss' ->
    CharListMap.add (irr_cons c ts) (c::ts') tss') tss CharListMap.empty

exception Irrmap of char list

let unbalanced_word_of cfg =
  let uv_map = Cfg.useful_with_witness cfg in
  let bound_map = Cfg.Prod.fold (fun x (ls, rs) bound_map ->
    Cfg.Prod.add x (List.length (normalize_pword ls) + List.length (normalize_pword rs)) bound_map) uv_map Cfg.Prod.empty in
  let rec loop irrmap =
    let clm_union tss1 tss2 =
      CharListMap.fold (fun ts1 ts1' tss -> CharListMap.add ts1 ts1' tss) tss1 tss2 in
    let newirr irrmap ss = 
      List.fold_right 
	(fun s tss -> 
	  match s with 
	    (Cfg.Terminal c) -> irrset_cons' c tss 
	  | (Cfg.Variable x) -> irrset_app' (Cfg.Prod.find x irrmap) tss) 
	ss (CharListMap.add [] [] CharListMap.empty) in
    let irrmap' =
      Cfg.Prod.fold (fun x rhss irrmap ->
	let tss = Cfg.SententialForm_set.fold (fun rhs tss ->
	  clm_union (newirr irrmap rhs) tss) rhss (Cfg.Prod.find x irrmap) in
	Cfg.Prod.add x tss irrmap) cfg.Cfg.prod irrmap in
    if Cfg.Prod.equal (CharListMap.equal (fun _ _ -> true)) irrmap irrmap' 
    then 
      let tss = CharListMap.remove [] (Cfg.Prod.find cfg.Cfg.start irrmap) in
      CharListMap.iter (fun ts ts' -> raise (Irrmap ts')) tss;
      failwith "unbalanced_word_of"
    else 
      let () = Cfg.Prod.iter (fun x tss ->
	CharListMap.iter (fun ts ts' -> 
	  if List.length ts > Cfg.Prod.find x bound_map then 
	    let l,r = Cfg.Prod.find x uv_map in
	    raise (Irrmap (l@ts'@r))) tss) irrmap'  in
      loop irrmap' in
  try
    loop (Cfg.Prod.fold (fun x _ irrmap -> Cfg.Prod.add x CharListMap.empty irrmap)
	    cfg.Cfg.prod Cfg.Prod.empty)
  with Irrmap cs -> cs


module VarIntMap =
  Map.Make(struct 
    type t = Cfg.variable * int
    let compare = compare
  end)

let varint_find (x,i) m = try VarIntMap.find (x,i) m with 
  Not_found -> failwith (Format.sprintf "%s %d" (Cfg.string_of_v x) i)

exception UnderflowRightChar of 
  Cfg.terminal * Cfg.symbol list * Cfg.symbol list

let factorize' ss =
  let rec parse stack b ss' ss =
    match ss with
      [] -> (b, ss', stack)
    | Cfg.Terminal c::ss when is_left_char c ->  parse ((b,ss')::stack) c [] ss
    | Cfg.Terminal c::ss when is_neutral_char c ->  failwith "factorize'"
    | Cfg.Terminal c::ss -> 
	(match stack with
	  (b'',ss'')::stack -> 
	  if matching_chars b c then
	    parse stack b'' (Cfg.Terminal c::ss'@Cfg.Terminal b::ss'') ss
	  else
	    failwith (Format.sprintf "Unbalanced symbol: %c" c)
	| _ -> raise (UnderflowRightChar (c, ss', ss)))
    | (Cfg.Variable x as s)::ss -> parse stack b (s::ss') ss in
  let rec right ss =
    try
      let (_, ss', stack) = parse [] (left_char 0) [] ss in
      List.rev_map (fun (c,ss) -> List.rev ss) stack@[List.rev ss']
    with UnderflowRightChar (c, ss', ss) -> List.rev ss'::right ss in
  right ss

let factorize ss =
  let rec parse stack b ss' ss =
    match ss with
      [] -> (b, ss', stack)
    | Cfg.Terminal c::ss when is_left_char c ->  parse ((b,ss')::stack) c [] ss
    | Cfg.Terminal c::ss when is_neutral_char c ->  failwith "factorize"
    | Cfg.Terminal c::ss -> 
	(match stack with
	  (b'',ss'')::stack -> 
	  if matching_chars b c then
	    parse stack b'' (Cfg.Terminal c::Cfg.Terminal b::ss'') ss
	  else
	    failwith (Format.sprintf "Unbalanced symbol: %c" c)
	| _ -> raise (UnderflowRightChar (c, ss', ss)))
    | (Cfg.Variable x as s)::ss -> parse stack b (s::ss') ss in
  let rec right ss =
    try
      let (_, ss', stack) = parse [] (left_char 0) [] ss in
      List.rev_map (fun (c,ss) -> List.rev ss) stack@[List.rev ss']
    with UnderflowRightChar (c, ss', ss) -> List.rev ss'::right ss in
  right ss


let int_fold f n b =
  let rec loop n b = if n >= 0 then loop (n - 1)  (f n b) else b in
  loop n b

let surface irr_map cfg = 
  let prod = prod_homo cfg.Cfg.prod 
      (fun x -> if is_neutral_char x then [neutral2left x; neutral2right x] else [x]) in
  let env = Cfg.Prod.fold
      (fun x cs env -> 
	int_fold (fun n env -> VarIntMap.add (x, n) (Cfg.fresh_variable ()) env) (List.length cs) env) irr_map VarIntMap.empty in

  let () = Options.show 1 (fun fmt ->
    VarIntMap.iter (fun (x,i) x' -> Format.fprintf fmt "(%s,%d) => %s@."
	(Cfg.string_of_v x) i (Cfg.string_of_v x')) env) in

  let subst = 
    Cfg.Prod.fold (fun x cs subst ->
      let rec loop cs n =
	match cs with
	  [] -> []
	| c::cs -> Cfg.Terminal c::Cfg.Variable (varint_find (x,n) env)::loop cs (n+1) in
      let ss = Cfg.Variable (varint_find (x,0) env)::loop cs 1 in
      Cfg.Prod.add x ss subst) irr_map Cfg.Prod.empty in

(*  let () =
    let pp_syms fmt syms = Basic.print_list "" Cfg.pp_sym fmt syms in
    let pp_prod fmt x syms =
      Format.fprintf fmt "%s -> %a" (Cfg.string_of_v x) pp_syms syms in
    Format.printf "%a@."
    (Basic.print_iter2 Cfg.Prod.iter ",@," pp_prod) subst in *)

  let prod' = Cfg.Prod.fold (fun x sss prod' ->
    let sss =
      Cfg.SententialForm_set.fold (fun ss sss ->
	let ss =
	  List.fold_right (fun s ss ->
	    match s with
	      Cfg.Terminal c -> Cfg.Terminal c::ss 
	    | Cfg.Variable x -> Cfg.Prod.find x subst@ss) ss [] in
	Cfg.SententialForm_set.add ss sss) sss Cfg.SententialForm_set.empty in
    Cfg.Prod.add x sss prod') prod Cfg.Prod.empty in

(*  let () = Format.printf "%a@." Cfg.pp_cfg 
      (Cfg.Variable_set.empty,Cfg.Terminal_set.empty, prod',s) in *)

  let trace ts = 
    List.fold_right (fun t ts ->
      match t with
	Cfg.Terminal c when is_right_char c -> ts
      |	Cfg.Terminal c when is_neutral_char c -> Cfg.Terminal (neutral2left c)::ts
      | _ -> t::ts) ts [] in

  let newprod =
    Cfg.prod_fold (fun x ss newprod ->
      let sss = factorize ss in
      let rec loop sss i newprod =
	match sss with
	  [] -> newprod
	| ss::sss -> 
	    let ss = trace ss in
	    loop sss (i+1)  (Cfg.prod_add (varint_find (x,i) env, ss) newprod) in
      loop sss 0 newprod) prod' Cfg.Prod.empty in
  env, newprod, prod'

let surface_of_ss n sss ss =
  let _, sss =
    List.fold_right (fun s (cs, sss) ->
      match s with
	Cfg.Variable y ->
	  (match cs with
	    (c,c_sss)::cs' when c = right_char n -> 
	      (c, Cfg.Variable y::c_sss)::cs',
	      sss
	  | _ ->
	      (cs, sss))
      | Cfg.Terminal c ->
	  if is_neutral_char c then failwith "surface_of_ss"
	  else if is_right_char c then 
	    (match cs with
	      (c',c_sss)::cs -> 
(*		((c,[])::(c', Cfg.Terminal c::c_sss)::cs, sss) *)
		((c,[])::(c', c_sss)::cs, sss) 
	    | _ -> ([(c,[])], sss))
	  else
	    (match cs with
	      (c',c_sss)::cs -> 
		let sss =
		  if c' = right_char n 
		  then Cfg.SententialForm_set.add c_sss sss
		  else sss in
		(match cs with
		  (c',c_sss)::cs -> (c',Cfg.Terminal c::c_sss)::cs, sss
		| _ -> (cs,sss))
	    | _ -> failwith "surface_of")) ss ([], sss) in
  sss

let surface_of surface_env newprod prod' n =
  let sss =  
    Cfg.prod_fold (fun x ss (sss:Cfg.SententialForm_set.t) ->
      let sss' = factorize' ss in
      List.fold_left (fun sss ss -> surface_of_ss n sss ss)
	sss sss') prod' Cfg.SententialForm_set.empty in
  let s' = Cfg.fresh_variable () in
  let prod' = Cfg.Prod.add s' sss newprod in
  Cfg.create prod' s'

let set_cons c tss =
  Cfg.SententialForm_set.fold (fun ts tss' ->
    Cfg.SententialForm_set.add (c::ts) tss') tss Cfg.SententialForm_set.empty

let fullqualify irr_map cfg =
  let b = Cfg.Prod.fold (fun _ css b -> b && CharListSet.cardinal css = 1)
      irr_map true in
  if b then 
    let irr_map =
      Cfg.Prod.fold (fun x css imap ->
	if CharListSet.cardinal css = 1 then
	  let cs = CharListSet.choose css in
	  Cfg.Prod.add x cs imap
	else failwith "surface'") irr_map Cfg.Prod.empty in
    irr_map, cfg
  else
    let env, irr_map', xenv = Cfg.Prod.fold
	(fun x css (env, irr_map', xenv) -> 
	  let env, irr_map', xs =
	    CharListSet.fold (fun cs (env,irr_map',xs) -> 
	      let x' = Cfg.fresh_variable () in
	      (VarIntMap.add (x, List.length cs) x' env, 
	       Cfg.Prod.add x' cs irr_map',
	       Cfg.Variable_set.add x' xs))
	      css  (env,irr_map', Cfg.Variable_set.empty) in
	  env, irr_map', Cfg.Prod.add x xs xenv) irr_map 
	(VarIntMap.empty, Cfg.Prod.empty, Cfg.Prod.empty ) in
    let prod' =
      Cfg.prod_fold (fun x ss prod' ->
	let sss =
	  List.fold_right (fun s sss ->
	    match s with
	      Cfg.Terminal c -> set_cons s sss
	    | Cfg.Variable x ->
		Cfg.Variable_set.fold (fun y sss' ->
		  Cfg.SententialForm_set.union (set_cons (Cfg.Variable y) sss) sss')
		  (Cfg.Prod.find x xenv) Cfg.SententialForm_set.empty)
	    ss (Cfg.SententialForm_set.singleton []) in
	Cfg.SententialForm_set.fold (fun ss prod' ->
	  let cs = List.fold_right (fun s cs ->
	    match s with
	      Cfg.Terminal c -> c::cs
	    | Cfg.Variable x -> Cfg.Prod.find x irr_map'@cs) ss [] in
	  let x' = varint_find (x, List.length (normalize_pword cs)) env in
	  Cfg.prod_add (x', ss) prod') sss prod') cfg.Cfg.prod Cfg.Prod.empty in
    irr_map', 
    Cfg.create  prod' (varint_find (cfg.Cfg.start, 0) env)

open Reg 

let rec dyck_reg n =
  match n with
    0 -> Phi
  | _ -> App (App (Alpha (left_char 0), Star (dyck_reg (n - 1))), 
	      Alpha (right_char 0))

let rec check_depth n cfg =
  if n > 20 then Format.printf "The depth may be unbounded."
  else
    let reg = dyck_reg n in 
    let automaton = Fa.minimize (Reg2fa.reg2nfa charset reg) in
    let automaton = Fa.neg automaton in
    let b = Fa_cfg.is_disjoint automaton cfg in 
    if b then Format.printf "The depth is %d@." n 
    else check_depth (n+1) cfg

let check_depth_main cfg =
  let h c = if is_left_char c then [left_char 0]
      else if is_right_char c then [right_char 0]
      else [] in
  let cfg = Cfg.homo cfg h in
  check_depth 5 cfg

let cfg_size cfg =
  (Cfg.Variable_set.cardinal (Cfg.vars_of cfg),
   Cfg.Prod.fold (fun x rhss size ->
     Cfg.SententialForm_set.cardinal rhss + size) cfg.Cfg.prod 0)

let rec left_chars n = if n < 0 then [] else left_char n::left_chars (n - 1)
let rec right_chars n = if n < 0 then [] else right_char n::right_chars (n - 1)
let rec neutral_chars n = if n < 0 then [] else neutral_char n::neutral_chars (n - 1)


let left_reg n = Alphalist (left_chars n)
let right_reg n = Alphalist (right_chars n)
let neutral_reg n = Alphalist (neutral_chars n)

let rec dyck_reg' k n =
  let lreg = left_reg k in
  let rreg = right_reg k in
  let nreg = neutral_reg k in
  let star reg =
    match reg with
      Epsilon -> Epsilon
    | Phi -> Epsilon
    | Plus (reg, Epsilon) -> Star reg
    | _ -> Star reg in
  let app (reg1, reg2) =
    match reg1 with
      Epsilon -> reg2
    | _ -> App (reg1, reg2) in
  let rec dreg n =
    match n with
      0 -> Phi
    | _ -> Plus (nreg, app (lreg, app (star (dreg (n - 1)), rreg))) in
  dreg n


let c2reg h' c = 
   let reg0 = Star (Negalphalist ['<'; '>']) in
   let cdata_reg = 
     Star (Plus(Negalphalist ['>'],
			      Plus (App (Negalphalist [']'], Alpha '>'),
					   App (Negalphalist [']'], 
						       App (Alpha ']', Alpha '>'))))) in
   let cdata_reg = 
     App (Plus (Epsilon,
			      Plus (Alpha '>',
					   App (Alpha ']', Alpha '>'))),
		 cdata_reg) in
   let tag = h' (base_of c) in
   if is_left_char c then List.fold_right
   (fun c reg -> App (Alpha c, reg)) ('<'::tag)  (App (reg0, Alpha '>')) 
   else if is_right_char c then List.fold_right
   (fun c reg -> App (Alpha c, reg)) ('<'::'/'::tag)  (App (reg0, Alpha '>')) 
   else if is_xml_neutral tag then 
     match implode tag with
       "![CDATA[]]" ->
	 let start_tag = string_reg "<![CDATA[" in
	 let end_reg = string_reg "]]>" in
	 App (start_tag, App (cdata_reg, end_reg))
     | _ ->
	 List.fold_right
	   (fun c reg -> App (Alpha c, reg)) ('<'::tag)  (App (reg0, Alpha '>'))
   else if is_neutral_char c then
     List.fold_right
       (fun c reg -> App (Alpha c, reg)) ('<'::tag)  (App (reg0, App (Alpha '/', Alpha '>')))
   else failwith "c2reg"
    

let show_fullexample show_example h' cs =
  let reg0 = Star (Negalphalist ['<'; '>']) in
  let reg = 
    List.fold_right (fun x reg -> 
(*      let reg = 
	List.fold_right
	  (fun c reg -> App (Alpha c, reg)) (h x) reg in *)
      let reg = App (c2reg h' x, reg) in
      App (reg0, reg)) cs reg0 in 
  show_example reg

let pp_char h fmt c = pp_charlist fmt (h c)

let pp_word h fmt cs = Basic.print_list "" (pp_char h) fmt cs
  
let get_cexample show_example h h' k i cs cfg =
  let rec loop n =
    if n > 20 then failwith "get_example" else
    let dreg = Star (dyck_reg' k n) in
    let reg = List.fold_right (fun c reg -> 
      let creg = Plus (Alpha (left2neutral c),
		       App(Alpha c, App (dreg, Alpha (left2right c)))) in
      App (creg, reg)) cs Epsilon in
    let reg = App (Alpha (left_char i), App (reg, Alpha (right_char i))) in
    let reg = App (Star Allalpha, App (reg, Star Allalpha)) in
    let automaton = Reg2fa.reg2nfa charset reg in
    if Fa_cfg.is_disjoint automaton cfg then loop (n+1)
    else
      let cfg' = Fa_cfg.inter automaton cfg in
      let cfg' = Cfg.useful cfg' in 
      let cs = word_of cfg' in 
      Format.printf "Counter example:@.%a@." (pp_word h) cs;
      show_fullexample show_example h' cs in
  loop 1

let check_balance show_example tags cfg = 
  let cfg', h, m, n = parenthesis_grammar tags cfg in
  let ptime = Unix.times () in
  
  let () =
    Options.show 1 (fun fmt ->
      let (vsize, psize) = cfg_size cfg' in
      Format.fprintf fmt "the number of variables: %d@."  vsize;
      Format.fprintf fmt "the number of productions: %d@." psize) in

  let cfg' = simplify_cfg (cfg_simplify cfg') in
  let () =  Options.show 1 (fun fmt -> Cfg.pp_cfg fmt cfg') in

  let b,irr_map = irrmap_of cfg' in
  let () =
    Options.show 1 (fun fmt ->
      let () = Format.printf "%s@." (Cfg.string_of_v cfg'.Cfg.start) in
      let pp_syms fmt syms = Basic.print_list "" Format.pp_print_char fmt syms in
      let pp_symss fmt symss =
	Basic.print_iter CharListSet.iter "|" pp_syms fmt symss in
      let pp_prod fmt x symss =
	Format.fprintf fmt "%s -> %a" (Cfg.string_of_v x) pp_symss symss in
      Basic.print_iter2 Cfg.Prod.iter ",@," pp_prod fmt irr_map) in
  if b then 
    let () = Format.printf "balanced@." in
    let () = if !Options.check_depth then check_depth_main cfg' in 
    let irr_map, cfg' = fullqualify irr_map cfg' in
    let () =
      Options.show 1 (fun fmt ->
	let () = Format.printf "%s@." (Cfg.string_of_v cfg'.Cfg.start) in
	let pp_syms fmt syms = Basic.print_list "" Format.pp_print_char fmt syms in
	let pp_prod fmt x symss =
	  Format.fprintf fmt "%s -> %a" (Cfg.string_of_v x) pp_syms symss in
	Basic.print_iter2 Cfg.Prod.iter ",@," pp_prod fmt irr_map) in

    let () = Options.show 1 (fun fmt -> Format.fprintf fmt "%a@." Cfg.pp_cfg cfg') in
    let surface_env, newprod, prod' = surface irr_map cfg' in

    let dtd = Dtdmisc.get_xhtml_dtd (List.map implode tags) in 

    let rec loop validity i =
      if i > 0 then
	if is_xml_neutral (List.assoc (i-1) m) then loop validity (i - 1) 
	else
	let () = Format.printf "%a@." (pp_char h) (left_char (i-1)) in
	let cfg'' = surface_of surface_env newprod prod' (i-1) in
	let cfg'' = simplify_cfg (cfg_simplify cfg'') in
	let () = Options.show 1 (fun fmt -> Cfg.pp_cfg fmt cfg'') in 
	let () = Cfg.pp_cfg Format.std_formatter (Cfg.homo cfg'' h) in
	let tag = implode (List.assoc (i-1) m) in 

	let elm2reg_tbl = Hashtbl.create 49 in
	let () = List.iter (fun (n, t) -> Hashtbl.add elm2reg_tbl (Support.implode t) n) m in
	let elm2reg str =
	  let n = Hashtbl.find elm2reg_tbl str in
	  Alpha(left_char n) in

	let reg = Dtdmisc.surface_reg elm2reg dtd tag in
	let fa = Fa.neg(Fa.minimize (Reg2fa.reg2nfa charset reg)) in
	let b = Fa_cfg.is_disjoint fa cfg'' in
	if b then loop validity (i - 1) 
	else 
	  let () =Format.printf "Invalid for the element %a@." (pp_char h) (left_char (i-1)) in
	  let cfg''' = Fa_cfg.inter fa cfg'' in
	  let ex = word_of cfg''' in
	  Format.printf "%a@." (pp_word h) ex;

	  let c2elm_tbl = Hashtbl.create 49 in
	  let () = List.iter (fun (n, t) -> Hashtbl.add c2elm_tbl n t) m in
	  let h' c = Hashtbl.find c2elm_tbl c in  
	  let () = get_cexample show_example h h' n (i-1) ex cfg' in
	  loop false (i - 1)
      else 
	if validity then Format.printf "Valid@." 
	else Format.printf "Invalid@." in
    (loop true n ; ptime)
  else (Format.printf "Not well-formed@."; 
	let cs = unbalanced_word_of cfg' in
	Format.printf "%a@." (pp_word h) cs;
	ptime) 

let check_balance ptime show_example tags cfg = 
  let ptime1 = check_balance show_example tags cfg in
  let ptime2 = Unix.times () in
  Format.printf "Simplification utime %f@."
    (ptime1.Unix.tms_utime -. ptime.Unix.tms_utime);
  Format.printf "validation utime %f@." 
    (ptime2.Unix.tms_utime -. ptime1.Unix.tms_utime) 

