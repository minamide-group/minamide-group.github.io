open Abssyn 

let expand stmts = 
  let rec expand_exp exp =
    match exp with
      Lvalue lv -> Lvalue (expand_lv lv)
    | Const _  | Int _ | Float _ | Bool _  | String _ -> exp
    | NewArray ees -> 
	NewArray (List.map (fun (e1,e2) -> (expand_exp e1, expand_exp e2)) ees)
    | RefAssign (x, Lv lv) -> RefAssign (x, Lv lv)
    | RefAssign (x, Exp exp) -> RefAssign (x, Exp (expand_exp exp))
    | ListAssign (xs, exp) -> ListAssign (xs, expand_exp exp)
    | LAssign (lv, exp) -> LAssign (lv, expand_exp exp)
    | LOpAssign (lv, p, exp) -> LOpAssign (lv, p, expand_exp exp)
    | Prim (p, es) -> 
	Prim (p, expand_exp_list es)
    | ClassMethod (cname, mname, es) -> 
	ClassMethod (cname, mname, expand_exp_list es)
    | Method (e, mname, es) -> 
	Method (expand_exp e, mname, expand_exp_list es)
    | NewObj (classname, es) -> 
	NewObj (classname, expand_exp_list es)
    | UClassMethod (cname, e, es) -> 
	UClassMethod (cname, expand_exp e, expand_exp_list es)
    | UMethod (e1, e2, es) -> 
	UMethod (e1, expand_exp e2, expand_exp_list es)
    | UNewObj (e, x, es) -> 
	UNewObj (expand_exp e, x, expand_exp_list es)
    | App ("preg_replace", [NewArray ees1; NewArray ees2; e3], i) ->
	let ss, xs = List.fold_right (fun (e1, e2) (ss, xs)  ->
	  let x = fresh_var () in 
	  ExpSt e1::ExpSt(LAssign (LVar x, e2))::ss, x::xs) ees1 ([], []) in
	let ss, ys = List.fold_right (fun (e1, e2) (ss, xs)  ->
	  let x = fresh_var () in 
	  ExpSt e1::ExpSt(LAssign (LVar x, e2))::ss, x::xs) ees2 (ss, []) in
	StmtExp (ss,
		 List.fold_left2 (fun e x y ->
		   App ("preg_replace", [Lvalue (LVar x); Lvalue (LVar y); e], None))
		   e3 xs ys)
    | App ("preg_replace", [NewArray ees1; e2; e3], i) ->
	let ss, xs = List.fold_right (fun (e1, e2) (ss, xs)  ->
	  let x = fresh_var () in 
	  ExpSt e1::ExpSt(LAssign (LVar x, e2))::ss, x::xs) ees1 ([], []) in
	StmtExp (ss,
		 List.fold_left (fun e x  ->
		   App ("preg_replace", [Lvalue (LVar x); e2; e], None))
		   e3 xs)
    | App ("str_replace", [NewArray ees1; String s; e3], i) ->
	let ss, xs = List.fold_right (fun (e1, e2) (ss, xs)  ->
	  let x = fresh_var () in 
	  ExpSt e1::ExpSt(LAssign (LVar x, e2))::ss, x::xs) ees1 ([], []) in
	StmtExp (ss,
		 List.fold_left (fun e x  ->
		   App ("str_replace", [Lvalue (LVar x); String s; e], None))
		   e3 xs)
    | App ("array_merge", e1::e2::es, i) ->
	List.fold_left (fun ek e -> App ("array_merge", [e; ek], None)) 
	(App ("array_merge", [e1; e2], i)) es
    | App ("array_walk", [e; String fname], i) -> 
	let x = fresh_var () in
	let y = fresh_var () in
	StmtExp ([Foreach (e, Some x, y, ExpSt (App (fname, [Lvalue (LVar y);  Lvalue (LVar x)], None)))], 
		 Bool true)
    | App (s,es,i) -> 
	App (s, expand_exp_list  es, i)
    | AppVar (e,x,es) -> 
	AppVar (expand_exp e, x, expand_exp_list  es)
    | FileBlock (fname, dirname, ss) -> FileBlock (fname, dirname, List.map expand ss)
    | IncludeExp (once, exp, fid, expanded_files, sss) -> 
	IncludeExp (once, expand_exp exp, fid, expanded_files, 
		    List.map (fun (str, ss) -> (str, List.map expand ss)) sss)
    | Define (s, exp) -> Define (s, expand_exp exp)
    | StmtExp _ -> failwith "StmtExp"
  and expand_exp_list es = List.map expand_exp es

  and expand_lv lv =
    match lv with
      LVar x -> LVar x
    | LVarVar e -> LVarVar (expand_exp e)
    | LArray1 lv -> LArray1 (expand_lv lv)
    | LArray2 (lv, e) -> LArray2 (expand_lv lv, expand_exp e) 
    | LObjRef (lv, s) -> LObjRef (expand_lv lv, s)
    | LUObjRef (lv, e) -> LUObjRef (expand_lv lv, expand_exp e)
    | LStringRef (lv, e) -> LStringRef (expand_lv lv, expand_exp e)

  and expand stmt =
    match stmt with
      ExpSt e -> ExpSt (expand_exp e)
    | Echo e -> Echo (expand_exp e)
    | Return e -> Return (expand_exp e)
    | Assert (e, s) -> Assert (expand_exp e, s)
    | Unset lv  -> Unset (expand_lv lv) 
    | Break _ | Continue _ | Skip | Global _ | Static _ ->  stmt
    | BlockSt ss -> BlockSt (List.map expand ss)
    | While (e,s) -> While (expand_exp e,expand s)
    | DoWhile (s, e) -> DoWhile (expand s, expand_exp e)
    | Foreach (e,optx,y,s) -> Foreach (expand_exp e,optx,y, expand s)
    | For (e1, e2, e3, s) -> 
	For (expand_exp_list e1, expand_exp_list e2, expand_exp_list e3, expand s)
    | If (e, s1, s2) -> If (expand_exp e, expand s1, expand s2)
    | Switch (e, css) ->
	let css = List.map (fun (e,ss) -> 
	  let e = 
	    match e with
	      Some e -> Some (expand_exp e)
	    | None -> None in
	  (e, List.map expand ss)) css in
	Switch (e, css)
    | Function (s, xs, stmt, b) -> Function (s, xs, expand stmt, b)
	  (* assume that class definition is not nested *)
    | Class (cname,optp,xs,ms) -> 
	let ms = List.map (fun (s,xs,stmt,r) -> (s,xs,expand stmt,r)) ms in
	Class (cname, optp, xs, ms) in
 List.map expand stmts 



