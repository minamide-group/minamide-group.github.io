open Basic 

let fresh_var () =  Support.fresh_id ()
let string_of_var x = "$"^string_of_int x^"$"
let pp_var fmt  x = Format.fprintf fmt "$%d$" x
type var = int


module Fa_orig = Fa
module Fa = Charset.Fa

module Cfg = 
  Cfg.Make
    (struct
      type variable = int
      let string_of = string_of_var
      let fresh_variable = fresh_var 
      let compare = compare
    end)
    (struct
      type terminal = char
      let string_of t = Char.escaped t
      let compare = compare
      module Terminal_set = Charset.Charset
    end)    

module Cfg2fa =  Cfg2fa.Make (Fa)(Cfg)
    
module VarSet = Cfg.Variable_set
module Fa_cfg = Fa_cfg.Make(Fa)(Cfg)
module Minimize_orig = Minimize
module Minimize = Minimize.Make(Fa)
module Ft = Ft.Make(
  struct
    type symbol = char 
    let string_of chr = Char.escaped chr
    let pp_print = Format.pp_print_char 
  end)
  (struct
    type symbol = Cfg.symbol
    let string_of chr = Cfg.string_of_symbol chr
    let pp_print = Cfg.pp_sym 
  end)

let string_fa str =
  let size = String.length str in
  let rec loop qs a n = 
    if n <= size then
      loop
	(Basic.Q_set.add n qs)
	(Fa.Arrow.add (n - 1) (String.get str (n - 1)) n a) (n+1)
    else (qs, a) in
  let qs, a = loop (Basic.Q_set.singleton 0) Fa.Arrow.empty 1 in
  {Fa.symbols = Charset.charset;
   Fa.states = qs;
   Fa.arrow = a;
   Fa.start = 0;
   Fa.final = Basic.Q_set.singleton size}

let ft2fa ft =
  let cs = Ft.Arrow.fold 
      (fun _ c _ _ cs -> Charset.Charset.add c cs) ft.Ft.arrow Charset.Charset.empty in
  let a = Ft.Arrow.fold 
      (fun q1 c q2 _ a -> Fa.Arrow.add q1 c q2 a) ft.Ft.arrow Fa.Arrow.empty in
  {Fa.symbols = cs; 
   Fa.states = ft.Ft.states; 
   Fa.arrow = a; 
   Fa.start = ft.Ft.start; 
   Fa.final = ft.Ft.final}

module Ft_cfg = Ft_cfg.Make(Cfg)(Ft)

let prod_add = Cfg.prod_add
let prod_fold = Cfg.prod_fold
let prod_find = Cfg.prod_find
let prod_union = Cfg.prod_union
let vars_of_rules rules = Cfg.vars_of_prod rules

let rhs_map f rhss =
  Cfg.SententialForm_set.fold (fun rhs s -> 
    Cfg.SententialForm_set.add  (f rhs) s) rhss Cfg.SententialForm_set.empty

let cfg_subst p f =
  Cfg.Prod.map (fun rhss ->
    rhs_map 
      (fun rhs -> List.map 
	  (fun sym ->
	    match sym with
	      Cfg.Terminal c ->  f c
	    | _ -> sym) rhs) rhss) p

let prod_homo = Cfg.prod_homo

let top_grammar cs =
  let x = fresh_var () in 
  let y = fresh_var () in 
  let prod = prod_add (x,[]) Cfg.Prod.empty in  
  let prod = Cfg.Terminal_set.fold 
      (fun c rules -> prod_add (y,[Cfg.Terminal c]) rules) cs prod  in  
  (x, prod_add (x,[Cfg.Variable x; Cfg.Variable y]) prod)


open Reg

let rec reg2cfg r rules =
  match r with
    Phi -> ([Cfg.Variable (fresh_var ())], rules)
  | Alpha a -> ([Cfg.Terminal a], rules)
  | Group r -> reg2cfg r rules
  | App (r1, r2) ->
      let c1, rules = reg2cfg r1 rules in
      let c2, rules = reg2cfg r2 rules in
      (c1@c2, rules)
  | Plus (r1, r2) ->
      let c1, rules = reg2cfg r1 rules in
      let c2, rules = reg2cfg r2 rules in
      let x = fresh_var () in
      let rules = prod_add (x, c1) rules in
      let rules = prod_add (x, c2) rules in
      ([Cfg.Variable x], rules)
  | Epsilon -> ([], rules)
  | Star r ->
      let c, rules = reg2cfg r rules in
      let x = fresh_var () in
      let rules = prod_add (x, []) rules in
      let rules = prod_add (x, Cfg.Variable x::c) rules in
      ([Cfg.Variable x], rules)
  | Allalpha ->
      let x = fresh_var () in
      let rules = Cfg.Terminal_set.fold
	  (fun a rules -> prod_add (x, [Cfg.Terminal a]) rules)
	  Charset.charset rules in
      ([Cfg.Variable x], rules)
  | Alphalist al ->
      let x = fresh_var () in
      let rules = List.fold_right 
	  (fun a rules -> prod_add (x, [Cfg.Terminal a]) rules)
	  al rules in
      ([Cfg.Variable x], rules)
  | Negalphalist al ->
      let x = fresh_var () in
      let rules = Cfg.Terminal_set.fold
	  (fun a rules -> 
	    if List.mem a al then rules else
	    prod_add (x, [Cfg.Terminal a]) rules)
	  Charset.charset rules in
      ([Cfg.Variable x], rules)
  | Repetition (r, i, None) ->
      Format.printf "%d None@." i; 
      if i < 0 then failwith "Repetition" 
      else if i = 0 then ([], rules)
      else 
      let c, rules = reg2cfg r rules in
      let x, rules =
	match c with
	  [x] -> x, rules
	| _ ->
	    let x = fresh_var () in
	    Cfg.Variable x, prod_add (x, c) rules in
	let rec repeat j = 
	  if j = 1 then ([x], rules)
	  else 
	    let c, rules = repeat (j - 1) in
	    let y = fresh_var () in
	    let rules = prod_add (y, x::c) rules in
	    ([Cfg.Variable y], rules) in
	let xs, rules = repeat i in
      let x = fresh_var () in
      let rules = prod_add (x, xs) rules in
      let rules = prod_add (x, Cfg.Variable x::c) rules in
      ([Cfg.Variable x], rules)
  | Repetition (r, i, Some j) ->
      if i < 0 then failwith "Repetition" 
      else 
      let c, rules = reg2cfg r rules in
      let x, rules =
	match c with
	  [x] -> x, rules
	| _ ->
	    let x = fresh_var () in
	    Cfg.Variable x, prod_add (x, c) rules in
	let rec repeat j = 
	  if j = 0 then ([], rules)
	  else 
	    let c, rules = repeat (j - 1) in
	    let y = fresh_var () in
	    let rules = prod_add (y, x::c) rules in
	    ([Cfg.Variable y], rules) in
	let xs, rules = repeat i in
	let rec repeat' j = 
	  if j = 0 then (xs, rules)
	  else 
	    let c, rules = repeat' (j - 1) in
	    let y = fresh_var () in
	    let rules = prod_add (y, c) rules in
	    let rules = prod_add (y, x::c) rules in
	    ([Cfg.Variable y], rules) in
	repeat' (j - i)

let idecimal_reg = Pregparser.parse_reg "/0|-{0,1}[1-9][0-9]*/"  
let int_grammar =
  let x = fresh_var () in
  let (ys, prod) = reg2cfg idecimal_reg Cfg.Prod.empty in
  (x, prod_add (x,ys) prod)

let nonnegative_int_reg = Pregparser.parse_reg "/0|[1-9][0-9]*/"  
let nonnegative_int_grammar =
  let x = fresh_var () in
  let (ys, prod) = reg2cfg nonnegative_int_reg Cfg.Prod.empty in
  (x, prod_add (x,ys) prod)

let simplify_cfg cfg = 
  let ps = 
    prod_fold (fun y rhs making ->
      match rhs with
	[Cfg.Variable z] when y = z -> making
      | _ -> prod_add (y, rhs) making) cfg.Cfg.prod Cfg.Prod.empty in
  let find x making =
    try 
      Cfg.Prod.find x making
    with Not_found -> 0 in
  let update x making =
    Cfg.Prod.add x (find x making + 1) making in
  let env =
    prod_fold (fun x rhs making ->
      List.fold_right (fun s making -> match s with
	Cfg.Variable x -> update x making
      | _ -> making) rhs making) ps Cfg.Prod.empty in
  Cfg.Variable_set.fold (fun y cfg->
    try
      let rhss = Cfg.Prod.find y cfg.Cfg.prod in
      if Cfg.SententialForm_set.cardinal rhss = 1 
      then
	let rhs = Cfg.SententialForm_set.choose rhss in
	if (find y env < 2|| List.length rhs < 2) && cfg.Cfg.start != y then
	  let vs = Cfg.Variable_set.remove y (Cfg.vars_of cfg) in
	  let ps = Cfg.Prod.remove y cfg.Cfg.prod in
	  let ps = prod_fold (fun x ss making ->
	    let ss = List.fold_right (fun s making ->
	      match s with
		Cfg.Variable z when z = y -> rhs@making
	      | _ -> s::making) ss [] in
	    prod_add (x, ss) making) ps Cfg.Prod.empty in
	  Cfg.create3 vs ps cfg.Cfg.start
	else cfg
      else
	cfg
    with Not_found ->  cfg) (Cfg.vars_of cfg) cfg


module CharListSet =
  Set.Make(struct 
    type t = char list
    let compare = compare
  end)

let charListSet_map f ss =
  CharListSet.fold (fun s ss ->
    CharListSet.add (f s) ss) ss CharListSet.empty

let concat_set ss ss' =
  CharListSet.fold (fun s ss'' ->
    CharListSet.fold (fun s' ss'' ->
      CharListSet.add (s@s') ss'') ss' ss'') ss CharListSet.empty

exception Infinite

let words_of s prod  =
  let rec dfs env ys x =
    if List.mem x ys then 
      (Format.printf "%s@." (string_of_var x);
       raise Infinite)
    else
      let env, ss =
	Cfg.SententialForm_set.fold 
	  (fun rhs (env,ss) ->
	    let env, ss' =
	      (List.fold_right (fun sym (env,ss) ->
		match sym with
		  Cfg.Terminal c ->(env, charListSet_map (fun s -> c::s) ss)
		| Cfg.Variable z ->
		    let env, ss' =
		      try 
			(env, Cfg.Prod.find z env)
		      with Not_found ->
			dfs env (x::ys) z in
		    env, concat_set ss' ss)
		 rhs (env, CharListSet.singleton [])) in
	    (env, CharListSet.union ss ss')) 
	  (try Cfg.Prod.find x prod with Not_found -> Cfg.SententialForm_set.empty)
	  (env, CharListSet.empty) in
      Cfg.Prod.add x ss env, ss in
  let env, ss = dfs Cfg.Prod.empty [] s in
  CharListSet.elements ss

let words_of_cfg cfg = words_of cfg.Cfg.start cfg.Cfg.prod

let unitpair cfg =
  let find x next = 
    try Cfg.Prod.find x next with Not_found -> [] in
  let add x y next = Cfg.Prod.add x (y:: find x next) next in
  prod_fold (fun x rhs making ->
    match rhs with
      [Cfg.Variable y] -> add x y making
    | _ -> making) cfg.Cfg.prod Cfg.Prod.empty

let unitchain cfg =
  let add x y next = Cfg.Prod.add x y next in
  Cfg.Prod.fold (fun x rhss making ->
    if Cfg.SententialForm_set.cardinal rhss = 1 then
      match Cfg.SententialForm_set.choose rhss with
	[Cfg.Variable y] -> add x y making
      | _ -> making
    else making ) cfg.Cfg.prod Cfg.Prod.empty

let rec solve x chain =
  try
    let y = Cfg.Prod.find x chain in
    let z, chain = solve y chain in
    z, Cfg.Prod.add x z chain
  with Not_found -> x,chain
      
let chain_elim cfg =
(*  let () = Cfg.printCFG cfg in *)
  let () = Options.show 1 (fun fmt -> Format.fprintf fmt "chain elim@.") in
  let chain = unitchain cfg in
(*  let () = Cfg.Prod.iter 
      (fun x y -> Format.printf "%s --> %s@." (Il.string_of_var x)
	  (Il.string_of_var y)) chain in *)
  let prod, chain = 
    prod_fold (fun x rhs (making, chain) ->
      try 
	let _ = Cfg.Prod.find x chain in (making, chain) 
      with
	Not_found ->
	  let ss, chain =
	    List.fold_right (fun s (ss, chain) ->
	      match s with 
		Cfg.Variable y -> 
		  let y',chain = solve y chain in (Cfg.Variable y'::ss, chain)
	      | _ -> (s::ss, chain)) rhs ([], chain) in
	  (prod_add (x, ss) making, chain)) cfg.Cfg.prod (Cfg.Prod.empty, chain) in
  let s,_ = solve cfg.Cfg.start chain in
  Cfg.create3 (Cfg.vars_of cfg) prod s

  

let nexts n x = try Cfg.Prod.find x n with Not_found -> []
let nodes_of n = 
  Cfg.Prod.fold (fun x ys making ->
    List.fold_left 
      (fun making y -> Cfg.Variable_set.add y making)
      (Cfg.Variable_set.add x making) ys) 
    n Cfg.Variable_set.empty

module Absgraphx = 
  Absgraph.Make(struct 
    type t = var
    type g = var list Cfg.Prod.t 
    let nexts = nexts
    let nodes_of = nodes_of
    module NodeSet = Cfg.Variable_set
  end)

let simplify_unitpair cfg =
  let upair = unitpair cfg in
  let () = Options.show 2 (fun fmt -> Format.printf "Comuputing unitpair@.") in
  let vs' = nodes_of upair in
  let () = Options.show 2 (fun fmt -> Format.printf "Nodesof@.") in
  let scc = Absgraphx.sc upair in
  let () = Options.show 2 (fun fmt -> Format.printf "After scc@.") in
  let env =
    List.fold_left (fun making sc ->
      match (Cfg.Variable_set.elements sc) with
	[] -> failwith "simplify_unitpair"
      | [_] -> making
      | x::xs -> 
	  List.fold_left (fun making y -> Cfg.Prod.add y x making) making xs)
      Cfg.Prod.empty scc in
  let rename x = try Cfg.Prod.find x env with Not_found -> x in
  let rename_sym sym = 
    match sym with
      Cfg.Variable x -> Cfg.Variable (rename x)
    | _ -> sym in
  let rename_rhs rhs = List.map rename_sym rhs in
  let rename_rhss rhss = 
    Cfg.SententialForm_set.fold 
      (fun rhs rhss -> 
	Cfg.SententialForm_set.add (rename_rhs rhs) rhss)
      rhss Cfg.SententialForm_set.empty in
  let prod = 
    Cfg.Prod.fold (fun x rhss prod -> 
      let rhss = rename_rhss rhss in
      if Cfg.Variable_set.mem x vs' then 
	let x = rename x in
      let rhss = Cfg.SententialForm_set.filter (fun rhs ->
	    match rhs with
	      [Cfg.Variable z] -> z <> x
	    | _ -> true) rhss in
      let rhss = try Cfg.SententialForm_set.union rhss
	  (Cfg.Prod.find x prod) with Not_found -> rhss in 
	Cfg.Prod.add x rhss prod
      else Cfg.Prod.add x rhss prod) cfg.Cfg.prod Cfg.Prod.empty in
  Cfg.create3 (Cfg.vars_of cfg) prod (rename (cfg.Cfg.start))


let dependency cfg =
  let find x next = 
    try Cfg.Prod.find x next with Not_found -> [] in
  let add x y next = Cfg.Prod.add x (y:: find x next) next in
  prod_fold (fun x rhs making ->
    List.fold_left (fun making s ->
      match s with
      Cfg.Variable y -> add y x making
    | _ -> making) making rhs) cfg.Cfg.prod Cfg.Prod.empty


(* The set of variables from which only the empty string can be derived. *)
let null cfg vs =
  let g = dependency cfg in
  let xs = Cfg.Variable_set.elements (  
    Cfg.Prod.fold (fun x rhss making ->
      if Cfg.SententialForm_set.exists (fun rhs ->
	List.exists (fun s -> match s with
	  Cfg.Terminal _ -> true
	| _ -> false) rhs) rhss
      then Cfg.Variable_set.add x making else making)
      cfg.Cfg.prod vs) in
  let ys = Absgraphx.dfs g xs Cfg.Variable_set.empty in
  Cfg.Variable_set.diff (Cfg.vars_of cfg) ys

let simplify_null' cfg vs' =
  let () = Options.show 1 (fun fmt -> Format.printf "Computing null...@?") in
  let xs = null cfg vs' in
(*  let () = Cfg.Variable_set.iter (fun x -> Format.printf "%s@." (Il.string_of_var x)) 
      xs in *)
  let () = Options.show 1 (fun fmt -> Format.printf "DONE!@.") in
  let simplify_ss ss = 
    List.filter
      (fun s ->
	match s with
	  Cfg.Variable x -> not (Cfg.Variable_set.mem x xs)
	| _ -> true) ss in
  if Cfg.Variable_set.mem cfg.Cfg.start xs then
    if Cfg.Variable_set.mem cfg.Cfg.start (Cfg.generating cfg) 
    then
      Cfg.create3 
	(Cfg.Variable_set.singleton cfg.Cfg.start)
	(Cfg.prod_add (cfg.Cfg.start,[]) Cfg.Prod.empty)
	cfg.Cfg.start
    else
      Cfg.create3 
	(Cfg.Variable_set.singleton cfg.Cfg.start)
	Cfg.Prod.empty cfg.Cfg.start
  else    
    Cfg.create3 
      (Cfg.Variable_set.diff (Cfg.vars_of cfg) xs)
      (prod_fold (fun x rhs making ->
	if Cfg.Variable_set.mem x xs then making
	else prod_add (x, simplify_ss rhs) making) cfg.Cfg.prod Cfg.Prod.empty)
      cfg.Cfg.start

let simplify_null cfg = simplify_null' cfg Cfg.Variable_set.empty


exception Empty
exception Backtrack of Cfg.symbol list Cfg.Prod.t


let word_of cfg  =
  let rec dfs_and env ys x ss cs =
    match ss with
      [] -> Cfg.Prod.add x (List.rev cs) env
    | s::ss ->
	(match s with
	  Cfg.Terminal c -> dfs_and env ys x ss (s::cs) 
	| Cfg.Variable z ->
	    let env = if Cfg.Prod.mem z env then env else dfs env ys z in
	    dfs_and env ys x ss (s::cs))
  and dfs_or env ys x rhss =
    if Cfg.SententialForm_set.is_empty rhss then raise (Backtrack env)
    else
      let rhs = Cfg.SententialForm_set.choose rhss in
      let rhss = Cfg.SententialForm_set.remove rhs rhss in
      if Cfg.SententialForm_set.is_empty rhss then dfs_and env ys x rhs []
      else
	try dfs_and env ys x rhs []
	with Backtrack env -> dfs_or env ys x rhss 
  and dfs env ys x =
    if Cfg.Variable_set.mem x ys then raise (Backtrack env)
    else 
      dfs_or env (Cfg.Variable_set.add x ys) x (Cfg.prod_find x cfg.Cfg.prod) in 
  let env = 
    try dfs Cfg.Prod.empty Cfg.Variable_set.empty cfg.Cfg.start 
    with Backtrack env -> raise Empty in
(*  let () = Format.printf "dfs end@." in *)
  let rec dfs x cs =
    let rhs = Cfg.Prod.find x env in 
    List.fold_right (fun s cs ->
      match s with
	Cfg.Terminal c -> c::cs
      | Cfg.Variable z -> dfs z cs) rhs cs in
  dfs cfg.Cfg.start []


let digit_reg = Reg.Alphalist 
    ['0';'1';'2';'3';'4';'5';'6';'7';'8';'9'] 
let lnum_reg' = Reg.Star digit_reg
let lnum_reg = 
  Reg.App (Reg.Plus (digit_reg, Reg.Epsilon),
	      lnum_reg')
let dnum_reg = 
    Reg.App (lnum_reg, Reg.App (Reg.Alpha '.',
				      lnum_reg))
let exponent_float_reg = 
  Reg.App (Reg.App 
    (Reg.App (dnum_reg,
		 Reg.Plus (Reg.Alpha 'e', Reg.Alpha 'E')),
     Reg.Plus (Reg.Plus (Reg.Alpha '+', Reg.Alpha '-'),
		Reg.Epsilon)), lnum_reg)

let float_reg = Reg.Plus (dnum_reg, exponent_float_reg)

let float_grammar = reg2cfg float_reg Cfg.Prod.empty

module TerminalMap =
  Map.Make(struct 
    type t = Cfg.terminal
    let compare = compare
  end)

let concat_ss_sss ss sss =
  Cfg.SententialForm_set.fold (fun ss' sss' ->
    Cfg.SententialForm_set.add (ss@ss') sss') sss 
    Cfg.SententialForm_set.empty

let concat_sss_sss sss1 sss2 =
  Cfg.SententialForm_set.fold (fun ss' sss' ->
    Cfg.SententialForm_set.union (concat_ss_sss ss' sss2) sss')
    sss1 Cfg.SententialForm_set.empty
    
let expand_ss prod ss =
  List.fold_right (fun s sss ->
    let sss' = match s with
      Cfg.Variable x -> Cfg.prod_find x prod 
    | Cfg.Terminal t ->
 	Cfg.SententialForm_set.singleton [Cfg.Terminal t] in
    concat_sss_sss sss' sss) ss
    (Cfg.SententialForm_set.singleton [])

let word_of' cfg =
  let rec dfs_and env ys ss =
    match ss with
      [] -> (env,[])
    | s::ss ->
	(match s with
	  Cfg.Terminal c ->
	    let env, cs = dfs_and env ys ss in
	    (env, c::cs)
	| Cfg.Variable z ->
	    try 
	      let cs' = Cfg.Prod.find z env in
	      let env, cs = dfs_and env ys ss in
	      (env, cs'@cs)
	    with Not_found ->
	      let env, cs' = dfs env ys z in
	      let env, cs = dfs_and env ys ss in
	      (env, cs'@cs))
  and dfs_or env ys rhss =
    if Cfg.SententialForm_set.is_empty rhss then raise Empty
    else
      let rhs = Cfg.SententialForm_set.max_elt rhss in
      try dfs_and env ys rhs
      with Empty | Infinite -> 
	let rhss = Cfg.SententialForm_set.remove rhs rhss in
	dfs_or env ys rhss 
  and dfs env ys x =
    if List.mem x ys then raise Infinite
    else 
      let env, cs = dfs_or env (x::ys) (Cfg.prod_find x cfg.Cfg.prod) in 
      Cfg.Prod.add x cs env, cs in
  dfs_and

let nwords_of cfg n =
  let rec loop (queue, tss, env) =
    match queue with
      [] -> tss
    | ss::queue ->
	let env, ts = word_of' cfg env [] ss in
	let tss = CharListSet.add ts tss in
	if CharListSet.cardinal tss >= n then tss
	else 
	  let sss = expand_ss cfg.Cfg.prod ss in
	  loop (queue@ Cfg.SententialForm_set.elements sss, tss, env) in
  loop ([[Cfg.Variable cfg.Cfg.start]], CharListSet.empty, Cfg.Prod.empty)

open Support

let cfg_simplify cfg =
  let cfg = Cfg.useful cfg in
  let () = Options.show 1 (fun fmt -> Format.fprintf fmt "Symplify_null...@?") in
  let cfg = simplify_null cfg in  
  let () = Options.show 1 (fun fmt -> Format.fprintf fmt "DONE!@.") in
  let () = Options.show 1 (fun fmt -> Format.fprintf fmt "Symplify_unitpair...@?") in
  let cfg = simplify_unitpair cfg in 
  let () = Options.show 1 (fun fmt -> Format.fprintf fmt "DONE!@.") in 
  let cfg = Cfg.useful cfg in
  let cfg = chain_elim cfg in  
  let cfg = Cfg.useful cfg in
  cfg
