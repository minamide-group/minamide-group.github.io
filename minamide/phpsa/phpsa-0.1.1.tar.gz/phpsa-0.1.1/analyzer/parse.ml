let parse_php file = 
  let () =
    try
      match (Unix.stat file).Unix.st_kind with
	Unix.S_REG -> ()
      | _ -> raise (Sys_error "not a regular file") 
    with _  -> raise (Sys_error "file not found")  in
  let inchan = open_in file in
  let lexbuf = Lexing.from_channel inchan in
  let () = Lexer.set_fname lexbuf file in
  let () = Lexer.reset () in
  let phptoken lexbuf = 
    match !Lexer.pending_tokens with
      Some tok -> Lexer.pending_tokens := None; tok
    | None ->
	(match Lexer.mode_of () with
	| (Lexer.InHtml, _) -> Lexer.html_token lexbuf 
	| (Lexer.InCode, Lexer.InScript) -> Lexer.token lexbuf 
	| (Lexer.InCode, Lexer.InString) -> Lexer.string_token lexbuf 
	| (Lexer.InCode, Lexer.InBackQuoteString) -> Lexer.string_token lexbuf 
	| (Lexer.InCode, Lexer.InIndex) -> Lexer.index_token lexbuf 
	| (Lexer.InCode, Lexer.InHeredoc1) -> Lexer.heredoc1_token lexbuf
	| (Lexer.InCode, Lexer.InHeredoc2) -> Lexer.heredoc2_token lexbuf) in
  try
    let ss = Parser.main phptoken lexbuf in
    close_in inchan; 
    ss
  with 
    Failure s ->
      let {Lexing.pos_lnum=lnum} = Lexing.lexeme_start_p lexbuf in
      failwith 
	(Format.sprintf "Parser error (%s): file \"%s\" line %d"  s file lnum);
  | _ -> 
	let {Lexing.pos_lnum=lnum} = Lexing.lexeme_start_p lexbuf in
	failwith (Format.sprintf "Parser error : file \"%s\" line %d" file lnum);
	
