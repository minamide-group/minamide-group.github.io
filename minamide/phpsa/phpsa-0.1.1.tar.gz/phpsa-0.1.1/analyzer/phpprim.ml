(*
 * PHP string analyzer
 * Copyright (C) 2006 Yasuhiko Minamide
 *)

open Il
open Flbasics

let string_fold_right = Support.string_fold_right
let explode = Support.explode

let string2cfg s = 
  let x = fresh_var () in
  (x, string_fold_right (fun c s -> Cfg.Terminal c :: s) s [])

let (ltx, rule) = string2cfg "&lt;" 
let htmlspecialchars_rules = prod_add (ltx, rule) Cfg.Prod.empty 
let (gtx, rule) = string2cfg "&gt;" 
let htmlspecialchars_rules = prod_add (gtx, rule) htmlspecialchars_rules 
let (ampx, rule) = string2cfg "&amp;" 
let htmlspecialchars_rules = prod_add (ampx, rule) htmlspecialchars_rules 
let (doublequotex, rule) = string2cfg "&quot;" 
let htmlspecialchars_rules = prod_add (doublequotex, rule) htmlspecialchars_rules 

let add_string_rule str rules =
  let (x, rule) = string2cfg str  in
  let rules = prod_add (x, rule) rules in
  (x, rules)

let (quoteperiod, quote_rules) = add_string_rule "\\." Cfg.Prod.empty 
let (quotebackslash, quote_rules) = add_string_rule "\\\\" quote_rules
let (quoteplus, quote_rules) = add_string_rule "\\+" quote_rules
let (quotestar, quote_rules) = add_string_rule "\\*" quote_rules
let (quotequestionmark, quote_rules) = add_string_rule "\\?" quote_rules
let (quotelbracket, quote_rules) = add_string_rule "\\[" quote_rules
let (quotehat, quote_rules) = add_string_rule "\\^" quote_rules
let (quoterbracket, quote_rules) = add_string_rule "\\]" quote_rules
let (quotelparenthesis, quote_rules) = add_string_rule "\\(" quote_rules
let (quotedollar, quote_rules) = add_string_rule "\\$" quote_rules
let (quoterparenthesis, quote_rules) = add_string_rule "\\)" quote_rules
let (quotesinglequote, quote_rules) = add_string_rule "\\'" quote_rules
let (quotedoublequote, quote_rules) = add_string_rule "\\\"" quote_rules
let (quotenull, quote_rules) = add_string_rule "\\\000" quote_rules

let date_regs =
  [('a',"/am|pm/");
   ('A',"/AM|PM/");
   ('B',"/\\d\\d\\d/");
   ('d',"/0\\d|1\\d|2\\d|30|31/");
   ('D',"/Mon|Tue|Wes|Thu|Fri|Sta|Sun/");
   ('F',"/January|February|March|April|May|June|July|August|September|October|November|December/");
   ('g',"/[1-9]|1[0-2]/");
   ('G',"/\\d|1\\d|2[0-3]/");
   ('h',"/0[1-9]|1[0-2]/");
   ('H',"/0\\d|1\\d|2[0-3]/");
   ('i',"/[0-5]\\d/");
   ('j',"/[1-9]|1\\d|2\\d|30|31/");
   ('l',"/Sunday|Monday|Tuesday|Wednesday|Thursday|Friday|Sturday/");
   ('m',"/0\\d|1[0-2]/");
   ('M',"/Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec/");
   ('n',"/[1-9]|1[0-2]/");
   ('s',"/[0-5]\\d/");
   ('s',"/[0-5]\\d/");
   ('Y',"/\\d\\d\\d\\d/");
   ('y',"/\\d\\d/")]

let date_alist, date_rules =
  List.fold_left (fun (alist,rules) (c,s) ->
    let reg = Pregparser.parse_reg s in
    let xs, rules = reg2cfg reg rules in
    let x, rules = 
      match xs with
	[x] -> x, rules
      | _ -> let x = fresh_var () in Cfg.Variable x, prod_add (x, xs) rules in
    (c,x)::alist, rules) ([], Cfg.Prod.empty) date_regs

let hex_var, hex_rules =
  let reg = Pregparser.parse_reg "/%[0-9A-Z][0-9A-Z]/" in
  let xs, rules = reg2cfg reg Cfg.Prod.empty in
  match xs with
    [x] -> x, rules
  | _ -> let x = fresh_var () in 
    Cfg.Variable x, prod_add (x, xs) rules 

let cfg_rev cfg =
  let p = prod_fold 
      (fun x sent making -> prod_add (x, List.rev sent) making) cfg.Cfg.prod Cfg.Prod.empty in
  Cfg.create3 (Cfg.vars_of cfg) p cfg.Cfg.start

type stringop =
    OpSubst of (char -> Cfg.symbol) * Cfg.SententialForm_set.t Cfg.Prod.t
  | OpHomo of (char -> Cfg.terminal list) 
  | OpTransducer of Ft.ft
  | OpTransducerEndmark of Ft.ft
  | OpOther of (Cfg.cfg -> Cfg.cfg)

let char2hex c =
  let hex2char i = 
    if i < 10 then Char.chr (Char.code '0' + i) else Char.chr (Char.code 'A' + i - 10) in
  let code = Char.code c in
  (hex2char (code lsr 4), hex2char (code mod 16))

let urlencode c =
  match c with
    '-' | '.' | '_' -> [c]
  | ' ' -> ['+']
  | _ -> 
      if (c >= '0' && c <= '9') ||
      (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') 
      then [c] else 
	let x, y = char2hex c in
	['%'; x; y]

let rot13 c base = Char.chr ((Char.code c - Char.code base + 13) mod 26 + Char.code base)

let htmlentities =
  [|"&nbsp;"; "&iexcl;"; "&cent;"; "&pound;"; "&curren;"; "&yen;"; "&brvbar;"; "&sect;"; 
    "&uml;"; "&copy;"; "&ordf;"; "&laquo;"; "&not;"; "&shy;"; "&reg;"; "&macr;"; 
    "&deg;"; "&plusmn;"; "&sup2;"; "&sup3;"; "&acute;"; "&micro;"; "&para;"; "&middot;"; 
    "&cedil;"; "&sup1;"; "&ordm;"; "&raquo;"; "&frac14;"; "&frac12;"; "&frac34;"; "&iquest;"; 
    "&Agrave;"; "&Aacute;"; "&Acirc;"; "&Atilde;"; "&Auml;"; "&Aring;"; "&AElig;"; "&Ccedil;"; 
    "&Egrave;"; "&Eacute;"; "&Ecirc;"; "&Euml;"; "&Igrave;"; "&Iacute;"; "&Icirc;"; "&Iuml;"; 
    "&ETH;"; "&Ntilde;"; "&Ograve;"; "&Oacute;"; "&Ocirc;"; "&Otilde;"; "&Ouml;"; "&times;"; 
    "&Oslash;"; "&Ugrave;"; "&Uacute;"; "&Ucirc;"; "&Uuml;"; "&Yacute;"; "&THORN;"; "&szlig;"; 
    "&agrave;"; "&aacute;"; "&acirc;"; "&atilde;"; "&auml;"; "&aring;"; "&aelig;"; "&ccedil;"; 
    "&egrave;"; "&eacute;"; "&ecirc;"; "&euml;"; "&igrave;"; "&iacute;"; "&icirc;"; "&iuml;"; 
    "&eth;"; "&ntilde;"; "&ograve;"; "&oacute;"; "&ocirc;"; "&otilde;"; "&ouml;"; "&divide;"; 
    "&oslash;"; "&ugrave;"; "&uacute;"; "&ucirc;"; "&uuml;"; "&yacute;"; "&thorn;"; "&yuml;"|]

let htmlentities_decode =
  let _, tbl = Array.fold_left (fun (i, tbl) s -> (i+1, (s, String.make 1 (Char.chr i))::tbl)) (160, []) htmlentities in
  tbl

open Valuespec

let stringop_list =
  ["htmlspecialchars", 
   OpSubst ((fun c -> 
     match c with
       '<' -> Cfg.Variable ltx
     | '>' -> Cfg.Variable gtx
     | '&' -> Cfg.Variable ampx
     | '"' -> Cfg.Variable doublequotex
     | _ -> Cfg.Terminal c), htmlspecialchars_rules),
   ([Vstring; Vint], [Vstring], Vstring);
   "htmlentities",  
   OpHomo (fun c -> 
     match c with
       '<' -> explode "&lt;"
     | '>' -> explode "&gt;"
     | '&' -> explode "&amp;"
     | '"' -> explode "&quote;"
     | c when c >= '\160' -> explode (htmlentities.(Char.code c - 160))
     | _ -> [c]),
   ([Vstring; Vint], [Vstring], Vstring);
   "preg_quote",   
   OpHomo (fun c -> 
     match c with
       '.' | '\\' | '+' | '*' | '?' | '[' | '^' | ']' | '$' | '(' | ')' 
     | '{' | '}' | '=' | '!' | '<' | '>' | '|' | ':' ->
	 ['\\'; c]
     | _ -> [c]),
   ([Vstring], [Vstring], Vstring);
   "quotemeta",  
   OpSubst ((fun c -> 
     match c with
       '.' -> Cfg.Variable quoteperiod
     | '\\' -> Cfg.Variable quotebackslash
     | '+' -> Cfg.Variable quoteplus
     | '*' -> Cfg.Variable quotestar
     | '?' -> Cfg.Variable quotequestionmark
     | '[' -> Cfg.Variable quotelbracket
     | '^' -> Cfg.Variable quotehat
     | ']' -> Cfg.Variable quoterbracket
     | '(' -> Cfg.Variable quotelparenthesis
     | '$' -> Cfg.Variable quotedollar
     | ')' -> Cfg.Variable quoterparenthesis
     | _ -> Cfg.Terminal c), quote_rules),
   ([Vstring], [], Vstring);
   "addslashes", 
   OpSubst ((fun c -> 
     match c with
       '\'' -> Cfg.Variable quotesinglequote
     | '"' -> Cfg.Variable quotedoublequote
     | '\\' -> Cfg.Variable quotebackslash
     | '\000' -> Cfg.Variable quotenull
     | _ -> Cfg.Terminal c), quote_rules),
   ([Vstring], [], Vstring);
   "mysql_escape_string", 
   OpHomo (fun c -> 
     match c with
      '\x00' | '\n' | '\r' | '\\' | '\'' | '"' | '\x1a' -> ['\\'; c]
     | _ ->  [c]),
   ([Vstring], [], Vstring);
   "mysql_real_escape_string", 
   OpHomo (fun c -> 
     match c with
      '\x00' | '\n' | '\r' | '\\' | '\'' | '"' | '\x1a' -> ['\\'; c] 
     | _ ->  [c]),
   ([Vstring], [Vresource], Vstring);
   "strtolower", 
   OpSubst ((fun c -> Cfg.Terminal (Char.lowercase c)),
	   Cfg.Prod.empty),
   ([Vstring], [], Vstring);
   "strtoupper", 
   OpSubst ((fun c -> Cfg.Terminal (Char.uppercase c)),
	   Cfg.Prod.empty),
   ([Vstring], [], Vstring);
   "str_rot13",  
   OpSubst ((fun c -> 
     if c >= 'a' && c <= 'z' then Cfg.Terminal (rot13 c 'a') 
     else if c >= 'A' && c <= 'Z' then Cfg.Terminal (rot13 c 'A') 
     else Cfg.Terminal (Char.uppercase c)),
	   Cfg.Prod.empty),
   ([Vstring], [], Vstring);
   "bin2hex",    
   OpHomo (fun c -> let x, y = char2hex c in [x; y]),
   ([Vstring], [], Vstring);
   "rawurlencode", 
   OpHomo (fun c -> 
     match c with
       '-' | '.' | '_' -> [c]
     | _ -> 
	 if (c >= '0' && c <= '9') ||
	 (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') 
	 then [c] else 
	   let x, y = char2hex c in
	   ['%'; x; y]), 
   ([Vstring], [], Vstring);
   "urlencode", 
   OpHomo urlencode,
   ([Vstring], [], Vstring);
   "nl2br", OpTransducerEndmark Fts.nl2br_ft,
   ([Vstring], [], Vstring);
   "trim", OpTransducer (Fts.trim_ft Fts.sp),
   ([Vstring], [Vstring], Vstring);  
   "ltrim", OpTransducer (Fts.ltrim_ft Fts.sp),
   ([Vstring], [Vstring], Vstring); 
   "rtrim", OpTransducer (Fts.rtrim_ft Fts.sp),
   ([Vstring], [Vstring], Vstring);  
   "chop", OpTransducer (Fts.rtrim_ft Fts.sp),
   ([Vstring], [Vstring], Vstring); 
   "ucfirst", OpTransducer Fts.ucfirst_ft,
   ([Vstring], [], Vstring); 
   "ucwords", OpTransducer Fts.ucword_ft,
   ([Vstring], [], Vstring); 
   "strip_tags", OpTransducer Fts.strip_tags_ft,
   ([Vstring], [Vstring], Vstring); 
   "strrev", OpOther cfg_rev,
   ([Vstring], [], Vstring); 
   "stripslashes", OpTransducerEndmark 
     (Fts.strings_ft_endmark
	[("\\\\","\\");("\\\"","\""); ("\\'","'")]),
   ([Vstring], [], Vstring);
   "html_entity_decode", OpOther (fun cfg ->
     Ft_cfg.inter
     (Fts.strings_ft
	([("&amp;","&");
	  ("&quot;","\""); 
	  ("&lt;","<"); 
	  ("&gt;",">")]@htmlentities_decode)) cfg), 
   ([Vstring], [Vint; Vstring], Vstring); 
   "date", OpSubst ((fun c -> 
     try
       List.assoc c date_alist 
     with Not_found -> Cfg.Terminal c), date_rules),
   ([Vstring], [Vint], Vstring);
   "urldecode", OpTransducer Fts.urldecode_ft,
   ([Vstring], [], Vstring); 
   "rawurldecode", OpTransducer Fts.rawurldecode_ft,
   ([Vstring], [], Vstring); 
   "base64_encode", OpTransducerEndmark Fts.base64encode_ft,
   ([Vstring], [], Vstring); 
   "base64_dencode", OpTransducer Fts.base64encode_ft,
   ([Vstring], [], Vstring); 
   "stripcslashes", OpTransducerEndmark Fts.stripcslashes_ft,
   ([Vstring], [], Vstring); 
   "quoted_printable_decode", OpOther Fts.quoted_printable_decode,
   ([Vstring], [], Vstring); 
   "str_shuffle", OpOther Fts.str_shuffle,
   ([Vstring], [], Vstring); 
   "soundex", OpOther Fts.soundex,
   ([Vstring], [], Vstring); 
 ]

let stringops_spec = 
  [
   "addcslashes", ([Vstring], [Vstring], Vstring);
   "chunk_split", ([Vstring], [Vint; Vstring], Vstring); 
   "explode", ([Vstring; Vstring], [Vint], Varray0);
   "implode", ([Vstring; Varray0], [], Vstring); 
   "join", ([Vstring; Varray0], [], Vstring); 
   "number_format", ([Vfloat], [Vint], Vstring); 
   (* "http_build_query"; *)

   "str_split", ([Vstring], [Vint], Varray0); 
   "strtok", ([Vstring; Vstring], [], Vstring); 
   "strstr", ([Vstring; Vstring], [], vor Vstring vfalse); 
  (* the second argument is converted into an integer, and then a character *)
   "stristr", ([Vstring; Vstring], [], vor Vstring vfalse); 
   "strrchr", ([Vstring; Vstring], [], vor Vstring vfalse); 
   "substr_replace", ([Vstring; Vstring; Vint], [Vint], Vstring); 
   "substr", ([Vstring; Vint], [Vint], vor Vstring vfalse); 
   "str_pad", ([Vstring; Vint], [Vstring; Vint], Vstring); 
   "str_repeat", ([Vstring; Vint], [], Vstring); 
   "str_replace", ([Vmixed; Vmixed; Vmixed], [Vint], Vmixed); 
   "strval", ([Vmixed], [], Vstring); 
   "wordwrap", ([Vstring], [Vint; Vstring; Vbool], Vstring);

   "sprintf", ([], [], Vstring); 
   "vsprintf", ([], [], Vstring);
   "printf", ([], [], Vstring); 
   "vprintf", ([], [], Vstring);

   "preg_split", ([Vstring; Vstring], [Vint; Vint], Varray0);
   "preg_match", 
   ([Vstring; Vstring], [], Vint); 
   "__preg_match_array", ([Vstring; Vstring], [], Varray0); 
   "__preg_match", ([Vstring; Vstring], [], Vstring);  
   "__npreg_match", ([Vstring; Vstring], [], Vstring);  
   "preg_match_all", 
(* ([Vstring; Vstring; Varray0], [Vint; Vint], Vint); (* string, string, array;  int; int -> int *) *)
   ([Vstring; Vstring], [], Vint); 
   "__preg_match_all", ([Vstring; Vstring], [], Varray0); 
   "ereg", ([Vstring; Vstring], [Varray0], Vbool); 
   "__ereg_array", ([Vstring; Vstring], [], Varray0);  
   "__ereg", ([Vstring; Vstring], [], Vstring);   
   "__nereg", ([Vstring; Vstring], [], Vstring);  
   "eregi", ([Vstring; Vstring], [Varray0], Vbool); 
   "__eregi_array", ([Vstring; Vstring], [], Varray0); 
   "__eregi", ([Vstring; Vstring], [], Vstring);   
   "__neregi", ([Vstring; Vstring], [], Vstring);  

   "get_class", ([], [], vor (Vboolval false) Vstring);
   "get_parent_class", ([], [], vor (Vboolval false) Vstring); 
   "preg_replace", ([Vmixed; Vmixed; Vmixed], [Vint], Vmixed); 
   "ereg_replace", ([Vstring; Vstring; Vstring], [], Vstring); 
   "eregi_replace", ([Vstring; Vstring; Vstring], [], Vstring); 

   "array_slice", ([Varray0; Vint], [Vint], Varray0); 
   "array_values", ([Varray0], [], Varray0); 
   "array_keys", ([Varray0], [Vmixed], Varray0);
   "key", ([Varray0], [], Vmixed); 
   "array_chunk", ([Varray0; Vint], [Vbool], Varray0);
   "array_push", ([Varray0; Vmixed], [], Vint);
   "array_pop", ([Varray0], [], Vmixed); 
   "each", ([Varray0], [], Varray0); 
   "array_count_values", ([Varray0], [], Varray0); 
   "current", ([Varray0], [], Vmixed);
   "next", ([Varray0], [], Vmixed); 
   "end", ([Varray0], [], Vmixed); 
   "pos", ([Varray0], [], Vmixed); 
   "prev", ([Varray0], [], Vmixed); 
   "reset", ([Varray0], [], Vmixed); 
   "array_merge", ([Varray0; Varray0], [], Varray0); 
   "array_change_key_case", ([Varray0], [Vint], Varray0); 
   "array_search", ([Vmixed; Varray0], [Vbool], Vmixed); 

   "arrayeach", ([Varray0], [], Vbool); 
   (* This primitive is used for translation of foreach *)
   ]

let stringops = List.map fst stringops_spec @ List.map (fun (x,_,_) -> x) stringop_list 

let boolops =
  ["is_a"; "is_array"; "is_bool"; "is_callable"; "is_double"; "is_float";
   "is_int"; "is_integer"; "is_long"; "is_null"; "is_numeric";
   "is_object"; "is_real"; "is_scalar"; "is_string"; "is_resource";
   "empty"; "isset"; "defined"; "function_exists"; "class_exists";
   "is_subclass_of"; "method_exists";
   "extension_loaded"; "is_file"; "file_exists"; "in_array";
   "settype"; "array_key_exists"]

let predefined_prims = 
  List.fold_left (fun ss s -> Support.StringSet.add s ss) 
    Support.StringSet.empty (stringops@boolops)

let find_stringop s = 
  let rec loop ss = 
    match ss with
      [] -> raise Not_found
    | (s', operation,_)::ss -> if s = s' then operation else loop ss in
  loop stringop_list
   
let find_type s =
  let rec loop ss = 
    match ss with
      [] -> let _,_,t  = List.assoc s stringops_spec in t
    | (s', operation,(_,_,t))::ss -> if s = s' then t else loop ss in
  if List.mem s boolops then Vbool else loop stringop_list
  

let find_stringop_type s =
  let rec loop ss = 
    match ss with
      [] -> List.assoc s stringops_spec 
    | (s', operation,t)::ss -> if s = s' then t else loop ss in
loop stringop_list
  
let htmlentities_hom n c =
  match c with
    '<' -> explode "&lt;"
  | '>' -> explode "&gt;"
  | '&' -> explode "&amp;"
  | '"' -> if n = 0 then [c] else explode "&quote;"
  | '\'' -> if n = 3 then explode "&#039;" else [c]
  | c when c >= '\160' -> explode (htmlentities.(Char.code c - 160))
  | _ -> [c]

let htmlspecialchars_hom n c =
  match c with
    '<' -> explode "&lt;"
  | '>' -> explode "&gt;"
  | '&' -> explode "&amp;"
  | '"' -> if n = 0 then [c] else explode "&quote;"
  | '\'' -> if n = 3 then explode "&#039;" else [c]
  | _ -> [c]

let html_entity_decode_transducer n =
  match n with
    0 -> Fts.strings_ft 
	([("&amp;","&");("&quot;","\""); 
	 ("&lt;","<"); ("&gt;",">")]@htmlentities_decode)
  | 2 -> Fts.strings_ft 
	([("&amp;","&");("&quot;","\""); 
	 ("&lt;","<"); ("&gt;",">")]@htmlentities_decode)
  | 3 -> Fts.strings_ft 
	([("&amp;","&");("&quot;","\""); 
	 ("&lt;","<"); ("&gt;",">")]@htmlentities_decode)
  | _ -> failwith "html_entity_decode"

