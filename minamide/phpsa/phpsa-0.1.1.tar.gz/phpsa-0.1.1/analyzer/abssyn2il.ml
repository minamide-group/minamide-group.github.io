(*
 * PHP string analyzer
 * Copyright (C) 2006 Yasuhiko Minamide
 *)
open Support
open Il

let trans_prim p =
  match p with
    Abssyn.Plus -> Plus
  | Abssyn.Minus -> Minus
  | Abssyn.Times -> Times
  | Abssyn.Div -> Div
  | Abssyn.Mod -> Mod
  | Abssyn.Concat -> Concat
  | Abssyn.Eq -> Eq
  | Abssyn.Neq -> Neq
  | Abssyn.Le -> Le
  | Abssyn.Lt -> Lt
  | Abssyn.Ge -> Ge
  | Abssyn.Gt -> Gt
  | Abssyn.Not -> Not
  | Abssyn.Xor -> Xor
  | Abssyn.Bitnot -> Bitnot
  | Abssyn.Bitand -> Bitand
  | Abssyn.Bitor -> Bitor
  | Abssyn.Bitxor -> Bitxor
  | Abssyn.Bitshiftl -> Bitshiftl
  | Abssyn.Bitshiftr -> Bitshiftr
  | Abssyn.Cast t -> Cast t
  | _ -> failwith "trans_prim"

type ilinfo = { constant_of : string -> var }

open Abssynmisc

let is_top scope =
  match scope with
    TopScope -> true
  | _ -> false

module StaticVarMap =
  Map.Make(struct 
    type t = scope * string
    let compare = compare
  end)

let mksswitch e ss s =
  List.fold_right (fun (x,s') s ->
    mkif (mkprim' (Eq, [e; String x]), s', s)) ss s


let analyzer_variable_variable = ref 0

let mkidswitch y e ss =
  Switch (e, y, 
	  List.fold_right (fun (x,s) cs ->
	   (Some x, fresh_var (), s)::cs)
	    ss [])

let mkvarswitch y e f s vs =
  let () = incr analyzer_variable_variable in
  Switch (e, y, 
	  StringSet.fold (fun v cs ->
	   (Some v, fresh_var (), f ("$"^v))::cs)
	    vs [(None, fresh_var (), s)])

let mkvarswitch' y e f s vs =
  let () = incr analyzer_variable_variable in
  Switch (e, y, 
	  StringSet.fold (fun v cs ->
	   (Some v, fresh_var (), f v)::cs)
	    vs [(None, fresh_var (), s)])

	  
(* Translation of $x[e]
 * It is not sound to translate $x["foo"] into $y &= $x["foo"]; $y
 * because it creates the index "foo" in the array $x.
 * Thus, we cannot dispense with ArrayDref.
 *)

let arrayref (x, e) k = 
  let y = fresh_var () in
  Seq (Assign (y, mkprim' (ArrayDref, [Var x; e])),
       k (Var y))

(* Translation of lv = exp *)

let lassign (lv, exp) k = 
  let y = fresh_var () in
  Seq (RefAssign (LVar y, lv), Seq (Assign (y, exp), k))

(* Translation of x[ixp] = exp *)

let array_update (x, iexp, exp) k = 
  lassign (LArray2 (x, iexp), exp) k

let translate unresolved_tbl spec ss = 
  let functions_tbl = Hashtbl.create 49 in
  let classes_tbl = Hashtbl.create 49 in

  let () = (analyzer_variable_variable := 0) in
  let gvars_tbl = Hashtbl.create 1000 in
  let constant_tbl = Hashtbl.create 1000 in
  let constant_of name = 
    try Hashtbl.find constant_tbl name 
    with Not_found ->
      let x = Support.fresh_fid name in
      Hashtbl.add constant_tbl name x; x in
  let () = Valuespec.iter_cspec (fun s i -> let _  = constant_of s in ()) spec in

  let rec eval_const c =
    match c with 
      Const.ConstInt i -> ConstInt i 
    | Const.ConstBool b -> ConstBool b 
    | Const.ConstFloat f -> ConstFloat f 
    | Const.ConstString s -> ConstString s 
    | Const.ConstArray l -> 
	let l = List.map (fun (x,y) -> (eval_const x, eval_const y)) l in
	ConstArray (l, fresh_var (), fresh_var (), fresh_var ())
    | Const.ConstConst x -> ConstConst (constant_of x) in
  let eval_const_opt c = option_map eval_const c in

  let copt2const copt =
    match copt with
      Some const -> ConstExp (eval_const const) 
    | None -> Null in

  let superglobals = Abssynmisc.superglobals in

  let all_constants, all_ivars, gvars, var_tbl, static_var_tbl,
    function_tbl, method_tbl, classmethod_tbl, var_args_tbl, all_classes = 
    Abssynmisc.collect ss in 

  let fun_args_of fname =
    try Hashtbl.find function_tbl fname with _ -> [] in
  let method_args_of mname =
    try Hashtbl.find method_tbl mname with _ -> [] in
  let classmethod_args_of cname mname =
    try Hashtbl.find classmethod_tbl (cname, mname) with _ -> [] in

  let fname_tbl = Hashtbl.create 49 in
  let mname_tbl = Hashtbl.create 49 in

  let lookup tbl (name, bs) =
    try Hashtbl.find tbl (name, bs) 
    with Not_found -> 
      let name' = fresh_fid name in
      Hashtbl.add tbl (name, bs) name';
      name' in

  let lookup_fname (fname, bs) = lookup fname_tbl (fname, bs) in
  let lookup_mname (mname, bs) = lookup mname_tbl (mname, bs) in

  let all_constants = 
    Valuespec.fold_cspec  (fun s _ env  -> StringSet.add s env) spec all_constants in

  let gvars = StringSet.remove "$GLOBALS" gvars in
  let gvars = StringSet.fold (fun x gvars -> StringSet.add x gvars) superglobals 
      gvars in


  let () = Options.show 1 
      (fun fmt -> Format.fprintf fmt "The number of global variables is %d@." (StringSet.cardinal gvars)) in

  let vars_of scope = Hashtbl.find var_tbl scope in
  let staticvar, staticss = 
    Hashtbl.fold 
      (fun scope smap (staticvar, ss) -> StringMap.fold 
	  (fun x copt (staticvar, ss) ->
	    let x' = fresh_topvar () in
	    StaticVarMap.add (scope, x) x' staticvar,
	    Assign (x', copt2const copt)::ss) smap (staticvar, ss)) 
      static_var_tbl
      (StaticVarMap.empty, []) in

  let ftbl = Hashtbl.create 49 in
  let check_ftbl fname loc = 
    let floc = fname, loc.Loc.cloc in
    if Hashtbl.mem ftbl floc then false
    else (Hashtbl.add ftbl floc (); true) in

  let ctbl = Hashtbl.create 49 in
  let check_ctbl cname loc = 
    let cloc = cname, loc.Loc.cloc in
    if Hashtbl.mem ctbl cloc then false
    else (Hashtbl.add ctbl cloc (); true) in


  (* these information are used to resolve variable functions, etc. *)
  let all_functions, all_methods = 
    Hashtbl.fold (fun scope _ (fs, ms) -> 
      match scope with
	TopScope -> (fs, ms)
      | FunctionScope (s, _) -> (StringSet.add s fs, ms)
      | MethodScope (_, _, s) -> (fs, StringSet.add s ms)) var_tbl
      (Phpprim.predefined_prims, StringSet.empty) in

  let kind_methods = all_methods in 
  let kind_functions = all_functions in 
  let kind_classes = all_classes in 

  let var_of_tbl tbl  scope name = 
    try Hashtbl.find tbl name 
    with Not_found ->
      let x = Support.fresh_var_of scope name in
      Hashtbl.add tbl name x; x in

  let rec exec_top lvars_tbl scope k returnref stmt = 

    let var_of scope name = 
      let scope = StringSet.mem name superglobals || is_top scope in
      let tbl = if scope then gvars_tbl else lvars_tbl in
      var_of_tbl tbl scope name in

    (* mode  = true if there is no side effects on variable binding and
                                no subexpression that must be lifted *)
    let appK mode exp k =
      if mode then k exp else
      let x = fresh_var () in
      Seq (Assign (x, exp),k (Var x)) in

    let lookup_unresolved y kind info =
      try Hashtbl.find unresolved_tbl y.id 
      with Not_found -> 
	(Hashtbl.add unresolved_tbl y.id (kind, StringSet.empty, info);
	 (kind, StringSet.empty, info)) in

    let lookup_unresolved_var e vars =
      let y = Abssyn.aloc_of_exp e in
      let info = 
	(fun fmt ->  Format.fprintf fmt "%a at %a" Abssyn.pp_exp e Loc.pp_loc e.Abssyn.exp_loc) in
      let kind = StringSet.fold (fun s ss -> StringSet.add (String.sub s 1 (String.length s - 1)) ss)
	  vars StringSet.empty in
      let _, vs, _ = lookup_unresolved y kind info in
      y, vs in

    let resolve kind e y es mkstmt k info =
      let l = fresh_var () in
      let _, names, info = lookup_unresolved y kind info in
      let names = StringSet.fold (fun name names ->
	StringSet.add (String.lowercase name) names) names StringSet.empty in
      let ss = StringSet.fold (fun name ss ->
	let stmt = mkstmt name es (fun z -> LocalCall (l, [z])) in
	(name, stmt)::ss) names [] in
      let s = mkidswitch y (mkapp' ("strtolower", [e])) ss in
      let x = fresh_var () in
      Seq (LocalFun (l, [x], k (Var x)), s) in
    
    let rec eval mode exp k =
      let eval = eval mode in
      let loc = exp.Abssyn.exp_loc in

      let mkvarvar_assign mkassign scope vars gx e exp k =
	let y, gvars = lookup_unresolved_var e vars in
	eval' mode e (fun e ->
	  eval' mode exp (fun exp ->
	    let l = fresh_var () in
	    let lv = mklarray2 (gx, e) in
	    let base =
	      let y = fresh_var () in
	      Seq (RefAssign (LVar y, lv), Seq (mkassign y exp, LocalCall (l, []))) in
	    Seq (LocalFun (l, [], k exp),
		 mkvarswitch y e 
		   (fun x -> 
		     let x = var_of scope x in
		     Seq (mkassign x exp,
				  LocalCall (l, [])))
		   base gvars)))  in

        (* adding an extra arguement for vararg *)
      let fix_args b es bs =
	if b then 
	  let y = fresh_var () in
	  let k = fun s -> Seq (Assign (y, mkprim' (NewArray, [])), s) in
	  let rec fix_args_loop bs es n k =
	    match (bs, es) with
	    | (_, []) -> k
	    | ([], es) ->
		let k, _ = 
		  List.fold_left (fun (k,n) e -> 
		    ((fun s -> k (array_update (y, Int n, e) s)),
		     n+1)) (k, n) es in
		k
	    | (true::bs, Var x::es) ->
		fix_args_loop bs es (n+1)
		  (fun s -> 
		    k (Seq (RefAssign (mklarray2 (y, Int n), LVar x),
			    s)))
	    | (true::bs, _::es) -> unsupported_simple loc "varargs"
	    | (false::bs, e::es) ->
		fix_args_loop bs es (n+1)
		  (fun s -> k (array_update (y, Int n, e) s)) in
	  let k = fix_args_loop bs es 0 k in
	  (k, (Var y)::es, false::bs)
	else ((fun s -> s), es, bs) in

      let mkcall call checkcall failcall bss x b es k =  
	let mkcall1 bs varargs k =
	  eval_list'' mode bs es (fun es ->
	    let k', es, bs = fix_args varargs es bs in
	    k' (Seq (call (x, es, b, bs), k (Var x)))) in
	(match bss with
	  [] -> failcall (); mkcall1 [] false k 
	| [bs,varargs] -> mkcall1 bs varargs k 
	| (bs,varargs)::bss -> 
	    let k, con = mk_localcon k in
	    let block = mkcall1 bs varargs k  in
	    con (List.fold_left (fun block (bs, varargs) ->
	      mkif (mkprim' (checkcall bs, []),
		      mkcall1 bs varargs k,
		      block)) block bss)) in

      let mkfuncall x b s es k =  
	let bss = fun_args_of s in
	let call (x, es, b, bs) = 
	  let s = lookup_fname (s, bs) in
	  FunCall ([x], s, es, b, bs) in
	let checkcall bs = CheckFunction (s, bs) in
	let failcall () = warning loc (fun fmt -> Format.fprintf fmt "undefined function %s" s) in
	mkcall call checkcall failcall bss x b es k in

      let mkmethodcall x b (e:var) mname es k =
	let bss = method_args_of mname in
	let call (x, es, b, bs) = 
	  let mname = lookup_mname (mname, bs) in
	  MethodCall ([x], e, mname, es, b, bs) in
	let checkcall bs = CheckMethod (mname, bs) in
	let failcall () = warning loc (fun fmt -> Format.fprintf fmt "undefined method %s@." mname) in
	mkcall call checkcall failcall bss x b es k in

      let mkclassmethodcall x b cname mname es k =
	let bss = classmethod_args_of cname mname in
	let call (x, es, b, bs) = 
	  let mname = lookup_mname (mname, bs) in
	  ClassMethodCall ([x], cname, mname, es, b, bs) in
	let checkcall bs = CheckMethod (mname, bs) in
	let failcall () = warning loc (fun fmt -> Format.fprintf fmt "undefined class method %s %s@." cname mname) in
	mkcall call checkcall failcall bss x b es k in
      
      (* $e1 *)

      let mkapp loc s es k =
	match s with
	| "printf" -> 
	    eval_list mode es (fun es -> Seq (Echo (mkapp loc ("sprintf", es)), k Null))
	| "vprintf" -> 
	    eval_list mode es (fun es -> Seq (Echo (mkapp loc ("vsprintf", es)), k Null))
	| "strtok" ->
	    (match es with
	      [e2] -> 
		let x = var_of scope "$__strtok" in
		eval e2
		  (fun e2 -> appK mode (mkapp loc ("strtok", [Var x; e2])) k)
	    | [e1;e2] -> 
		let x = var_of scope "$__strtok" in
		eval e1
		  (fun e1 -> 
		    eval e2
		      (fun e2 -> 
			Seq (Assign (x, e1),
			     appK mode (mkapp loc ("strtok", [Var x; e2])) k)))
	    | _ -> phperror_simple loc "strtok")
	| ("preg_match" | "ereg" | "eregi" | "preg_match_all" ) as regop ->
	    (match es with
	      [e1; e2] -> 
		eval_list mode es 
		  (fun es -> appK mode (mkapp loc (s, es)) k) 
	    | [e1; e2; e3] -> 
		let reg_arrayop = 
		  match regop with
		    "preg_match" -> "__preg_match_array"
		  | "ereg" -> "__ereg_array"
		  | "eregi" -> "__eregi_array"
		  | "preg_match_all" -> "__preg_match_all"
		  | _ -> impossible "regop" in
		(match e3.Abssyn.exp_desc with
		  Abssyn.Lvalue ({Abssyn.lvalue_desc = Abssyn.LVar x}) ->
		    let x = var_of scope x in
		    eval e1
		      (fun e1 ->
			eval e2
			  (fun e2 -> 
			    Seq (Assign (x, mkapp loc (reg_arrayop, [e1; e2])),
				 appK mode (mkapp loc (regop, [e1; e2])) k)))
		| Abssyn.Lvalue lv ->
		    let x = fresh_var () in
		    eval e1
		      (fun e1 ->
			eval e2
			  (fun e2 -> 
			    eval_lv mode lv (fun lv ->
			      Seq (RefAssign (LVar x, lv),
				   Seq (Assign (x, mkapp loc (reg_arrayop, [e1; e2])),
					appK mode (mkapp loc (regop, [e1; e2])) k)))))
		| _ -> unsupported exp.Abssyn.exp_loc (fun fmt -> Format.pp_print_string fmt regop))
	    | [_; _; _; _] | [_; _; _; _; _] ->
		(match regop with
		  "preg_match" | "preg_match_all" ->
		    unsupported exp.Abssyn.exp_loc (fun fmt -> Format.pp_print_string fmt regop)
		| _ -> phperror_simple loc regop)
	    | _ -> phperror_simple loc regop)
	| "array_slice" -> 
	    eval_list mode es 
	      (fun es ->
		match es with
		  [e1; _] | [e1; _; _] -> appK mode e1 k
		| _ -> phperror_simple loc "array_slice")
	| "array_reverse" -> 
	    eval_list mode es 
	      (fun es ->
		match es with
		  [e1] -> appK mode e1 k
		| [_; _] -> unsupported_simple loc "array_reverse"
		| _ -> phperror_simple loc "array_reverse");
	| "array_unique" -> 
	    eval_list mode es 
	      (fun es ->
		match es with
		  [e1] -> appK mode e1 k
		| _ -> phperror_simple loc "array_unique")
	| "array_unshift" -> 
   	    eval_list mode es 
	      (fun es -> 
		match es with
		| [] | [_] -> phperror_simple loc "array_unshift"
		| [e1; e2] -> 
		    appK mode (mkapp loc ("array_push", [e1; e2])) k
		| _ -> unsupported_simple loc "array_unshift")
	| "array_shift" -> 
   	    eval_list mode es 
	      (fun es -> 
		match es with
		  [e] -> 
		    appK mode (mkapp loc ("array_pop", [e])) k
		| _ -> phperror_simple loc "array_shift")
	| "array_sesrch" -> 
   	    eval_list mode es 
	      (fun es -> 
		match es with
		  [_; e] |[_; e; _]  -> 
		    appK mode (mkapp loc ("key", [e])) k
		| _ -> phperror_simple loc "array_search")
	| "func_get_args" -> 
	    (match es with
	      [] ->
		let z = var_of scope "$__varargs" in
		k (Var z)
	    | _ -> phperror_simple loc "bad func_get_args")
	| "func_get_arg" -> 
	    (match es with
	      [e] ->
		eval e (fun e ->
		  let z = var_of scope "$__varargs" in
		  arrayref (z, e) k)
	    | _ -> phperror_simple loc "bad func_get_arg")
	| "settype" -> 
	    (match es with
	      [{Abssyn.exp_desc = Abssyn.Lvalue lv}; 
	       {Abssyn.exp_desc = Abssyn.String s}] ->
		 let phptype =
		   match s with
		     "boolean" | "bool" -> Phptype.BoolTy 
		   | "integer" | "int" -> Phptype.IntTy 
		   | "float" | "double" -> Phptype.FloatTy 
		   | "string" -> Phptype.StringTy 
		   | "array" -> Phptype.ArrayTy
		   | "object" -> Phptype.ObjectTy
		   | "null" -> unsupported_simple exp.Abssyn.exp_loc "settype for null" 
		   | _ -> phperror exp.Abssyn.exp_loc (fun fmt -> Format.fprintf fmt "settype for %s" s) in
		 eval_lv mode lv (fun lv ->
		   let x = fresh_var () in
		   let y = fresh_var () in
		   Seq (RefAssign (LVar x, lv),
			Seq (Assign (x, mkprim loc (Cast phptype, [Var x])),
			     Seq (Assign (y, mkapp loc ("settype", 
						  [Var x; String s])),
				  k (Var y)))))
	    | _ -> unsupported exp.Abssyn.exp_loc (fun fmt -> Format.pp_print_string fmt "settype"))
	| "mysql_real_escape_string" -> 
	    eval_list mode es 
	      (fun es -> 
		match es with
		  [e1; e2] ->  appK mode (mkapp loc ("mysql_real_escape_string", [e1])) k
		| _ ->
		    appK mode (mkapp loc ("mysql_real_escape_string", es)) k)
	| "mysql_query" -> 
	    eval_list mode es 
	      (fun es -> 
		match es with
		  ([e1]| [e1; _]) ->  
		    if !Options.assert_mode then
		      let x = fresh_var () in
		      Seq (Assert (e1, x, ""), appK mode (Vspec Valuespec.Vresource) k)
		    else
		      appK mode (Vspec Valuespec.Vresource) k
		| _ -> phperror exp.Abssyn.exp_loc (fun fmt -> Format.fprintf fmt "mysql_query"))
	| _ ->
	    try
	      let vspec = Valuespec.find_fspec spec s loc in
	      eval_list mode es 
		(fun es -> appK mode (Vspec vspec) k)
	    with Not_found ->
	      if StringSet.mem s Phpprim.predefined_prims then
		eval_list mode es 
		  (fun es -> appK mode (mkapp loc (s, es)) k) 
	      else
		mkfuncall (fresh_var ()) false s es k in

      match exp.Abssyn.exp_desc with
	Abssyn.Lvalue lv -> eval_lvexp mode lv k 
      | Abssyn.Const x -> 
	  if not (StringSet.mem x all_constants) 
	  then warning exp.Abssyn.exp_loc 
	      (fun fmt -> Format.fprintf fmt "undefined constant \"%s\"" x);
	  appK mode (Const (constant_of x)) k
      | Abssyn.Null -> k Null
      | Abssyn.Int i -> k (Int i)
      | Abssyn.Float i -> k (Float i)
      | Abssyn.Bool b -> k (Bool b)
      | Abssyn.String s -> k (String s)
      | Abssyn.NewArray [] -> k (mknewarray ())
      | Abssyn.NewArray ees -> 
	  let x = fresh_var () in
	  let rec eval_array_init ees k =
	    match ees with
	      [] -> k (Var x)
	    | (exp1, exp2)::ees ->
		eval exp1 (fun exp1 ->
		  eval exp2 (fun exp2 ->
		    array_update (x, exp1, exp2)
		      (eval_array_init ees k))) in
	  Seq (Assign (x, mknewarray ()),
	       eval_array_init ees k)
      | Abssyn.RefAssign ({Abssyn.lvalue_desc = Abssyn.LVar "$this"}, _) -> 
	  unsupported exp.Abssyn.exp_loc 
	    (fun fmt -> Format.fprintf fmt "$this =& ...")
      | Abssyn.RefAssign (lv1, Abssyn.Lv ({Abssyn.lvalue_desc = Abssyn.LVar "$this"})) -> 
	  warning exp.Abssyn.exp_loc (fun fmt -> Format.fprintf fmt " =& $this");
	  eval (Abssyn.mkexp 
		  (Abssyn.LAssign 
		     (lv1, Abssyn.mkexp 
			(Abssyn.Lvalue (Abssyn.mklvalue (Abssyn.LVar "$this")))))) k
      | Abssyn.RefAssign (lv1, Abssyn.Lv lv2) -> 
	  eval_lv mode lv1
	    (fun lv1 ->
	      eval_lv mode lv2 
		(fun lv2 -> 
		  match lv1 with
		    LVar x ->
		      Seq (RefAssign (lv1, lv2), appK mode (Var x) k)
		  | _ ->
		      let x = fresh_var () in
		      Seq (RefAssign (lv1, lv2), 
			   Seq (RefAssign (LVar x, lv1), appK mode (Var x) k))))
      | Abssyn.RefAssign (lv, Abssyn.Exp e) ->
	  let msg = (fun fmt -> Format.fprintf fmt "%a =& %a" Abssyn.pp_lvalue lv Abssyn.pp_exp e) in
	  eval_lv mode lv (fun lv ->
	    let x, b = 
	      match lv with
		LVar x -> x, k (Var x)
	      | _ -> 
		  let x = fresh_var () in
		  x, Seq (RefAssign (lv, LVar x), appK mode (Var x) k) in
	    match e.Abssyn.exp_desc with
	      Abssyn.App (s, es) -> mkfuncall x true s es (fun x -> b)
	    | Abssyn.AppVar (e, es) ->
		let y = Abssyn.aloc_of_exp e in
		let info = (fun fmt ->  Format.fprintf fmt "%a at %a" Abssyn.pp_exp e Loc.pp_loc exp.Abssyn.exp_loc) in
		eval' mode e (fun e -> resolve kind_functions e y es (mkfuncall x true) 
		    (fun x -> b) info) 
	    | Abssyn.ClassMethod (cname, mname, es) -> 
		mkclassmethodcall x true cname mname es (fun x -> b)
	    | Abssyn.UClassMethod (cname, e, es) -> 
		let y = Abssyn.aloc_of_exp e in
 		let info = (fun fmt ->  Format.fprintf fmt "%a" Abssyn.pp_exp e) in
		eval' mode e (fun e -> 
		  let mkstmt = mkclassmethodcall x true cname in
		  resolve kind_methods e y es mkstmt (fun x -> b) info)  
	    | Abssyn.Method (e, mname, es) -> 
		eval_exp2var mode e (fun z ->
		  mkmethodcall x true z mname es (fun x -> b))
	    | Abssyn.UMethod (e1, e2, es) -> 
		let y = Abssyn.aloc_of_exp e in
		let info = (fun fmt ->  Format.fprintf fmt "%a" Abssyn.pp_exp e) in
		eval_exp2var mode e1 (fun z1 -> 
		  eval e2 (fun e2 -> 
		    resolve kind_methods e2 y es (mkmethodcall x true z1) 
		      (fun x -> b) info)) 
	    | (Abssyn.NewObj _ | Abssyn.UNewObj _) -> 
		eval e (fun exp -> Seq (Assign (x, exp), b))
	    | _ -> unsupported exp.Abssyn.exp_loc msg)
      | Abssyn.ListAssign (lvs, exp) -> 
	  eval_lvs mode lvs (fun lvs -> 
	    let y = fresh_var () in
	    let _,kexp = 
	      List.fold_left (fun (i, k) olv ->
		match olv with
		  None ->
		    (i+1, k)
		| Some lv ->
		    (i+1, 
		     arrayref (y, Int i) 
		       (fun v -> lassign (lv, v) k)))
		(0, k (Var y)) lvs in
	    eval exp (fun exp -> Seq (Assign (y, exp), kexp)))
      | Abssyn.LAssign (lv, exp) ->
	  (match lv.Abssyn.lvalue_desc with
	  | Abssyn.LArray2 ({Abssyn.lvalue_desc = Abssyn.LVar "$GLOBALS"}, e2) -> 
	      (match e2.Abssyn.exp_desc with
		Abssyn.String s ->
		  let x = var_of TopScope ("$"^s) in
		  eval exp 
		    (fun exp -> Seq(Assign (x, exp), k exp))
	      | _ ->
		  let gx = var_of TopScope "$GLOBALS" in
		  mkvarvar_assign (fun x exp -> Assign (x, exp)) TopScope gvars gx e2 exp k)
	  | Abssyn.LVar x -> 
	      let x = var_of scope x in
	      eval exp (fun exp -> Seq (Assign (x, exp), appK mode (Var x) k))
	  | Abssyn.LVarVar e2 -> 
	      let gx = 
		match scope with 
		  TopScope -> var_of TopScope "$GLOBALS" 
		| _ -> var_of scope "$__LOCALS" in
	      mkvarvar_assign (fun x exp -> Assign (x, exp)) scope (vars_of scope) gx e2 exp k
	  | Abssyn.LStringRef (lv, e) -> 
	      eval_lv mode lv (fun lv ->
		eval e (fun e -> 
		  eval exp 
		    (fun exp -> 
		      let x = fresh_var () in
		      Seq (RefAssign (LVar x, lv),
			   Seq (Assign (x, mkprim' (StringUpdate, [Var x; e; exp])),
				k (Var x))))))
	  | _ -> 
	      eval_lv mode lv (fun lv ->
		eval exp 
		  (fun exp -> lassign (lv, exp) (k exp)))) 
      | Abssyn.LOpAssign (lv, p, exp) ->
	  let p = trans_prim p in 
	  (match lv.Abssyn.lvalue_desc with
	    Abssyn.LArray2 ({Abssyn.lvalue_desc = Abssyn.LVar "$GLOBALS"}, e2) ->
	      (match e2.Abssyn.exp_desc with
	      | Abssyn.String s ->
		  let x = var_of TopScope ("$"^s) in
		  eval exp 
		    (fun exp -> Seq(Assign (x, mkprim loc (p,  [Var x; exp])), 
				    appK mode (Var x) k))
	      | _ ->
		  let gx = var_of TopScope "$GLOBALS" in
		  let mkassign x exp = Assign (x, mkprim loc (p,  [Var x; exp])) in
		  mkvarvar_assign mkassign TopScope gvars gx e2 exp k)
	  | Abssyn.LVar x -> 
	      let x = var_of scope x in
	      eval exp (fun exp -> 
		Seq (Assign (x, mkprim loc (p,  [Var x; exp])), appK mode (Var x) k))

	  | Abssyn.LVarVar e2 -> 
	      let gx = 
		match scope with 
		  TopScope -> var_of TopScope "$GLOBALS" 
		| _ -> var_of scope "$__LOCALS" in
	      let mkassign x exp = Assign (x, mkprim loc (p,  [Var x; exp])) in
	      mkvarvar_assign mkassign scope (vars_of scope) gx e2 exp k
	  | _ -> 
	      let y = fresh_var () in
	      eval_lv mode lv (fun lv ->
		eval exp 
		  (fun exp -> 
		    Seq (RefAssign (LVar y, lv),
			 Seq (Assign (y,  mkprim loc (p, [Var y; exp])),
			      k (Var y))))))
      | Abssyn.Prim (p, es) -> 
	  (match p with
	    Abssyn.Print ->
	      (match es with
		[e] -> eval e (fun e -> Seq (Echo e, k Null))
	      | _ -> impossible "print")
	  | Abssyn.Exit ->
	      (match es with
		[e] -> eval e (fun e -> Stop (1, None))
	      | _ -> impossible "exit")
	  | Abssyn.Andand ->
	      (match es with
		[e1; e2] ->
		  eval e1 (fun e1 ->
		    let l = fresh_var () in
		    let x = fresh_var () in
		    Seq (LocalFun (l, [x], k (Var x)), 
			 mkif (e1, 
				 eval e2 
				   (fun e2 -> 
				     mkif (e2, LocalCall (l,[Bool true]),
					     LocalCall (l,[Bool false]))),
				 LocalCall (l, [Bool false]))))
	      | _ -> impossible "&&")
	  | Abssyn.Oror ->
	      (match es with
		[e1; e2] ->
		  eval e1 (fun e1 ->
		    let l = fresh_var () in
		    let x = fresh_var () in
		    Seq (LocalFun (l, [x], k (Var x)), 
			 mkif (e1, 
				 LocalCall (l, [Bool true]),
				 eval e2 
				   (fun e2 -> 
				     mkif (e2, LocalCall (l,[Bool true]),
					     LocalCall (l,[Bool false]))))))
	      | _ -> impossible "||")
	  | Abssyn.Pif ->
	      (match es with
		[e1; e2; e3] ->
		  eval e1 (fun e1 ->
		    let l = fresh_var () in
		    let x = fresh_var () in
		    Seq (LocalFun (l, [x], k (Var x)), 
			 mkif (e1, 
				 eval e2 
				   (fun e2 -> LocalCall (l,[e2])),
				 eval e3
				   (fun e3 -> LocalCall (l,[e3])))))
	      | _ -> impossible "pif")
	  | _ -> 
	      let p = trans_prim p in
	      eval_list mode es (fun es ->
		appK mode (mkprim loc (p, es)) k))
      | Abssyn.App (s, es) -> mkapp loc s es k
      | Abssyn.AppVar (e, es) -> 
	  let y = Abssyn.aloc_of_exp e in
	  let info = (fun fmt ->  Format.fprintf fmt "%a" Abssyn.pp_exp e) in
	  eval' mode e (fun e -> resolve kind_functions e y es (mkapp loc) k info) 
      | Abssyn.ClassMethod (cname, mname, es) -> 
	  mkclassmethodcall (fresh_var ()) false cname mname es k
      | Abssyn.UClassMethod (cname, e, es) -> 
	  let y = Abssyn.aloc_of_exp e in
	  let info = (fun fmt ->  Format.fprintf fmt "%a" Abssyn.pp_exp e) in
	  eval' mode e (fun e -> 
	    let mkstmt = mkclassmethodcall (fresh_var ()) false cname in
	    resolve kind_methods e y es mkstmt k info) 
      | Abssyn.Method (e, mname, es) -> 
	  let x = fresh_var () in
	  eval_exp2var mode e (fun y -> mkmethodcall x false y mname es k)
      | Abssyn.UMethod (e1, e2, es) -> 
	  let y = Abssyn.aloc_of_exp e1 in
	  let info = (fun fmt ->  Format.fprintf fmt "%a" Abssyn.pp_exp e1) in
	  let x = fresh_var () in 
	  eval_exp2var mode e1 (fun z ->
	    eval e2 (fun e2 -> resolve kind_methods e2 y es (mkmethodcall x false z) k info)) 
      | Abssyn.NewObj (classname, es) -> 
	  let x = fresh_var () in
	  let y = fresh_var () in
	  let k _ = k (Var x) in
	  Seq (Assign (x, mknewobj classname), mkmethodcall y false x classname es k)
      | Abssyn.UNewObj (e, es) -> 
	  let y = Abssyn.aloc_of_exp e in
	  let info = (fun fmt ->  Format.fprintf fmt "%a" Abssyn.pp_exp e) in
	  eval e (fun e ->
	    let mkstmt classname es k = 
	      let y = fresh_var () in
	      let z = fresh_var () in
	      let k _ = k (Var y) in
	      Seq (Assign (y, mknewobj classname), mkmethodcall z false y classname es k) in
	    resolve kind_classes e y es mkstmt k info)
      | Abssyn.FileBlock (fname, dirname, ss) -> 
	  let l = fresh_var () in
	  let x = fresh_var () in
	  Seq (LocalFun (l, [x], k (Var x)), 
	       exec_list (LocalCall (l, [Int 1])) []  [] ss)
      | Abssyn.IncludeExp (_, e, _, sss) -> 
	  let aloc = Abssyn.aloc_of_exp e in
	  let l = fresh_var () in
	  let x = fresh_var () in
	  eval e (fun e -> 
	    let sss = List.map 
		(fun (str, ss) -> 
		  (str, exec_list (LocalCall (l, [Int 1])) []  [] ss)) sss in
	    Seq (LocalFun (l, [x], k (Var x)), 
		 mkidswitch aloc e sss))
      | Abssyn.StmtExp (ss, e) ->
	  let l = fresh_var () in
	  let x = fresh_var () in
	  Seq (LocalFun (l, [x], eval e k),
	       exec_list (LocalCall (l, [Int 1])) []  [] ss)
      | Abssyn.Define (s,exp) -> 
	  eval exp (fun exp -> Seq(Define (constant_of s, exp),
				   k (Int 1)))

    and eval_exp2var mode e (k' : var -> block) =
      eval mode e (fun e -> 
	match e with
	  Var x -> k' x
	| _ -> 
	    let x = fresh_var () in
	    Seq (Assign (x, e), k' x))
    and eval_list mode es k =
      match es with
	[] -> k [] 
      | e::es ->
	  eval mode e 
	    (fun e -> eval_list mode es (fun es -> k (e::es))) 
    and eval_list'' mode bs es k =
      match (bs, es) with
	(_, []) -> k [] 
      | ([], es) -> eval_list mode es k
      | (true::bs, e::es) ->
	  (match e.Abssyn.exp_desc with
	    Abssyn.Lvalue lv ->
	      eval_lv mode lv 
		(fun lv -> 
		  let x = fresh_var () in
		  Seq (RefAssign (LVar x, lv),
		       eval_list'' mode bs es (fun es -> k (Var x::es))))
	  | _ -> Stop (0, None))
      | (false::bs, e::es) ->
	  eval mode e 
	    (fun e -> eval_list'' mode bs es (fun es -> k (e::es)))  

    and eval_lvexp mode lv k =
      let mkvarvar scope vars gx e k =
	let l = fresh_var () in
	let x = fresh_var () in
	let y, gvars = lookup_unresolved_var e vars in
	eval' mode e (fun e ->
	    Seq (LocalFun (l, [x], k (Var x)), 
		 mkvarswitch y  e 
		   (fun x -> LocalCall (l, [Var (var_of scope x)]))
		   (arrayref (gx,e) 
		      (fun v -> LocalCall (l, [v])))
		   gvars))  in
      
      let loc = lv.Abssyn.lvalue_loc in
      match lv.Abssyn.lvalue_desc with
      | Abssyn.LVar "$GLOBALS" -> 
	  unsupported_simple loc "$GLOBALS as a variable" 
      | Abssyn.LVar x -> appK mode (Var (var_of scope x)) k
      | Abssyn.LVarVar e -> 
	  let lx = 
	    match scope with 
	      TopScope -> var_of TopScope "$GLOBALS" 
	    | _ -> var_of scope "$__LOCALS" in
	  mkvarvar scope (vars_of scope) lx e k
      | Abssyn.LArray1 _ -> 
	  phperror_simple loc "lv[] as an expression"
      | Abssyn.LArray2 ({Abssyn.lvalue_desc = Abssyn.LVar "$GLOBALS"}, e2) -> 
	  (match e2.Abssyn.exp_desc with
	    Abssyn.String s -> appK mode (Var (var_of TopScope ("$"^s))) k
	  | _ ->
	      let gx = var_of TopScope "$GLOBALS" in
	      mkvarvar TopScope gvars gx e2 k)
      | Abssyn.LArray2 (lv,exp) -> 
	  eval_lvexp mode lv (fun lv -> 
	    eval mode exp (fun exp -> 
	      (match lv with
		Var y -> arrayref (y, exp) k
	      | _ ->
		  let y = fresh_var () in
		  Seq (Assign (y, lv), arrayref (y, exp) k))))
      | Abssyn.LObjRef (lv,s) -> 
	  eval_lvexp mode lv (fun lv -> 
	    let x = fresh_var () in
	    (match lv with
	      Var y ->
		Seq (RefAssign (LVar x, mklobjref (y, s)),
		     k (Var x))
	    | _ ->
		let y = fresh_var () in
		Seq (Assign (y, lv), 
		     Seq (RefAssign (LVar x, mklobjref (y, s)),
			  k (Var x)))))
      | Abssyn.LUObjRef (lv,e) ->
	  let y = Abssyn.aloc_of_exp e in
	  let info = 
	    (fun fmt ->  Format.fprintf fmt "%a" Abssyn.pp_exp e) in
	  let _, vs, _ = lookup_unresolved y all_ivars info in
	  eval_lvexp mode lv (fun lv -> 
	    eval mode e (fun e -> 
	      let x = fresh_var () in
	      let y = fresh_var () in
	      let l = fresh_var () in
	      Seq (LocalFun (l, [], k (Var y)), 
		   mkvarswitch' y e 
		     (fun z -> 
		       Seq (Assign (x, lv),
			    Seq (RefAssign (LVar y, mklobjref (x, z)),
				 LocalCall (l, []))))
		     (Seq (Assign (x, lv),
			   Seq (RefAssign (LVar y, mklobjref (x, "")),
				LocalCall (l, []))))
		     vs)))
      | Abssyn.LStringRef (lv,e) ->
	  eval_lvexp mode lv (fun lv -> 
	    eval mode e (fun e -> appK mode (mkapp loc ("substr", [lv; e; Int 1])) k))

    and eval' mode exp k =
      eval mode exp (fun exp ->
	if is_nonvalue exp then 
	  let x = fresh_var () in Seq (Assign (x, exp), k (Var x)) 
	else k exp)

    and eval_lv mode lv k =

      let mkvarvar_lv scope vars gx e k =
	let y, gvars = lookup_unresolved_var e vars in
	eval mode e (fun e ->
	  let l = fresh_var () in
	  let x = fresh_var () in
	  Seq (LocalFun (l, [x], k (LVar x)), 
	       mkvarswitch y e 
		 (fun x -> LocalCall (l, [Var (var_of scope x)])) 
		 (arrayref (gx,e) 
		    (fun v -> LocalCall (l, [v])))
		 gvars)) in

      let loc = lv.Abssyn.lvalue_loc in
      match lv.Abssyn.lvalue_desc with
	Abssyn.LVar "$GLOBALS" -> unsupported_simple loc "$GLOBALS as a variable" 
      | Abssyn.LVar x -> k (LVar (var_of scope x))
      | Abssyn.LVarVar e -> 
	  let lx = 
	    match scope with 
	      TopScope -> var_of TopScope "$GLOBALS" 
	    | _ -> var_of scope "$__LOCALS" in
	  mkvarvar_lv scope (vars_of scope) lx e k
      | Abssyn.LArray1 lv ->
	  eval_lv mode lv (fun lv ->
	    (match lv with
	      LVar x -> Seq (Assign (x, mkinitarray (Var x)),
			     k (mklarray1 x))
	    | _ ->
		let x = fresh_var () in
		Seq (RefAssign (LVar x, lv),
		     Seq (Assign (x, mkinitarray (Var x)),
			  k (mklarray1 x)))))
      | Abssyn.LArray2 ({Abssyn.lvalue_desc = Abssyn.LVar "$GLOBALS"}, exp) ->
	  (match exp with
	    {Abssyn.exp_desc = Abssyn.String s} -> k (LVar (var_of TopScope ("$"^s)))
	  | e ->
	      let gx = var_of TopScope "$GLOBALS" in
	      mkvarvar_lv TopScope gvars gx e k) 
      | Abssyn.LArray2 (lv,exp) ->
	  eval_lv mode lv (fun lv -> 
	    eval mode exp (fun exp -> 
	      (match lv with
		LVar x -> 
		  Seq (Assign (x, mkinitarray (Var x)),
		       k (mklarray2 (x, exp))) 
	      | _ ->
		  let x = fresh_var () in
		  Seq (RefAssign (LVar x, lv),
		       Seq (Assign (x, mkinitarray (Var x)),
			    k (mklarray2 (x, exp)))))))
      | Abssyn.LObjRef (lv,m) ->
	  eval_lv mode lv (fun lv -> 
	    (match lv with
	      LVar x -> 
		Seq (Assign (x, mkinitobj (Var x)),
		     k (LObjRef (x, m)))
	    | _ ->
		let x = fresh_var () in
		Seq (RefAssign (LVar x, lv),
		     Seq (Assign (x, mkinitobj (Var x)),
			  k (LObjRef (x, m))))))
      | Abssyn.LUObjRef (lv,e) ->
	  let y = Abssyn.aloc_of_exp e in
	  let info = 
	    (fun fmt ->  Format.fprintf fmt "%a" Abssyn.pp_exp e) in
	  let _, vs, _ = lookup_unresolved y all_ivars info in
	  eval_lv mode lv (fun lv -> 
	    eval mode e (fun e -> 
	      let x = fresh_var () in
	      let y = fresh_var () in
	      let l = fresh_var () in
	      Seq (LocalFun (l, [], k (LVar y)), 
		   mkvarswitch' y e 
		     (fun z -> 
		       Seq (RefAssign (LVar x, lv),
			    Seq (RefAssign (LVar y, LObjRef (x,z)),
				 LocalCall (l, []))))
		     (Seq (RefAssign (LVar x, lv),
			   Seq (RefAssign (LVar y, LObjRef (x,"")),
				LocalCall (l, []))))
		     vs)))
      | Abssyn.LStringRef (lv,e) -> 
	  phperror_simple loc "lv{e} as reference"
    and eval_lvs mode lvs k =
      match lvs with

	[] -> k [] 
      | None::lvs -> eval_lvs mode lvs (fun lvs -> k (None::lvs))
      | Some lv::lvs ->
	  eval_lv mode lv
	    (fun lv -> eval_lvs mode lvs (fun lvs -> k (Some lv::lvs))) 

    and eval_seq es v k = 
      match es with
	[] -> k v
      | [e] -> eval_top e k 
      | e::es -> eval_top e 
	    (fun e -> 
	      if is_nonvalue e 
	      then Seq (ExpSt e, eval_seq es v k) else eval_seq es v k)


    and mk_localfun k = 
      match k with
	LocalCall _ | Return _ -> (k, fun x -> x)
      | _ -> 
	  let l = fresh_var () in
	  (LocalCall (l,[]), fun x -> Seq (LocalFun (l, [], k),x)) 

    and mk_localcon k =
      let z = fresh_var () in
      let l = fresh_var () in
      let con b = Seq (LocalFun (l, [z], k (Var z)), b) in
      let k e = LocalCall (l, [e]) in
      k, con

    and eval_lv_unset lv k =
	match lv.Abssyn.lvalue_desc with
	| Abssyn.LVar "$GLOBALS" -> 
	    unsupported_simple lv.Abssyn.lvalue_loc "$GLOBALS as a variable"
	| Abssyn.LVar x -> k (LVar (var_of scope x))
	| Abssyn.LVarVar e -> 
	    unsupported_simple lv.Abssyn.lvalue_loc "variable variable for unset"
	| Abssyn.LArray1 _ -> 
	      phperror_simple stmt.Abssyn.stmt_loc "lv[] for unset"
	| Abssyn.LArray2 ({Abssyn.lvalue_desc = Abssyn.LVar "$GLOBALS"}, e2) -> 
	    (match e2.Abssyn.exp_desc with
	      Abssyn.String s -> k (LVar (var_of TopScope ("$"^s)))
	    | _ -> unsupported_simple lv.Abssyn.lvalue_loc "Unsupported: $GLOBALS[exp] for unset")
	| Abssyn.LArray2 (lv,exp) -> 
	    eval_top  (Abssyn.mkexp (Abssyn.Lvalue lv)) (fun lv -> 
	      eval_top exp (fun exp -> 
		(match lv with
		  Var y -> k (mklarray2 (y, exp))
		| _ -> 
		    let y = fresh_var () in
		    Seq (Assign (y, lv), k (mklarray2 (y, exp))))))
	| Abssyn.LObjRef (lv,s) -> 
	    eval_top (Abssyn.mkexp (Abssyn.Lvalue lv)) (fun lv -> 
	      (match lv with
		Var y -> k (mklobjref (y, s))
	      | _ ->
		  let y = fresh_var () in
		  Seq (Assign (y, lv), 
		       k (mklobjref (y, s)))))
	| Abssyn.LUObjRef (lv,e) ->
	    unsupported_simple lv.Abssyn.lvalue_loc "Unsupported: lv->exp for unset"
	| Abssyn.LStringRef (lv,e) ->
	    phperror_simple stmt.Abssyn.stmt_loc "lv{exp} for unset"

    and eval_top exp k = 
       let mode = not (Abssynmisc.nontrivial false exp) in 
       eval mode exp k

(*
 *    k   : continuation
 *    bks : break continuation
 *    cks : continue continuation
 *)

    and exec k bks cks stmt =
      let loc = stmt.Abssyn.stmt_loc in
      let aloc = stmt.Abssyn.stmt_loc.Loc.aloc in
      match stmt.Abssyn.stmt_desc with
	Abssyn.ExpSt exp -> 
	  eval_top exp (fun exp -> 
	    if is_nonvalue exp then Seq (ExpSt exp, k) else k)
      | Abssyn.Echo exp -> 
	  eval_top exp (fun exp -> Seq (Echo exp, k))
      | Abssyn.Unset lv -> 
	  eval_lv_unset lv (fun lv -> Seq (Unset lv, k))
      | Abssyn.Assert (exp, str) -> 
	  let x = fresh_var () in
	  eval_top exp (fun exp -> Seq (Assert (exp,x,str), k))
      | Abssyn.Return exp -> 
	  let k = fun exp -> Return [exp] in
	  (match (returnref, exp.Abssyn.exp_desc) with
	    (false, _) -> eval_top exp k
	  | (true, Abssyn.Lvalue lv) -> 
	      eval_lv (Abssynmisc.nontrivial_lv false lv) lv (fun lv ->
		let x = fresh_var () in
		Seq (RefAssign (LVar x, lv), k (Var x)))
	  | (true, _) -> 
	      eval_top exp (fun e ->
		let x = fresh_var () in
		Seq (Assign (x, e), k (Var x)))) 
      | Abssyn.Break i ->
	  (match bks with
	    [] -> phperror_simple stmt.Abssyn.stmt_loc "break"
	  | ks -> List.nth ks (i-1))
      | Abssyn.Continue i -> 
	  (match cks with
	    [] -> phperror_simple stmt.Abssyn.stmt_loc "continue"
	  | ks -> List.nth ks (i-1))
      | Abssyn.Skip -> k
      | Abssyn.BlockSt ss -> exec_list k bks cks ss
      | Abssyn.While (e, s) -> 
	  let k, con = mk_localfun k in
	  let l = fresh_var () in
	  let k' = LocalCall (l,[]) in
	  let s = exec k' (k::bks) (k'::cks) s in
	  Seq (LocalFun (l, [], eval_top e (fun e -> con (mkif (e, s, k)))),
	       LocalCall (l, []))
      | Abssyn.DoWhile (s, e) -> 
	  let k, con = mk_localfun k in
	  let l = fresh_var () in
	  let l' = fresh_var () in
	  let k' = LocalCall (l',[]) in
	  let s = exec k' (k::bks) (k'::cks) s in
	  Seq (LocalFun (l, [], 
			 con (Seq (LocalFun (l', [], 
					     eval_top e (fun e -> 
					       mkif (e, LocalCall (l,[]), k))),
				   s))),
	       LocalCall (l, []))
      | Abssyn.For (e1, e2, e3, s) -> 
	  let k, con = mk_localfun k in
	  let l2 = fresh_var () in
	  let l3 = fresh_var () in
	  let k2 = LocalCall (l2,[]) in
	  let k3 = LocalCall (l3,[]) in
	  let s = exec k3 (k::bks) (k3::cks) s in
	  eval_seq e1 Null (fun e1 ->
	    Seq (LocalFun (l2, [], 
			   Seq (LocalFun (l3, [], eval_seq e3 Null (fun e3 -> k2)),
				eval_seq e2 (Bool true) (fun e2 -> 
				  con (mkif (e2, s, k))))),
		 LocalCall (l2, [])))
      | Abssyn.Foreach (e, optx, y, s) -> 
	  let x = match optx with
	    Some x -> var_of scope x 
	  | None -> fresh_var () in
	  let y = var_of scope y in
	  let k, con = mk_localfun k in
	  let l = fresh_var () in
	  let k' = LocalCall (l,[]) in
	  let z = fresh_var () in
	  let s = 
	    Seq (Assign (x, mkapp loc ("key",[Var z])),
		 arrayref (z, Var x) 
		   (fun v ->
		     Seq (Assign (y, v),
			  exec k' (k::bks) (k'::cks) s))) in
	  eval_top e (fun e ->
	    Seq (Assign (z,e),
		 Seq (LocalFun (l, [], 
				con (mkif (mkapp loc ("arrayeach", [Var z]),
					     s, k))),
		      LocalCall (l, []))))
      | Abssyn.If (e, s1, s2) -> 
	  let k, con = mk_localfun k in
	  let kthen, conthen = mk_localfun (exec k bks cks s1) in
	  let kelse, conelse = mk_localfun (exec k bks cks s2) in
	  let rec eval_if kthen kelse e =
	    match e.Abssyn.exp_desc with
	      Abssyn.Prim (Abssyn.Not, [e]) -> eval_if kelse kthen e 
	    | Abssyn.Prim (Abssyn.Andand, [e1;e2]) -> 
		let kthen, conthen = mk_localfun (eval_if kthen kelse e2) in
		conthen (eval_if kthen kelse e1) 
	    | Abssyn.Prim (Abssyn.Oror, [e1;e2]) -> 
		let kelse, conelse = mk_localfun (eval_if kthen kelse e2) in
		conelse (eval_if kthen kelse e1) 
	    | _ -> 
		eval_top e (fun e -> mkif (e, kthen, kelse)) in
	  con (conthen (conelse (eval_if kthen kelse e)))
      | Abssyn.Function (f, xs, s, b) -> 
	  if check_ftbl f loc then
	    let lvars_tbl = Hashtbl.create 100 in
	    let scope = FunctionScope (f, aloc) in
	    let xs = List.map 
		(fun (x,constopt,b) -> (var_of_tbl lvars_tbl false x, eval_const_opt constopt, b)) xs in
	    let xs = 
	      let varargs = Hashtbl.find var_args_tbl scope in
	      if varargs then 
		let z = var_of_tbl lvars_tbl false "$__varargs" in
		(z, None, false)::xs
	      else xs in
	    let returnk = Return [Null] in

	    let block = exec_top lvars_tbl scope returnk b s in
	    let block = 
	      if Hashtbl.mem lvars_tbl "$__LOCALS" 
	      then
		Seq (Assign (var_of_tbl lvars_tbl false "$__LOCALS", 
			     mkprim loc (NewArray, [])),
		     block) 
	      else block in
	    let f = lookup_fname (f, List.map (fun (_,_,b) -> b) xs) in
	    Hashtbl.add functions_tbl f (xs, block, [fresh_var ()], b);
	    k
	  else k
      | Abssyn.Switch (e, css) -> 
	  let exec_clist kendswitch bks cks x css =
	    let rec exec_clist css kdefault ktest kbody =
	      match css with
		[] -> kbody (ktest kdefault) kendswitch
	      | (None,ss)::css ->
		  let l2 = fresh_var () in
		  let k2' = LocalCall (l2,[]) in
		  exec_clist css k2' ktest 
		    (fun k1 k2 -> 
		      Seq (LocalFun (l2, [], exec_list k2 bks cks ss), 
			   kbody k1 k2))
	      | (Some c,ss)::css ->
		  let l1 = fresh_var () in
		  let k1' = LocalCall (l1,[]) in
		  let l2 = fresh_var () in
		  let k2' = LocalCall (l2,[]) in
		  exec_clist css kdefault
		    (fun k1 ->
		      Seq (LocalFun (l1,[], 
				     eval_top c (fun c ->
				       mkif (mkprim loc (Eq,[Var x; c]), k2', k1))),
			   ktest k1')) 
		    (fun k1 k2 ->
		      Seq (LocalFun (l2, [], exec_list k2 bks cks ss),
			   kbody k1 k2')) in
	    exec_clist css kendswitch (fun k -> k) (fun k1 k2 -> k1) in
	  let k, con = mk_localfun k in
	  let bks, cks = k::bks, k::cks in
	  let x = fresh_var () in
	  eval_top e (fun e -> 
	    con (Seq(Assign (x,e), exec_clist k bks cks x css)))
      | Abssyn.Global xs -> 
	  List.fold_right 
	    (fun x k -> 
	      Seq(RefAssign (LVar (var_of scope x), LVar (var_of TopScope x)), k)) xs k 
      | Abssyn.Static xcs -> 
	  List.fold_right (fun (x, _) k ->
	    let x' = 
	      try
		StaticVarMap.find (scope,x) staticvar 
	      with _ -> impossible ("static variable not registered: "^x)
	    in
	    Seq (RefAssign (LVar (var_of scope x), LVar x'), k)) xcs k
      | Abssyn.Class (cname, _, xs, ms) -> 
	  if check_ctbl cname loc then
	    let exec_method (mname, xs, s, r) =
	      let lvars_tbl = Hashtbl.create 100 in
	      let scope = MethodScope (cname, aloc, mname) in
	      let xs = List.map 
		  (fun (x,constopt,b) -> 
		    (var_of_tbl lvars_tbl false x, eval_const_opt constopt, b)) xs in
	      let xs = 
		let varargs = Hashtbl.find var_args_tbl scope in
		if varargs then 
		  let z = var_of_tbl lvars_tbl false "$__varargs" in
		  (z, None, false)::xs
		else xs in
	      let returnk = Return [Null] in
	      let block = exec_top lvars_tbl scope returnk r s in
	      let block = 
		if Hashtbl.mem lvars_tbl "$__LOCALS" 
		then
		  Seq (Assign (var_of_tbl lvars_tbl false "$__LOCALS", 
			       mkprim loc (NewArray, [])),
		       block) 
		else block in
	      let mname = lookup_mname (mname, List.map (fun (_,_,b) -> b) xs) in
	      (mname, xs, var_of_tbl lvars_tbl false "$this", block, [fresh_var ()], r) in
	    let xs = List.map (fun (x,constopt,_) -> (x, eval_const_opt constopt)) xs in
	    Hashtbl.add classes_tbl cname (fresh_fid cname, xs, List.map exec_method ms);
	    k
	  else k
    and exec_list k bks cks stmts =
      match stmts with
	[] -> k
      | s::ss -> exec (exec_list k bks cks ss) bks cks s in
    exec k [] [] stmt in

  let b = exec_top gvars_tbl TopScope (Stop (0,None)) false 
      (Abssyn.mkstmt (Abssyn.BlockSt ss)) in
  let b = Valuespec.fold_vspec (fun x v b -> 
    if StringSet.mem x (vars_of TopScope) then
    Seq (Assign (var_of_tbl gvars_tbl true x, Vspec v), b)
    else b) spec b in 
  let b = List.fold_left (fun b s -> Seq (s, b)) b staticss in
  let b = 
    if Hashtbl.mem gvars_tbl "$GLOBALS" 
    then
      Seq (Assign (var_of_tbl gvars_tbl true "$GLOBALS", 
		   mkprim' (NewArray, [])),
	   b) 
    else b in 
  rebuild_program b functions_tbl classes_tbl,
  { constant_of = constant_of }
