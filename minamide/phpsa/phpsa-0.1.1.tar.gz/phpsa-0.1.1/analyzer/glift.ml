open Il
open Support
open Ref

type env = 
    { fun_env : (VarSet.t * VarSet.t * VarSet.t * VarSet.t) VarMap.t;
      method_env : (VarSet.t * VarSet.t * VarSet.t * VarSet.t) VarMap.t}

let empty_env =
    { fun_env = VarMap.empty; 
      method_env = VarMap.empty}

let lv_var xs x = if x.scope then VarSet.add x xs else xs

let rec lv_exp xs e =
  match e with 
    Var x -> lv_var xs x
  | Dref _ -> failwith "Dref"
  | Int _ | Float _ | String _ | Bool _ | Const _ 
  | Null | Vspec _ | ConstExp _ -> xs
  | Prim (_, es,_) | App (_, es,_) -> lv_exp_list xs es
and lv_exp_list xs es = 
  List.fold_left (fun xs e -> lv_exp xs e) xs es

let rec lv_lv xs e =
  match e with 
    LVar x -> lv_var xs x
  | LArray1 lv -> lv_var xs lv
  | LArray2 (lv, e) -> lv_exp (lv_var xs lv) e
  | LObjRef (lv, m) -> lv_var xs lv

let find id env =
  try VarMap.find id env 
  with Not_found -> 
    VarSet.empty, VarSet.empty, VarSet.empty, VarSet.empty

let rec lv_stmt (vs, ws, fs, ms) s =
  match s with 
    ExpSt e | Echo e | Assert (e, _, _) | Define (_,e) -> 
      (lv_exp vs e, ws, fs, ms)
  | DrefAssign (x, e) -> failwith "DrefAssign"
  | RefAssign (lv1, lv2) ->
      let vs = lv_lv vs lv1 in
      let vs = lv_lv vs lv2 in 
      (vs, ws, fs, ms) 
  | Unset lv -> 
      (lv_lv vs lv, ws, fs, ms)  
  | LocalFun (x, ys, b) -> lv_block (vs, ws, fs, ms) b
  | FunCall (xs,s,es,_,_) -> 
      (lv_exp_list vs es, ws, VarSet.add s fs, ms) 
  | ClassMethodCall (xs,_,s,es,_,_) -> 
      (lv_exp_list vs es, ws, fs, VarSet.add s ms) 
  | MethodCall (xs,e,s,es,_,_) -> 
      let vs = lv_var vs e in
      let vs = lv_exp_list vs es in
      (vs, ws, fs, VarSet.add s ms)
  | Assign (x,e) ->
      let ws = if x.scope then  VarSet.add x ws else ws in
      (lv_exp vs e, ws, fs, ms) 
and lv_block (vs, ws, fs, ms) s =
  match s with 
    Stop (_, optx) -> 
      let vs = match optx with
	Some x -> lv_var vs x
      | None -> vs in
      (vs, ws, fs, ms) 
  | Return es -> (lv_exp_list vs es, ws, fs, ms) 
  | If (e, _,s1, _, s2) -> 
      let (vs, ws, fs, ms) = lv_block (vs, ws, fs, ms) s1 in
      let (vs, ws, fs, ms) = lv_block (vs, ws, fs, ms) s2 in
      let vs = lv_exp vs e in
      (vs, ws, fs, ms)
  | Switch (e, x, cs) -> 
      let lv_case (vs, ws, fs, ms) (_, x, b) =
	lv_block (vs, ws, fs, ms) b in
      let (vs, ws, fs, ms) = List.fold_left lv_case  (vs, ws, fs, ms) cs in
      let vs = lv_exp vs e in
      (vs, ws, fs, ms)
  | LocalCall (x, es) -> 
      (lv_exp_list vs es, ws, fs, ms) 
  | Seq (s,b) -> 
      let (vs, ws, fs, ms) = lv_block (vs, ws, fs, ms) b in
      lv_stmt (vs, ws, fs, ms) s 

let lv_program lvmap program =
  let function_f lvmap (x, xs, b, ys, r) =
    let vs, ws, fs, ms = lv_block (find x lvmap.fun_env) b  in
    {lvmap with fun_env = VarMap.add x (vs, ws, fs, ms) lvmap.fun_env} in
  let class_f lvmap (cname, xs, ms) =
    List.fold_left 
      (fun lvmap (mname, xs, this, b, ys, r) -> 
	let vs, ws, fs, ms = lv_block (find mname lvmap.method_env) b in
	{lvmap with method_env =  VarMap.add mname (vs, ws, fs, ms) lvmap.method_env} ) lvmap ms in
  let main_f lvmap b = lvmap in
  fold_program main_f function_f class_f program lvmap


let rec solve lvmap =
  let fun_env = 
    VarMap.fold (fun s (vs, ws, fs, ms) env ->
      let vs, ws = VarSet.fold 
	  (fun f (vs, ws) ->
	    let vs', ws', fs, ms = find f lvmap.fun_env in
	    VarSet.union vs vs', VarSet.union ws ws') fs (vs, ws) in
      let vs, ws = VarSet.fold 
	  (fun m (vs, ws) ->
	    let vs', ws', fs, ms = find m lvmap.method_env in
	    VarSet.union vs vs', VarSet.union ws ws') ms (vs, ws) in
      VarMap.add s (vs, ws, fs, ms) env) lvmap.fun_env VarMap.empty in
  let method_env = 
    VarMap.fold (fun s (vs, ws, fs, ms) env ->
      let vs, ws = VarSet.fold 
	  (fun f (vs, ws) ->
	    let vs', ws', fs, ms = find f lvmap.fun_env in
	    VarSet.union vs vs', VarSet.union ws ws') fs (vs, ws) in
      let vs, ws = VarSet.fold 
	  (fun m (vs, ws) ->
	    let vs', ws', fs, ms = find m lvmap.method_env in
	    VarSet.union vs vs', VarSet.union ws ws') ms (vs, ws) in
      VarMap.add s (vs, ws, fs, ms) env) lvmap.method_env VarMap.empty in
  let env_equal env1 env2 = 
    VarMap.equal 
      (fun (vs, ws, fs, ms) (vs', ws', fs', ms') -> 
	VarSet.equal vs vs' && VarSet.equal ws ws') env1 env2 in
  if env_equal fun_env lvmap.fun_env && env_equal method_env lvmap.method_env 
  then lvmap else solve {fun_env = fun_env; method_env = method_env } 

let fun_global_of ilenv vmap s = 
  let vs, ws, _, _ = find s ilenv.fun_env in
  let vs = VarSet.union vs ws in
  let ws = VarSet.diff ws vmap in
  VarSet.elements vs, VarSet.elements ws 

let method_global_of ilenv vmap s = 
  let vs, ws, _, _ = find s ilenv.method_env  in
  let vs = VarSet.union vs ws in
  let ws = VarSet.diff ws vmap in
  VarSet.elements vs, VarSet.elements ws 


let lift vmap ilenv ws s =
  let rec lift_stmt s =
  match s with 
  | LocalFun (x, xs, b) -> 
      LocalFun (x, xs, lift_block b)
  | FunCall (xs, s, es, b, bs) ->
      let vs, ws = fun_global_of ilenv vmap s in
      let es' = List.map (fun v -> Var v) vs in
      let bs' = List.map (fun v -> VarSet.mem v vmap) vs in
      FunCall (xs@ws, s, es'@es, b, bs'@bs)
  | ClassMethodCall (xs, cname, mname, es, r, bs) ->
      let vs, ws = method_global_of ilenv vmap mname in
      let es' = List.map (fun v -> Var v) vs in
      let bs' = List.map (fun v -> VarSet.mem v vmap) vs in
      ClassMethodCall (xs@ws, cname, mname, es'@es, r, bs'@bs)
  | MethodCall (xs, e, mname, es, r, bs) ->
      let vs, ws = method_global_of ilenv vmap mname in
      let es' = List.map (fun v -> Var v) vs in
      let bs' = List.map (fun v -> VarSet.mem v vmap) vs in
      MethodCall (xs@ws, e, mname, es'@es, r, bs'@bs)
  | _ -> s
  and lift_block s =
    match s with 
    | If (e, x1, s1, x2, s2) -> 
	If (e, x1, lift_block s1, x2, lift_block s2)
    | Switch (e, x, cs) ->
	let lift_case (g, y, b) = (g, y, lift_block b) in
	Switch (e, x, List.map lift_case cs)
    | LocalCall (x, es) -> LocalCall (x, es)
    | Seq (s,b) -> Seq (lift_stmt s, lift_block b) 
    | Stop _ -> s
    | Return es -> Return (es@ List.map (fun w -> Var w) ws) in
  lift_block s
 

let lift s =
  let vmap = Ref.refvar_program s in
  let vmap = VarSet.filter (fun x -> x.scope) vmap in
  let ilenv = lv_program empty_env s in
  let ilenv = solve ilenv in
 
  let function_f (x, xs, b, zs, r) =
    let vs, ws = fun_global_of ilenv vmap x in
    let vs' = List.map (fun v -> (v, None, VarSet.mem v vmap)) vs in
    let ws' = List.map (fun w -> fresh_var ()) ws in
    (x, vs'@xs, lift vmap ilenv ws b, zs@ws', r) in
  let class_f (s, xs, ms) =
      let lift_method  (x, xs, this, b, zs, r) =
	let vs, ws = method_global_of ilenv vmap x in
	let vs' = List.map (fun v -> (v, None, VarSet.mem v vmap)) vs in
	let ws' = List.map (fun w -> fresh_var ()) ws in
	(x, vs'@xs, this, lift vmap ilenv ws b, zs@ws', r) in
      (s, xs, List.map lift_method ms) in

  map_program (lift vmap ilenv []) function_f class_f s

