open Support
open Il
open Phptype

type value = 
    Varray 
  | Vobject 
  | Vtop

let lookup env x = 
  try	
    VarMap.find x env
  with Not_found -> Vtop

let rec eval_const env const =
  match const with
  | ConstArray _ -> Varray
  | _ -> Vtop

let rec eval_vspec vspec =
  match vspec with
  | Valuespec.Varray (vspec,x,y,z) -> Varray
  | _ -> Vtop

let rec exp2v env exp =
  match exp with
    Var x -> lookup env x
  | Vspec vspec -> Vtop
  | Dref (x,y) -> Vtop
  | Const x -> Vtop
  | ConstExp const -> Vtop
  | String s -> Vtop
  | Prim (p, es, _) ->
      (match p with
      | NewArray | InitArray _ -> Varray
      | NewObj _ | InitObj _ -> Vobject
      | _ -> Vtop)
  | App (s, es, _) -> Vtop
  | e -> Vtop

let eval_var vmap x =
  try VarMap.find x vmap with Not_found -> x

let rec eval vmap e =
  match e with 
    Var x -> Var (eval_var vmap x)
  | Dref (x,y) -> Dref (eval_var vmap x, y)
  | Prim (p, es, i) -> Prim (p, eval_list vmap es, i)
  | App (s, es, x) -> App (s, eval_list vmap es, x)
  | e -> e
and eval_list vmap es =
  List.map (eval vmap) es 
and eval_lv vmap lv =
  match lv with 
    LVar x -> LVar (eval_var vmap x)
  | LArray1 lv -> LArray1 (eval_var vmap lv)
  | LArray2 (lv, e) -> LArray2 (eval_var vmap lv, eval vmap e) 
  | LObjRef (lv, m) -> LObjRef (eval_var vmap lv, m)

let rec exec vmap env s =
  match s with 
  | LocalFun (x, xs, b) -> 
      LocalFun (x, xs, exec_block vmap env b)
  | DrefAssign (x, e) -> 
      DrefAssign (eval_var vmap x, eval vmap e)
  | RefAssign (lv1, lv2)  -> 
      let lv1 = eval_lv vmap lv1 in
      let lv2 = eval_lv vmap lv2 in
      RefAssign (lv1, lv2)
  | Assign (x, e) ->
      let e = eval vmap e in
      Assign (x, e)
  | ExpSt e -> ExpSt (eval vmap e)
  | FunCall (xs, s, es, b, bs) ->
      let es = eval_list vmap es in
      FunCall (xs, s, es, b, bs)
  | ClassMethodCall (xs, cname, mname, es, r, bs) ->
      let es = eval_list vmap es in
      ClassMethodCall (xs, cname, mname, es, r, bs)
  | MethodCall (xs, y, mname, es, r, bs) ->
      let y = eval_var vmap y in
      let es = eval_list vmap es in
      MethodCall (xs, y, mname, es, r, bs)
  | Define (x,e) -> Define (x, eval vmap e)
  | Echo e -> failwith "Echo"
  | Assert (e, x, s) -> Assert (eval vmap e, x, s)
  | Unset _ -> failwith "Unset"
and exec_block vmap env s =
  match s with 
  | If (e, x1, s1, x2, s2) -> 
      If (eval vmap e, x1, exec_block vmap env s1, 
	  x2, exec_block vmap env s2)
  | Switch (e, x, cs) ->
      let exec_case (g, y, b) = (g, y, exec_block vmap env b) in
      Switch (eval vmap e, x, List.map exec_case cs) 
  | LocalCall (x, es) -> LocalCall (x, eval_list vmap es)
  | Seq (Assign (x, Var y), b) ->
      let y = eval_var vmap y in
      exec_block (VarMap.add x y vmap) env b
  | Seq (Assign (x, Prim (InitArray y, [e], i)), b) ->
      let e = eval vmap e in
      (match (e, exp2v env e) with
      | (Var z, Varray) -> exec_block (VarMap.add x z vmap) env b
      | (_, Varray) -> 
	  Seq (Assign (x, e), 
	       exec_block vmap (VarMap.add x Varray env) b)
      | _ -> 
	  Seq (Assign (x, Prim(InitArray y, [e], i)), 
	       exec_block vmap (VarMap.add x Varray env) b))
  | Seq (Assign (x, Prim (InitObj y, [e], i)) as s, b) ->
      let e = eval vmap e in
      (match (e, exp2v env e) with
      | (Var z, Vobject) -> exec_block (VarMap.add x z vmap) env b
      | (_, Vobject) -> 
	  Seq (Assign (x, e), 
	       exec_block vmap (VarMap.add x Vobject env) b)
      | _ -> 
	  Seq (Assign (x, Prim(InitObj y, [e], i)), 
	       exec_block vmap (VarMap.add x Vobject env) b))
  | Seq (s,b) -> Seq (exec vmap env s, exec_block vmap env b) 
  | Stop (i, optx) -> 
      Stop (i, match optx with
	None -> None
      | Some x -> Some (eval_var vmap x))
  | Return es -> Return (eval_list vmap es) 

let exec b = 
  let main_f b = exec_block VarMap.empty VarMap.empty b in
  let function_f (x, xs, b, zs, r) = (x, xs, exec_block VarMap.empty VarMap.empty b, zs, r) in
  let class_f (s, xs, ms) = 
    let exec_method (x, xs, this, b, zs, r) =
      (x, xs, this, exec_block VarMap.empty VarMap.empty b, zs, r) in
    (s, xs, List.map exec_method ms)  in
  map_program main_f function_f class_f b


