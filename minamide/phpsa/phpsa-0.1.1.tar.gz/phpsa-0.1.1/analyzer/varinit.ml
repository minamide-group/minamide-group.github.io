open Support
open Il
open Ilmisc

(* 
 * live variables analysis. 
 *)

let rec lv_exp xs e =
  match e with 
    Var x -> VarSet.add x xs
  | Dref (x,_) -> VarSet.add x xs
  | Int _ | Float _ | String _ | Bool _ | Const _ 
  | Null | Vspec _  | ConstExp _ -> xs
  | Prim (_, es,_) | App (_, es,_) -> lv_exp_list xs es
and lv_exp_list xs es = 
  match es with
    [] -> xs
  | e::es -> lv_exp_list (lv_exp xs e) es

let lv_lv xs lv =
  match lv with
    LVar x -> VarSet.add x xs
  | LArray1 x -> VarSet.add x xs
  | LArray2 (x, e) -> lv_exp (VarSet.add x xs) e
  | LObjRef (x, m) -> VarSet.add x xs

let rec lv_stmt zs ws s =
  match s with 
    ExpSt e | Echo e | Assert (e, _,_) | Define (_,e) -> lv_exp zs e, ws
  | DrefAssign (x, e) -> failwith "RefAssign"
  | LocalFun (x, ys, b) -> failwith "LocalFun"
  | Assign (x,e) -> lv_exp (VarSet.remove x zs) e, VarSet.add x ws
  | FunCall (xs,_,es,_,_) -> 
      let zs = 
	List.fold_left (fun vs x -> VarSet.remove x vs) zs xs in
      let ws = 
	List.fold_left (fun ws x -> VarSet.add x ws) ws xs in
      lv_exp_list zs es, ws
  | ClassMethodCall (xs,_,_,es,_,_) ->  
      let zs = 
	List.fold_left (fun vs x -> VarSet.remove x vs) zs xs in
      let ws = 
	List.fold_left (fun ws x -> VarSet.add x ws) ws xs in
      lv_exp_list zs es, ws
  | MethodCall (xs,y,_,es,_,_) -> 
      let zs = 
	List.fold_left (fun vs x -> VarSet.remove x vs) zs xs in
      let ws = 
	List.fold_left (fun ws x -> VarSet.add x ws) ws xs in
      lv_exp_list (VarSet.add y zs) es, ws
  | RefAssign (LVar x, lv) ->
      lv_lv (VarSet.remove x zs) lv, VarSet.add x ws
  | RefAssign (lv1, lv2) -> 
      lv_lv (lv_lv zs lv2) lv1, ws
  | Unset (LVar x) -> 
      VarSet.remove x zs, VarSet.add x ws
  | Unset lv -> 
      lv_lv zs lv, ws

let add_genkill x vs ws (genmap, killmap) = 
  Dflow.add x vs genmap, Dflow.add x ws killmap
  
let rec lv_block lvmap cflow z s =
  match s with 
    Stop (_, None) -> (VarSet.empty, VarSet.empty, lvmap, cflow)
  | Stop (_, Some x) -> (VarSet.singleton x, VarSet.empty, lvmap, cflow)
  | Return es -> (lv_exp_list VarSet.empty es, VarSet.empty, lvmap, cflow)
  | If (e, x1, s1, x2, s2) -> 
      let cflow = Dflow.cflow_add z x1 cflow in
      let vs1, ws1, lvmap, cflow = lv_block lvmap cflow x1 s1 in
      let lvmap = add_genkill x1 vs1 ws1 lvmap in
      let cflow = Dflow.cflow_add z x2 cflow in
      let vs2, ws2, lvmap, cflow = lv_block lvmap cflow x2 s2 in
      let lvmap = add_genkill x2 vs2 ws2 lvmap in
      (lv_exp (VarSet.union vs1 vs2) e, VarSet.empty, lvmap, cflow)

  | Switch (e, x, cs) -> 
      let lv_case (vs, lvmap, cflow) (_, x, b) =
	let cflow = Dflow.cflow_add z x cflow in
	let vs1, ws1, lvmap, cflow = lv_block lvmap cflow x b in
	let lvmap = add_genkill x vs1 ws1 lvmap in
	(VarSet.union vs vs1, lvmap, cflow) in
      let vs, lvmap, cflow = List.fold_left lv_case (VarSet.empty, lvmap, cflow) cs in
      (lv_exp vs e, VarSet.empty, lvmap, cflow)
  | LocalCall (x, es) -> 
      (lv_exp_list VarSet.empty es, VarSet.empty, lvmap, Dflow.cflow_add z x cflow)
  | Seq (LocalFun (x, ys, b'), b)  -> 
      let vs, ws, lvmap, cflow = lv_block lvmap cflow z b in
      let vs', ws', lvmap, cflow  = lv_block lvmap cflow x b' in
      let vs' = List.fold_left 
	  (fun vs' y -> VarSet.remove y vs') vs' ys in
      let ws' = List.fold_left 
	  (fun ws' y -> VarSet.add y ws') ws' ys in
      (vs, ws, add_genkill x vs' ws' lvmap, cflow)
  | Seq (s,b) -> 
      let vs, ws, lvmap, cflow = lv_block lvmap cflow z b in
      let vs, ws = lv_stmt vs ws s in
      (vs, ws, lvmap, cflow)

let lv s =
  let z = fresh_var () in
  let cflow = Dflow.cflow_create () in
  let maps = (Dflow.create (), Dflow.create ()) in
  let vs, ws, maps, cflow = lv_block maps cflow z s in
  let genmap, killmap = add_genkill z vs ws maps in
  Dflow.solve genmap killmap cflow z

let rec varinit xs s =
  let lvmap = lv s in

  let rec exec_block s =
    match s with 
    | If (e, x1, s1, x2, s2) -> 
	let s1, vs1 = exec_block s1 in
	let s2, vs2 = exec_block s2 in
	If (e, x1, s1, x2, s2), lv_exp (VarSet.union vs1 vs2) e
    | Switch (e, x, cs) ->
	let exec_case (g, x, b) (cs, vs) = 
	  let b, vs' = exec_block b in
	  (g, x, b)::cs, VarSet.union vs vs' in
	let cs, vs = List.fold_right exec_case cs ([], VarSet.empty) in
	Switch (e, x, cs), lv_exp vs e
    | Seq (LocalFun (x, xs, b'), b) -> 
	let b, vs = exec_block b in
	let b', _ = exec_block b' in
	Seq (LocalFun (x, xs, b'), b), vs
    | Seq(Unset (LVar x), b) -> 
	let b, vs = exec_block b in
	let b = if VarSet.mem x vs then Seq (Assign (x, Null), b) else b in
	Seq (Unset (LVar x), b), VarSet.remove x vs 
    | Seq (s,b) -> 
	let b, vs = exec_block b in 
	let vs, _ = lv_stmt vs VarSet.empty s in
	Seq (s, b), vs
    | LocalCall (x, es) -> 
	let vs = Dflow.find x lvmap in
	s, lv_exp_list vs es
    | Stop (_, None) -> s, VarSet.empty
    | Stop (_,Some x) -> s, VarSet.singleton x
    | Return es -> s, lv_exp_list VarSet.empty es in
  let s, vs = exec_block s in
  let vs = List.fold_left (fun vs x -> VarSet.remove x vs) vs xs in
  let b = VarSet.fold (fun x b -> Seq (Assign (x, Null), b)) vs s in
  b

let varinit program =
  let function_f (x, xs, b', zs, r) =  (x, xs, varinit (vars_of_fparams xs) b', zs, r) in
  let class_f (s, xs, ms) =
    let exec_method (x, xs, this, b, zs, r) =
      (x, xs, this, varinit (this::vars_of_fparams xs) b, zs, r) in
    (s, xs, List.map exec_method ms) in
  map_program (varinit [])  function_f class_f program
