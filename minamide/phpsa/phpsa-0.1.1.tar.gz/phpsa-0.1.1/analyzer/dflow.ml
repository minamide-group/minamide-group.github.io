(*
 * PHP string analyzer
 * Copyright (C) 2006 Yasuhiko Minamide
 *)
open Support

let cflow_find x cflow =
  try Hashtbl.find cflow x with Not_found -> VarSet.empty 

let cflow_add x y cflow =
  Hashtbl.replace cflow x (VarSet.add y (cflow_find x cflow));
  cflow

let cflow_create () = Hashtbl.create 1000 

let add x y map = Hashtbl.replace map x y; map
let find x map = Hashtbl.find map x
let create () = Hashtbl.create 1000 

let solve genmap killmap cflow z =
  let rec loop lvmap =
    let rec dfs x xs new_lvmap flag =
      if VarSet.mem x xs then xs, new_lvmap, find x new_lvmap, flag  
      else
	let kill =  find x killmap in
	let zs = find x new_lvmap in
	let xs, new_lvmap, zs', flag =
	  VarSet.fold (fun y (xs, new_lvmap, zs, flag) ->
	    let xs, new_lvmap, zs', flag = dfs y xs new_lvmap flag in
	    let zs = VarSet.union zs (VarSet.diff zs' kill) in
	    xs, new_lvmap, zs, flag) (cflow_find x cflow) (VarSet.add x xs, new_lvmap, zs, flag) in
	xs, add x zs' new_lvmap, zs', flag || not (VarSet.equal zs zs') in
    let _, new_lvmap, _, flag = dfs z VarSet.empty lvmap false in
    if flag then loop new_lvmap else lvmap in
  loop genmap 
