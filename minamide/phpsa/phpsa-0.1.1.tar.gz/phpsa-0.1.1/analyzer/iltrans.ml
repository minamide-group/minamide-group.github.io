open Support
open Il


let rec lv_exp xs e =
  match e with 
    Var x -> VarSet.add x xs
  | Dref (x,_) -> VarSet.add x xs
  | Int _ | Float _ | String _ | Bool _ | Const _ 
  | Null | Vspec _  | ConstExp _ -> xs
  | Prim (_, es,_) | App (_, es,_) -> lv_exp_list xs es
and lv_exp_list xs es = 
  match es with
    [] -> xs
  | e::es -> lv_exp_list (lv_exp xs e) es

let rec lv_lv xs lv =
  match lv with
    LVar x -> VarSet.add x xs
  | LArray1 x -> VarSet.add x xs
  | LArray2 (x, e) -> lv_exp (VarSet.add x xs) e
  | LObjRef (x, m) -> VarSet.add x xs

let rec lv_stmt zs ws s =
  match s with 
    ExpSt e | Echo e | Assert (e, _, _) | Define (_,e) -> lv_exp zs e, ws
  | DrefAssign (x, e) -> lv_exp (VarSet.add x zs) e, ws
  | LocalFun (x, ys, b) -> failwith "LocalFun"
  | Assign (x,e) -> lv_exp (VarSet.remove x zs) e, VarSet.add x ws
  | FunCall (xs,_,es,_,_) -> 
      let zs = 
	List.fold_left (fun vs x -> VarSet.remove x vs) zs xs in
      let ws = 
	List.fold_left (fun ws x -> VarSet.add x ws) ws xs in
      lv_exp_list zs es, ws
  | ClassMethodCall (xs,_,_,es,_,_) ->  
      let zs = 
	List.fold_left (fun vs x -> VarSet.remove x vs) zs xs in
      let ws = 
	List.fold_left (fun ws x -> VarSet.add x ws) ws xs in
      lv_exp_list zs es, ws
  | MethodCall (xs,y,_,es,_,_) -> 
      let zs = 
	List.fold_left (fun vs x -> VarSet.remove x vs) zs xs in
      let ws = 
	List.fold_left (fun ws x -> VarSet.add x ws) ws xs in
      lv_exp_list (VarSet.add y zs) es, ws
  | RefAssign (LVar x, lv) ->
      lv_lv (VarSet.remove x zs) lv, VarSet.add x ws
  | RefAssign (lv1, lv2) -> 
      lv_lv (lv_lv zs lv2) lv1, ws
  | Unset (LVar x) -> 
      VarSet.remove x zs, VarSet.add x ws
  | Unset lv -> 
      lv_lv zs lv, ws

let add_genkill x vs ws (genmap, killmap) = 
  Dflow.add x vs genmap, Dflow.add x ws killmap
  
let rec lv_block lvmap cflow z s =
  match s with 
    Stop (_, None) -> (VarSet.empty, VarSet.empty, lvmap, cflow)
  | Stop (_, Some x) -> (VarSet.singleton x, VarSet.empty, lvmap, cflow)
  | Return es -> (lv_exp_list VarSet.empty es, VarSet.empty, lvmap, cflow)
  | If (e, x1, s1, x2, s2) -> 
      let cflow = Dflow.cflow_add z x1 cflow in
      let vs1, ws1, lvmap, cflow = lv_block lvmap cflow x1 s1 in
      let lvmap = add_genkill x1 vs1 ws1 lvmap in
      let cflow = Dflow.cflow_add z x2 cflow in
      let vs2, ws2, lvmap, cflow = lv_block lvmap cflow x2 s2 in
      let lvmap = add_genkill x2 vs2 ws2 lvmap in
      (lv_exp (VarSet.union vs1 vs2) e, VarSet.empty, lvmap, cflow)
  | Switch (e, x, cs) -> 
      let lv_case (vs, lvmap, cflow) (_, x, b) =
	let cflow = Dflow.cflow_add z x cflow in
	let vs1, ws1, lvmap, cflow = lv_block lvmap cflow x b in
	let lvmap = add_genkill x vs1 ws1 lvmap in
	(VarSet.union vs vs1, lvmap, cflow) in
      let vs, lvmap, cflow = List.fold_left lv_case (VarSet.empty, lvmap, cflow) cs in
      (lv_exp vs e, VarSet.empty, lvmap, cflow)
  | LocalCall (x, es) -> 
      (lv_exp_list VarSet.empty es, VarSet.empty, lvmap, Dflow.cflow_add z x cflow)
  | Seq (LocalFun (x, ys, b'), b)  -> 
      let vs, ws, lvmap, cflow = lv_block lvmap cflow z b in
      let vs', ws', lvmap, cflow  = lv_block lvmap cflow x b' in
      let vs' = List.fold_left 
	  (fun vs' y -> VarSet.remove y vs') vs' ys in
      let ws' = List.fold_left 
	  (fun ws' y -> VarSet.add y ws') ws' ys in
      (vs, ws, add_genkill x vs' ws' lvmap, cflow)
  | Seq (s,b) -> 
      let vs, ws, lvmap, cflow = lv_block lvmap cflow z b in
      let vs, ws = lv_stmt vs ws s in
      (vs, ws, lvmap, cflow)

let lv' s =
  let z = fresh_var () in
  let cflow = Dflow.cflow_create () in
  let maps = (Dflow.create (), Dflow.create ()) in
  let vs, ws, maps, cflow = lv_block maps cflow z s in
  let genmap, killmap = add_genkill z vs ws maps in
  Dflow.solve genmap killmap cflow z

(************)


let rec lv_loop old_lvmap s =
  let rec lv_exp xs e =
    match e with 
      Var x -> VarSet.add x xs
    | Dref (x,_) -> VarSet.add x xs
    | Int _ | Float _ | String _ | Bool _ | Const _ 
    | Null | Vspec _  | ConstExp _ -> xs
    | Prim (_, es,_) | App (_, es,_) -> lv_exp_list xs es
  and lv_exp_list xs es = 
    match es with
      [] -> xs
    | e::es -> lv_exp_list (lv_exp xs e) es in

  let rec lv_lv xs lv =
    match lv with
      LVar x -> VarSet.add x xs
    | LArray1 x -> VarSet.add x xs
    | LArray2 (x, e) -> lv_exp (VarSet.add x xs) e
    | LObjRef (x, m) -> VarSet.add x xs in

  let lv_stmt xs s =
    match s with 
      ExpSt e | Echo e | Assert (e, _, _) | Define (_,e) -> lv_exp xs e
    | DrefAssign (x, e) -> VarSet.add x (lv_exp xs e)
    | LocalFun (x, ys, b) -> failwith "LocalFun"
    | Assign (x,e) -> lv_exp (VarSet.remove x xs) e
    | RefAssign (LVar x,lv) -> lv_lv (VarSet.remove x xs) lv
    | RefAssign (lv1,lv2) -> lv_lv (lv_lv xs lv1) lv2
    | FunCall (ys,_,es,_,_) -> 
	let xs =  List.fold_right (fun y xs -> VarSet.remove y xs) ys xs in
	lv_exp_list xs es
    | ClassMethodCall (ys,_,_,es,_,_) -> 
	let xs =  List.fold_right (fun y xs -> VarSet.remove y xs) ys xs in
	lv_exp_list xs es
    | MethodCall (ys,z,_,es,_,_) -> 
	let xs =  List.fold_right (fun y xs -> VarSet.remove y xs) ys xs in
	lv_exp_list (VarSet.add z xs) es
    | Unset  _ -> failwith "Unset" in

  let rec lv_block lvmap s =
    match s with 
      Stop (_, None) -> (VarSet.empty, lvmap)
    | Stop (_,Some x) -> (VarSet.singleton x, lvmap)
    | Return es -> (lv_exp_list VarSet.empty es, lvmap)
    | If (e, _,s1, _, s2) -> 
	let vs1, lvmap = lv_block lvmap s1 in
	let vs2, lvmap = lv_block lvmap s2 in
	(lv_exp (VarSet.union vs1 vs2) e, lvmap)
    | Switch (e, x, cs) ->
	let lv_case (vs, lvmap) (g, y, b) = 
	  let vs', lvmap = lv_block lvmap b in
	  (VarSet.union vs vs', lvmap) in
	let vs, lvmap  = List.fold_left lv_case (VarSet.empty, lvmap) cs in
	(lv_exp vs e, lvmap)
    | LocalCall (x, es) -> 
	let vs = 
	  try VarMap.find x old_lvmap 
	  with _ -> VarSet.empty  in
	(lv_exp_list vs es, lvmap)
    | Seq (LocalFun (x, ys, b1), b2) -> 
	let vs2, lvmap = lv_block lvmap b2 in
	let vs1, lvmap = lv_block lvmap b1 in
	let vs1 = List.fold_left 
	    (fun vs y -> VarSet.remove y vs) vs1 ys in
	(vs2, VarMap.add x vs1 lvmap)
    | Seq (s,b) -> 
	let vs, lvmap = lv_block lvmap b in
	(lv_stmt vs s, lvmap) in
(*
  let lvmapeq lvmap1 lvmap2 =
    VarMap.fold (fun k vs b ->
      try b && VarSet.equal vs (VarMap.find k lvmap2)
      with _ -> false)
      lvmap1 true in
*)
  let lvmapeq lvmap1 lvmap2 =
    VarMap.equal VarSet.equal lvmap1 lvmap2 in



  let () = 
    Options.show 2 (fun fmt -> Format.printf "LOOP!\n") in
  let _, lvmap = lv_block old_lvmap s in
  if lvmapeq lvmap old_lvmap  then lvmap 
  else lv_loop lvmap s

let lv s = lv_loop VarMap.empty s



(* 
 *  Translate "echo" into a combination of concatination and assignment.
 *  Additionally, insert assignment to improve precision of analysis for
 *  preg_match and ereg.
 *
 *  the first argument is the output string at the function call.
 *  the last return value is the string outputted during the function call 
 *)
  
let rec trans context z s =
  let x = fresh_var () in
  let rec trans_stmt s =
    match s with 
      Echo e -> 
	if !Options.trace_mode then 
	  ExpSt e
	else
	  Assign (x, mkprim' (Concat, [Var x; e]))
    | LocalFun (x, ys, b) -> 
	LocalFun (x, ys, trans_block b)
    | FunCall _ -> failwith "FunCall"
    | ClassMethodCall _ -> failwith "ClassMethodCall"
    | MethodCall _ -> failwith "MethodCall"
    | s -> s
  and trans_block s =
    match s with 
    | If (App ("preg_match", ([_; Var x] as es), info) as e, x1, s1, x2, s2) -> 
	let sthen = Assign (x, remkapp ("__preg_match", es, info)) in
	let selse = Assign (x, remkapp ("__npreg_match", es, info)) in
	If (e, x1, Seq (sthen, trans_block s1), 
	    x2, Seq (selse, trans_block s2))
    | If (App ("ereg", ([_; Var x] as es), info) as e, x1, s1, x2, s2) -> 
	let sthen = Assign (x, remkapp ("__ereg", es, info)) in
	let selse = Assign (x, remkapp ("__nereg", es, info)) in
	If (e, x1, Seq (sthen, trans_block s1), 
	    x2, Seq (selse, trans_block s2))
    | If (App ("eregi", ([_; Var x] as es), info) as e, x1, s1, x2, s2) -> 
	let sthen = Assign (x, remkapp ("__eregi", es, info)) in
	let selse = Assign (x, remkapp ("__neregi", es, info)) in
	If (e, x1, Seq (sthen, trans_block s1), 
	    x2, Seq (selse, trans_block s2))
    | If (e, x1, s1, x2, s2) -> If (e, x1, trans_block s1, x2, trans_block s2)
    | Switch (e, x, cs) -> 
	let trans_case (g, y, b) = (g, y, trans_block b) in 
	Switch (e, x, List.map trans_case cs) 
    | Seq (FunCall (xs,s,es,r,bs),b) -> 
	let y = fresh_var () in
	let e = mkprim' (Concat,[Var z;Var x]) in
	Seq (FunCall (xs@[y],s,e::es,r,false::bs),
	     Seq (Assign (x, mkprim' (Concat,[Var x;Var y])),
		  trans_block b))
    | Seq (ClassMethodCall (xs,cname,mname,es,r,bs),b) -> 
	let y = fresh_var () in
	let e = mkprim' (Concat,[Var z;Var x]) in
	Seq (ClassMethodCall (xs@[y],cname,mname,e::es,r,false::bs),
	     Seq (Assign (x, mkprim' (Concat,[Var x;Var y])),
		  trans_block b))
    | Seq (MethodCall (xs,eobj,mname,es,r,bs),b) -> 
	let y = fresh_var () in
	let e = mkprim' (Concat,[Var z;Var x]) in
	Seq (MethodCall (xs@[y],eobj,mname,e::es,r,false::bs),
	     Seq (Assign (x, mkprim' (Concat,[Var x;Var y])),
		  trans_block b))
    | Seq (s,b) -> Seq (trans_stmt s, trans_block b) 
    | Return es -> Return (es@[Var x])     

    | Stop (i,None) -> 
	if !Options.exit_analysis_mode || i = 0 then
	  let y = fresh_var () in 
	  Seq (Assign (y, mkprim' (Concat,[Var z;Var x])),
	       Stop (i, Some y)) 
	else
	  Stop (i,None)
    | s -> s in
  let str = if !Options.trace_mode then context^"\n" else "" in
  Seq (Assign (x, String str), trans_block s)


let trans program =
  let trans_main s = 
    let z = fresh_var () in
    Seq (Assign (z, String ""), trans "" z s) in
  let function_f (x, xs, b, ys, r) =
	let z = fresh_var () in (* Output of context *)
	(x, (z,None,false)::xs, trans x.name z b, ys@[fresh_var ()], r) in
  let class_f (s, xs, ms) =
    let trans_method (x, xs, this, b, ys, r) =
      let z = fresh_var () in (* Output of context *)
     let context = s.name^"::"^x.name in
      (x, (z,None,false)::xs, this, trans context z b, ys@[fresh_var ()], r) in
    (s, xs, List.map trans_method ms) in
  map_program trans_main function_f class_f program


(*
 * Lambda lifting for local functions.
 *) 

let rec lift s =
  let lvmap = lv' s in
  let find x = Dflow.find x lvmap in
  let () = Options.show 4 (fun fmt -> Format.printf "lv done@.") in
  let rec lift_stmt s =
    match s with 
    | LocalFun (x, xs, b) -> 
	LocalFun (x, xs@VarSet.elements (find x), lift_block b)
    | s -> s
  and lift_block s =
    match s with 
    | If (e, x1, s1, x2, s2) -> 
	If (e, x1, lift_block s1, x2, lift_block s2)
    | Switch (e, x, cs) -> 
	let lift_case (g, y, b) = (g, y, lift_block b) in 
	Switch (e, x, List.map lift_case cs) 
    | LocalCall (x, xs) -> 
	LocalCall (x, xs @ List.map (fun x -> Var x) (VarSet.elements (find x)))
    | Seq (s,b) -> Seq (lift_stmt s, lift_block b) 
    | s -> s in
  lift_block  s

let lift program =
  let function_f (x, xs, b, ys, r) = (x, xs, lift b, ys, r) in
  let class_f (s, xs, ms) =
    (s, xs, List.map (fun (x, xs, this, b, ys, r) -> (x, xs, this, lift b, ys, r)) ms) in
  map_program lift function_f class_f program

(*
 * Rename all the variables in the program
 *)
let rename program =
  let extend vmap x =
    let y = rename_var x in 
    y, VarMap.add x y vmap in
  
  let extend_list vmap xs =
    List.fold_right 
      (fun x (ys, vmap) -> 
	let y, vmap = extend vmap x in y::ys, vmap)
      xs ([],vmap) in
      
  let rename_var vmap x =
    try VarMap.find x vmap with _ -> x in

  let rec rename_exp vmap e =
    match e with 
      Var x -> Var (rename_var vmap x)
    | Dref (x,y) -> Dref (rename_var vmap x, y)
    | Prim (p, es, i) -> Prim (p, rename_exp_list vmap es, i)
   
    | App (s, es, x) -> App (s, rename_exp_list vmap es, x)
    | e -> e
  and rename_exp_list vmap es =
    List.map (rename_exp vmap) es 
  and rename_lv vmap lv =
    match lv with 
      LVar x -> LVar (rename_var vmap x)
    | LArray1 lv -> LArray1 (rename_var vmap lv)
    | LArray2 (lv, e) -> LArray2 (rename_var vmap lv, rename_exp vmap e) 
    | LObjRef (lv, m) -> LObjRef (rename_var vmap lv, m) in

  let rename_fparam vmap (x,constopt,b) =
    let y, vmap = extend vmap x in
    (y,constopt,b),vmap in
  
  let rename_fparams vmap xs =
    List.fold_right 
      (fun x (ys, vmap) -> 
	let y, vmap = rename_fparam vmap x in y::ys, vmap)
      xs ([],vmap) in

  let rec rename_stmt vmap s =
    match s with 
    | LocalFun (x, xs, b) -> 
	let ys, vmap' = extend_list vmap xs in
	LocalFun (x, ys, rename_block vmap' b), vmap 
    | FunCall (xs, s, es, b, bs) ->
      let es = rename_exp_list vmap es in
      let xs, vmap = extend_list vmap xs in
      FunCall (xs, s, es, b, bs), vmap
    | ClassMethodCall (xs, cname, mname, es, r, bs) ->
      let es = rename_exp_list vmap es in
      let xs, vmap = extend_list vmap xs in
      ClassMethodCall (xs, cname, mname, es, r, bs), vmap
    | MethodCall (xs, e, mname, es, r, bs) ->
      let e = rename_var vmap e in
      let es = rename_exp_list vmap es in
      let xs, vmap = extend_list vmap xs in
      MethodCall (xs, e, mname, es, r, bs), vmap
    | Assign (x, e) ->
      let e = rename_exp vmap e in
      let x, vmap = extend vmap x in
      Assign (x, e), vmap
    | ExpSt e -> ExpSt (rename_exp vmap e), vmap
    | Define (x,e) -> Define (x,rename_exp vmap e), vmap
    | DrefAssign (x, e) -> 
	DrefAssign (rename_var vmap x, rename_exp vmap e), vmap
    | RefAssign (LVar x, lv)  -> 
	let lv = rename_lv vmap lv in
	let x, vmap = extend vmap x in
	RefAssign (LVar x, lv), vmap
    | RefAssign (x, lv)  -> 
	let lv = rename_lv vmap lv in
	let x = rename_lv vmap x in
	RefAssign (x, lv), vmap
    | Echo e -> Echo (rename_exp vmap e), vmap
    | Assert (e, x, s) -> Assert (rename_exp vmap e, x, s), vmap
    | Unset _ -> failwith "Unset"
  and rename_block vmap s =
    match s with 
    | If (e, x1, s1, x2, s2) -> 
	If (rename_exp vmap e, 
	    x1, rename_block vmap s1, x2, rename_block vmap s2)
    | Switch (e, x, cs) ->
	let rename_case (g, y, b) = (g, y, rename_block vmap b) in
	Switch (rename_exp vmap e, x, List.map rename_case cs)
    | LocalCall (x, es) -> 
	LocalCall (x, rename_exp_list vmap es)
    | Seq (s,b) -> 
	let s, vmap = rename_stmt vmap s in
	Seq (s, rename_block vmap b) 
    | Stop (i, optx) -> 
	Stop (i, match optx with
	  None -> None
	| Some x -> Some (rename_var vmap x))
    | Return es -> Return (rename_exp_list vmap es) in

  let function_f (x, xs, b, zs, r) =
    let ys, vmap' = rename_fparams VarMap.empty xs in
    (x, ys, rename_block vmap' b, zs, r) in
  let class_f (s, xs, ms) =
    let rename_method  (x, xs, this, b, zs, r) =
      let ys, vmap = rename_fparams VarMap.empty xs in
      let this, vmap = extend vmap this in
      (x, ys, this, rename_block vmap b, zs, r) in
    (s, xs, List.map rename_method  ms) in
  map_program (rename_block VarMap.empty) function_f class_f program







  



    


