open Support

type vspec =
    Vregexp of Reg.reg
  | Vint
  | Vbool
  | Vboolval of bool
  | Vfloat
  | Varray of vspec * var * var * var
  | Varray2 of vspec * vspec * var * var * var
  | Vresource 
  | Vnull
  | Vor of vspec * vspec * var
  | Vstring 
  | Vmixed
  | Varray0
  | Vobject of vspec * var * var * var
  | Vdtd of string * string (* filename * root *)

type spec_list = 
    { vspec : (string, vspec) Hashtbl.t;
      fspec : (string * (string * int) option, vspec) Hashtbl.t;
      cspec : (string, int) Hashtbl.t }

let spec_empty () = 
  { vspec = Hashtbl.create 49;
    fspec = Hashtbl.create 49;
    cspec =Hashtbl.create 49}

let add_vspec spec_tbl x vspec = 
  Hashtbl.add spec_tbl.vspec x vspec;
  spec_tbl
let add_fspec spec_tbl x loc vspec = 
  Hashtbl.add spec_tbl.fspec (x,loc) vspec;
  spec_tbl
let add_cspec spec_tbl x i = 
  Hashtbl.add spec_tbl.cspec x i;
  spec_tbl

let rec pp_vspec fmt = function
    Vregexp r -> Reg.pp_reg fmt r
  | Vint -> Format.pp_print_string fmt "int"
  | Vfloat -> Format.pp_print_string fmt "float"
  | Vbool -> Format.pp_print_string fmt "bool"
  | Vboolval v -> Format.pp_print_string fmt "bool"
  | Varray (vspec,x,y,z) -> Format.fprintf fmt "[%a]" pp_vspec vspec
  | Varray2 (keyspec,vspec,x,y,z) -> 
      Format.fprintf fmt "array(%a => %a)" pp_vspec keyspec pp_vspec vspec
  | Vresource -> Format.pp_print_string fmt "resource"
  | Vnull -> Format.pp_print_string fmt "null"
  | Vor (v1, v2, _)-> Format.fprintf fmt "%a|%a" pp_vspec v1 pp_vspec v2
  | Vstring -> Format.pp_print_string fmt "string"
  | Vmixed -> Format.pp_print_string fmt "mixed"
  | Varray0 -> Format.pp_print_string fmt "array0"
  | Vobject (vspec,x,y,z) -> Format.fprintf fmt "object(%a)" pp_vspec vspec
  | Vdtd (f,r) -> Format.fprintf fmt "dtd(%s,%s)" f r

let varray vspec = Varray (vspec, fresh_var (), fresh_var (), fresh_var ())
let varray2 (vspec_key, vspec)  = Varray2 (vspec_key, vspec, fresh_var (), fresh_var (), fresh_var ())
let vor v1 v2 = Vor (v1, v2, fresh_var ())
let vfalse = Vboolval false
let vobject vspec = Vobject (vspec, fresh_var (), fresh_var (), fresh_var ())

let initial_vspec =
  let r = Reg.Star Reg.Allalpha in
  ["$_SERVER", varray (Vregexp r);
   "$_GET", varray (Vregexp r); 
   "$_POST",  varray (Vregexp r); 
   "$_COOKIE", varray (Vregexp r);
   "$_FILES", varray (Vregexp r);
   "$_ENV", varray (Vregexp r);
   "$_REQUEST", varray (Vregexp r);
   "$_SESSION", varray (Vregexp r);]


let initial_fspec =
  let r = Reg.Star Reg.Allalpha in
  ["empty", Vbool;
   "ereg", Vbool;
   "preg_match", Vbool;
   "is_array", Vbool;
   "file_exists", Vbool;
   "mysql_fetch_array",  varray (Vregexp r); 
   "mysql_field_name", Vregexp r;
   "isset", Vbool;
   "mysql_connect", Vresource;
   "mysql_select_db", Vbool;
   "mysql_query", Vresource;
   "mysql_num_fields", Vint;
   "mysql_free_result", Vbool;
   "mysql_close", Vbool;
   "chr", Vregexp (Reg.Negalphalist []);
   "md5", Vregexp (Pregparser.parse_reg "/[0-9a-f]{32}/");
   "md5_file", Vregexp (Pregparser.parse_reg "/[0-9a-f]{32}/");
   "sha1", Vregexp (Pregparser.parse_reg "/[0-9a-f]{40}/");
   "sha1_file", Vregexp (Pregparser.parse_reg "/[0-9a-f]{40}/");
   (* MD5 based crypt *)
   "crypt", Vregexp (Pregparser.parse_reg "/$1$[0-9a-zA-Z.\\/]{8}$[.\\/0-9A-Za-z]{22}/");  
 ]

let iter_cspec f spec =
  Hashtbl.iter (fun x v -> f x v) spec.cspec

let fold_vspec f spec a =
  Hashtbl.fold (fun x v a -> f x v a) spec.vspec a
let fold_cspec f spec a =
  Hashtbl.fold (fun x v a -> f x v a) spec.cspec a

let find_fspec spec s loc =
  let sloc = Loc.simple_loc loc in
  try 
    Hashtbl.find spec.fspec (s, Some sloc) 
  with Not_found -> 
    Hashtbl.find spec.fspec (s, None)

let merge_spec spec =
  List.iter 
    (fun (x, v) -> 
      if not (Hashtbl.mem spec.vspec x) then Hashtbl.add spec.vspec x v)
    initial_vspec;
  List.iter 
    (fun (x, v) -> 
      if not (Hashtbl.mem spec.fspec (x, None)) 
      then Hashtbl.add spec.fspec (x, None) v)
    initial_fspec;
  spec

    

      
