open Support
open Phptype
open Il
open Ilmisc
 


type rvalue = 
    Vvar of var 
  | Vbox of var 
  | Vdref of var                 (* $x for an aliased variable, i.e., *$x  *)
  | Vadref of var                (* $x[]    *)
  | Vadref2 of var * var         (* $x[$y]  *)
  | Vkey of var                 (* key($x) *)
  | Vcond of rvalue * var * var (* the last var : classname *)
  | Vcondnull of rvalue * var 
  | Vcondarray of rvalue * var 
  | Vstring 
  | Vstringval of string 
  | Vint
  | Vintval of int
  | Vfloat
  | Vbool
  | Vboolval of bool
  | Vnull
  | Varray of var * var * (var StringMap.t)
  | Vresource
  | Vobject of var (* classid *)
  | Vodref of var * fieldname    (* $x->m *)

type lvalue = 
    Lvar of var 
  | Ldref of var 
  | Ladref of var 
  | Ladref2 of var * var
  | Lkey of var 
  | Lodref of var * fieldname    (* $x->m *)

(* Constraints *)

module LRSet =
  Set.Make(struct 
    type t = lvalue * rvalue
    let compare = compare
  end)


let extend x v env = LRSet.add (x,v) env 

 let rec extend_list xs vs env = 
  match xs, vs with
    [], [] -> env
  | x::xs, v::vs -> extend_list xs vs (extend x v env)
  | _ -> failwith "extend_list"

let rec extend_list' extend  xs vs env = 
  match xs, vs with
    [], [] -> env
  | x::xs, v::vs -> extend_list' extend xs vs (extend x v env)
  | _ -> failwith "extend_list"


let rec pp_rvalue fmt = function
    Vvar x -> pp_var fmt x
  | Vbox x -> Format.fprintf fmt "box*%a" pp_var x
  | Vdref x -> Format.fprintf fmt "*%a" pp_var x
  | Vadref x -> Format.fprintf fmt "%a[]" pp_var x
  | Vadref2 (x,y) -> Format.fprintf fmt "%a[%a]" pp_var x pp_var y
  | Vkey x -> Format.fprintf fmt "key(%a)" pp_var x
  | Vstring  -> Format.pp_print_string fmt "STRING"
  | Vstringval s -> Format.pp_print_string fmt s
  | Vint  -> Format.pp_print_string fmt "INT"
  | Vintval i -> Format.fprintf fmt "INT %d" i
  | Vnull  -> Format.pp_print_string fmt "null"
  | Vfloat  -> Format.pp_print_string fmt "FLOAT"
  | Vbool  -> Format.pp_print_string fmt "BOOL"
  | Vboolval b -> Format.pp_print_string fmt "BOOL"
  | Varray (x,y,_)  -> Format.fprintf fmt "ARRAY(%a,%a)" pp_var x pp_var y
  | Vresource -> Format.pp_print_string fmt "RESOURCE"
  | Vobject classname -> Format.fprintf fmt "OBJECT(%a)" pp_var classname
  | Vcond (v,x,classname) -> 
      Format.fprintf fmt "COND(%a,%a,%a)" pp_rvalue v pp_var x pp_var classname
  | Vcondnull (v,x) -> 
      Format.fprintf fmt "CONDNULL(%a,%a)" pp_rvalue v pp_var x
  | Vcondarray (v,x) -> 
      Format.fprintf fmt "CONDARRAY(%a,%a)" pp_rvalue v pp_var x
  | Vodref (x,m) -> 
      Format.fprintf fmt "%a->%s" pp_var x m

let pp_lvalue fmt = function
    Lvar x -> pp_var fmt x
  | Ldref x -> Format.fprintf fmt "*%a" pp_var x
  | Ladref x -> Format.fprintf fmt "%a[]" pp_var x
  | Ladref2 (x,y) -> Format.fprintf fmt "%a[%a]" pp_var x pp_var y
  | Lkey x -> Format.fprintf fmt "key(%a)" pp_var x
  | Lodref (x,m) -> Format.fprintf fmt "%a->%s" pp_var x m

let varray (x,y) = Varray (x, y, StringMap.empty)

let rec eval_const env const =
  match const with
    ConstInt i -> (Vintval i, env)
  | ConstBool b -> (Vboolval b, env)
  | ConstFloat f -> (Vfloat, env)
  | ConstString s -> (Vstringval s, env)
  | ConstArray (l, x, y, z) -> 
      let env = extend (Lvar x) (Vbox z) env in
      let env = extend (Lvar z) Vnull env in
      let env =
	List.fold_left (fun env (a,b) ->
	  let v, env  = eval_const env a in
	  let env = extend (Lvar y) v env in
	  let w, env  = eval_const env b in
	  extend (Lvar z) w env) env l in
      (varray (x, y), env)
  | ConstConst x -> (Vvar x, env)
  | ConstBox (c, x) -> 
      let v, env  = eval_const env c in
      let env = extend (Lvar x) v env in
      (Vbox x, env)

let rec eval_vspec ilenv env vspec =
  match vspec with
    Valuespec.Vregexp r -> (Vstring, env)
  | Valuespec.Vdtd _ -> (Vstring, env)
  | Valuespec.Vint -> (Vint, env)
  | Valuespec.Vfloat -> (Vfloat, env)
  | Valuespec.Vbool -> (Vbool, env)
  | Valuespec.Vboolval b -> (Vboolval b, env)
  | Valuespec.Vresource -> (Vresource, env)
  | Valuespec.Vnull -> (Vnull, env)
  | Valuespec.Varray (vspec,x,y,z) -> 
      let v, env = eval_vspec ilenv env vspec in
      let env = extend (Lvar z) v env in
      let env = extend (Lvar z) Vnull env in
      let env = extend (Lvar x) (Vbox z) env in
      let env = extend (Lvar y) Vint env in
      let env = extend (Lvar y) Vstring env in
      (varray (x,y), env)
  | Valuespec.Vor (vspec1,vspec2,x) ->
      let v1, env = eval_vspec ilenv env vspec1 in
      let env = extend (Lvar x) v1 env in
      let v2, env = eval_vspec ilenv env vspec2 in
      let env = extend (Lvar x) v2 env in
      (Vvar x, env)
  | Valuespec.Vstring -> (Vstring, env)
  | Valuespec.Vmixed -> failwith "mixed"
  | Valuespec.Varray0 -> failwith "array0"
  | Valuespec.Vobject (vspec,x,y,z) -> 
      let v, env = eval_vspec ilenv env vspec in
      let ivenv, a, b, c = Ilmisc.find_stdclass ilenv in
      let env = extend (Lvar b) v env in
      let env = 
	StringMap.fold (fun m (a,b) env -> extend (Lvar b) v env) ivenv
	  env in
      (Vobject (stdclass_of ilenv), env)
  | Valuespec.Varray2 (keyspec, vspec,x,y,z) -> 
      let v1, env = eval_vspec ilenv env keyspec in
      let v2, env = eval_vspec ilenv env vspec in
      let env = extend (Lvar z) v2 env in
      let env = extend (Lvar z) Vnull env in
      let env = extend (Lvar x) (Vbox z) env in
      let env = extend (Lvar y) v1 env in
      (varray (x,y), env)
  

let rec extend_fparam_list extend s (ys, vs, es) env =
  match (ys, vs, es) with
    ([], [], []) -> env 
  | ([], _, _) -> env (*  It is OK to supply arguments more than necessary  *)
  | ((y,_,_)::ys, v::vs, e::es) -> extend_fparam_list extend s (ys, vs, es) (extend (Lvar y) v env)
  | ((y,Some const,_)::ys, [], []) -> 
      let v, env = eval_const env const in
      extend_fparam_list extend s (ys, [], []) (extend (Lvar y) v env)
  | (_, [], []) -> 
(*      Format.printf "Warning: too few arguments %s@." s; *)
      env
  | _ -> failwith ("extend_fparam_list"^s.name) 

let rec extend_cond_list (y, cname) xs vs env = 
  match xs, vs with
    [], [] -> env
  | x::xs, v::vs -> extend_cond_list (y,cname) xs vs (extend x (Vcond (v, y, cname)) env)
  | _ -> failwith "extend_list"

let extend_cond (y, cname) x v env = 
  let v, env =
    match v with
      Vdref _ | Vadref _ | Vkey _ | Vcond _ | Vcondnull _ | Vcondarray _ | Vodref _ -> 
	let y = fresh_var () in
	Vvar y, extend (Lvar y) v env 
    | _ -> v, env in
  extend x (Vcond (v, y, cname)) env

(*
let rec check_fparams bs fps =
  match (bs, fps) with
    (b::bs, (_,_,b')::fps) ->  b = b' && check_fparams bs fps 
  | ([], []) -> true
  | _ -> false
*)

let rec exec ilenv fvar_htbl ys env s = 

  let rec eval env exp =
    match exp with
      Var x -> (Vvar x, env)
    | Vspec vspec -> eval_vspec ilenv env vspec
    | Dref (x,y) -> 
(*	let env = extend (Lvar y) Vnull env in *) (* Dereference may yield null *)
	(Vvar y, extend (Lvar y) (Vdref x) env)
    | Const x -> (Vvar x, env)
    | ConstExp const -> eval_const env const
    | Null -> (Vnull, env)
    | Int i -> (Vintval i, env)
    | Float f -> (Vfloat, env)
    | Bool b -> (Vboolval b, env)
    | String s -> (Vstringval s, env) 
    | Prim (p, es, (x,y,z,_)) -> 
	let vs, env = eval_list env es in
	(match p with
	  Concat | Cast StringTy -> Vstring, env
	| Cast FloatTy -> Vfloat, env
	| Cast IntTy -> Vint, env
	| Mod -> Vint, env
       (* these operations may cause overflow and thus produce a float even for integers *)
	| Plus | Minus | Times -> 
	    let env = extend (Lvar x) Vint env in	
	    let env = extend (Lvar x) Vfloat env in	
	    Vvar x, env 
	| Div -> Vfloat, env
	| Bitnot | Bitand | Bitor | Bitxor | Bitshiftl | Bitshiftr -> Vint, env
	| Eq | Neq | Lt | Le | Gt | Ge | Not | Xor | Cast BoolTy -> Vbool, env
	| Cast ArrayTy ->  (* not precise for objects *)
	    (match vs with
	      [v] ->
		let w = fresh_var () in
		let env = extend (Lvar x) v env in
		let env = extend (Lvar x) (varray (y,w)) env in
		let env = extend (Lvar w) (Vbox z) env in
		let env = extend (Lvar z) v env in
		let env = extend (Lvar y) Vint env in
		Vvar x, env
	    | _ -> failwith "cast array")
	| Cast ObjectTy -> 
	    (match vs with
	      [v] ->
		let env = extend (Lvar x) v env in
		let env = extend (Lvar x) (Vobject (stdclass_of ilenv)) env in
		let ivenv, a, b, _ = Ilmisc.find_stdclass ilenv in
		let env = extend (Lvar b) v env in
		Vvar x, env
	    | _ -> failwith "cast object")
	| Cast ResourceTy -> failwith "cast resource"
	| NewRef -> Vbox x, env
	| NewArray -> 
	    let env = extend (Lvar x) (Vbox z) env in
	    let env = extend (Lvar z) Vnull env in
	    varray (x,y), env
	| NewArrayL sxys -> 
	    let env = extend (Lvar x) (Vbox z) env in
	    let env = extend (Lvar z) Vnull env in
	    let amap, env = 
	      List.fold_left (fun (amap, env) (s,x',y') ->
		let env = extend (Lvar x') (Vbox y') env in
		let env = extend (Lvar y') Vnull env in
		let env = extend (Lvar x) (Vvar x') env in
		let env = extend (Lvar y) (Vstringval s) env in
		let amap = StringMap.add s x' amap in
		amap, env) (StringMap.empty, env) sxys in
	    Varray (x,y,amap), env
	| InitArray w -> 
	    (match vs with
	      [v] ->
		let w' = fresh_var () in
		let env = extend (Lvar z) Vnull env in
		let env = extend (Lvar x) (Vbox z) env in
		let env = extend (Lvar w') v env in
		let env = extend (Lvar w) (Vcondnull (varray (x,y), w')) env in
		Vvar w, env
	    | _ -> failwith "init_array")
	| InitObj w -> 
	    (match vs with
	      [v] ->
		let env = extend (Lvar y) v env in
		let env = extend (Lvar x) (Vcondnull (Vobject (stdclass_of ilenv), y)) env in
		Vvar x, env
	    | _ -> failwith "init_array")
	| NewObj classname -> 
	    (match Hashtbl.find_all ilenv.Ilmisc.classes classname with
	      [(cid,_,_)] -> Vobject cid, env
	    | cs -> 
		let env = List.fold_left 
		    (fun env (cid,_,_) -> extend (Lvar x) (Vobject cid) env) env cs in
		Vvar x, env)
	| CheckFunction _ -> Vbool, env
	| CheckMethod _ -> Vbool, env
	| StringUpdate -> Vstring, env
	| ArrayDref -> 
	    (match vs with
	      [v1; v2] -> 
		let y' = fresh_var () in
		let env = extend (Lvar y') v1 env in
		let env = extend (Lvar x) v2 env in
		let env = extend (Lvar y) (Vadref2 (y',x)) env in
		let env = extend (Lvar z) (Vdref y) env in
		let env = extend (Lvar z) Vnull env in
		(Vvar z, env)
	    | _ -> failwith "arraydref")) 
    | App (s, es, (x,y,z,loc)) -> 
	let vs, env = eval_list env es in
	match s with
	  "explode" | "preg_split" | "str_split" ->
	    let env = extend (Lvar y) Vint env in
	    let env = extend (Lvar x) (Vbox z) env in
	    let env = extend (Lvar z) Vstring env in
	    let env = extend (Lvar z) Vnull env in
	    (varray (x,y), env)
	| "str_replace" | "preg_replace" ->
	    (match vs with
	      [v1; v2; v3] -> 
	    let w = fresh_var () in
	    let v3' = fresh_var () in
	    let env = extend (Lvar z) Vnull env in
	    let env = extend (Lvar z) Vstring env in
	    let env = extend (Lvar w) (Vbox z) env in
	    let env = extend (Lvar v3') v3 env in
	    let env = extend (Lvar y) (Vkey v3') env in
	    let env = extend (Lvar x) Vstring env in
	    let env = extend (Lvar x) (Vcondarray (varray (w,y), v3')) env in
	    (Vvar x, env)	    
	    | _ -> Il.unsupported loc (fun fmt -> Format.fprintf fmt "%a" Il.pp_exp exp))
	| "array_slice" ->
	    (match vs with
	      v::_ -> (v, env)
	    | _ -> failwith "array_slice")
	| "array_keys" ->
	    (match vs with
	      v::_ -> 
		let w = fresh_var () in
		let env = extend (Lvar y) Vint env in
		let env = extend (Lvar x) (Vbox z) env in
		let env = extend (Lvar w) v env in
		let env = extend (Lvar z) (Vkey w) env in
		let env = extend (Lvar z) Vnull env in
		(varray (x,y), env)
	    | _ -> failwith "array_keys")
	| "array_values" ->
	    (match vs with
	      v::_ -> 
		let w = fresh_var () in
		let env = extend (Lvar y) Vint env in
		let env = extend (Lvar x) (Vadref w) env in
		let env = extend (Lvar w) v env in
		(varray (x,y), env)
	    | _ -> failwith "array_values")
	| "array_chunk" ->
	    (match vs with
	      [v1;v2] -> 
		let env = extend (Lvar y) Vint env in
		let env = extend (Lvar x) (Vbox z) env in
		let env = extend (Lvar z) v1 env in
		let env = extend (Lvar z) Vnull env in
		(varray (x,y), env)
	    | _ -> failwith "array_chunk")
	| "array_merge" ->
	    (match vs with
	      [v1;v2] -> 
		let z1 = fresh_var () in
		let z2 = fresh_var () in
		let env = extend (Lvar z1) v1 env in
		let env = extend (Lvar z2) v2 env in
		let env = extend (Lvar x) (Vadref z1) env in
		let env = extend (Lvar x) (Vadref z2) env in
		let env = extend (Lvar y) (Vkey z1) env in
		let env = extend (Lvar y) (Vkey z2) env in
		(varray (x,y), env)
	    | _ -> failwith "array_merge")
	| "array_change_key_case" ->
	    (match vs with
	      [v]|[v; _] -> 
		let w = fresh_var () in
		let env = extend (Lvar w) v env in
		let env = extend (Lvar x) (Vadref w) env in
		let env = extend (Lvar y) (Vkey w) env in
		let env = extend (Lvar y) Vstring env in
		(varray (x,y), env)
	    | _ -> failwith "array_change_key_case")
	| "array_push" ->
	    (match vs with
	      [v1;v2] -> 
		let env = extend (Lvar x) v1 env in
		let env = extend (Lvar y) (Vadref x) env in
		let env = extend (Ldref y) v2 env in
		(Vint, env)
	    | _ -> failwith "array_push")
	| "array_pop" ->
	    (match vs with
	      [v1] -> 
		let env = extend (Lvar x) v1 env in
		let env = extend (Lvar y) (Vadref x) env in
		let env = extend (Lvar z) (Vdref y) env in
		(Vvar z, env)
	    | _ -> failwith "array_pop")
	| "array_count_values" ->
	    (match vs with
	      [v1] -> 
		let env = extend (Lvar y) v1 env in
		let env = extend (Lvar y) (Vbox y) env in
		let env = extend (Lvar z) Vint env in
		let env = extend (Lvar z) Vnull env in
		(varray (x,y), env)
	    | _ -> failwith "array_count_values")

	| "end" | "current" | "next" | "pos" | "prev" | "reset" ->
	    (match vs with
	      [v1] -> 
		let env = extend (Lvar x) v1 env in
		let env = extend (Lvar y) (Vadref x) env in
		let env = extend (Lvar z) (Vdref y) env in
		(Vvar z, env)
	    | _ -> failwith "current")
	| "key" ->
	    (match vs with
	      v::_ -> 
		let env = extend (Lvar y) v env in
		let env = extend (Lvar x) (Vkey y) env in
		(Vvar x, env)
	    | _ -> failwith "key")
	| "array_search" ->
	    (match vs with
	      _::v::_ -> 
		let env = extend (Lvar y) v env in
		let env = extend (Lvar x) (Vkey y) env in
		(Vvar x, env)
	    | _ -> failwith "array_search")
	| "each" ->
	    (match vs with
	      [v1] -> 
		let w = fresh_var () in
		let w' = fresh_var () in
		let env = extend (Lvar w) v1 env in
		let env = extend (Lvar y) Vint env in
		let env = extend (Lvar y) Vstring env in
		let env = extend (Lvar x) (Vbox z) env in
		let env = extend (Lvar z) (Vkey w) env in
		let env = extend (Lvar z) (Vdref w') env in
		let env = extend (Lvar z) Vnull env in
		let env = extend (Lvar w') (Vadref w) env in
		(varray (x,y), env)
	    | _ -> failwith "each")
	| "__preg_match_array" | "__ereg_array" | "__eregi_array" ->
	    (match vs with
	      [v1;v2] -> 
		let env = extend (Lvar y) Vint env in
		let env = extend (Lvar x) (Vbox z) env in
		let env = extend (Lvar z) Vstring env in
		let env = extend (Lvar z) Vnull env in
		(varray (x,y), env)
	    | _ -> failwith "__preg_match_array")
	| "preg_match_all" -> (Vint, env)
	| "__preg_match_all" ->
	    let x', y', z' = fresh_var (), fresh_var (), fresh_var () in 
	    let env = extend (Lvar x) (Vbox z') env in
	    let env = extend (Lvar z') (varray (x',y')) env in
	    let env = extend (Lvar x') (Vbox z) env in
	    let env = extend (Lvar z) Vstring env in
	    (varray (x,y), env)
	| "get_class" | "get_parent_class" ->
	    (match vs with
	      [v] -> 
		let env = extend (Lvar x) (Vboolval false) env in
		let env = extend (Lvar x) Vstring env in
		(Vvar x, env)
	    | _ -> failwith "get_class")
	| _ ->
	try
	  match Phpprim.find_type s with
	  | Valuespec.Vmixed | Valuespec.Varray0 -> Il.impossible ("alias analysis: "^s)
	  | t -> eval_vspec ilenv env t
	with Not_found -> failwith ("alias analysis: "^s)
  and eval_list env es = List.fold_right 
      (fun e (vs,env) -> 
	let v, env = eval env e in
	v::vs, env) es ([],env) in

  let rec eval_lv env lv =
    match lv with
      LVar x -> (Vvar x, env)
    | LArray1 lv -> 
	let env = extend (Lkey lv) Vint env in
	(Vadref lv, env)
    | LArray2 (lv, e) -> 
	let x = fresh_var () in
	let v, env = eval env e in 
	let env = extend (Lvar x) v env in
	let env = extend (Lkey lv) (Vvar x) env in
	(Vadref2 (lv,x), env)
    | LObjRef (lv, m) -> (Vodref (lv, m), env) in

  let rec eval_lv' env lv =
    match lv with
      LVar x -> (Lvar x, env)
    | LArray1 lv -> 
	let env = extend (Lkey lv) Vint env in
	(Ladref lv, env)
    | LArray2 (lv, e) -> 
	let x = fresh_var () in
	let v, env = eval env e in 
	let env = extend (Lvar x) v env in
	let env = extend (Lkey lv) (Vvar x) env in
	(Ladref2 (lv,x), env)
    | LObjRef (lv, m) -> (Lodref (lv, m), env) in

  let rec exec_stmt env s =
    match s with 
    | LocalFun (x, xs, b) -> exec_block env b
    | FunCall (xs, s, es, r, bs) ->
	let vs,env = eval_list env es in
	List.fold_left (fun env (ys,_,zs,r') -> 
	  let env = extend_fparam_list extend s (ys, vs, es) env in
	  let xs, zs, env = 
	    match (xs, zs, r, r') with
	      (x::xs, z::zs, true, true) -> xs, zs, extend (Lvar x) (Vvar z) env
	    | (x::xs, z::zs, true, false)-> xs, zs, extend (Lvar x) (Vbox z) env
	    | (x::xs, z::zs, false, true) -> xs, zs, extend (Lvar x) (Vdref z) env
	    | _ -> xs, zs, env in
	  extend_list (List.map (fun x -> Lvar x) xs)
	    (List.map (fun x -> Vvar x) zs) env)
	  env (Ilmisc.fun_env_find s ilenv)
    | ClassMethodCall (xs, cname, mname, es, r, bs) ->
	let vs,env = eval_list env es in
	let classmethod_call (_, ys,this,_, zs,r') env =
	  let env = extend_fparam_list extend mname (ys, vs, es) env in
	  let xs, zs, env = 
	    match (xs, zs, r, r') with
	      (x::xs, z::zs, true, true) -> xs, zs, extend (Lvar x) (Vvar z) env
	    | (x::xs, z::zs, true, false)-> xs, zs, extend (Lvar x) (Vbox z) env
	    | (x::xs, z::zs, false, true) -> xs, zs, extend (Lvar x) (Vdref z) env
	    | _ -> xs, zs, env in
	  let env = extend (Lvar this) Vnull env in
	  extend_list (List.map (fun x -> Lvar x) xs) 
	    (List.map (fun x -> Vvar x) zs) env in
	List.fold_right (fun m env -> classmethod_call m env)
	  (Ilmisc.find_classmethod ilenv cname mname) env
    | MethodCall (xs, x, mname, es, r, bs) ->
	let vs,env = eval_list env es in
	let method_call (cname, (_, ys,this,_, zs,r')) env =
	  let extend' = extend_cond (x, cname) in
	  let env = extend_fparam_list extend' mname (ys, vs, es) env in
	  let xs, zs, env = 
	    match (xs, zs, r, r') with
	      (x::xs, z::zs, true, true) -> 
		xs, zs, extend' (Lvar x) (Vvar z) env
	    | (x::xs, z::zs, true, false)-> 
		let z' = fresh_var () in
		let env = extend (Lvar z') (Vbox z) env in
		xs, zs, extend' (Lvar x) (Vvar z') env
	    | (x::xs, z::zs, false, true) -> 
		let z' = fresh_var () in
		let env = extend (Lvar z') (Vdref z) env in
		xs, zs, extend' (Lvar x) (Vvar z') env
	    | _ -> xs, zs, env in
	  let env = extend' (Lvar this) (Vvar x) env in
	  extend_list' extend' (List.map (fun x -> Lvar x) xs) 
	    (List.map (fun x -> Vvar x) zs) env in
	List.fold_right (fun (cname, m) env -> method_call (cname, m) env)
	  (Ilmisc.find_method ilenv mname) env 
    | Assign (x, e) -> let v,env = eval env e in extend (Lvar x) v env
    | Define (x, e) -> let v,env = eval env e in extend (Lvar x) v env
    | ExpSt e -> 
	let v,env = eval env e in env
    | DrefAssign (x, exp) -> 
	let v, env = eval env exp in
	extend (Ldref x) v env
    | RefAssign (LVar x, lv) -> 
	let lv,env = eval_lv env lv in 
	extend (Lvar x) lv env
    | RefAssign (x, lv) -> 
	let y = fresh_var () in
	let x,env = eval_lv' env x in 
	let lv,env = eval_lv env lv in 
	let env = extend x (Vvar y) env in
	extend (Lvar y) lv env
    | Echo e -> failwith "exec_stmt"
    | Assert (e, x, s) -> 
	let v,env = eval env e in extend (Lvar x) v env
    | Unset _ -> failwith "exec_stmt"
  and exec_block env s =
    match s with 
    | If (e, _, b1, _,b2) -> 
	let v, env = eval env e in
	exec_block (exec_block env b1) b2
    | Switch (e, x, cs) -> 
	let v, env = eval env e in
	let env = extend (Lvar x) v env in
	let exec_case env (g, y, b) = exec_block env b in
	List.fold_left exec_case env cs 
    | LocalCall (x, es) -> 
	let vs, env = eval_list env es in
	let ys = 
	  try Hashtbl.find ilenv.Ilmisc.lfun_env x
	  with Not_found -> 
	    (Format.printf "%a@." pp_var x; raise Not_found) in
	extend_list 
	  (List.map (fun x -> Lvar x) ys) vs env
    | Seq (s,b) -> exec_block (exec_stmt env s) b
    | Stop _ -> env
    | Return es -> 
	let vs, env = eval_list env es in
	extend_list (List.map (fun x -> Lvar x) ys) 
	  vs env in
  exec_block env s

let exec ilenv fvar_htbl ys env b =
  let function_f env (x, xs, b, ys, r) = exec ilenv fvar_htbl ys env b in
  let class_f env (cname, xs, ms) =
    let ivenv, a, b, _ = 
      try
	Ilmisc.find_class ilenv cname
      with Not_found -> failwith "Impossible: unknown class" in
    let env = extend (Lvar a) (Vbox b) env in
    let env = extend (Lvar b) Vnull env in
    let env = List.fold_left 
	(fun env (x,constopt) -> 
	  let y, z = 
	    try StringMap.find x ivenv 
	    with Not_found -> 
	      failwith ("Impossible: unknown instance variable :"^cname.name) in
	  let env = extend (Lvar y) (Vbox z) env in
	  match constopt with
	    None -> 
	      extend (Lvar z) Vnull env
	  | Some c -> 
	      let v, env = eval_const env c in
	      extend (Lvar z) v env) env xs in
    List.fold_left 
      (fun env (s,xs,this,b,ys,_) -> exec ilenv fvar_htbl ys env b) env ms in
  fold_program (fun env b -> exec ilenv fvar_htbl ys env b) function_f  class_f b env


module Vset =
  Set.Make(struct 
    type t = rvalue
    let compare = compare
  end)

let lookup env x = 
  try Hashtbl.find env x with _ -> VarSet.empty

let env_add x ys env =
  Hashtbl.replace env x ys; env

let env_remove x env =
  Hashtbl.remove env x; env

let update' env (x,v) = 
  let vs = lookup env x in
  env_add x (VarSet.add v vs) env

let update (env,flag) (x,v) = 
  let vs = lookup env x in
  if VarSet.mem v vs then (env,flag) 
  else (env_add x (VarSet.add v vs) env, true)

let lookup_var env v = 
  let visited = Hashtbl.create 1000 in
  let rec dfs x rs =
    if Hashtbl.mem visited x then rs 
    else
      let rs = VarSet.add x rs in
      Hashtbl.add visited x ();
      VarSet.fold (fun y rs -> dfs y rs) (lookup env x)  rs in
  dfs v VarSet.empty

let nontrivial_scc_of env xs =
  let i = ref 0 in
  let sccs = ref [] in
  let stack = Stack.create () in
  let stacked = Hashtbl.create 1000 in
  let dfsnum = Hashtbl.create 1000 in
  let rec dfsscc v =
    let vi = !i in
    Hashtbl.add dfsnum v vi;
    incr i;
    Stack.push v stack; Hashtbl.add stacked v ();
    let low = 
      VarSet.fold (fun w low ->
	if not (Hashtbl.mem dfsnum w) then
	  min low (dfsscc w)
	else
	  if Hashtbl.mem stacked w then
	    min low (Hashtbl.find dfsnum w)
	  else
	    low)
	(lookup env v) vi in
    if low = vi then
      (let component = ref VarSet.empty in
      let n = ref 0 in
      while not (Stack.is_empty stack) && 
	Hashtbl.find dfsnum (Stack.top stack) >= vi do
	let w = Stack.pop stack in
	incr n;
	Hashtbl.remove stacked w;
	component := VarSet.add w (!component);
      done;
      if !n > 1 then sccs := !component::!sccs);
    low in
  VarSet.iter 
    (fun v -> if not (Hashtbl.mem dfsnum v) then let _ = dfsscc v in ())
    xs;
  !sccs

let vs_find vs_map x = 
  try Hashtbl.find vs_map x with Not_found -> Vset.empty 
let vs_add vs_map x v = 
  Hashtbl.replace vs_map x (Vset.add v (vs_find vs_map x)) 

let rec rename_find rename_map x =
  try 
    let y = Hashtbl.find rename_map x in 
    let z = rename_find rename_map y in
    if y != z then Hashtbl.replace rename_map x z;
    z
  with Not_found -> x
let rename_add rename_map x y = Hashtbl.add rename_map x y 
let rename_vars rename_map ys = 
    VarSet.fold (fun y ys -> VarSet.add (rename_find rename_map y) ys)
    ys VarSet.empty

let pp_set_hashtbl fmt iter pp_key pp_value htbl =
  Hashtbl.iter (fun x vs ->
    iter (fun v ->
      Format.fprintf fmt "%a -> %a@." pp_key x pp_value v) vs) htbl

let pp_env fmt env = pp_set_hashtbl fmt VarSet.iter pp_var pp_var env


let solve ilenv constraints = 

  let l_constraints, r_constraints, env, vs_map = 
   LRSet.fold (fun (l, r) (ls, rs, env, vs_map) ->
    match (l, r) with
   ((Ldref _ | Ladref _ | Lkey _ | Lodref _ | Ladref2 _ ), 
   (Vdref _ | Vadref _ | Vkey _ | Vcond _ | Vcondnull _ | Vcondarray _ | Vodref _ | Vadref2 _)) -> 
   failwith "bad constraint"
    | ((Ldref _ | Ladref _ | Lkey _ | Lodref _ | Ladref2 _), _)  -> 
   ((l,r)::ls, rs, env, vs_map)
    | (Lvar x, (Vdref _ | Vadref _ | Vkey _ | Vcond _ | Vcondnull _ | Vcondarray _ | Vodref _ | Vadref2 _)) ->
   (ls, (x,r)::rs, env, vs_map)
    | (Lvar x, Vvar y) -> (ls, rs, update' env (x,y), vs_map)
    | (Lvar x, v) -> (ls, rs, env, (vs_add vs_map x v; vs_map))) 
   constraints ([], [], Hashtbl.create 1000, Hashtbl.create 1000) in 

  let rename_map = Hashtbl.create 1000 in

  let () = Options.show 2 
      (fun fmt -> Format.fprintf fmt "before scc@.%a@." pp_env env) in

  let xs =
    let process_l l xs =
      match l with 
	Ldref x | Ladref x | Lkey x | Lodref (x,_) -> VarSet.add x xs
      | Ladref2 (x,y) -> VarSet.add y (VarSet.add x xs) 
      | _ -> failwith "process_l'" in
    let xs = List.fold_left (fun xs (x,v) -> process_l x xs) VarSet.empty
	l_constraints in   
    let process_r r xs = 
      match r with
	Vdref x | Vadref x | Vkey x | Vcond (_, x, _)| Vcondnull (_, x) 
      | Vcondarray (_, x) | Vodref (x,_) -> VarSet.add x xs
      | Vadref2 (x,x') -> VarSet.add x' (VarSet.add x xs) 
      | _ -> failwith "process_r'" in
    let xs = 
      List.fold_left (fun xs (x,v) -> process_r  v xs) xs
	r_constraints in 
    xs in

  let simplify_env env =
    let () = Options.show 2 
	(fun fmt -> Basic.print_iter VarSet.iter "," pp_var fmt xs) in 


    let sccs = nontrivial_scc_of env xs in

    let () = 
      Options.show 2 (fun fmt ->
	Format.fprintf fmt "scc@.";
	List.iter (fun xs ->
	  Format.fprintf fmt "%a@."
	    (Basic.print_iter VarSet.iter "," pp_var) xs)
	  sccs) in 

    let env = List.fold_left (fun env xs ->
      let z = fresh_var () in
      let env,zs  = VarSet.fold (fun x (env, zs) -> 
	let ys = Hashtbl.find env x in
	let env = VarSet.fold (fun y env -> if VarSet.mem y xs then env else update' env (z, y)) ys env in
	let env = env_remove x env in
	let zs = Vset.union (vs_find vs_map x) zs in
	rename_add rename_map x z;
	Hashtbl.remove vs_map x;
	(env, zs)) xs (env, Vset.empty) in
      Hashtbl.add vs_map z zs;
      env) env sccs in

    let env = Hashtbl.fold 
	(fun x ys env -> env_add x (rename_vars rename_map ys) env) 
	env (Hashtbl.create 1000) in

    let () = Options.show 2 
	(fun fmt -> Format.fprintf fmt "after scc@.%a@." pp_env env) in
    env in

  let update (env,flag) (x,v) = 
    let x = rename_find rename_map x in
    match v with
      Vvar y ->
	let y = rename_find rename_map y in
	let vs = lookup env x in
	if VarSet.mem y vs then (env,flag) 
	else (env_add x (VarSet.add y vs) env, true)
    | Vdref _ | Vadref _ | Vkey _ | Vcond _ | Vcondnull _ | Vcondarray _ | Vodref _ | Vadref2 _ -> failwith "bad update"
    | _ -> 
	let vs = vs_find vs_map x in
	if Vset.mem v vs then (env, flag) else (vs_add vs_map x v; (env, true)) in

  let rec loop env =
    let () = Format.printf ".@?" in
    let env = simplify_env env in

    let lookup_var env x = 
      let x = rename_find rename_map x in
      let ys = lookup_var env x in
      let ws = VarSet.fold (fun y ws -> Vset.union (vs_find vs_map y) ws) ys Vset.empty in
      ws in 

    let htbl = ref (Hashtbl.create 1000) in 
    let updated = ref false in
    let update env (x, v) = 
      let env, flag = update env (x, v) in
      updated := flag;
      (env, flag) in

    let lookup_var env x =
      if ! updated then (updated := false; htbl :=  Hashtbl.create 1000);
      try
	Hashtbl.find (!htbl) x 
      with Not_found ->
	let ws = lookup_var env x in
	Hashtbl.add (!htbl) x ws;
	ws in

    let process_l l v (env,flag) = 
      match l with 
	Ldref x -> 
	  let ws = lookup_var env x in 
	  Vset.fold
	    (fun w envflag -> 
	      match w with 
		Vbox z -> update envflag (z, v)
	      | _ -> envflag) ws (env, flag) 
      | Ladref x -> 
	  let ws = lookup_var env x in 
	  Vset.fold (fun w envflag -> 
	    match w with 
	      Varray (z,_,_) -> update envflag (z, v) 
(*	  | Vstring | Vstringval _ -> 
   Format.printf "Warning: string update: %s@." (string_of_var x);
   envflag *)
	    | _ -> envflag) ws (env, flag) 
      | Ladref2 (x,y) -> 
	  let ws = lookup_var env x in 
	  let ws' = lookup_var env y in 
	  Vset.fold (fun w' envflag -> 
	    match w' with
	      Vstringval s ->
		Vset.fold (fun w envflag -> 
		  match w with 
		    Varray (z,_,amap) when StringMap.mem s amap -> 
		      update envflag (StringMap.find s amap, v)
		  | Varray (z,_,_) -> update envflag (z, v) 
		  | _ -> envflag) ws envflag
	    | _ ->
		Vset.fold (fun w envflag -> 
		  match w with 
		    Varray (z,_,_) -> update envflag (z, v) 
		  | _ -> envflag) ws envflag) ws' (env, flag) 
      | Lkey x -> 
	  let ws = lookup_var env x in 
	  Vset.fold (fun w envflag -> 
	    match w with 
	      Varray (_,z,_) -> update envflag (z, v)
	    | _ -> envflag) ws (env, flag) 
      | Lodref (x,m) -> 
	  let ws = lookup_var env x in 
	  Vset.fold (fun w envflag -> 
	    match w with
	      Vobject cname -> 
		let ivenv, a, b, c = Ilmisc.find_class ilenv cname in
		let (z,_), envflag = 
		  try StringMap.find m ivenv, envflag 
		  with Not_found -> 
		    Format.printf "WARNING %s@." cname.name;
		    ((a, b), update envflag (c, Vstringval m)) in
		update envflag (z, v) 
	    | _ -> envflag) ws (env, flag)
      | _ -> (env,flag) in

    let process_r y r (env, flag) = 
      match r with
	Vdref x -> 
	  let ws = lookup_var env x in
	  Vset.fold
	    (fun w envflag ->
	      match w with
		Vbox z -> update envflag (y, Vvar z)
	      | _ -> envflag) ws (env, flag) 
      | Vadref x -> 
	  let ws = lookup_var env x in
	  Vset.fold
	    (fun w envflag ->
	      match w with
		Varray (z,_,_) -> update envflag (y, Vvar z)
(*	    | Vstring | Vstringval _ -> 
   Format.printf "Warning: string update %s@." (string_of_var x);
   envflag *)
	      | _ -> envflag) ws (env, flag)

      | Vadref2 (x,x') -> 
	  let ws = lookup_var env x in
	  let ws' = lookup_var env x' in
	  Vset.fold
	    (fun w' envflag ->
	      match w' with
		Vstringval s ->
		  Vset.fold
		    (fun w envflag ->
		      match w with
			Varray (z,_,amap) when StringMap.mem s amap -> 
			  update envflag (y, Vvar (StringMap.find s amap))
		      | Varray (z,_,_) -> update envflag (y, Vvar z)
		      | _ -> envflag) ws envflag
	      | _ -> 
		  Vset.fold
		    (fun w envflag ->
		      match w with
			Varray (z,_,_) -> update envflag (y, Vvar z)
		      | _ -> envflag) ws envflag)
	    ws' (env, flag)
      | Vkey x -> 
	  let ws = lookup_var env x in
	  Vset.fold
	    (fun w envflag ->
	      match w with
		Varray (_,z,_) -> update envflag (y, Vvar z)
	      | _ -> envflag) ws (env, flag)
      | Vcond (v, x, cname) ->
	  let ws = lookup_var env x in
	  Vset.fold
	    (fun w envflag ->
	      match w with
		Vobject cname' when cname = cname' -> update envflag (y, v)
	      | _ -> envflag) ws (env, flag)
      | Vcondnull (v1, x) ->
	  let ws = lookup_var env x in
	  Vset.fold
	    (fun w envflag ->
	      match w with
		Vnull -> update envflag (y, v1)
	      | _ -> update envflag (y,w)) ws (env, flag)
      | Vcondarray (v1, x) ->
	  let ws = lookup_var env x in
	  Vset.fold
	    (fun w envflag ->
	      match w with
		Varray _ -> update envflag (y, v1)
	      | _ -> update envflag (y,w)) ws (env, flag)
      | Vodref (x,m) -> 
	  let ws = lookup_var env x in
	  Vset.fold
	    (fun w envflag ->
	      match w with
		Vobject cname -> 
		  let ivenv, a, b, c = Ilmisc.find_class ilenv cname in
		  let (z,_), envflag = 
		    try StringMap.find m ivenv, envflag 
		    with Not_found -> ((a, b), update envflag (c, Vstringval m)) in
		  update envflag (y, Vvar z)
              | _ -> envflag) ws (env, flag)
      | _ -> (env,flag) in

    let () = Options.show 1 (fun fmt -> Format.fprintf fmt ".@,") in
    let () = Options.show 2 (fun fmt -> pp_env fmt env) in
    let () = Options.show 2 
	(fun fmt -> pp_set_hashtbl fmt Vset.iter pp_var pp_rvalue vs_map) in

   let env, flag = 
      List.fold_left (fun envflag (x,v) -> process_l x v envflag) (env,false)
	l_constraints in   
   let env, flag = 
      List.fold_left (fun envflag (x,v) -> process_r x v envflag) (env,flag)
	r_constraints in   

    if flag then loop env else env in 
  (loop env, vs_map, rename_map)


let analyse ilenv spec ilinfo (s:program) =
  let fvar_htbl = Hashtbl.create 1000 in
  let pre_env =
    Valuespec.fold_cspec
      (fun s i env -> extend (Lvar (ilinfo.Abssyn2il.constant_of s)) (Vintval i) env) 
      spec LRSet.empty in
  let constraints = exec ilenv fvar_htbl [] pre_env s in
  let () = Options.show 0 (fun fmt -> Format.fprintf fmt "size: %d@?" (LRSet.cardinal constraints)) in 
  let (env, vs_map, rename_map) = solve ilenv constraints in
  let () = Options.show 2 (fun fmt -> pp_env fmt env )in
  (env, vs_map, rename_map, fvar_htbl)

let lookup_var_var htbl (env, vs_map, rename_map, _) x = 
  try Hashtbl.find htbl x 
  with Not_found ->
  let x = rename_find rename_map x in
  let ys = lookup_var env x in
  let ws = VarSet.fold (fun y ws -> Vset.union (vs_find vs_map y) ws) ys Vset.empty in
  Hashtbl.add htbl x ws;
  ws 


let lookup_var (env, vs_map, rename_map, _) v = 
  match v with 
    Vvar x ->
      let x = rename_find rename_map x in
      let ys = lookup_var env x in
      let ws = VarSet.fold (fun y ws -> Vset.union (vs_find vs_map y) ws) ys Vset.empty in
      ws 
  | _ -> Vset.singleton v

let lookup_var' alias_env vs = 
  Vset.fold (fun v ws ->
    Vset.union (lookup_var alias_env v) ws) vs Vset.empty 


type absbool =
    AbsBool
  | AbsTrue
  | AbsFalse
  | AbsBot

let value2bool v =
  match v with
  | Vstring  -> AbsBool
  | Vstringval s -> 
      (match s with
	"" | "0" -> AbsFalse
      |	_ -> AbsTrue)
  | Vint  -> AbsBool
  | Vintval n -> if n = 0 then AbsFalse else AbsTrue
  | Vnull  -> AbsFalse
  | Vfloat  -> AbsBool
  | Vbool  -> AbsBool
  | Vboolval b -> if b then AbsTrue else AbsFalse
  | Varray _ -> AbsBool
  | Vresource -> AbsTrue
  | Vobject _ -> AbsTrue
  | _ -> failwith "value2bool"

let vs2absbool vs =
  Vset.fold (fun v b ->
    match (value2bool v, b) with
      (AbsTrue, AbsTrue) -> AbsTrue 
    | (AbsTrue, AbsBot) -> AbsTrue 
    | (AbsFalse, AbsFalse) -> AbsFalse
    | (AbsFalse, AbsBot) -> AbsFalse
    | _ -> AbsBool) vs AbsBot

