(*
 * PHP string analyzer
 * Copyright (C) 2006 Yasuhiko Minamide
 *)

(*
 * Module to collect information required for the translation
 * from the abstract syntax into the intermidiate language
 *  1. the set of possible calling convention for each function and
 *     method. 
 *     1.1 whether each function has variable-length arguments
 *  2. the set of static variables used in each function and method
 * 
 * In addition to the information above, the following information are
 * used to resolve variable variables and variable field reference.
 *  1. the set of all instance variable names in the program.
 *  2. the set of all global variable names in the program.
 *  3. the set of all local variable names in each function and method.
 *  
 * The following information used to generate warning messages.
 *  1. the set of constant names.
 *
 *)

open Support
open Abssyn

let superglobals =
  List.fold_left (fun ss s -> StringSet.add s ss)
    StringSet.empty
    ["$_SERVER"; "$_GET"; "$_POST"; "$_COOKIE";
     "$_FILES"; "$_ENV"; "$_REQUEST"; "$_SESSION"; "$__strtok"]
    (* "$GLOBALS" should not be in this list *)

type scope =
    TopScope 
  | FunctionScope of string * Loc.aloc
  | MethodScope of string * Loc.aloc * string (* classname * methodname *)

let collect ss =
  let constant_tbl = Hashtbl.create 49 in 
  let instance_var_tbl = Hashtbl.create 49 in 

  (* Hashtbl with keys of type "scope" *)
  let var_tbl = Hashtbl.create 49 in 
  let add_var scope x = 
    let xs = Hashtbl.find var_tbl scope in
    Hashtbl.replace var_tbl scope (StringSet.add x xs) in

  (* Hashtbl with keys of type "scope" *)
  let static_var_tbl = Hashtbl.create 49 in 
  let add_static_var scope x copt = 
    let svmap = Hashtbl.find static_var_tbl scope in
    let svmap = StringMap.add x copt svmap in
    Hashtbl.replace static_var_tbl scope svmap in

  (* Hashtbl with keys of type "scope" *)
  let scope_var_args_tbl = Hashtbl.create 49 in 

  let register_scope scope =
    Hashtbl.add var_tbl scope StringSet.empty;
    Hashtbl.add static_var_tbl scope StringMap.empty;
    Hashtbl.add scope_var_args_tbl scope false in

  let add_calling_convention tbl x fps va =
    let bs = List.map (fun (_,_,b) -> b) fps in
    let bss = try Hashtbl.find tbl x with _ -> [] in
    let bss = if List.mem (bs,va) bss then bss else (bs,va)::bss in
    Hashtbl.replace tbl x bss in

  let function_tbl = Hashtbl.create 49 in 
  let add_function name fps va = 
    add_calling_convention function_tbl name fps va in 

  let method_tbl = Hashtbl.create 49 in 
  let add_method name fps va = 
    add_calling_convention method_tbl name fps va in 

  let classmethod_tbl = Hashtbl.create 49 in 
  let add_classmethod cname mname fps va = 
    add_calling_convention classmethod_tbl (cname, mname) fps va in 

  let class_tbl = Hashtbl.create 49 in 
 
  let rec global_of scope stmt =

    let rec global_of_exp exp =
      match exp.exp_desc with 
	Lvalue lv -> global_of_lv lv
      | Null | Int _ | Float _ | String _ | Bool _ | Const _ -> ()
      | NewObj (_, es) -> global_of_exp_list es
      | UNewObj (e, es) -> (global_of_exp e; global_of_exp_list es)
      | NewArray ees -> global_of_expexp_list ees
      | Prim (p, es) -> global_of_exp_list es
      | App (s, es) -> 
	  (match s with
	    "func_get_args" | "func_get_arg" -> 
	      Hashtbl.replace scope_var_args_tbl scope true
	  | _ -> ());
	  global_of_exp_list es
      | AppVar (e, es) -> (global_of_exp e; global_of_exp_list es)
      | ClassMethod (cname, mname, es) -> global_of_exp_list es
      | UClassMethod (cname, e, es) -> (global_of_exp e; global_of_exp_list es)
      | Method (e, mname, es) -> (global_of_exp e; global_of_exp_list es)
      | UMethod (e1, e2, es) -> 
	  (global_of_exp e1;
	   global_of_exp e2;
	   global_of_exp_list es)
      | LAssign (lv, e) -> (global_of_lv lv; global_of_exp e)
      | LOpAssign (lv, p, e) -> (global_of_lv lv; global_of_exp e)
      | ListAssign (lvs, e) ->
	  (List.iter
	     (fun olv -> 
	       match olv with
		 None -> ()
	       | Some lv -> global_of_lv lv)  lvs;
	   global_of_exp e)
      | RefAssign (lv, Exp e) -> (global_of_lv lv; global_of_exp e)
      | RefAssign (lv1, Lv lv2) -> (global_of_lv lv1; global_of_lv lv2)
      | FileBlock (_, _, ss) -> global_of_stmt_list ss 
      | IncludeExp (once, exp, expanded_files, sss) -> 
	  List.iter (fun (_, ss) -> global_of_stmt_list ss) sss
      | StmtExp (ss, e) ->
	  (global_of_stmt_list ss; global_of_exp e)
      | Define (s, e) -> 
	  Hashtbl.replace constant_tbl s (); global_of_exp e
    and global_of_exp_list es = List.iter global_of_exp es
    and global_of_expexp_list ees =
      List.iter (fun (e1, e2) -> global_of_exp e1; global_of_exp e2) ees
    and global_of_lv lv =
      match lv.lvalue_desc with
	LVar "$GLOBALS" -> failwith "$GLOBALS as a variable"
      | LVar x -> add_var scope x
      | LVarVar e -> global_of_exp e
      | LArray1 lv -> global_of_lv lv
      | LArray2 (lv, e) -> 
	  (match lv.lvalue_desc with 
	    LVar "$GLOBALS" ->
	      (match e.exp_desc with
		String s -> add_var TopScope ("$"^s)
	      | _ -> global_of_exp e)
	  | _ -> (global_of_lv lv; global_of_exp e))
      | LObjRef (lv, s) -> 
	  (Hashtbl.replace instance_var_tbl ("$"^s) ();
	   global_of_lv lv) 
      | LUObjRef (lv, e) -> (global_of_lv lv; global_of_exp e)
      | LStringRef (lv, e) -> (global_of_lv lv; global_of_exp e)
    and global_of_stmt stmt =
      let aloc = stmt.stmt_loc.Loc.aloc in
      match stmt.stmt_desc with
	ExpSt e | Echo e | Return e -> global_of_exp e
      | Unset lv -> global_of_lv lv
      | BlockSt ss -> global_of_stmt_list ss
      | While (e,s) -> global_of_exp e; global_of_stmt s
      | DoWhile (s,e) -> global_of_exp e; global_of_stmt s
      | Foreach (e,optx,y,s) ->
	  global_of_exp e;
	  (match optx with
	    Some x -> add_var scope x
	  | None -> ());
	  add_var scope y;
	  global_of_stmt s
      | For (e1, e2, e3, s) ->
	  global_of_exp_list e1;
	  global_of_exp_list e2;
	  global_of_exp_list e3;
	  global_of_stmt s
      | If (e, s1, s2) ->
	  global_of_exp e;
	  global_of_stmt s1;
	  global_of_stmt s2
      | Switch (e, css) ->
	  global_of_exp e;
	  List.iter (fun (eopt,ss) ->
	    (match eopt with
	      Some e -> global_of_exp e 
	    | None -> ());
	    global_of_stmt_list ss)
	    css
      | Assert (e, _) -> global_of_exp e
      | Function (s, fps, stmt, _) ->
	  let newscope = FunctionScope (s,aloc) in
	  let () = register_scope newscope in
	  let () = global_of newscope stmt in
	  let va = Hashtbl.find scope_var_args_tbl newscope in
	  add_function s fps va
      | Break _ | Continue _ | Skip -> ()
      | Static xcs ->
	  List.iter 
	    (fun (x, copt) -> add_static_var scope x copt) xcs
      | Global ys -> List.iter (fun y -> add_var TopScope y) ys
      | Class (cname,_,ys,ms) -> 
	  let global_of_method (mname, fps, stmt,_) = 
	    let newscope = MethodScope (cname,aloc,mname) in
	    let () = register_scope newscope in
	    let () = global_of newscope stmt in
	    let va = Hashtbl.find scope_var_args_tbl newscope in
	    Hashtbl.add class_tbl cname ();
	    add_method mname fps va;
	    add_classmethod cname mname fps va in
	  List.iter global_of_method ms
    and global_of_stmt_list ss = List.iter global_of_stmt ss in
    global_of_stmt stmt in

  let () = register_scope TopScope in 
  let () = global_of TopScope (mkstmt (BlockSt ss)) in
  let all_constants = 
    Hashtbl.fold (fun s _ env  -> StringSet.add s env) 
      constant_tbl StringSet.empty in
  let all_ivars = 
    Hashtbl.fold (fun s _ env  -> StringSet.add s env) 
      instance_var_tbl StringSet.empty in
  let gvars = Hashtbl.find var_tbl TopScope in
  let all_classes = 
    Hashtbl.fold (fun s _ cs  -> StringSet.add s cs) 
      class_tbl StringSet.empty in

  all_constants, all_ivars, gvars, var_tbl, static_var_tbl,
  function_tbl, method_tbl, classmethod_tbl, scope_var_args_tbl,
  all_classes

let nontrivial_prim p = 
  match p with
    Andand | Oror | Xor | Pif -> true
  | _ -> false 

(* pos : false if it is not an expression that is evaluated first *)

let rec nontrivial pos exp =
  match exp.exp_desc with
    Lvalue lv -> nontrivial_lv pos lv
  | Null | Const _ | Int _ | Float _ | Bool _ | String _ -> false
  | NewArray ees -> 
      List.exists 
	(fun (e1, e2) -> nontrivial true e1 || nontrivial true e2) ees
  | RefAssign (lv1, Lv lv2) -> pos || nontrivial_lv true lv1 || nontrivial_lv pos lv2
  | RefAssign (lv, Exp exp) -> pos || nontrivial_lv true lv || nontrivial pos exp
  | ListAssign (lvs, exp) ->  pos || nontrivial pos exp
  | LAssign (lv, exp) | LOpAssign (lv, _, exp) -> 
      pos || nontrivial_lv pos lv || nontrivial true exp 
  | Prim (p, es) -> (pos &&  nontrivial_prim p) || nontrivial_list es
  | ClassMethod (cname, mname, es) -> pos || nontrivial_list es
  | UClassMethod (cname, e, es) -> 
      pos || nontrivial true e || nontrivial_list es
  | Method (e, mname, es) -> pos || nontrivial true e || nontrivial_list es
  | UMethod (e1, e2, es) -> 
      pos || nontrivial true e1 || nontrivial true e2 || nontrivial_list es
  | NewObj (classname, es) -> pos || nontrivial_list es
  | UNewObj (e, es) -> pos || nontrivial true e || nontrivial_list es
  | App (s,es) -> pos || nontrivial_list es
  | AppVar (e,es) -> pos || nontrivial true e || nontrivial_list es
  | IncludeExp _ | FileBlock _ | StmtExp _ -> true
  | Define (_, e) -> nontrivial pos e 
and nontrivial_list es = List.exists (fun e -> nontrivial true e) es 
and nontrivial_lv pos lv =
  match lv.lvalue_desc with
    LVar _ -> false
  | LVarVar e -> pos
  | LArray1 lv -> nontrivial_lv pos lv 
  | LArray2 (lv, e) -> nontrivial_lv pos lv || nontrivial true e
  | LObjRef (lv, s) -> nontrivial_lv pos lv
  | LUObjRef (lv, e) -> nontrivial_lv pos lv || nontrivial true e
  | LStringRef (lv, e) -> nontrivial_lv pos lv || nontrivial true e

