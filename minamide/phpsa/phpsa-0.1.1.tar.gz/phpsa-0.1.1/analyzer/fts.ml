(*
 * PHP string analyzer
 * Copyright (C) 2006 Yasuhiko Minamide
 *)
open Support
open Flbasics
open Basic
open Ft

(* there must exist exactly one final state in ft1
   no out-going arrow from the final state of ft1 *)
let simple_join ft1 ft2 =
  let s2' = Q_set.choose ft1.Ft.final in
  let () = if not (Q_set.is_empty (Q_set.remove s2' ft1.Ft.final)) then failwith "simple_join" in
  let arrow =
    Arrow.fold (fun q1 c q2 cs arrow ->
      let q1 = if q1 = ft2.Ft.start then s2' else q1 in
      let q2 = if q2 = ft2.Ft.start then s2' else q2 in
      Arrow.add q1 c q2 cs arrow) ft2.Ft.arrow ft1.Ft.arrow in
  Ft.create (Q_set.union ft1.Ft.states (Q_set.remove ft2.Ft.start ft2.Ft.states)) arrow ft1.Ft.start ft2.Ft.final

let create_ft_cs cset transition x xs =
  let tbl = Hashtbl.create 100 in
  let current_id = ref 0 in
  let fresh_id () = 
    let id = !current_id in 
    current_id := id+1; 
    id in
    
  let rec dfs x arrow =
    Charset.Charset.fold 
      (fun c arrow -> 
	List.fold_right (fun (y, cs) arrow ->
	  let i = Hashtbl.find tbl x in
	  try 
	    let j = Hashtbl.find tbl y in
	    Arrow.add i c j cs arrow 
	  with Not_found -> 
	    let j = fresh_id () in
	    let () = Hashtbl.add tbl y j in
	    let arrow = Arrow.add i c j cs arrow in 
	    dfs y arrow) (transition x c) arrow) 
      cset arrow in
  let () =  Hashtbl.add tbl x (fresh_id ()) in
  let arrow = dfs x Ft.ArrowMap.empty in

  let rec loop n qs = 
    if n < !current_id then loop (n+1) (Q_set.add n qs) else qs in
  Ft.create
    (loop 0 Q_set.empty) arrow (Hashtbl.find tbl x)
    (List.fold_right (fun y fs -> 
      try Q_set.add (Hashtbl.find tbl y) fs with Not_found -> fs)
       xs Q_set.empty) 

let create_ft transition x xs = create_ft_cs Charset.charset transition x xs
let create_ft_full transition x xs = create_ft_cs Charset.fullcharset transition x xs

let fa2ft_id fa =
  let arrow = 
    Fa.Arrow.fold (fun q c q' arrow ->
      Arrow.add q c q' [Cfg.Terminal c] arrow) fa.Fa.arrow
      ArrowMap.empty in
  Ft.create fa.Fa.states arrow fa.Fa.start fa.Fa.final

let fa2ft_empty fa =
  let arrow = 
    Fa.Arrow.fold (fun q c q' arrow ->
      Arrow.add q c q' [] arrow) fa.Fa.arrow
      ArrowMap.empty in
  Ft.create fa.Fa.states arrow fa.Fa.start fa.Fa.final

let mark_char = Charset.metachar0

let add_endmark cfg =
  let s' = fresh_var () in
  Cfg.create3 (Cfg.Variable_set.add s' (Cfg.vars_of cfg))
    (Cfg.prod_add  (s',  [Cfg.Variable cfg.Cfg.start; 
			  Cfg.Terminal mark_char]) cfg.Cfg.prod) s'

let cs2ss cs = List.map (fun c -> Cfg.Terminal c) cs
let str2ss str = cs2ss (explode str)

module Fa_ft = Fa_orig.Make(
  struct
    type symbol = char * Cfg.symbol list
    let string_of (chr,cs) = Char.escaped chr ^
      (String.concat ""
	 (List.map Cfg.string_of_symbol cs))
    let pp_print fmt (chr,cs) = 
      (Format.fprintf fmt "%c/%a" chr (Basic.print_list "" Cfg.pp_sym) cs)
    let compare = compare 
    module Symbol_set = 
      Set.Make(struct 
	type t = symbol
	let compare = compare end)
  end)

module Minimize_ft = Minimize_orig.Make(Fa_ft)

let minimize_states_ft ft =
  let fa_arrow = Arrow.fold (fun q c q' cs making ->
    Fa_ft.ArrowMap.add (q,(c,cs)) (Q_set.singleton q') making) ft.arrow Fa_ft.ArrowMap.empty in
  let ss = 
    Fa_ft.Arrow.fold (fun _ c _ ss -> Fa_ft.Symbol_set.add c ss) fa_arrow Fa_ft.Symbol_set.empty in
  let fa = {Fa_ft.symbols = ss; 
	    Fa_ft.states = ft.Ft.states; 
	    Fa_ft.arrow = fa_arrow; 
	    Fa_ft.start = ft.Ft.start; 
	    Fa_ft.final = ft.Ft.final} in
  let fa = Minimize_ft.minimize fa in
  let arrow = Fa_ft.ArrowMap.fold (fun (q,(c,cs)) qs making ->
    Q_set.fold (fun q' making ->
      Arrow.add q c q' cs making) qs making) fa.Fa_ft.arrow
      ArrowMap.empty in 
  Ft.create fa.Fa_ft.states arrow fa.Fa_ft.start fa.Fa_ft.final

let minimize_ft ft =
  let ft = Ft.quasi_determinize ft in
  minimize_states_ft ft

let clist2cset cl = 
  List.fold_left (fun s c ->
    Charset.Charset.add c s) Charset.Charset.empty cl

let sp = clist2cset [' '; '\t'; '\n'; '\r'; '\x0B']

let uc_alpha = Charset.Charset.filter 
    (fun c -> c >= 'A' && c <= 'Z') Charset.charset

let lc_alpha = Charset.Charset.filter 
    (fun c -> c >= 'a' && c <= 'z') Charset.charset

(* trim *)
let trim_ft sp =   
  let transition s c =
    match s with
      0 when Charset.Charset.mem c sp -> [(0, [])]
    | 0  -> [(1,[Cfg.Terminal c])]
    | 1 when Charset.Charset.mem c sp -> [(2,[Cfg.Terminal c]); (3, [])]
    | 1 -> [(1,[Cfg.Terminal c])]
    | 2 when Charset.Charset.mem c sp -> [(2, [Cfg.Terminal c])]
    | 2 -> [(1, [Cfg.Terminal c])]
    | 3 when Charset.Charset.mem c sp -> [(3, [])]
    | _ -> [] in
  create_ft transition 0 [0; 1; 3]

let ltrim_ft sp =   
  let transition s c =
    match s with
      false when Charset.Charset.mem c sp -> [(false, [])]
    | _ -> [(true, [Cfg.Terminal c])] in
  create_ft transition false [false; true]

let rtrim_ft sp =   
  let transition s c =
    match s with
      0 when Charset.Charset.mem c sp -> [(1,[Cfg.Terminal c]); (2, [])]
    | 0  -> [(0,[Cfg.Terminal c])]
    | 1 when Charset.Charset.mem c sp -> [(1,[Cfg.Terminal c])]
    | 1 -> [(0,[Cfg.Terminal c])]
    | 2 when Charset.Charset.mem c sp -> [(2, [])]
    | _ -> [] in
  create_ft transition 0 [0; 2]


(* ucfirst *)
let ucfirst_ft =   
  let transition s c =
    match s with
      true -> [(false,[Cfg.Terminal (Char.uppercase c)])]
    | false -> [(false,[Cfg.Terminal c])] in
  create_ft transition true [true; false]

(* ucword *)
let ucword_ft =   
  let transition s c =
    match s with
      true when Charset.Charset.mem c sp -> [(true,[Cfg.Terminal c])]
    | true -> [(false,[Cfg.Terminal (Char.uppercase c)])]
    | false when Charset.Charset.mem c sp -> [(true,[Cfg.Terminal c])]
    | false -> [(false,[Cfg.Terminal c])] in
  create_ft transition true [true; false]
  
let prefix xs =
  List.fold_right 
    (fun x yss -> []::(List.map (fun ys -> x::ys) yss)) xs [[]]

(*  is_prefix xs ys = ? zs. xs = ys@zs *)
let rec is_prefix xs ys =
  match (xs, ys) with
    (_, []) -> true
  | ([], _) -> false
  | (x::xs, y::ys) -> x = y && is_prefix xs ys 

(* find_prefix [] xs = (xs1, xs2) where xs = xs1@xs2 /\ is_prefix cs xs2 *)
let find_prefix cs zs =
  let rec find_prefix ys zs = 
    if is_prefix cs zs then (List.rev ys, zs) 
    else find_prefix (List.hd zs::ys) (List.tl zs) in
  find_prefix [] zs 

let string_ft cs ss =
  let transition xs c =
    match xs with
      None -> []
    | Some xs ->
	let xs' = xs@[c] in
	if xs' = cs then [(Some [], ss)] 
	else
	  let ys,zs = find_prefix cs xs' in
	  [(Some zs, cs2ss ys);
	   (None, cs2ss xs')] in
  create_ft transition (Some []) [Some []; None]

let rec is_prefix_case case_sensitive xs ys =
  match (xs, ys) with
    (_, []) -> true
  | ([], _) -> false
  | (x::xs, y::ys) -> 
      let y = if case_sensitive then y else Char.lowercase y in
      x = y && is_prefix_case case_sensitive xs ys 

let find_prefix_case case_sensitive cs zs =
  let rec loop ys zs = 
    if is_prefix_case case_sensitive cs zs then (List.rev ys, zs) 
    else loop (List.hd zs::ys) (List.tl zs) in
  loop [] zs 

(* case sensitive for mode = true,
   case insensitive for mode = false *)

let strstr_ft mode cs = 
  let cs = if mode then cs else List.map Char.lowercase cs in
  let transition xs c =
    match xs with
      None -> [(None, [Cfg.Terminal c])]
    | Some xs ->
	let xs' = xs@[c] in
	let xs'' = if mode then xs' else List.map Char.lowercase xs' in
	if xs'' = cs then [(None, cs2ss xs')]
	else
	  let ys,zs = find_prefix_case mode cs xs' in
	  [(Some zs, [])] in
  create_ft transition (Some []) [Some []; None]

type explode_state =
    Explode_A 
  | Explode_state of Cfg.terminal list
  | Explode_B 

(* fa(xs) = { zs | xs = ys@cs@zs } \/ { xs } *) 

let explode_ft1 cs =
  let transition xs c =
    match xs with
      Explode_B -> [(Explode_B, [Cfg.Terminal c])]
    | Explode_A -> 
	[(Explode_B, [Cfg.Terminal c])]@
	let xs' = [c] in
	if xs' = cs then 
	  [(Explode_B, []); (Explode_state [],[])] 
	else
	  let ys,zs = find_prefix cs xs' in
	  [(Explode_state zs, [])]
    | Explode_state xs ->
	let xs' = xs@[c] in
	if xs' = cs then 
	  [(Explode_B, []); (Explode_state [],[])] 
	else
	  let ys,zs = find_prefix cs xs' in
	  [(Explode_state zs, [])] in
  create_ft transition Explode_A [Explode_A; Explode_B]

(* fa(xs@cs@ys) = xs 
   fa(xs)    =  xs 
   wehre for all ys. xs != ys@cs *)

let explode_ft2 cs =
  let transition xs c =
    match xs with
      Explode_A -> [(Explode_A, [])]
    | Explode_B -> []
    | Explode_state xs ->
	let xs' = xs@[c] in
	if xs' = cs then 
	  [(Explode_A, [])]
	else
	  let ys,zs = find_prefix cs xs' in
	  [(Explode_state zs, cs2ss ys);
	   (Explode_B, cs2ss xs')] in
  create_ft transition (Explode_state []) [Explode_state [];Explode_A; Explode_B]

let strings_ft' css =
  let css = List.map (fun (xs,ys) -> (explode xs, ys)) css in
  let dtree = List.fold_left (fun dtree (cs, _) ->  Dtree.add cs dtree) Dtree.empty css in
  let rec find_prefix ys zs = 
    if Dtree.is_prefix dtree zs 
    then (List.rev ys, zs) 
    else find_prefix (List.hd zs::ys) (List.tl zs) in
  let transition xs c =
    match xs with
      None -> []
    | Some xs ->
	let xs' = xs@[c] in
	try 
	  let ss = List.assoc xs' css in [(Some [], ss)] 
	with Not_found ->
        let ys,zs = find_prefix [] xs' in 
   [(Some zs, cs2ss ys);  (None, cs2ss xs')] in
  create_ft transition (Some []) [Some []; None]

let strings_ft_endmark' css =
  let css = List.map (fun (xs,ys) -> (explode xs, ys)) css in
  let rec find_prefix ys zs = 
    if List.exists (fun (cs,_) -> is_prefix cs zs) css 
    then (List.rev ys, zs) 
    else find_prefix (List.hd zs::ys) (List.tl zs) in

  let transition xs c =
      match xs with
	None -> []
    | Some xs ->
	if c = mark_char 
	then 
	  [(None, cs2ss xs)] 
	else
	  let xs' = xs@[c] in
	  try 
	    let ss = List.assoc xs' css in [(Some [], ss)] 
	  with Not_found ->
	    let ys,zs = find_prefix [] xs' in
	    [(Some zs, cs2ss ys)] in
  create_ft_full transition (Some []) [None]

let strings_ft css =
  strings_ft' 
    (List.map (fun (xs,ys) -> (xs, str2ss ys)) css)

let strings_ft_endmark css =
  strings_ft_endmark' 
    (List.map (fun (xs,ys) -> (xs, str2ss ys)) css)

let skip_ft optn =
  match optn with
    Some n ->
      let rec loop i (q, arrow) = 
	if i < n then 
	  loop (i+1)
	    (Q_set.add (i+1) q,
	     Charset.Charset.fold 
	       (fun c arrow -> Arrow.add i c (i+1) [] arrow) Charset.charset arrow)
	else (q, arrow) in
      let q, arrow = loop 0 (Q_set.singleton 0, Ft.ArrowMap.empty) in
      (q, arrow, n)
  | None ->
      let arrow = Charset.Charset.fold 
	  (fun c arrow -> Arrow.add 0 c  0 [] arrow) Charset.charset 
	  Ft.ArrowMap.empty in
      let q = Q_set.singleton 0 in
      (q, arrow, 0)

(*  
 *  pre_ft : (qs, arrow, f)
 *  the initial state must be 0
 *  the set of states qs must be {0, 1, ..., f } 
 *)
let append_id_ft (qs, arrow, f) =
  let arrow = Charset.Charset.fold 
	  (fun c arrow -> 
	    Arrow.add f c  (f+1) [Cfg.Terminal c] arrow) Charset.charset arrow in
  let arrow = Charset.Charset.fold 
	  (fun c arrow -> 
	    Arrow.add (f+1) c  (f+1) [Cfg.Terminal c] arrow) Charset.charset arrow in
  let qs = Q_set.add (f + 1) qs in
  Ft.create qs arrow 0 qs

let append_cut_ft optn (qs, arrow, f) =
  match optn with
    None ->
      let arrow = Charset.Charset.fold 
	  (fun c arrow -> 
	    Arrow.add f c  (f+1) [Cfg.Terminal c] arrow) Charset.charset arrow in
      let arrow = Charset.Charset.fold 
	  (fun c arrow -> 
	    Arrow.add f c  (f+2) [] arrow) Charset.charset arrow in
      let arrow = Charset.Charset.fold 
	  (fun c arrow -> 
	    Arrow.add (f+1) c  (f+1) [Cfg.Terminal c] arrow) Charset.charset arrow in
      let arrow = Charset.Charset.fold 
	  (fun c arrow -> 
	    Arrow.add (f+1) c  (f+2) [] arrow) Charset.charset arrow in
      let arrow = Charset.Charset.fold 
	  (fun c arrow -> 
	    Arrow.add (f+2) c  (f+2) [] arrow) Charset.charset arrow in
      let qs = Q_set.add (f+1) qs in
      let qs = Q_set.add (f+2) qs in
      Ft.create qs arrow 0 qs
  | Some n ->
      let rec loop i (q, arrow) = 
	if i <= n then 
	  loop (i+1)
	    (Q_set.add (f+i) q,
	     Charset.Charset.fold 
	       (fun c arrow -> Arrow.add (f+i-1) c (f+i) [Cfg.Terminal c] arrow) Charset.fullcharset arrow)
	else (q, arrow) in
      let qs, arrow = loop 1 (qs, arrow) in
      let arrow = Charset.Charset.fold 
	  (fun c arrow -> 
	    Arrow.add (f+n) c  (f+n) [] arrow) Charset.fullcharset arrow in
      Ft.create qs arrow 0 qs

let prefix_ft =
  let transition state c =
   match state with
   true -> [(true,[Cfg.Terminal c]); (false,[])]
   | false -> [(false,[])] in
  create_ft transition true [true;false]

let strip_tags_ft =
  let arrow = Ft.ArrowMap.empty in
  let arrow = Arrow.add 0 '<' 1 [] arrow in
  let arrow = Arrow.add 1 ' ' 0 [Cfg.Terminal '<';Cfg.Terminal ' '] arrow in
  let arrow = Arrow.add 1 '>' 0 [] arrow in
  let arrow = Arrow.add 2 '>' 0 [] arrow in
  let arrow = Charset.Charset.fold 
      (fun c arrow -> Arrow.add 0 c 0 [Cfg.Terminal c] arrow) 
      (Charset.Charset.remove '<' Charset.fullcharset) 
      arrow in
  let arrow = Charset.Charset.fold 
      (fun c arrow -> Arrow.add 1 c 2 [] arrow) 
      (Charset.Charset.remove '>' (Charset.Charset.remove ' ' Charset.fullcharset)) arrow in
  let arrow = Charset.Charset.fold 
      (fun c arrow -> Arrow.add 2 c 2 [] arrow) Charset.fullcharset arrow in
  let q = Q_set.add 2 (Q_set.add 1 (Q_set.singleton 0)) in
  Ft.create q arrow 0 q



let pad_ft padchar len =
  let rec pad n = 
    match n with
      0 -> []
    | n -> Cfg.Terminal padchar :: pad (n - 1) in
  let rec spine n (qs, arrow) = 
    if n < len then 
      let arrow = Fa.Symbol_set.fold (fun c arrow -> 
	Arrow.add n c (n+1) [Cfg.Terminal c] arrow)
	  Charset.fullcharset arrow in
      let arrow = Arrow.add n mark_char (len+1) (pad (len-n)) arrow in
      spine (n+1) (Q_set.add (n+1) qs, arrow) 
    else 
      let arrow = Fa.Symbol_set.fold (fun c arrow -> 
	  Arrow.add n c n [Cfg.Terminal c] arrow)
	  Charset.fullcharset arrow in
      let arrow = Arrow.add n mark_char (len+1) [] arrow in
      (qs, arrow) in
  let qs, arrow = spine 0 (Q_set.singleton 0, Ft.ArrowMap.empty) in
  Ft.create (Q_set.add (len+1) qs)  arrow 0 (Q_set.singleton (len+1))


let base64array =
(*    0    1    2    3    4    5    6    7    8    9   *)
  [| 'A'; 'B'; 'C'; 'D'; 'E'; 'F'; 'G'; 'H'; 'I'; 'J';
     'K'; 'L'; 'M'; 'N'; 'O'; 'P'; 'Q'; 'R'; 'S'; 'T';
     'U'; 'V'; 'W'; 'X'; 'Y'; 'Z'; 'a'; 'b'; 'c'; 'd';
     'e'; 'f'; 'g'; 'h'; 'i'; 'j'; 'k'; 'l'; 'm'; 'n';
     'o'; 'p'; 'q'; 'r'; 's'; 't'; 'u'; 'v'; 'w'; 'x';
     'y'; 'z'; '0'; '1'; '2'; '3'; '4'; '5'; '6'; '7';
     '8'; '9'; '+'; '/' |] 

(* Assume end mark *)

let base64encode_ft =
   let transition (n, m) c =
   match n with
   0 -> 
   if c = mark_char then [((0,0),[])] else
   let code = Char.code c in
   let x = code lsr 2 in
   let y = code mod 4 in
   [((1,y), (cs2ss [base64array.(x)]))]
   | 1 -> 
   if c = mark_char then [((0,0),(cs2ss [base64array.(m * 16); '='; '=']))]
   else
   let code = Char.code c in
   let x = code lsr 4 in
   let y = code mod 16 in
   [((2,y), (cs2ss [base64array.(m * 16 + x)]))]
   | 2 -> 
   if c = mark_char then 
   [((0,0),(cs2ss [base64array.(m * 4); '=']))]
   else
   let code = Char.code c in
   let x = code lsr 6 in
   let y = code mod 64 in
   [((0,0), (cs2ss [base64array.(m * 4 + x); base64array.(y)])) ]
   | _ -> failwith "base64encode" in
   create_ft_full transition (0,0) [(0,0)] 

let base64decode_char c =
   if c >= 'A' && c <= 'Z' then Some (Char.code c - Char.code 'A')
   else if c >= 'a' && c <= 'z' then Some ((Char.code c - Char.code 'a') + 26)
   else if c >= '0' && c <= '9' then Some ((Char.code c - Char.code '0') + 52)
   else if c = '+' then Some 62
   else if c = '/' then Some 63 else None

(*  
    87 states: 
    (0,0), (1,0), ..., (1,63), (2,0), ..., (2, 15), 
    (3,0), ..., (3,3), (4,0), (5,0) 
*)

let base64dencode_ft =
   let transition (n, m) c =
     if c = '=' then [((4,0),[])]
     else
       match base64decode_char c with
	 None -> []
       | Some z ->
	   match n with
	     0 -> [((1,z), [])]
	   | 1 -> 
	       let x = z lsr 4 in
	       let y = z mod 16 in
	       [((2,y), cs2ss [Char.chr (m * 4 + x)])]
	   | 2 -> 
	       let x = z lsr 2 in
	       let y = z mod 4 in
	       [((3,y),cs2ss [Char.chr (m * 16 + x)])]
	   | 3 -> 
	       [((0,0), cs2ss [Char.chr (m * 64 + z)])]
	   | 4 -> [((4,0),[])]
	   | _ -> failwith "base64dencode" in
   create_ft transition (0,0) [(0,0);(4,0)] 

let is_hexadecimal c =
   (c >= 'A' && c <= 'F') || (c >= 'a' && c <= 'f') || (c >= '0' && c <= '9')

let hexdecode_char c =
   if c >= 'A' && c <= 'F' then Char.code c - Char.code 'A' + 10
   else if c >= 'a' && c <= 'f' then Char.code c - Char.code 'a' + 10
   else if c >= '0' && c <= '9' then Char.code c - Char.code '0'
   else failwith "hexdecode"

(* 
   initial state: None
   state after c: Some c
   Dead state   : Some '*' 
*)

let rawurldecode_ft =
   let transition n c =
   match n with
     None -> if c = '%' then [(Some '%',[]); (Some '*', cs2ss [c])] 
     else [(None, cs2ss [c])] 
   | Some '%' -> 
       if is_hexadecimal c then [(Some c, []); (Some '*', cs2ss ['%';c])]
       else [(None, cs2ss ['%'; c])]
   | Some '*' -> []
   | Some c' -> 
       if is_hexadecimal c then 
	  [(None, cs2ss [Char.chr (hexdecode_char c' * 16 + hexdecode_char c)])]
       else [(None, cs2ss ['%'; c'; c])] in
   create_ft transition None [None; Some '*'] 

(* 
   initial state: None
   state after c: Some c
   Dead state   : Some '*' 
*)

let urldecode_ft =
   let transition n c =
   match n with
     None -> 
       if c = '%' then [(Some '%',[]); (Some '*', cs2ss [c])] 
       else if c = '+' then [(None,cs2ss [' '])]
       else [(None, cs2ss [c])] 
   | Some '%' -> 
       if is_hexadecimal c then [(Some c, []); (Some '*', cs2ss ['%';c])]
       else if c = '+' then [(None, cs2ss ['%'; ' '])]
       else [(None, cs2ss ['%'; c])]
   | Some '*' -> []
   | Some c' -> 
       if is_hexadecimal c then [(None, cs2ss [Char.chr (hexdecode_char c' * 16 + hexdecode_char c)])]
       else if c = '+' then [(None, cs2ss ['%'; c'; ' '])]
       else [(None, cs2ss ['%'; c'; c])] in
   create_ft transition None [None; Some '*'] 

let str_pad_ft padchars len =
  let rec pad' cs n = 
    match (n,cs) with
      (0,_) -> []
    | (n,[]) -> pad' padchars n
    | (n,c::cs) -> Cfg.Terminal c :: pad' cs (n - 1) in
  let pad n = pad' padchars n in
  let transition n c =
   if c = mark_char then [(len, pad (len-n))] else 
   let n = if n < len then n+1 else n in
   [(n, [Cfg.Terminal c])] in
   create_ft_full transition 0 [len] 

let chunk_split_ft len cs =
  let transition n c =
    if n < len then [(n+1, cs2ss [c])] 
    else [(1, cs2ss (c::cs))] in
  let ft = create_ft transition 1 [] in
  Ft.create ft.Ft.states ft.Ft.arrow ft.Ft.start ft.Ft.states 

(* substr_replace *)

let nth_mark_ft len meta_c =
  let transition n c =
    if c = Reg.start_metachar then [(n,cs2ss [Reg.start_metachar])]
    else if n < len then [(n+1, cs2ss [c])] 
    else if n = len then [(len+1, cs2ss [meta_c; c])] 
    else [(len+1, cs2ss [c])] in
  create_ft_full transition 0 [len+1] 

let allcs_metachars = 
  let cs = Charset.Charset.add Reg.start_metachar Charset.fullcharset in
  Charset.Charset.add Reg.end_metachar cs

let substr_replace_ft x =
  let transition n c =
    match (n,c) with
      (0,c) when c = Reg.start_metachar -> [(1, [x])]
    | (0,c) when c = mark_char -> []
    | (0,_) -> [(0,cs2ss [c])] 
    | (1,c) when c = Reg.end_metachar -> [(2,[])]
    | (1,_) -> [(1,[])] 
    | (2,c) when c = mark_char -> [(2,[])] 
    | (2,_) -> [(2,cs2ss [c])] 
    | _ -> failwith "substr_replace_ft" in
  create_ft_full transition 0 [1;2]
  

let substr_replace x n optm cfg =
  let nth_mark cfg len c =
    let fa = 
      if len >= 0 then nth_mark_ft len c else Ft.rev (nth_mark_ft (-len+1) c) in 
    Ft_cfg.inter fa cfg in
  let cfg = add_endmark cfg in
  let cfg = nth_mark cfg n Reg.start_metachar in 
  let cfg = 
    match optm with
      None -> cfg
    | Some m -> 
	if n < 0 && n+m >= 0 then cfg 
	else
	  let m = if m > 0 then n + m else m in
	  nth_mark cfg m Reg.end_metachar in
  Ft_cfg.inter (substr_replace_ft x) cfg 

(* str_split *)

let str_split_ft len =
  let transition (b,n) c =
    match (b, n) with
      (false, 1) -> 
	let n' = if len = 1 then 1 else 2 in
	[((true, 1), cs2ss [c]); ((false, n'),[])]
    | (false, n) when n < len -> [((false, n+1),[])]
    | (false, n) when n = len -> [((false, 1),[])]
    | (true, n) when n < len -> [((true, n+1), cs2ss [c])]
    | (true, n) when n = len -> [((true, n), [])] 
    | _ -> failwith ("str_split"^(string_of_int n)^(string_of_int len)) in
  let fs = 
    let rec loop n =
      if n > 0 then (true,n)::loop (n-1) else [] in
    loop len in
  create_ft transition (false,1) fs

let str_split_approx_ft =
  let transition n c =
    match n with
      0 -> [(0,[]); (1, cs2ss [c])]
    | 1 -> [(1, cs2ss [c]); (2,[])]
    | 2 -> [(2,[])] 
    | _ -> failwith "str_split_approx_ft" in
  create_ft transition 0 [1;2]

  
let strrchr_ft needle =
  let transition n c =
    match n with
    true -> if c = needle then [(false, cs2ss [c])] else [(true, cs2ss [c])] 
  | false -> [(false, [])] in
  Ft.rev (create_ft transition true [true; false])

(* wordwrap *)

(* 
   m : distance from the newline before the last new line 
   n : distance from the last newline 
   b : true if space has been encountered
*)
let is_newline c = c = '\n' || c = '\r'

let wordwrap_ft len break mode =
  let inc m = if m <= len then m+1 else len+1 in
  let start = if mode then 0 else 1 in
  let transition (m, n, b) c =
    match c with
      ' ' when m <= len  -> []
    | ' ' -> 
	if n < len then [((inc m, inc n, true),cs2ss[' ']); ((inc n, start, false), [break])] 
	else [((inc n, 0, false), [break])]
    | _ when is_newline c && m <= len  -> []
    | _ when is_newline c -> [((inc m, start, false), cs2ss [c])]
    | _ when c = mark_char && m <= len -> []
    | _ when c = mark_char && b && n > len -> []
    | _ when c = mark_char -> [((-1,-1, false),[])]
    | _ when b && n >= len -> []
    | _ when mode && n = len-1 -> [((inc n, 0, false), cs2ss ([c])@[break])] 
    | _ ->  [((inc m, inc n, b),cs2ss [c])] in
   create_ft_full transition (len,0,false) [(-1,-1, false)] 

let wordwrap_approx_ft break =
  let transition () c =
    match c with
      ' ' -> [((),cs2ss[c]); ((), [break])]
    | _ ->  [((),cs2ss[c])]  in
   create_ft transition () [()] 

let wordwrap_strict_approx_ft break =
  let transition s c =
   match (s, c) with
   (0, c) when c = mark_char ->  [(2, [])]
   | (0, c) ->  [(1, [Cfg.Terminal c])]
   | (1,' ') -> [(1,cs2ss[c]); (1, [break])]
   | (1, c) when c = mark_char ->  [(2,[])] 
   | (1, c) ->  [(1,cs2ss[c]); (1,break::cs2ss ([c]))]  
   | _ ->  [] in
   create_ft_full transition 0 [2] 


(* str_shuffle *)
  
let str_shuffle cfg =
   let ts = Cfg.terminals_of_prod cfg.Cfg.prod in
   let y = fresh_var () in
   let p = cfg_subst (cfg.Cfg.prod) (fun c -> Cfg.Variable y) in
   let p = Charset.Charset.fold (fun c p -> prod_add (y, [Cfg.Terminal c]) p) ts p in
   Cfg.create p cfg.Cfg.start


(* soundex *)

let soundex_array = 
   [| 
   0 (* A *); 1 (* B *) ; 2 (* C *); 3 (* D *); 0 (* E *); 
   2 (* F *); 2 (* G *) ; 0 (* H *); 0 (* I *); 2 (* J *); 
   2 (* K *); 4 (* L *) ; 5 (* M *); 5 (* N *); 0 (* O *); 
   1 (* P *); 2 (* Q *) ; 6 (* R *); 2 (* S *); 3 (* T *); 
   0 (* U *); 1 (* V *) ; 0 (* W *); 2 (* X *); 0 (* Y *); 
   2 (* z *)
   |]
   
let soundex1_ft =
   let transition n c =
   let code = soundex_array.(Char.code c - Char.code 'A') in
   if n = -1 then [(code, cs2ss [c])]
   else if code = n then [(n, [])]
   else if code = 0 then [(code,[])]
   else [(code, cs2ss [Char.chr (code + Char.code '0')])] in
   let ft = create_ft_cs uc_alpha transition (-1) [] in
   Ft.create ft.Ft.states ft.Ft.arrow ft.Ft.start ft.Ft.states 

let soundex2_ft =
   let transition n c =
   match (n,c) with
   (0,c) when c = mark_char -> [(5, [])]
   | (0,_) when c >= 'A' && c <= 'Z' -> [(1, cs2ss [c])]
   | (1,c) when c = mark_char -> [(5, cs2ss ['0';'0';'0'])]
   | (1,_) when c >= '1' && c <= '6' -> [(2, cs2ss [c])]
   | (2,c) when c = mark_char -> [(5, cs2ss ['0';'0'])]
   | (2,_) when c >= '1' && c <= '6' -> [(3, cs2ss [c])]
   | (3,c) when c = mark_char -> [(5, cs2ss ['0'])]
   | (3,_) when c >= '1' && c <= '6' -> [(4, cs2ss [c])]
   | (4,_) -> [(4, [])] 
   | _ -> [] in
   create_ft_full transition 0 [0;4;5] 

let soundex cfg =
   let cfg = Cfg.homo cfg
      (fun c -> 
	if c >= 'A' && c <= 'Z' then [c]
	else if c >= 'a' && c <= 'z' then [Char.uppercase c]
	else []) in
  let cfg = Ft_cfg.inter soundex1_ft cfg in
  let cfg = add_endmark cfg in
  Ft_cfg.inter soundex2_ft cfg

(* quoted_printable_decode *)

(* b : true at the end of line *)

let multiline_rtrim_ft =
  let transition b c =
    match (b,c) with
      (_,'\n') | (_,'\r') -> [(true, cs2ss [c])]
    | (true, ' ') | (true, '\t') -> [(true, [])]
    | (_, c) -> [(false, cs2ss [c])] in
  Ft.rev (create_ft transition true [true; false])

let remove_soft_linebreak_ft =
  let transition n c =
    match (n, c) with
      (0, '=') -> [(1, [])]
    | (0, c) -> [(0, cs2ss [c])]
    | (1, '\r') -> [(2, [])]
    | (1, '\n') -> [(0, [])]
    | (1, c) -> [(0, cs2ss ['='; c])]
    | (2, '\n') -> [(0, [])]
    | (2, c) -> [(0, cs2ss [c])] 
    | _ -> failwith "remove_soft_linebreak" in
  create_ft transition 0 [0;1;2]

let ishexadecimal c =
  (c >= '0' && c <= '9') || (c >= 'A' && c <= 'F') || (c >= 'a' && c <= 'f')

let hexadecimal_decode c =
  if (c >= '0' && c <= '9') then Char.code c - Char.code '0'
  else if (c >= 'A' && c <= 'F') then Char.code c - Char.code 'A' + 10
  else Char.code c - Char.code 'a' + 10

let isoctal c = c >= '0' && c <= '7'

let octal_decode c = Char.code c - Char.code '0'

(* This is made into a function to avoid long initial time *)

let quoted_printable_decode_ft =
  let hexchars = 
    ['0'; '1'; '2'; '3'; '4'; '5'; '6'; '7'; '8'; '9';
     'A'; 'B'; 'C'; 'D'; 'E'; 'F';
     'a'; 'b'; 'c'; 'd'; 'e'; 'f'] in
  let table = 
    List.fold_left (fun tbl c1 -> 
      List.fold_left (fun tbl c2 -> 
	(Support.implode ['='; c1; c2], 
	 String.make 1 
	   (Char.chr (hexadecimal_decode c1 * 16 + hexadecimal_decode c2)))::tbl) tbl hexchars)
	[] hexchars in
  strings_ft table

let quoted_printable_decode cfg =
  let cfg = Ft_cfg.inter multiline_rtrim_ft cfg in
  let cfg = Ft_cfg.inter remove_soft_linebreak_ft cfg in
  Ft_cfg.inter quoted_printable_decode_ft cfg 


(* addcslashes *)

let rec parse_addcslashes cs ts =
   match cs with
     [] -> ts
   | c1::'.'::'.'::c2::cs ->
       let n = Char.code c2 in
       let rec add_chars k ts = 
	 if k <= n then add_chars (k+1) (Charset.Charset.add (Char.chr k) ts)
	 else ts in
       parse_addcslashes cs (add_chars (Char.code c1) ts) 
   | c::cs -> parse_addcslashes cs (Charset.Charset.add c ts)

let escape_char c =
  match c with
    '\007' -> "\\a"
  | '\008' -> "\\b"
  | '\009' -> "\\t"
  | '\010' -> "\\n"
  | '\011' -> "\\v"
  | '\012' -> "\\f"
  | '\013' -> "\\r"
  | c -> 
      if c >= '\000' && c < '\032' then Printf.sprintf "\\%03o" (Char.code c)
      else Printf.sprintf "\\%c" c

(* stripclashes *)

type scriptclashes_states =
    Start | Backslash | Hexadecimal0 | Hexadecimal1 of int 
  | Octal1 of int | Octal2 of int * int | Stop


(* assume end mark *)

let stripcslashes_ft =
  let transition n c =
    match (n,c) with
      (Start,c) when c = '\\' -> [(Backslash, [])]
    | (Start,c) when c = mark_char -> [(Stop, [])]
    | (Start,_) -> [(Start, cs2ss [c])]
    | (Backslash,'x') -> [(Hexadecimal0, [])]
    | (Backslash,c) when isoctal c -> [(Octal1 (octal_decode c), [])]
    | (Backslash,'a') -> [(Start, cs2ss ['\007'])]
    | (Backslash,'b') -> [(Start, cs2ss ['\008'])]
    | (Backslash,'t') -> [(Start, cs2ss ['\009'])]
    | (Backslash,'n') -> [(Start, cs2ss ['\010'])]
    | (Backslash,'v') -> [(Start, cs2ss ['\011'])]
    | (Backslash,'f') -> [(Start, cs2ss ['\012'])]
    | (Backslash,'r') -> [(Start, cs2ss ['\013'])]
    | (Backslash,c) when c = mark_char  -> [(Stop, cs2ss ['\\'])]
    | (Backslash,c) -> [(Start, cs2ss [c])]
    | (Octal1 m, c) when isoctal c -> [(Octal2 (m, octal_decode c), [])]
    | (Octal1 m, c) when c = '\\' -> [(Backslash, cs2ss [Char.chr m])]
    | (Octal1 m, c) when c = mark_char -> [(Stop, cs2ss [Char.chr m])]
    | (Octal1 m, c) -> [(Start, cs2ss [Char.chr m; c])]
    | (Octal2 (m,n), c) when isoctal c -> 
	[(Start, cs2ss [Char.chr ((m * 64 + n * 8 + octal_decode c) mod 256)])]
    | (Octal2 (m,n), c) when c = '\\' -> 
	[(Backslash, cs2ss [Char.chr (m * 8+ n)])]
    | (Octal2 (m,n), c) when c = mark_char -> 
	[(Stop, cs2ss [Char.chr (m * 8+ n)])]
    | (Octal2 (m,n), c) -> 
	[(Start, cs2ss [Char.chr (m * 8+ n); c])]
    | (Hexadecimal0,c) when ishexadecimal c -> 
	[(Hexadecimal1 (hexadecimal_decode c), [])]
    | (Hexadecimal0,c) when c = '\\' -> [(Backslash, cs2ss ['x'])]
    | (Hexadecimal0,c) when c = mark_char -> [(Stop, cs2ss ['x'])]
    | (Hexadecimal0,c) -> [(Backslash, cs2ss ['x'; c])]
    | (Hexadecimal1 n, c) when ishexadecimal c -> 
	[(Start, cs2ss [Char.chr (n * 16 + (hexadecimal_decode c))])]
    | (Hexadecimal1 n, c) when c = '\\' -> [(Backslash, cs2ss [Char.chr n])]
    | (Hexadecimal1 n, c) when c = mark_char -> [(Stop, cs2ss [Char.chr n])]
    | (Hexadecimal1 n, c) -> [(Backslash, cs2ss [c])] 
    | (Stop, c) -> [] in
  create_ft_full transition Start [Stop]

(* strtok *)
let strtok_ft cs =
  let transition n c =
    match n with
      0 when List.mem c cs -> [(0, [])]
    | 0 -> [(1, cs2ss [c]); (3, [])]
    | 1 when List.mem c cs -> [(2, [])]
    | 1 -> [(1, cs2ss [c])]
    | 2 -> [(2,[])]
    | 3 when List.mem c cs -> [(0, [])]
    | 3 -> [(3, [])] 
    | _ -> failwith "strtok_ft" in
  create_ft transition 0 [0;1;2;3]

(* String Update *)

let first_char_ft =
  let transition s c =
    match s with
   true -> [(false,[Cfg.Terminal c])]
   | false -> [(false,[])] in
   create_ft transition true [true; false]

let string_update_ft x =
  let transition s c =
    match s with
   true -> [(true, [Cfg.Terminal c]); (false, [x])]
   | false -> [(false,[Cfg.Terminal c])] in
   create_ft transition true [true; false]

(*
 * program: $x = "xyz";
 *          $x{4} = "abc";
 * result:  $x = "xyz a"
 *)
let string_update cfg1 cfg2 =
  let {Cfg.prod = p; Cfg.start = x} = cfg1 in
  let {Cfg.prod = p2; Cfg.start = x2} = Ft_cfg.inter first_char_ft cfg2 in 
  let {Cfg.prod = p1; Cfg.start = x1} = Ft_cfg.inter (string_update_ft (Cfg.Variable x2)) cfg1 in 
  let p = Cfg.prod_union p1 (Cfg.prod_union p2 p) in
  let y = fresh_var () in
  let z = fresh_var () in
  let p = Cfg.prod_add (y, [Cfg.Variable x2]) p in
  let p = Cfg.prod_add (y, [Cfg.Terminal ' '; Cfg.Variable y]) p in
  let p = Cfg.prod_add (z, [Cfg.Variable x1]) p in
  let p = Cfg.prod_add (z, [Cfg.Variable x; Cfg.Variable y]) p in
  Cfg.create p z

let nl2br_ft =
   let br_ss = cs2ss (explode "<br />") in
   let transition n c =
   match (n, c) with
   (0, '\n') -> [(1, [])]
   | (0, '\r') -> [(2, [])]
   | (0, c) when c = mark_char -> [(3, [])]
   | (0, _) -> [(0, cs2ss [c])]
   | (1, '\r') -> [(0, br_ss@cs2ss ['\n';'\r'])]
   | (1, '\n') -> [(1, br_ss@cs2ss['\n'])]
   | (1, c) when c = mark_char -> [(3, br_ss@cs2ss['\n'])]
   | (1, _) -> [(0, br_ss @ cs2ss ['\n'] @ cs2ss [c])]
   | (2, '\n') -> [(0, br_ss@cs2ss ['\r';'\n'])]
   | (2, '\r') -> [(2, br_ss@cs2ss ['\r'])]
   | (2, c) when c = mark_char -> [(3, br_ss@cs2ss ['\r'])]
   | (2, _) -> [(0, br_ss @ cs2ss ['\r'] @ cs2ss [c])]
   | _ -> [] in
  create_ft_full transition 0 [3]


(*
 * marker for preg operations 
 * Not correct if epsilon in L(reg) 
 *)

let marker reg =
  let reg = Reg.rev reg in
  (* ($^.)*reg *)
  let reg = Reg.App (Reg.Star (Reg.Plus (Reg.Alpha Reg.end_metachar, 
					 (Reg.Plus (Reg.Alpha Reg.start_metachar, 
						    Reg.Allalpha)))), 
		     reg) in
  let fa = Fa.minimize (Reg2fa.reg2nfa Charset.fullcharset reg) in
  let ft = fa2ft_id fa in
  let () = if Q_set.mem ft.Ft.start ft.Ft.final then failwith "marker" in
  let arrow = Arrow.fold (fun q c q' cs arrow ->
    let cs = if Q_set.mem q' ft.Ft.final then cs@[Cfg.Terminal mark_char] else cs in
    Arrow.add q c q' cs arrow) ft.Ft.arrow ArrowMap.empty in
  Ft.rev { ft with Ft.arrow = arrow; Ft.final = ft.Ft.states}

(* preg_split *)

let split reg =
  let fa = Minimize.minimize (Fa.nfa2dfa (Reg2fa.reg2nfa Charset.fullcharset reg)) in
  let ft = fa2ft_id fa in
  let n = Q_set.max_elt ft.Ft.states + 1 in
  let arrow = Arrow.fold (fun q c q' cs arrow ->
    Arrow.add q c q' [] arrow) ft.Ft.arrow ArrowMap.empty in

  let arrow = Q_set.fold (fun q arrow ->
    Arrow.add q mark_char q [] arrow) ft.Ft.states arrow in

  let arrow = Q_set.fold (fun q arrow ->
    Charset.Charset.fold (fun c arrow ->
      if c = mark_char 
      then Arrow.add q c (n+1) [] arrow
      else Arrow.add q c n [Cfg.Terminal c] arrow)
      Charset.fullcharset arrow) ft.Ft.final arrow in

  let arrow =
    Charset.Charset.fold (fun c arrow ->
      if c = mark_char 
      then Arrow.add n c (n+1) [] arrow
      else Arrow.add n c n [Cfg.Terminal c] arrow)
      Charset.fullcharset arrow in

  let arrow =
    Charset.Charset.fold (fun c arrow ->
      Arrow.add (n+1) c (n+1) [] arrow)
      Charset.fullcharset arrow in

  let arrow =
    Charset.Charset.fold (fun c arrow ->
      let arrow = Arrow.add (n+2) c (n+2) [] arrow in
      if c = mark_char 
      then Arrow.add (n+2) c ft.Ft.start [] arrow
      else arrow)
      Charset.fullcharset arrow in

  let arrow =
    Charset.Charset.fold (fun c arrow ->
      if c = mark_char 
      then Arrow.add (n+3) c ft.Ft.start [] arrow
      else 
	let arrow = Arrow.add (n+3) c n [Cfg.Terminal c] arrow in
	Arrow.add (n+3) c (n+2) [] arrow)
      Charset.fullcharset arrow in
  let q' = Q_set.add n (Q_set.add (n+1) (Q_set.singleton (n+3))) in
  Ft.create (Q_set.add (n+2) (Q_set.union q' ft.Ft.states))
    arrow (n+3) (Q_set.union q' ft.Ft.final)


let preg_split cfg ss =
  let reg = Pregparser.parse_reg_charlist ss in
  let cfg = Ft_cfg.inter (marker reg) cfg in
  Ft_cfg.inter (split reg) cfg

(* nondeterminisitic replacement *)

let replace reg x =
  let fa = Reg2fa.reg2nfa Charset.fullcharset reg in
  let ft = fa2ft_id fa in
  let n = Q_set.max_elt ft.Ft.states + 1 in
  let arrow = Arrow.fold (fun q c q' cs arrow ->
    Arrow.add q c q' [] arrow) ft.Ft.arrow ArrowMap.empty in
  let arrow = Arrow.fold (fun q c q' cs arrow ->
    if Q_set.mem q' ft.Ft.final then Arrow.add q c n x arrow
    else arrow) arrow arrow in

  let arrow = Q_set.fold (fun q arrow ->
    Arrow.add  q mark_char q [] arrow) ft.Ft.states arrow in
  let arrow =
    Charset.Charset.fold (fun c arrow ->
      let l,cs = if c = mark_char then ft.Ft.start,[] else n,[Cfg.Terminal c] in
      let arrow = Arrow.add n c l cs arrow in
      arrow) Charset.fullcharset arrow in
  Ft.create (Q_set.add n ft.Ft.states) arrow n (Q_set.singleton n)

(* ungreedy replacement  *)

let replace_ungreedy reg x =
  let fa = Minimize.minimize (Fa.nfa2dfa (Reg2fa.reg2nfa Charset.fullcharset reg)) in
  let ft = fa2ft_id fa in
  let n = Q_set.max_elt ft.Ft.states + 1 in
  let arrow = Arrow.fold (fun q c q' cs arrow ->
    (* Specific to ungreedy replacement *)
    if Q_set.mem q ft.Ft.final then arrow else
    if Q_set.mem q' ft.Ft.final then Arrow.add q c q' x arrow
    else Arrow.add  q c q' [] arrow)
      ft.Ft.arrow ArrowMap.empty in

  let arrow = Q_set.fold (fun q arrow ->
    if Q_set.mem q ft.Ft.final then arrow else
    Arrow.add  q mark_char q [] arrow) ft.Ft.states arrow in
  let arrow =
    Charset.Charset.fold (fun c arrow ->
      let l,cs = if c = mark_char then ft.Ft.start,[] else n,[Cfg.Terminal c] in
      let arrow = Arrow.add n c l cs arrow in
      Q_set.fold (fun q arrow -> Arrow.add q c l cs arrow)
	ft.Ft.final arrow) Charset.fullcharset arrow in 
  let ft = Ft.create (Q_set.add n ft.Ft.states) arrow n (Q_set.add n ft.Ft.final) in
  let ft = Ft.coaccessible ft in
  minimize_ft ft

let matches_c (l,reg,r) =
(*  let fa = Minimize.minimize (Fa.nfa2dfa (Reg2fa.reg2nfa reg)) in *)
  let fa = Reg2fa.reg2nfa Charset.fullcharset reg in 
  let reg_l =Reg.App (Reg.Star Reg.Allalpha, l) in
  let fa_l = Reg2fa.reg2nfa Charset.fullcharset reg_l in 
  let reg_r =Reg.App (r,Reg.Star Reg.Allalpha) in
  let fa_r = Minimize.minimize (Fa.nfa2dfa (Reg2fa.reg2nfa Charset.fullcharset reg_r)) in
  let ft = fa2ft_id fa in
  let n = Q_set.max_elt ft.Ft.states + 1 in
  let ft_l = fa2ft_empty (Fa.renameFA fa_l n) in
  let n = Q_set.max_elt ft_l.Ft.states + 1 in
  let ft_r = fa2ft_empty (Fa.renameFA fa_r n) in
  let ft = Ft.join ft_l (Ft.join ft ft_r) in
  Ft.coaccessible (Ft.accessible ft)

let match_start_end_cfg cfg start_match end_match multiline =
   let cfg =
     if not start_match then cfg else 
     let x = fresh_var () in
     Cfg.create3 (Cfg.Variable_set.add x (Cfg.vars_of cfg))
       (Cfg.prod_add (x, [Cfg.Terminal Reg.start_metachar ; Cfg.Variable cfg.Cfg.start]) cfg.Cfg.prod) x in
   let cfg =
     if not end_match then cfg else 
     let x = fresh_var () in
     Cfg.create3 
       (Cfg.Variable_set.add x (Cfg.vars_of cfg))
       (Cfg.prod_add (x, [Cfg.Variable cfg.Cfg.start; Cfg.Terminal Reg.end_metachar]) cfg.Cfg.prod) x in
   let cfg = 
     if not multiline then cfg 
     else
       let rhs = [Cfg.Terminal '\n'] in
       let rhs = if start_match then rhs@[Cfg.Terminal Reg.start_metachar] else rhs in
       let rhs = if end_match then [Cfg.Terminal Reg.end_metachar]@rhs else rhs in
       let x = fresh_var () in
       let prod = cfg_subst cfg.Cfg.prod
	   (fun c ->
	     match c with
	       '\n' -> Cfg.Variable x
	     | _ -> Cfg.Terminal c) in
       Cfg.create3 (Cfg.Variable_set.add x (Cfg.vars_of cfg)) (Cfg.prod_add (x, rhs) prod) cfg.Cfg.start in
   cfg

let match_start_end_cfg_ereg has_smc has_emc cfg = 
  match_start_end_cfg cfg has_smc has_emc false

let remove_metachars prod =
   Cfg.Prod.fold 
    (fun x rhss prod -> 
      let rhss = Cfg.SententialForm_set.fold
	  (fun rhs rhss -> 
	    let rhs = List.fold_right 
		(fun s ss ->
		  match s with
		    Cfg.Terminal c when c = Reg.start_metachar || c = Reg.end_metachar -> ss
		  | _ -> s::ss) rhs [] in
	    Cfg.SententialForm_set.add rhs rhss)
	  rhss Cfg.SententialForm_set.empty in
      Cfg.Prod.add x rhss prod) prod Cfg.Prod.empty
    
let preg_replace_main cfg preg (x,p) =
  let cfg = match_start_end_cfg cfg 
      preg.Reg.match_start preg.Reg.match_end preg.Reg.multiline in
  let cfg = Ft_cfg.normalize cfg in
  let {Reg.reg = reg; Reg.greedy = greedy } =  Reg.match_start_end_reg preg in
  let reg = if preg.Reg.caseless then Reg.case_insensitive reg else reg in
  let replace = if greedy then replace else replace_ungreedy in
  let () = Options.show 1 (fun fmt -> Format.printf "%s@." (Reg.string_of_reg reg)) in
  let regs = (Reg.Epsilon, reg, Reg.Epsilon) :: Reg.subreg_c (Reg.Epsilon, reg, Reg.Epsilon) in 
  let _,env,assoc = List.fold_left 
      (fun (i, env, assoc) (l,reg,r) -> 
	let x =
	  try List.assoc (l,reg,r) assoc
	  with Not_found -> fresh_var () in 
	(i+1,("$"^string_of_int i, [Cfg.Variable x])::("\\"^string_of_int i, [Cfg.Variable x])::env, ((l,reg,r),x)::assoc))
      (0, [], []) regs in 
  let {Cfg.prod = p'; Cfg.start = x} = Ft_cfg.inter (strings_ft' env) (Cfg.create p x) in
  let xs = vars_of_rules p' in
  let p' = List.fold_left (fun p' ((l,reg,r),x) ->
    if Cfg.Variable_set.mem x xs then
      let {Cfg.prod = rules'; Cfg.start = x'} = Ft_cfg.inter' (matches_c (l,reg,r)) cfg in 
      let p' = Cfg.prod_union p' rules' in
      Cfg.Prod.add x (Cfg.SententialForm_set.singleton [Cfg.Variable x']) p'
    else p') p' assoc in 

  let {Cfg.prod = p'; Cfg.start = x} = Cfg.useful (Cfg.create p' x) in
  let cfg' = Ft_cfg.inter' (marker reg) cfg in
  let cfg' = simplify_unitpair cfg' in 
  let cfg' = chain_elim cfg' in 
  let cfg' = Cfg.useful cfg' in  
  let {Cfg.prod = p; Cfg.start = y} = Ft_cfg.inter (replace reg [Cfg.Variable x]) cfg' in 
  let p = Cfg.prod_union p p' in
  let p = if preg.Reg.match_start || preg.Reg.match_end then remove_metachars p else p in
  let cfg = Cfg.create p y in
  let cfg = simplify_unitpair cfg in 
  let cfg = chain_elim cfg in 
  let cfg = Cfg.useful cfg in  
  let cfg = Ft_cfg.normalize cfg in  
  cfg


let preg_replace cfg ss (x,p) = 
   let reg = Pregparser.parse_charlist ss in
   preg_replace_main cfg reg (x,p) 

let preg_replace' cfg ss ss2 =
   let x = fresh_var () in
   let p = Cfg.Prod.add x (Cfg.SententialForm_set.singleton (str2ss ss2)) Cfg.Prod.empty in
   let () = Options.show 2 (fun fmt -> Format.fprintf fmt "%a@." (Basic.print_list "" Cfg.pp_sym) (str2ss ss2)) in 
   let preg = Pregparser.parse ss in
   preg_replace_main cfg preg (x,p) 

let ereg_replace mode cfg ss (x,p) =
  let reg = Eregparser.parse_charlist ss in
  let has_smc = Reg.has_start_metachar reg in
  let has_emc = Reg.has_end_metachar reg in
  let has_mc = has_smc || has_emc in
  let cfg = if has_mc then match_start_end_cfg_ereg has_smc has_emc cfg else cfg in
  let cfg = Ft_cfg.normalize cfg in
  let () = Options.show 2 (fun fmt -> Format.fprintf fmt "%s@." (Reg.string_of_reg reg)) in
  let reg = if mode then reg else Reg.case_insensitive reg in
  let regs = (Reg.Epsilon, reg, Reg.Epsilon) :: Reg.subreg_c (Reg.Epsilon, reg, Reg.Epsilon) in 

  let _,env,assoc = List.fold_left 
      (fun (i, env, assoc) (l,reg,r) -> 
	let x =
	  try List.assoc (l,reg,r) assoc
	  with Not_found -> fresh_var () in 
	(i+1,("\\"^string_of_int i, [Cfg.Variable x])::env, ((l,reg,r),x)::assoc))
      (0, [], []) regs in 
  let {Cfg.prod = p'; Cfg.start = x} = Ft_cfg.inter (strings_ft' env) (Cfg.create p x) in
  let xs = vars_of_rules p' in
  let p' = List.fold_left (fun p' ((l,reg,r),x) ->
    if Cfg.Variable_set.mem x xs then 
      let {Cfg.prod = rules'; Cfg.start = x'} = Ft_cfg.inter' (matches_c (l,reg,r)) cfg in 
      let p' = Cfg.prod_union p' rules' in
      Cfg.Prod.add x (Cfg.SententialForm_set.singleton [Cfg.Variable x']) p'
    else p') p' assoc in 

  let {Cfg.prod = p'; Cfg.start = x}  = Cfg.useful (Cfg.create p' x) in
  let cfg' = Ft_cfg.inter' (marker reg) cfg in
  let cfg' = simplify_unitpair cfg' in 
  let cfg' = chain_elim cfg' in 
  let cfg' = Cfg.useful cfg' in  
  let {Cfg.prod = p; Cfg.start = y} = Ft_cfg.inter (replace reg [Cfg.Variable x]) cfg' in 
  let p = Cfg.prod_union p p' in
  let p = if has_mc then remove_metachars p else p in
  let cfg = Cfg.create p y in
  let cfg = simplify_unitpair cfg in 
  let cfg = chain_elim cfg in 
  let cfg = Cfg.useful cfg in  
  let cfg = Ft_cfg.normalize cfg in  
  cfg

let preg_match mode cfg ss = 
  let {Reg.reg = reg } as preg = Pregparser.parse_charlist ss in
  let reg = if preg.Reg.caseless then Reg.case_insensitive reg else reg in
  let fa = Reg2fa.reg2nfa Charset.fullcharset reg in
  let fa = Fa.nfa2dfa fa in
  let fa = if mode then fa else Fa.neg fa in
  Fa_cfg.inter fa cfg 
   
let preg_match mode cfg ss =
   let {Reg.reg = reg } as preg = Pregparser.parse_charlist ss in
   let cfg = match_start_end_cfg cfg 
      preg.Reg.match_start preg.Reg.match_end preg.Reg.multiline in
   let {Reg.reg = reg; Reg.greedy = greedy } =  
   Reg.match_start_end_reg preg in
   let reg = if preg.Reg.caseless then Reg.case_insensitive reg else reg in
   let anystring_reg = Reg.Star (Reg.Negalphalist []) in
   let reg = Reg.App (anystring_reg, Reg.App (reg, anystring_reg)) in
   let fa = Reg2fa.reg2nfa Charset.fullcharset reg in
   let fa = Fa.nfa2dfa fa in
   let fa = if mode then fa else Fa.neg fa in
   let cfg = Fa_cfg.inter fa cfg in
   let h c = 
   if  c = Reg.start_metachar || c = Reg.end_metachar then [] 
   else [c] in
   Cfg.homo cfg h
   
(* Rough approximation containing all matching substrings *)

let preg_match_array cfg ss =
  let {Reg.reg = reg } as preg = Pregparser.parse_charlist ss in
  let cfg = match_start_end_cfg cfg 
      preg.Reg.match_start preg.Reg.match_end preg.Reg.multiline in
  let cfg = Ft_cfg.normalize cfg in
  let {Reg.reg = reg; Reg.greedy = greedy } =  Reg.match_start_end_reg preg in
  let reg = if preg.Reg.caseless then Reg.case_insensitive reg else reg in
  let regs = (Reg.Epsilon, reg, Reg.Epsilon) :: Reg.subreg_c (Reg.Epsilon, reg, Reg.Epsilon) in 
  let x = fresh_var () in 
  let p = List.fold_left 
      (fun p (l,reg,r) -> 
	let {Cfg.prod = p'; Cfg.start = x'} = Ft_cfg.inter' (matches_c (l,reg,r)) cfg in 
	let p = Cfg.prod_union p p' in
	Cfg.prod_add (x, [Cfg.Variable x']) p )
      Cfg.Prod.empty regs in 
  let p = if preg.Reg.match_start || preg.Reg.match_end then remove_metachars p else p in
  Cfg.create p x

let preg_match_all cfg ss = preg_match_array cfg ss 

let ereg_match_start_end reg cfg =
  let has_smc = Reg.has_start_metachar reg in
  let has_emc = Reg.has_end_metachar reg in
  let has_mc = has_smc || has_emc in
  if has_mc then match_start_end_cfg_ereg has_smc has_emc cfg else cfg 

(* ereg *)

let ereg case_sensitive mode cfg ss =
  let reg = Eregparser.parse_charlist ss in
  let reg = if case_sensitive then Reg.case_insensitive reg else reg in
  let cfg = ereg_match_start_end reg cfg in
  let anystring_reg = Reg.Star (Reg.Negalphalist []) in
  let reg = Reg.App (anystring_reg, Reg.App (reg, anystring_reg)) in
  let fa = Reg2fa.reg2nfa Charset.fullcharset reg in
  let fa = Fa.nfa2dfa fa in
  let fa = if mode then fa else Fa.neg fa in
  let cfg = Fa_cfg.inter fa cfg in
  let h c = 
    if  c = Reg.start_metachar || c = Reg.end_metachar then [] 
    else [c] in
  Cfg.homo cfg h
   
(* Rough approximation containing all matching substrings *)

let ereg_array case_sensitive cfg ss =
  let reg = Eregparser.parse_charlist ss in
  let reg = if case_sensitive then Reg.case_insensitive reg else reg in
  let cfg = ereg_match_start_end reg cfg in
  let cfg = Ft_cfg.normalize cfg in
  let regs = (Reg.Epsilon, reg, Reg.Epsilon) :: Reg.subreg_c (Reg.Epsilon, reg, Reg.Epsilon) in 
  let x = fresh_var () in 
  let p = List.fold_left 
      (fun p (l,reg,r) -> 
	let {Cfg.prod = p'; Cfg.start = x'} = Ft_cfg.inter' (matches_c (l,reg,r)) cfg in 
	let p = Cfg.prod_union p p' in
	Cfg.prod_add (x, [Cfg.Variable x']) p )
      Cfg.Prod.empty regs in 
  let cfg = Cfg.create p x in
  let h c = 
    if  c = Reg.start_metachar || c = Reg.end_metachar then [] 
    else [c] in
  Cfg.homo cfg h

(* finite tansducers for XHTML validation *)

let remove_attributes_ft =
  let {Reg.reg = reg } = Pregparser.parse "/.*<[a-zA-Z0-9!\\[\\]\\-\\?]+/" in
  let fa = 
    Minimize.minimize (Fa.nfa2dfa (Reg2fa.reg2nfa Charset.charset reg)) in
  let ft = fa2ft_id fa in
  let n = Q_set.max_elt ft.Ft.states + 1 in
  let arrow = 
    Arrow.fold (fun q c q' cs arrow ->
      if Q_set.mem q ft.Ft.final && (c <> '>' && 
      not ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c = '[' || c=']'))
      then arrow
      else
	  Arrow.add q c q' cs arrow) ft.Ft.arrow Ft.ArrowMap.empty in
  let arrow = 
    Charset.Charset.fold (fun c arrow ->
      if c = '>' ||  (c >= 'a' && c <= 'z') || 
      (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c = '[' || c = ']'
      then arrow
      else if c = '/' then
	Q_set.fold (fun q arrow ->
	  Arrow.add q c (n+1) [] arrow) ft.Ft.final arrow
      else
	Q_set.fold (fun q arrow ->
	  Arrow.add q c n [] arrow) ft.Ft.final arrow) Charset.fullcharset arrow in
  let arrow =
    Charset.Charset.fold (fun c arrow ->
      if c = '>' then 
	Arrow.add n c ft.Ft.start [Cfg.Terminal '>'] arrow 
      else if c = '/' then 
	Arrow.add n c (n+1) [] arrow 
      else
	Arrow.add n c n [] arrow) Charset.fullcharset arrow in
  let arrow =
    Charset.Charset.fold (fun c arrow ->
      if c = '>' then 
	Arrow.add (n+1) c ft.Ft.start [Cfg.Terminal '/'; Cfg.Terminal '>'] arrow 
      else if c = ' ' then 
	Arrow.add (n+1) c (n+1) [] arrow
      else
	Arrow.add (n+1) c n [] arrow) Charset.fullcharset arrow in 
  let q = Q_set.add (n+1) (Q_set.add n ft.Ft.states) in 
  Ft.create q arrow ft.Ft.start q


let strict_remove_attributes_ft =
  let transition state c =
    match (state, c) with
      (0, '<') -> [(1,[Cfg.Terminal '<'])]
    | (0, c) -> [(0,[Cfg.Terminal c])]
    | (1, ' ') -> [(2,[])]
    | (1, '>') -> [(0,[Cfg.Terminal '>'])]
    | (1, c) -> [(1,[Cfg.Terminal c])]
    | (2, '>') -> [(0,[Cfg.Terminal '>'])]
    | (2, '/') -> [(2,[Cfg.Terminal '/'])]
    | (2, '"') -> [(3,[])]
    | (2, '\'') -> [(4,[])]
    | (2, c) -> [(2,[])]
    | (3, '"') -> [(2,[])]
    | (3, c) -> [(3,[])]
    | (4, '\'') -> [(2,[])]
    | (4, c) -> [(4,[])] 
    | _ -> failwith "remove_attribute" in
  create_ft transition 0 [0]

let remove_nontag_ft =
  let transition state c =
    match (state, c) with
      (0, '<') -> [(1,[Cfg.Terminal '<'])]
    | (0, c) -> [(0,[])]
    | (1, '>') -> [(0,[Cfg.Terminal '>'])]
    | (1, c) -> [(1,[Cfg.Terminal c])]
    | _ -> failwith "remove_nontag" in
  create_ft transition 0 [0]

let remove_nontag_html_ft =
  let transition state c =
    match (state, c) with
      (0, '<') -> [(1,[])]
    | (0, c) -> [(0,[])]
    | (1, '/') -> [(2,[])]
    | (1, c) when ('a' <= c && c <= 'z') || ('A' <= c && c <= 'Z') -> [(3,[Cfg.Terminal '<'; Cfg.Terminal c])]
    | (1, c) -> [(0,[])]
    | (2, c) when ('a' <= c && c <= 'z') || ('A' <= c && c <= 'Z') -> 
	[(3,[Cfg.Terminal '<'; Cfg.Terminal '/'; Cfg.Terminal c])]
    | (2, c) -> [(0, [])]
    | (3, '>') -> [(0,[Cfg.Terminal '>'])]
    | (3, c) -> [(3,[Cfg.Terminal c])]
    | _ -> failwith "remove_nontag_html" in
  create_ft transition 0 [0]

let extract_tags_ft =
  let transition state c =
    match (state, c) with
      (0, '<') -> [(0,[]);(1,[])]
    | (0, c) -> [(0,[])]
    | (1, '>') -> [(3,[])]
    | (1, '/') -> [(2,[])]
    | (1, c) -> [(1,[Cfg.Terminal c])]
    | (2, '>') -> [(3,[])]
    | (2, c) -> [(2,[Cfg.Terminal c])]
    | (3, c) -> [(3,[])]
    | _ -> failwith "extract_tagse" in
  create_ft transition 0 [3]

let extract_tags_html_ft =
  let transition state c =
    match (state, c) with
      (0, '<') -> [(0,[]);(1,[])]
    | (0, c) -> [(0,[])]
    | (1, '>') -> [(3,[])]
    | (1, '/') -> [(2,[])]
    | (1, c) when ('a' <= c && c <= 'z') || ('A' <= c && c <= 'Z') -> [(3,[Cfg.Terminal c])]
    | (1, _) -> [(0, [])]
    | (2, c) when ('a' <= c && c <= 'z') || ('A' <= c && c <= 'Z') || ('0' <= c && c <= '9') ||
      c = '-' ||  c = '_' || c = ':' || c = '.' -> [(3,[Cfg.Terminal c])]
    | (2, c) -> [(0,[])]
    | (3, c) when ('a' <= c && c <= 'z') || ('A' <= c && c <= 'Z') || ('0' <= c && c <= '9') ||
      c = '-' ||  c = '_' || c = ':' || c = '.' -> [(3,[Cfg.Terminal c])]
    | (3, _) -> [(4, [])]
    | (4, c) -> [(4,[])]
    | _ -> failwith "extract_tagse" in
  create_ft transition 0 [4]


(* replace str1.*str2 with str1str2 *)

let cut_ft str1 str2 =
  let reg1 =Reg.App (Reg.Star Reg.Allalpha, Reg.string_reg str1) in
  let fa1 = Fa.minimize (Reg2fa.reg2nfa Charset.charset reg1) in
  let arrow = 
    Fa.Arrow.fold (fun q1 c q2 arrow -> 
      if Q_set.mem q1 fa1.Fa.final then arrow else Fa.Arrow.add q1 c q2 arrow) fa1.Fa.arrow Fa.Arrow.empty in 
  let ft1 = fa2ft_id {fa1 with Fa.arrow = arrow }in
  let reg2 =Reg.App (Reg.Star Reg.Allalpha, Reg.string_reg str2) in
  let fa2 = Fa.minimize (Reg2fa.reg2nfa Charset.charset reg2) in
  let n = Q_set.max_elt ft1.Ft.states + 1 in
  let fa2 = Fa.renameFA fa2 n in
  let ft2 = fa2ft_empty fa2 in
  let ft = simple_join ft1 ft2 in
  let arrow = 
    Ft.Arrow.fold (fun q1 c q2 cs arrow -> 
      if Q_set.mem q2 ft.Ft.final then Ft.Arrow.add q1 c ft.Ft.start (List.map (fun c -> Cfg.Terminal c) (explode str2)) arrow
      else Ft.Arrow.add q1 c q2 cs arrow) ft.Ft.arrow Ft.Arrow.empty in 
  let ft = Ft.create (Q_set.diff ft.Ft.states ft.Ft.final) arrow ft.Ft.start (Q_set.singleton ft.Ft.start) in
  ft

(* replace str1.*str2 with the empty string *)
let cut_comment_ft str1 str2 =
  let string_ft cs =
    let transition xs c =
      if xs = cs then []
      else
	let xs' = xs@[c] in
	if xs' = cs then [(cs, [])] 
	else
	  let ys,zs = find_prefix cs xs' in
	  [(zs, cs2ss ys)] in
    create_ft transition [] [cs] in
  let ft1 = string_ft (explode str1) in
  let reg2 =Reg.App (Reg.Star Reg.Allalpha, Reg.string_reg str2) in
  let fa2 = Fa.minimize (Reg2fa.reg2nfa Charset.charset reg2) in
  let n = Q_set.max_elt ft1.Ft.states + 1 in
  let fa2 = Fa.renameFA fa2 n in
  let ft2 = fa2ft_empty fa2 in
  let {Ft.states = q; Ft.arrow = arrow; Ft.start = s; Ft.final = f} = 
    simple_join ft1 ft2 in
  let arrow = 
    Ft.Arrow.fold (fun q1 c q2 cs arrow -> 
      if Q_set.mem q2 f then Ft.Arrow.add q1 c s [] arrow
      else Ft.Arrow.add q1 c q2 cs arrow) arrow Ft.Arrow.empty in 
  let ft = Ft.create (Q_set.diff q f) arrow s (Q_set.singleton s) in
  ft

(* ft for the macthing mode *)

let matches_ft reg = 
  let fa = Minimize.minimize (Fa.nfa2dfa (Reg2fa.reg2nfa Charset.charset reg)) in
  let ft = fa2ft_id fa in
  let n = Q_set.max_elt ft.Ft.states + 1 in
  let arrow =
    Charset.Charset.fold (fun c arrow ->
      let arrow = Arrow.add n c n [] arrow  in
      let arrow = Arrow.add (n+1) c (n+1) [] arrow  in
      let arrow = 
	Q_set.fold (fun q arrow -> 
	  Arrow.add q c (n+1) [] arrow)
	  ft.Ft.final arrow in
      Q_set.fold (fun q arrow -> 
	Arrow.add n c q [Cfg.Terminal c] arrow)
	(Fa.delta fa (ft.Ft.start,c)) arrow) Charset.fullcharset ft.Ft.arrow in
  let q = Q_set.add n (Q_set.add (n+1) ft.Ft.states) in
  let f = if Q_set.mem ft.Ft.start ft.Ft.final then Q_set.add n ft.Ft.final else ft.Ft.final in
  minimize_ft (Ft.accessible (
  Ft.coaccessible (Ft.create q arrow n (Q_set.add (n+1) f))))

let filter_element_ft element =
  let fa = string_fa element in
  let n = String.length element in
  let ft = fa2ft_empty fa in
  let arrow = ft.Ft.arrow in
  let arrow = Ft.Arrow.add n ' ' (n+1) [] arrow in
  let arrow = Ft.Arrow.add (n+1) ' ' (n+1) [] arrow in
  let arrow =
    Charset.Charset.fold (fun c arrow ->
      let arrow = Arrow.add (n+2) c (n+2) [Cfg.Terminal c] arrow in
      if c = ' ' then arrow
      else Arrow.add (n+1) c (n+2) [Cfg.Terminal c] arrow) Charset.charset arrow  in
  let q = Q_set.add (n+1) (Q_set.add (n+2) ft.Ft.states) in
  let f = Q_set.singleton (n+2) in
  Ft.create q arrow 0 f

let extract_attribute_names_ft =
  let transition state c =    
    match (state, c) with
    | (0, ' ') -> [(0,[])]
    | (0, '\t') -> [(0,[])]
    | (0, c) -> [(1, [Cfg.Terminal c]); (2, [])]
    | (1, '=') -> [(6,[])]
    | (1, ' ') -> [(6,[])]
    | (1, '\t') -> [(6,[])]
    | (1, c) -> [(1,[Cfg.Terminal c])]
    | (2, '=') -> [(3,[])]
    | (2, _) -> [(2,[])]
    | (3, ' ') -> [(3,[])]
    | (3, '\t') -> [(3,[])]
    | (3, '\'') -> [(4,[])]
    | (3, '"') -> [(5,[])]
    | (3, _) -> []
    | (4, '\'') -> [(0,[])]
    | (4, _) -> [(4,[])]
    | (5, '"') -> [(0,[])]
    | (5, _) -> [(5,[])]
    | (6, _) -> [(6,[])]
    | _ -> failwith "remove_attribute" in
  create_ft transition 0 [6]








