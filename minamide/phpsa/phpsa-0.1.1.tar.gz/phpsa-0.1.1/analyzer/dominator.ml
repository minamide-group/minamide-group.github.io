type node = int
type graph = node list array

let next g x = g.(x) 
let add_edge x y g = g.(x) <- y::g.(x)

let transpose g =
  let size = Array.length g in
  let g' = Array.make size [] in
  for x = 0 to (size - 1) do
    List.iter (fun y -> add_edge y x g') (next g x)
  done;
  g'

let list_max xs =
  match xs with 
    [] -> failwith "list_max"
  | x::xs -> List.fold_left (fun v y -> max v y) x xs

let make_graph l = 
  let size = list_max (List.map (fun (x,y) -> max x y) l) + 1 in
  let g = Array.make size [] in
  List.iter (fun (x,y) ->  add_edge x y g) l;
  g

let dfs g x =
  let size = Array.length g in
  let n = ref 0 in
  let dfsnum = Array.make size (-1) in
  let parent = Array.make size (-1) in
  let vertex = Array.make size 0 in
  let rec dfs_rec x =
    dfsnum.(x) <- (!n);
    vertex.(!n) <- x; 
    n := !n + 1;
    List.iter (fun y -> 
      if dfsnum.(y) = -1 then (parent.(y) <- x; dfs_rec y)) (next g x) in
  dfs_rec x;
  dfsnum, parent, vertex

let eval ancestor semi label v = 
  let rec compress v =
    if ancestor.(ancestor.(v)) <> (-1) then
      (compress ancestor.(v);
       if semi.(label.(ancestor.(v))) < semi.(label.(v)) then
	 label.(v) <- label.(ancestor.(v));
       ancestor.(v) <- ancestor.(ancestor.(v))) in
  if ancestor.(v) = (-1) then v
  else (compress v; label.(v)) 

let link ancestor v w = ancestor.(w) <- v

let min_list xs =
  match xs with
    [] -> failwith "min_list"
  | x::xs -> List.fold_left (fun v y -> min v y) x xs 

let dominators' g g' =
  let size = Array.length g in
  let ancestor = Array.make size (-1) in
  let dfsnum, parent, vertex = dfs g 0 in
  let semi = Array.make size (-1) in
  let bucket = Array.make size [] in
  let dom = Array.make size 0 in
  let label = Array.init size (fun x -> x) in
  let bucket_add x y = bucket.(x) <- y:: bucket.(x) in
  for i = size - 1 downto 1 do  
    let w = vertex.(i) in
    let w' =  min_list (List.map (fun v -> 
      if dfsnum.(v)  <= dfsnum.(w) then dfsnum.(v)
      else
	semi.(eval ancestor semi label v)) (next g' w)) in
    semi.(w) <- w';
    bucket_add vertex.(w') w;
    link ancestor parent.(w) w;
    List.iter (fun v ->
      let u = eval ancestor semi label v in
      dom.(v) <- 
	(if semi.(u) < semi.(v) then u else parent.(w)))
      bucket.(parent.(w))
  done;
  for i = 1 to size - 1 do  
    let w = vertex.(i) in
    if dom.(w) <> vertex.(semi.(w)) 
    then dom.(w) <- dom.(dom.(w))
  done;
  dom

let dominators g =
  let g' = transpose g in
  dominators' g g'
