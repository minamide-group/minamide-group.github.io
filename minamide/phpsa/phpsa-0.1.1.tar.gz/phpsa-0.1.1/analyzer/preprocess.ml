open Abssyn
open Support

let rec eval env exp =
  let exp_desc = exp.exp_desc in
  let exp_desc =
    match exp_desc with
      Lvalue lv -> Lvalue (eval_lv env lv)
    | Null | Const _  | Int _ | Float _ | Bool _  | String _ -> exp_desc
    | NewArray ees -> 
	NewArray (List.map (fun (e1,e2) -> (eval env e1, eval env e2)) ees)
    | RefAssign (x, Lv lv) -> RefAssign (x, Lv lv)
    | RefAssign (x, Exp exp) -> RefAssign (x, Exp (eval env exp))
    | ListAssign (xs, exp) -> ListAssign (xs, eval env exp)
    | LAssign (lv, exp) -> LAssign (lv, eval env exp)
    | LOpAssign (lv, p, exp) -> LOpAssign (lv, p, eval env exp)
    | Prim (p, es) -> 
	Prim (p, eval_list env es)
    | ClassMethod (cname, mname, es) -> 
	let cname =
	  match (cname, env) with
	    ("parent", Some parent) -> parent
	  | ("parent", None) -> failwith "No parent"
	  | _ -> cname in
	ClassMethod (cname, mname, eval_list env es)
    | Method (e, mname, es) -> 
	Method (eval env e, mname, eval_list env es)
    | NewObj (classname, es) -> 
	NewObj (classname, eval_list env es)
    | UClassMethod (cname, e, es) -> 
	let cname =
	  match (cname, env) with
	    ("parent", Some parent) -> parent
	  | ("parent", None) -> failwith "No parent"
	  | _ -> cname in
	UClassMethod (cname, eval env e, eval_list env es)
    | UMethod (e1, e2, es) -> 
	UMethod (e1, eval env e2, eval_list env es)
    | UNewObj (e,es) -> 
	UNewObj (eval env e, eval_list env es)
    | App (s,es) -> 
	App (s, eval_list env  es)
    | AppVar (e,es) -> 
	AppVar (eval env e, eval_list env  es)
    | FileBlock (fname, dirname, ss) -> FileBlock (fname, dirname, exec_list env ss)
    | StmtExp (ss, e) -> StmtExp (exec_list env ss, eval env e)
    | IncludeExp (once, exp, expanded_files, sss) -> 
	IncludeExp (once, eval env exp, expanded_files, 
		    List.map (fun (str, ss) -> (str, exec_list env ss)) sss)
    | Define (s, exp) -> Define (s, eval env exp) in
  { exp with exp_desc = exp_desc }
and eval_list env es = List.map (eval env) es

and eval_lv env lv =
  let lv_desc =
    match lv.lvalue_desc with
      LVar x -> LVar x
    | LVarVar e -> LVarVar (eval env e)
    | LArray1 lv -> LArray1 (eval_lv env lv)
    | LArray2 (lv, e) -> LArray2 (eval_lv env lv, eval env e) 
    | LObjRef (lv, s) -> LObjRef (eval_lv env lv, s)
    | LUObjRef (lv, e) -> LUObjRef (eval_lv env lv, eval env e)
    | LStringRef (lv, e) -> LStringRef (eval_lv env lv, eval env e) in
  { lv with lvalue_desc = lv_desc }
	  
and exec env stmt =
  let stmt_desc = stmt.stmt_desc in
  let stmt_desc = 
    match stmt_desc with
      BlockSt ss -> BlockSt (exec_list env ss)
    | While (e, s) -> While (eval env e, exec env s) 
    | DoWhile (s, e) -> DoWhile (exec env s, eval env e)
    | For (e1, e2, e3, s) -> For (eval_list env e1, eval_list env e2, eval_list env e3, exec env s)
    | Foreach (e, optx, y, s) -> Foreach (eval env e, optx, y, exec env s)
    | If (e, s1, s2) -> If (eval env e, exec env s1, exec env s2)
    | Function (f, xs, s, b) -> Function (f, xs, exec env s, b)
    | Switch (e, css) -> 
	let e = eval env e in
	let css = exec_clist env css in
	Switch (e, css)
    | ExpSt e -> ExpSt (eval env e)
    | Echo e -> Echo (eval env e)
    | Unset lv -> Unset (eval_lv env lv)
    | Skip | Global _ -> stmt_desc
    | Return exp -> Return (eval env exp)
    | Assert _ | Continue _ | Break _  | Static _ -> stmt_desc
    | Class (cname, parent, xs, ms) -> 
	let eval_method (mname, xs, s, r) = (mname, xs, exec parent s, r) in
	Class (cname, parent, xs, List.map eval_method ms) in
  { stmt with stmt_desc = stmt_desc }

  and exec_list env stmts = List.map (exec env) stmts 
  and exec_clist env css = List.map (fun (c, ss) -> (c, exec_list env ss)) css

let exec_list ss = exec_list None ss
