(*
 * PHP string analyzer
 * Copyright (C) 2006 Yasuhiko Minamide
 *)
(*
 * Context-free gramars with operation productions
 *)
open Ilextract
module VarMap = Support.VarMap
module VarSet = Support.VarSet

let vars_of_rhsval rhs xs =
  match rhs with
    Rvar x -> VarSet.add x xs
  | _ -> xs

let vars_of_rhs rhs xs =
  match rhs with
    Rval v -> vars_of_rhsval v xs
  | Rconcat (x,y) -> vars_of_rhsval y (vars_of_rhsval x xs) 
  | Rstring s -> xs
  | Rregexp r -> xs
  | Rdtd _ -> xs
  | Rapp (s,ys,_) -> List.fold_right (fun y xs -> vars_of_rhsval y xs) ys xs

let vars_of_rule (x,rhs) xs =
  vars_of_rhs rhs (VarSet.add x xs)

let vars_of_grammar g =
  List.fold_left (fun xs p -> vars_of_rule p xs) VarSet.empty g

let gfind x g = 
    try VarMap.find x g with Not_found -> [] 
let gadd x y g = VarMap.add x (y::gfind x g) g

let graph_of grammar =
  let g1 =
    List.fold_left (fun g (x,rhs) ->
      let ys = VarSet.fold (fun y ys -> y::ys) 
	  (vars_of_rhs rhs VarSet.empty) (gfind x g) in
      VarMap.add x ys g) VarMap.empty grammar in
  let xs = vars_of_grammar grammar in
  (g1, xs)

let nexts (g1, _) x = gfind x g1

module Absgraph = 
  Absgraph.Make(struct 
    type t = Support.var
    type g = Il.var list VarMap.t * VarSet.t
    let nexts = nexts
    let nodes_of (g1, xs) = xs
    module NodeSet = VarSet
  end)

let reorder grammar sccs =
  let rtbl = Hashtbl.create 1000 in
  let find x = try Hashtbl.find rtbl x with Not_found -> [] in
  List.iter (fun (x,rhs) -> Hashtbl.add rtbl x (rhs::find x)) grammar;
  List.rev (List.rev_map (fun scc -> 
    (scc, 
     VarSet.fold (fun x rules -> 
       List.fold_left (fun rules rhs -> (x, rhs)::rules)
	 rules (find x)) scc [])) sccs)

let generating_vars grammar =
  let add x y gmap =
    let ys = try VarMap.find x gmap with Not_found -> [] in
    VarMap.add x (y::ys) gmap in
  let vs, gmap = List.fold_left (fun (vs, gmap) (x, rhs)  ->
    if VarSet.mem x vs then (vs, gmap)
    else
      let ys = vars_of_rhs rhs VarSet.empty in
      let ys = VarSet.filter (fun x -> not (VarSet.mem x vs)) ys in
      if VarSet.is_empty ys 
      then (VarSet.add x vs, gmap)
      else 
	let nref = ref (VarSet.cardinal ys) in
	(vs, 
	 VarSet.fold 
	   (fun y gmap ->  add y (x, nref) gmap) ys gmap)) 
      (VarSet.empty, VarMap.empty) grammar in 
  let () = Basic.show 1 
      (fun () -> Format.printf "(after graph generation)@.") in
  let rec loop xs rs =
    match xs with
      [] -> rs
    | x::xs -> 
	let xs,rs = List.fold_left (fun (xs,rs) (y,nref) ->
	  decr nref;
	  if !nref = 0 && not (VarSet.mem y rs) 
	  then (y::xs, VarSet.add y rs) else (xs,rs)) 
	    (xs,rs)
	    (try VarMap.find x gmap with Not_found -> []) in
	loop xs rs in
  let vs = loop (VarSet.elements vs) vs in
  vs


let simplify grammar ass =
(*  let rs = generating_vars grammar in 
  let grammar =  List.filter 
      (fun (x, rhs) -> VarSet.mem x rs &&
	VarSet.for_all (fun y -> VarSet.mem  y rs) (vars_of_rhs rhs))
      grammar in  *)
  let rs = Absgraph.dfs (graph_of grammar) ass VarSet.empty in
  let grammar = List.filter (fun (x, rhs) -> VarSet.mem x rs) grammar in  
  let () = Options.show 2 (fun fmt -> Format.fprintf fmt "after rs@.") in
  let sccs = Absgraph.sc (graph_of grammar) in 
  let () = Options.show 2 (fun fmt -> Format.fprintf fmt "after sc@.") in
  reorder grammar sccs 






