type const = 
    ConstInt of int 
  | ConstBool of bool 
  | ConstFloat of float 
  | ConstString of string
  | ConstArray of (const * const) list
  | ConstConst of string


let rec pp_const ff c =
  match c with 
    ConstInt i -> Format.fprintf ff "%d" i
  | ConstBool b -> 
      let bs = if b then "TRUE" else "FALSE" in
      Format.fprintf ff "%s" bs
  | ConstFloat f -> Format.fprintf ff "%f" f
  | ConstString s -> Format.fprintf ff "\"%s\"" (String.escaped s)
  | ConstArray l -> 
      let pp_arrayinit ff (x,y) = 
	Format.fprintf ff "%a => %a" pp_const x pp_const y in
      Format.fprintf ff "array(%a)"
      (Basic.print_list "," pp_arrayinit) l
  | ConstConst s -> Format.fprintf ff "%s" s

