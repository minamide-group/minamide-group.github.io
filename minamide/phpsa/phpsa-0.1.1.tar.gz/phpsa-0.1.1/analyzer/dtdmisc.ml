(*
 * PHP string analyzer
 * Copyright (C) 2005, 2006 Nobuo Otoi, Yasuhiko Minamide
 *)
open Pxp_types
open Reg
open Basic
open Support
 
let rec pp_regspec fmt = function
    Optional  reg -> Format.fprintf fmt "(%a)?"  pp_regspec reg
  | Repeated  reg -> Format.fprintf fmt "(%a)*"  pp_regspec reg
  | Repeated1 reg -> Format.fprintf fmt "(%a)+" pp_regspec reg
  | Alt reglst -> 
      Format.fprintf fmt "(%a)" 
	(Basic.print_list "|" pp_regspec) reglst
  | Seq reglst -> 
      Format.fprintf fmt "(%a)" 
	(Basic.print_list "," pp_regspec) reglst
  | Child str  -> Format.fprintf fmt "%s" str

let pp_mixed fmt = function
    MPCDATA    -> Format.fprintf fmt "#PCDATA"
  | MChild str -> Format.fprintf fmt "%s" str
let pp_content_model fmt = function
    Unspecified -> Format.fprintf fmt "Unspecified"
  | Empty       -> Format.fprintf fmt "Empty"
  | Any         -> Format.fprintf fmt "Any"
  | Mixed lst   -> 
      Format.fprintf fmt "(%a)*" (Basic.print_list "|" pp_mixed) lst
  | Regexp reg  -> pp_regspec fmt reg

module ElmSet = Set.Make(struct type t = string let compare = compare end)
exception MyError of int

let cleanup elmset cmodel =
  let rec aux_reg = function
      Optional r -> 
	let r = aux_reg r in 
	(match r with
	  Alt [] -> Seq []
	| Seq [] -> Seq []
	| _ -> Optional r)
    | Repeated r    -> 
	let r = aux_reg r in
	(match r with
	  Alt [] -> Seq []
	| Seq [] -> Seq []
	| _ -> Repeated r)
    | Repeated1 r -> 
	let r = aux_reg r in
	(match r with
	  Alt [] -> Alt []
	| Seq [] -> Seq []
	| _ -> Repeated1 (aux_reg r))
    | Alt rlst -> 
	Alt(List.fold_right(fun r making -> 
	  let r = aux_reg r in      
	  (match r with
	    Alt [] -> making
	  | _ -> r::making)) rlst [])
    | Seq rlst -> 
	let lst,b = List.fold_right(fun r (mklst, mkb) -> 
	  if mkb then
	    let r = aux_reg r in
	    match r with
	      Alt [] -> ([],false) 
	    | Seq [] -> (mklst,true)
	    | _ -> (r::mklst,true)
	  else ([],false)) rlst ([],true) in
	if b then Seq lst else Alt []
    | Child str -> if ElmSet.mem str elmset then Child str else Alt [] in
  let aux_mixed = function
      MPCDATA    -> true
    | MChild str -> ElmSet.mem str elmset in
  let aux_content_model = function
      Unspecified   -> Unspecified
    | Empty         -> Empty
    | Any           -> Any
    | Mixed speclst -> Mixed(List.fold_right(fun e making -> if aux_mixed e then e::making else making) speclst [])
    | Regexp reg    -> Regexp (aux_reg reg) in
  aux_content_model cmodel


let cleanup_dtd dtd elmset my_dtd =
  let elmlst = dtd#element_names in
  let () =
    List.iter (fun elm -> 
      if ElmSet.mem elm elmset then 
	let newelm = new Pxp_dtd.dtd_element my_dtd elm in
	try
	  my_dtd#add_element newelm;
	  try
            let cmodel = cleanup elmset ((dtd#element elm)#content_model) in
(*            let () = print_string ("elm:" ^ elm ^ " cmodel:" ^ (string_of_content_model (dtd#element elm)#content_model)^"\n") in
            let () = print_string ("elm:" ^ elm ^ " cmodel:" ^ (string_of_content_model cmodel)^"\n") in *)
	    (my_dtd#element elm)#set_cm_and_extdecl cmodel false
	  with Pxp_types.Validation_error _ -> ()
	with Not_found ->()
      else ()) elmlst in
  my_dtd
    
let cmodel2reg elm2reg cmodel =
  let rec g' r = match r with
      Optional  reg -> Plus(g' reg , Epsilon)
    | Repeated  reg -> Star(g' reg )
    | Repeated1 reg -> if !Options.dtdstrict then Repetition (g' reg, 1, None) else Star(g' reg )
    | Alt speclst -> 
	if speclst = [] then Phi
	else
	  List.fold_right(fun reg making -> Plus(g' reg, making))(List.tl speclst) (g' (List.hd speclst) )
    | Seq speclst -> List.fold_right(fun reg making -> App(g' reg ,making)) speclst Epsilon
    | Child str  -> elm2reg str in
  let aux_mixed = function
      MPCDATA -> (try Star (elm2reg "![CDATA[]]") with Not_found -> Epsilon)
    | MChild str -> elm2reg str in
  let aux_content_model = function
      Unspecified -> raise (MyError 1)
    | Empty -> Epsilon
    | Any -> raise (MyError 2)
    | Mixed speclst -> 
	if speclst = [] then Epsilon
	else
	  Star(
	  List.fold_right(fun reg making -> Plus(making, aux_mixed reg)) (List.tl speclst) (aux_mixed (List.hd speclst))
     )
    | Regexp reg  -> g' reg in
  aux_content_model cmodel

let surface_reg elm2reg dtd tagname = 
  let get_entity tagname dtd = (dtd#element tagname)#content_model in
  let entity = get_entity tagname dtd in
  let reg = cmodel2reg elm2reg entity in
  let () = Format.printf "Content model for %s: %a@." tagname pp_content_model entity in
  let () = Options.show 1 (fun fmt -> Format.fprintf fmt "Corresponding reg: %a@." pp_reg reg) in
  reg 

let get_dtd filename =
    Pxp_yacc.parse_dtd_entity Pxp_yacc.default_config (Pxp_yacc.from_file filename)

let get_xhtml_dtd' tags =

  let cwd = Sys.getcwd () in
  let dtd_filename = !Options.dtdfile in
  let () =
    if not (Sys.file_exists dtd_filename) then
      try Sys.chdir Options.dtd_dir 
      with _ -> failwith ("Cannot change the directory for dtd: "^Options.dtd_dir) in
  let d = get_dtd dtd_filename in
  let () = Sys.chdir cwd in
  d


let get_xhtml_dtd tags =

  let cwd = Sys.getcwd () in
  let dtd_filename = !Options.dtdfile in
  let () =
    if not (Sys.file_exists dtd_filename) then
      try Sys.chdir Options.dtd_dir 
      with _ -> failwith ("Cannot change the directory for dtd: "^Options.dtd_dir) in
  let d = get_dtd dtd_filename in
  let () = Sys.chdir cwd in
  let needset = 
    List.fold_right(fun tag making ->
      ElmSet.add tag making ) tags ElmSet.empty in
  let my_dtd = new Pxp_dtd.dtd Pxp_yacc.default_config.Pxp_yacc.warner 
      Pxp_yacc.default_config.Pxp_yacc.encoding in
  cleanup_dtd d needset my_dtd


module StringMap = Support.StringMap
open Flbasics

let cmodel2cfg emap rules cmodel =
  let rec type2cfg rules r = match r with
      Optional reg -> 
	let rhs, rules = type2cfg rules reg in
	let x = Cfg.fresh_variable () in
	let rules = Cfg.prod_add (x, []) rules in
	let rules = Cfg.prod_add (x, rhs) rules in
	([Cfg.Variable x], rules)
    | Repeated  reg -> 
	let rhs, rules = type2cfg rules reg in
	let x = Cfg.fresh_variable () in
	let rules = Cfg.prod_add (x, []) rules in
	let rules = Cfg.prod_add (x, Cfg.Variable x::rhs) rules in
	([Cfg.Variable x], rules)
    | Repeated1 reg -> 
	let rhs, rules = type2cfg rules reg in
	let x = Cfg.fresh_variable () in
	let rules = Cfg.prod_add (x, rhs) rules in
	let rules = Cfg.prod_add (x, Cfg.Variable x::rhs) rules in
	([Cfg.Variable x], rules)
    | Alt speclst -> 
	let x = Cfg.fresh_variable () in
	let rules = List.fold_right (fun reg rules ->
	  let rhs, rules = type2cfg rules reg in
	  Cfg.prod_add (x, rhs) rules) speclst rules in
	([Cfg.Variable x], rules)
    | Seq speclst -> 
	List.fold_right (fun reg (rhs, rules) ->
	  let rhs1, rules = type2cfg rules reg in
	  (rhs1@rhs, rules)) speclst ([], rules) 
    | Child str  -> 
	let x = StringMap.find str emap in
	([Cfg.Variable x], rules) in
  let aux_mixed rules = function
      MPCDATA    -> 
	let x = Cfg.fresh_variable () in
	let y = Cfg.fresh_variable () in
	let rules = Cfg.Terminal_set.fold (fun c rules ->
	  if c <> '<' && c <> '>' then
	    Cfg.prod_add (y, [Cfg.Terminal c]) rules
	  else rules) Charset.charset rules in
	let rules = Cfg.prod_add (x, []) rules in
	let rules = Cfg.prod_add (x, [Cfg.Variable x; Cfg.Variable y]) rules in
	([Cfg.Variable x], rules)
    | MChild str -> 
	let x = StringMap.find str emap in
	([Cfg.Variable x], rules) in
 let aux_content_model rules = function
      Unspecified -> raise (MyError 1) 
    | Pxp_types.Empty       -> ([], rules) 
    | Any         -> raise (MyError 2) 
    | Mixed speclst   -> 
	let x = Cfg.fresh_variable () in
	let y = Cfg.fresh_variable () in
	let rules = List.fold_right (fun reg rules ->
	  let rhs, rules = aux_mixed rules reg in
	  Cfg.prod_add (x, rhs) rules) speclst rules in
	let rules = Cfg.prod_add (y, []) rules in
	let rules = Cfg.prod_add (y, [Cfg.Variable y; Cfg.Variable x]) rules in
	([Cfg.Variable y], rules)
    | Regexp reg  -> type2cfg rules reg in
  aux_content_model rules cmodel



let dtd2cfg root dtd =
  let enames = dtd#element_names in
  let ename_map = 
    List.fold_left (fun emap item -> StringMap.add item (Cfg.fresh_variable ()) emap)
    StringMap.empty enames in
  let rules = Cfg.Prod.empty in
  let rules = List.fold_left (fun rules item -> 
    let cmodel = (dtd#element item)#content_model in
    let rhs, rules = cmodel2cfg ename_map rules cmodel in
    let x = StringMap.find item ename_map in
    let otag = List.map (fun c -> Cfg.Terminal c) 
	(['<']@explode item@['>']) in
    let ctag = List.map (fun c -> Cfg.Terminal c) 
	(['<'; '/']@explode item@['>']) in
    Cfg.prod_add (x, otag@rhs@ctag) rules) rules enames in
  let rootx = StringMap.find root ename_map in
  Cfg.create rules rootx

let attribute_names dtd element =
  let dtd_elm = dtd#element element in
  dtd_elm#attribute_names


