open Il
open Ilmisc
open Support
open Dominator

type env = 
    { cflow : (var * var) list;
      varid: var list;
      varset: VarSet.t }

let empty_env =
  { cflow = [];
    varid = [];
    varset = VarSet.empty }

let extend x y env = 
  { env with cflow = (x,y)::env.cflow }

let bind x env = 
  if VarSet.mem x env.varset then failwith ("duplicate var"^string_of_var x);
  { env with varid = x::env.varid; varset = VarSet.add x env.varset }

let rec exec z env s = 
  let rec exec_stmt env s =
    match s with 
    | LocalFun (x, xs, b) -> exec x (bind x env) b
    | _ -> env
  and exec_block env s =
    match s with 
    | If (e, x1, b1, x2, b2) -> 
	let env = bind x1 (bind x2 env) in
	let env = extend z x1 (extend z x2 env) in
	exec x2 (exec x1 env b1) b2

    | Switch (e, x, cs) -> 
	let exec_case env (g, y, b) = 
	  let env = bind y env in
	  let env = extend z y env in
	  exec y env b in
	List.fold_left exec_case env cs 
    | LocalCall (x, es) -> extend z x env
    | Seq (s,b) -> exec_block (exec_stmt env s) b
    |  _ -> env in
  exec_block env s

let mk_bij size fmap =
  let garray = Array.make size (fresh_var ()) in
  VarMap.iter (fun x i -> garray.(i) <- x) fmap;
  garray

let mk_graph size fmap cflow =
  let garray = mk_bij size fmap in
  let graph = Array.make size [] in
  List.iter 
    (fun (x, y) -> 
      add_edge (VarMap.find x fmap) (VarMap.find y fmap) graph)
    cflow;
  graph, garray

let reachable env z =
  let find z graph = try VarMap.find z graph with Not_found -> [] in
  let graph = List.fold_left 
      (fun graph (x, y) -> VarMap.add x (y::find x graph) graph) 
      VarMap.empty env in
  let rec dfs xs rs =
    match xs with
      [] -> rs
    | x::xs -> if VarSet.mem x rs then dfs xs rs
    else dfs (find x graph@xs) (VarSet.add x rs) in
  dfs [z] VarSet.empty 

let rec fenv_of s =
  let rec fenv_of_stmt env s =
    match s with 
    | LocalFun (x, xs, b) -> 
	fenv_of_block (VarMap.add x (xs,b) env)  b
    | s -> env
  and fenv_of_block env s =
    match s with 
    | If (e, x1, s1, x2, s2) -> 
	fenv_of_block (fenv_of_block env s1) s2
    | Switch (e, x, cs) ->
	let fenv_of_case env (g, y, b) = fenv_of_block env b in
	List.fold_left fenv_of_case env cs
    | Seq (s,b) -> 
	fenv_of_block (fenv_of_stmt env s) b
    | s -> env in
  fenv_of_block VarMap.empty s

let rec sink s =
  let z = fresh_var () in
  let env = bind z empty_env in
  let env = exec z env s in 
  let zs = reachable env.cflow z in
  let size = VarSet.cardinal zs in
  let cflow = List.filter (fun (x,y) -> VarSet.mem x zs) env.cflow in
  let _, fmap = List.fold_right 
      (fun x (n, fmap) ->
	if VarSet.mem x zs then (n+1, VarMap.add x n fmap) 
	else (n, fmap)) env.varid (0, VarMap.empty) in
  let fenv = fenv_of s in
(*
  let () = List.iter
      (fun (x, y) -> 
	Format.printf "%s -> %s\n"
	(string_of_var (x)) (string_of_var (y))) env in
*)

  let graph, garray = mk_graph size fmap cflow in

  let domtree = Dominator.dominators graph in
(*
  let () = Array.iteri 
      (fun x y -> 
	Format.printf "%s -> %s\n"
	(string_of_var (garray.(x))) (string_of_var (garray.(y)))) domtree in
*)

  let next x =
    let i = VarMap.find x fmap in
    let xs =
      snd (Array.fold_left 
	     (fun (j, xs) k -> if j <> 0 && i = k then j+1,garray.(j)::xs else j+1,xs)
	     (0,[]) domtree) in
    xs in
(*
  let rec dfs xs rs =
    match xs with
      [] -> rs
    | x::xs -> if VarSet.mem x rs then failwith "duplication"
    else dfs (next x@xs) (VarSet.add x rs) in
  let _ = dfs [z] VarSet.empty in
*)

  let rec sink_block x s =
    match s with 
    | If (e, x1,s1,x2,s2) -> 
	let b = If (e, x1, sink_block x1 s1, x2, sink_block x2 s2) in
	let xs = next x in
	List.fold_left (fun b' x ->
	  try
	    let xs, b = VarMap.find x fenv in
	    Seq (LocalFun (x, xs, sink_block x b), b')
	  with Not_found -> b') b xs
    | Switch (e, z, cs) -> 
	let sink_case (g, y, b) = (g, y, sink_block y b) in
	let b = Switch (e, z, List.map sink_case cs) in
	let xs = next x in
	List.fold_left (fun b' x ->
	  try
	    let xs, b = VarMap.find x fenv in
	    Seq (LocalFun (x, xs, sink_block x b), b')
	  with Not_found -> b') b xs
    | Seq (s,b) -> 
	(match s with
	  LocalFun _ ->  sink_block x b
	| _ -> Seq (s, sink_block x b)) 
    | b -> 
	let xs = next x in
	List.fold_left (fun b' x ->
	  try
	    let xs, b = VarMap.find x fenv in
	    Seq (LocalFun (x, xs, sink_block x b), b')
	  with Not_found -> b') b xs  in
  sink_block z s

let sink program =
  let function_f (x, xs, b, ys, r) = (x, xs, sink b, ys, r) in
  let class_f (s, xs, ms)  =
    (s, xs, List.map (fun (s, xs, this, b, ys, r) -> (s, xs, this, sink b, ys, r)) ms) in
  map_program sink function_f class_f program
