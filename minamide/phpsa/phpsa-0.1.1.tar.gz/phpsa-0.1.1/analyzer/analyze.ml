(*
 * PHP string analyzer
 * Copyright (C) 2006 Yasuhiko Minamide
 *)
open Flbasics

let open_in filename =
  try open_in filename 
  with Sys_error _ -> failwith ("cannot open the file: "^filename)
 
let parse_spec inchan = 
  let lexbuf = Lexing.from_channel inchan in
  Specparser.main Speclexer.token lexbuf 

let get_line filename =
    let inchan = open_in filename in
    let text = input_line inchan  in
    close_in inchan;
    text

let get_fulltext filename =
    let inchan = open_in filename in
    let size = in_channel_length inchan in
    let text = String.create size in
    let rec loop pos =
      let n = input inchan text pos (size - pos) in
      if n = 0 then 
	(close_in inchan;
	 String.sub text 0 pos) 
      else loop (pos+n) in
    loop 0

let printCFG cfg = 
  let size = Cfg.Variable_set.cardinal (Cfg.vars_of cfg) in
  if size <= !Options.maxsize then Options.notice (fun fmt -> Cfg.pp_cfg fmt cfg) 
  else Format.printf "CFG of size %d@." size 

let invalid message cfg fa =
  let cfg' = Fa_cfg.inter fa cfg in
  let cfg' = cfg_simplify cfg' in
  let () = Cfg.pp_cfg Format.std_formatter cfg' in
  let sss = nwords_of cfg' 1 in
  CharListSet.iter (fun cs -> Format.printf "%a@." Support.pp_charlist cs) sss;
  failwith message 

let validate_attribute cfg =
  let () = Format.printf "Removing HTML/XHTML comments...@?" in
  let cfg, b = Ft_cfg.inter_with_check (Fts.cut_comment_ft "<!--" "-->") cfg in  
  let () = Format.printf "DONE@." in
  let () = if not b then invalid "Ill-formed comments" cfg (Fa.neg (ft2fa (Fts.cut_comment_ft "<!--" "-->"))) in
  let cfg =  
    if true then 
      let () = Format.printf "Removing CDATA content...@?" in
      let cfg, b = Ft_cfg.inter_with_check (Fts.cut_ft "<![CDATA[" "]]>") cfg in
      let () = Format.printf "DONE@." in
      let () = if not b then invalid "Ill-formed CDATA" cfg (Fa.neg (ft2fa (Fts.cut_ft "<![CDATA[" "]]>"))) in
      cfg
    else cfg in   

  let cfg = 
    if !Options.validate_mode then Ft_cfg.inter Fts.remove_nontag_ft cfg 
    else Ft_cfg.inter Fts.remove_nontag_html_ft cfg in  
  let cfg = cfg_simplify cfg in

  let () = Format.printf "Checking tags@." in
  let html_reg = if !Options.validate_mode then "/((<[^><]*>)|[^<])*/" else
  "/((<[^><]*>)|[^<]|<[^a-zA-Z])*/" in 
  let reg =  Pregparser.parse_reg html_reg in 

  let cfg = if !Options.validate_mode then cfg else Ft_cfg.inter (Fts.cut_comment_ft "<!DOCTYPE" ">") cfg in

  let automaton = Minimize.minimize (Fa.nfa2dfa (Reg2fa.reg2nfa Charset.charset reg)) in
  let automaton = Fa.neg automaton in
  let () = if not (Fa_cfg.is_disjoint automaton cfg) then invalid "Ill-formed tag" cfg automaton in

  let cfg = 
    if true then Ft_cfg.inter Fts.remove_nontag_ft cfg 
    else Ft_cfg.inter Fts.remove_nontag_html_ft cfg in  


  let () = Format.printf "Enumerating tags...@?" in
  let tags = 
    let () = Format.printf "Removing attributes...@?" in
    let cfg = Ft_cfg.inter Fts.remove_attributes_ft cfg in 
    let () = Format.printf "DONE@." in
    let tags_cfg = if !Options.validate_mode then Ft_cfg.inter Fts.extract_tags_ft cfg 
    else Ft_cfg.inter Fts.extract_tags_html_ft cfg in
    let tags_cfg = cfg_simplify tags_cfg in
    try List.map Support.implode (words_of_cfg tags_cfg)
    with exn ->
      CharListSet.iter (fun cs ->
	Format.printf "%a@."  Support.pp_charlist cs)
	(nwords_of tags_cfg 100);
      raise exn in
  let () = Format.printf "DONE@." in

  let () = Format.printf "Enumerating attributes...@." in
  let tags_cfg = if true then Ft_cfg.inter Fts.extract_tags_ft cfg 
  else Ft_cfg.inter Fts.extract_tags_html_ft cfg in
  let dtd = Dtdmisc.get_xhtml_dtd' tags in 
  List.iter (fun elm ->
    let () = Format.printf "Check attributes of %s@." elm in
    let tags_cfg = Ft_cfg.inter (Fts.filter_element_ft elm) tags_cfg in
    let tags_cfg = cfg_simplify tags_cfg in
    let () = Options.show 1 (fun fmt -> Cfg.pp_cfg fmt tags_cfg) in
    let attributes_cfg = Ft_cfg.inter Fts.extract_attribute_names_ft tags_cfg in
    let attributes_cfg = cfg_simplify attributes_cfg in
    let attribute_names =
      try List.map Support.implode (words_of_cfg attributes_cfg)
      with exn ->
	CharListSet.iter (fun cs ->
	  Format.printf "%a@."  Support.pp_charlist cs)
	  (nwords_of attributes_cfg 100);
	raise exn in
    let attribute_names = 
      List.fold_right (fun name ss -> Support.StringSet.add name ss) attribute_names Support.StringSet.empty in
    let dtd_attribute_names = Dtdmisc.attribute_names dtd elm in
    let dtd_attribute_names = 
      List.fold_right (fun name ss -> Support.StringSet.add name ss) dtd_attribute_names Support.StringSet.empty in
    Format.printf "attributes: %a@." (Basic.print_iter Support.StringSet.iter "," Format.pp_print_string) attribute_names;
    let extra_attribute_names = Support.StringSet.diff attribute_names dtd_attribute_names in
    if not (Support.StringSet.is_empty extra_attribute_names) then
      Format.printf "extra attributes: %a@." (Basic.print_iter Support.StringSet.iter "," Format.pp_print_string) 
      extra_attribute_names)
    tags


let validate cfg =
  let ptime0 = Unix.times () in
  let () = Format.printf "Removing HTML/XHTML comments...@?" in
  let cfg, b = Ft_cfg.inter_with_check (Fts.cut_comment_ft "<!--" "-->") cfg in  
  let () = Format.printf "DONE@." in
  let () = if not b then invalid "Ill-formed comments" cfg (Fa.neg (ft2fa (Fts.cut_comment_ft "<!--" "-->"))) in
  let cfg_with_nontags = cfg in 

  let cfg =  
    if !Options.validate_mode then 
      let () = Format.printf "Removing CDATA content...@?" in
      let cfg, b = Ft_cfg.inter_with_check (Fts.cut_ft "<![CDATA[" "]]>") cfg in
      let () = Format.printf "DONE@." in
      let () = if not b then invalid "Ill-formed CDATA" cfg (Fa.neg (ft2fa (Fts.cut_ft "<![CDATA[" "]]>"))) in
      cfg
    else cfg in   

  let () = Format.printf "Checking tags@." in
  let html_reg = if !Options.validate_mode then "/((<[^><]*>)|[^<])*/" else
  "/((<[^><]*>)|[^<]|<[^a-zA-Z])*/" in 
  let reg =  Pregparser.parse_reg html_reg in 

  let cfg = if !Options.validate_mode then cfg else Ft_cfg.inter (Fts.cut_comment_ft "<!DOCTYPE" ">") cfg in

  let automaton = Minimize.minimize (Fa.nfa2dfa (Reg2fa.reg2nfa Charset.charset reg)) in
  let automaton = Fa.neg automaton in
  let () = if not (Fa_cfg.is_disjoint automaton cfg) then invalid "Ill-formed tag" cfg automaton in

  let () = Format.printf "Removing attributes...@?" in
  let cfg = Ft_cfg.inter Fts.remove_attributes_ft cfg in 
  let () = Format.printf "DONE@." in

  let cfg = 
    if !Options.validate_mode then Ft_cfg.inter Fts.remove_nontag_ft cfg 
    else Ft_cfg.inter Fts.remove_nontag_html_ft cfg in  
  let cfg = cfg_simplify cfg in

  let () = Format.printf "Enumerating tags...@?" in
  let tags = 
    let tags_cfg = if !Options.validate_mode then Ft_cfg.inter Fts.extract_tags_ft cfg 
    else Ft_cfg.inter Fts.extract_tags_html_ft cfg in
    let tags_cfg = cfg_simplify tags_cfg in
    try words_of_cfg tags_cfg
    with exn ->
      CharListSet.iter (fun cs ->
	Format.printf "%a@."  Support.pp_charlist cs)
	(nwords_of tags_cfg 100);
      raise exn in
  let () = Format.printf "DONE@." in
  let () = List.iter Support.print_charlist tags in

  let show_example reg =
    let () = Format.printf "%a@." Reg.pp_reg reg in
    let () = Format.printf "DFA for the counter example...@?" in
    let automaton = Reg2fa.reg2nfa Charset.charset reg in
    let () = Format.printf "DONE@." in

    let () = Format.printf "Obtaining the grammar...@?" in
    let cfg' = Fa_cfg.inter automaton cfg_with_nontags in
    let () = Options.show 1 (fun fmt -> Cfg.pp_cfg fmt cfg') in
    let cfg' = cfg_simplify cfg' in
    let () = Format.printf "DONE@." in
    let cs = word_of cfg' in 
    Format.printf "Counter example:@.";
    Format.printf "%a@." Support.pp_charlist  cs in 

  if !Options.validate_mode then Xmlvalidate.check_balance ptime0 show_example tags cfg 
  else Htmlvalidate.check_balance show_example tags cfg 

let cfg_size cfg =
  (Cfg.Variable_set.cardinal (Cfg.vars_of cfg),
   Cfg.Prod.fold (fun x rhss size ->
     Cfg.SententialForm_set.cardinal rhss + size) cfg.Cfg.prod 0)

let show n f x = Options.show n (fun fmt -> f fmt x)

let analyzer_repetition = ref 0
let analyzer_dynamic_include = ref 0
let analyzer_dynamic_feature = ref 0

exception Reinclude

let rec il_analyze unresolved include_env spec prog n = 
  let () =  incr analyzer_repetition in
  let prog' = Abssyn.mkstmt (Abssyn.Class ("stdclass", None, [], []))::prog in
  let prog' = Expand.expand prog' in
  let () = Format.printf "Translating into IL...@?" in
  let ilprog, ilinfo = Abssyn2il.translate unresolved spec prog' in
  let () = Format.printf "DONE!@." in
  let () = show 3 Il.pp_program ilprog in

  let () = Format.printf "Translating echo...@?" in
  let ilprog = Iltrans.trans ilprog in 
  let () = Format.printf "DONE!@." in
  let () = show 3 Il.pp_program ilprog in
  let () = Format.printf "Local inline expansion...@?" in
  let ilprog = Localinline.exec ilprog in 
  let () = Format.printf "DONE!@." in 
  let () = show 3 Il.pp_program ilprog in 
  let () = Format.printf "Pre Ref : eliminating aliases ...@?" in
  let ilprog = Ref.remove_aliases ilprog in 
  let () = Format.printf "DONE!@." in
  let () = show 3 Il.pp_program ilprog in
  let () = Format.printf "Pre Ref : eliminating =& ...@?" in
  let ilprog = Ref.remove_refassignments ilprog in  
  let () = Format.printf "DONE!@." in
  let () = show 3 Il.pp_program ilprog in
  let () = Format.printf "Lambda lifting for global variables...@?" in
  let ilprog = Glift.lift ilprog in 
  let () = Format.printf "DONE!@." in
  let () = show 3 Il.pp_program ilprog in
  let () = Format.printf "Adding variable initialization...@?" in
  let ilprog = Varinit.varinit ilprog in 
  let () = Format.printf "DONE!@." in
  let () = show 3 Il.pp_program ilprog in
  let () = Format.printf "HIL2LIL...@?" in
  let ilprog = Ref.hil2lil_program ilprog in 
  let () = Format.printf "DONE!@." in
  let () = show 3 Il.pp_program ilprog in

  let () = Format.printf "Lambda lifting for local functions...@?" in
  let ilprog = Iltrans.lift ilprog in
  let () = Format.printf "DONE!@." in
  let () = show 3 Il.pp_program ilprog in
  let () = Format.printf "Renaming...@?" in
  let ilprog = Iltrans.rename ilprog in
  let () = Format.printf "DONE!@." in
  let () = show 3 Il.pp_program ilprog in

  let () = Format.printf "Checking...@?" in
  let () = Check.exec ilprog in 
  let () = Format.printf "DONE!@." in

  let () = Format.printf "Sinking...@?" in
  let ilprog = Sink.sink ilprog in
  let () = Format.printf "DONE!@." in
  let () = show 3 Il.pp_program ilprog in
  let () = Format.printf "Dropping...@?" in
  let ilprog = Pdrop.pdrop ilprog in 
  let () = Format.printf "DONE!@." in
  let () = show 2 Il.pp_program ilprog in

  let ilprog = 
    if !Options.localsymeval_mode 
    then
      let () = Format.printf "Local symbolic evaluation...@?" in
      let ilprog = Localsymeval.exec ilprog in 
      let () = Format.printf "DONE!@." in
      let () = show 2 Il.pp_program ilprog in 
      ilprog
    else ilprog in 

  let ilprog = 
    if Support.StringSet.is_empty (!Options.enable_inline)
    then ilprog 
    else
      let () = Format.printf "Inline...@?" in
      let ilprog = Inline.exec ilprog in 
      let () = Format.printf "DONE!@." in
      let () = show 2 Il.pp_program ilprog in 
      ilprog in 

  let () = Format.printf "Checking...@?" in
  let () = Check.exec ilprog in 
  let () = Format.printf "DONE!@." in

  let ilenv = Ilmisc.fenv_of_program ilprog in
  let () = Format.printf "Alias Analysis...@?" in
  let alias_env = Alias.analyse ilenv spec ilinfo ilprog in
  let () = Format.printf "DONE!@." in

  let ilprog, alias_env, ilenv = 
    if !Options.enable_deadelim then
      let () = Format.printf "Dead Code Elimination...@?" in
      let ilprog = Deadcode.deadelim alias_env ilprog in
      let () = Format.printf "DONE!@." in
      let () = show 2 Il.pp_program ilprog in

      let ilprog = 
	if !Options.enable_fullinline then
	  let () = Format.printf "Full inline...@?" in
	  let ilprog = Fullinline.exec alias_env ilprog in 
	  let () = Format.printf "DONE!@." in
	  let () = show 2 Il.pp_program ilprog in 
	  ilprog 
	else
      ilprog in

      let () = Format.printf "Checking...@?" in
      let () = Check.exec ilprog in 
      let () = Format.printf "DONE!@." in
      
      let ilenv = Ilmisc.fenv_of_program ilprog in
      let () = Format.printf "Alias Analysis...@?" in
      let alias_env = Alias.analyse ilenv spec ilinfo ilprog in
      let () = Format.printf "DONE!@." in
      ilprog, alias_env, ilenv
    else ilprog, alias_env, ilenv in 

  let ilprog, alias_env, ilenv = 
    if !Options.symeval_mode then
      let () = Format.printf "Symbolic evaluation...@?" in
      let ilprog = Symeval.exec ilenv alias_env ilprog in
      let () = Format.printf "DONE!@." in
      let () = show 2 Il.pp_program ilprog in
      
      let ilenv = Ilmisc.fenv_of_program ilprog in
      let () = Format.printf "Alias Analysis...@?" in
      let alias_env = Alias.analyse ilenv spec ilinfo ilprog in
      let () = Format.printf "DONE!@." in
      ilprog, alias_env, ilenv
    else ilprog, alias_env, ilenv in 

  let () = Format.printf "Extracting...@?" in
  let x, ys, grammar = Ilextract.extract ilenv alias_env spec ilprog in
  let () = Format.printf "DONE!@." in
  let () =  Options.show 1 (fun fmt -> Format.fprintf fmt "Output variable: %a@." Il.pp_var x) in
  let () = show 2 Ilextract.pp_grammar grammar in

  let () = Format.printf "Simplifying...@?" in
  let grammar = Opcfg.simplify grammar (x::ys) in
  let () = Format.printf "DONE!@." in
  let () = 
    match grammar with
    [] -> failwith "The empty grammar is obtained!"
    | _ -> () in
  let () = show 2
      (Basic.print_list ""
	 (fun fmt (scc, grammar) -> Format.fprintf fmt "{ %a }@.%a@."
	     (Basic.print_list "," Il.pp_var) (Opcfg.VarSet.elements scc)
	     Ilextract.pp_grammar grammar)) grammar in
 
  let () = Format.printf "Solving...@?" in
  let (rules, x, ys) = Solve.trans ilinfo alias_env (x, ys, grammar) in
  let () = Format.printf "DONE@." in
  match ys with
    [] -> 
      let () = Inspect.inspect ilprog in
      (rules, x)
  | _ ->
      let resolve bound y = 
	let cfg' = Cfg.create rules y in
	let cfg' = cfg_simplify cfg' in  
	let cfg' = 
	  match bound with
	    None -> cfg'
	  | Some reg -> 
	      let automaton = Reg2fa.reg2nfa Charset.charset reg in
	      let cfg' = Fa_cfg.inter automaton cfg' in
	      let cfg' = cfg_simplify cfg' in  
	      cfg' in
	let sss = 
	  try words_of_cfg cfg'
	  with Infinite ->
	    Cfg.pp_cfg Format.std_formatter cfg';
	    failwith ("Infinite for Unresolved")  in
	let ss = List.fold_left 
	    (fun ss s -> Support.StringSet.add (Support.implode s) ss)
	    Support.StringSet.empty sss in
	Options.show 2 
	  (fun fmt -> Format.fprintf fmt "The approximation for %d@." y);
	Format.printf "%a@." (Basic.print_iter Support.StringSet.iter "," Format.pp_print_string)  ss;
	ss in

      let () = Format.printf "Checking dynamic include...@?" in
      let repeat_include, yss = 
	Hashtbl.fold 
	  (fun y (ss, info) (b, yss) ->
	    let () = Options.show 0 
		(fun fmt -> Format.fprintf fmt "resolving "; info fmt) in
	    let bound_reg = Pregparser.parse_reg (!Options.phpfilefilter) in
	    let ss' = resolve (Some bound_reg) y in
	    let b = b || not (Support.StringSet.equal ss ss') in
	    let () = 
	      Options.show 1 (fun fmt -> 
		if  not (Support.StringSet.equal ss ss') 
		then Format.fprintf fmt "expanded@.") in
	    (b, (y, ss')::yss)) include_env (false,[]) in
      let () = Format.printf "DONE!@." in
      let () = List.iter 
	  (fun (y, ss) ->
	    let _, info = Hashtbl.find include_env y in
	    Hashtbl.replace include_env y (ss, info)) yss in
      let () = analyzer_dynamic_include := List.length yss in

      let () = if repeat_include then Format.printf "The analyzer found new files to be included.@." in

      let () = Format.printf "Checking dynamic features...@?" in
      let repeat, yss = 
	Hashtbl.fold 
	  (fun y (kind, ss, info) (b, yss) ->
	    let () = Options.show 0 
		(fun fmt -> Format.fprintf fmt "resolving "; info fmt) in
	    let bound_reg = Support.StringSet.fold (fun s reg ->
		Reg.Plus (Reg.string_reg s, reg)) kind Reg.Phi in
	    let ss' = resolve (Some bound_reg) y in
	    let ss' = Support.StringSet.union ss ss' in 
	    let b' = not (Support.StringSet.equal ss ss') in
	    let () = if b' then Options.show 1 (fun fmt -> Format.fprintf fmt "expanded.@.") in
	    let b = b || b' in
	    (b, (y, ss')::yss)) unresolved (false,[]) in
      let () = Format.printf "DONE!@." in
      let () = List.iter 
	  (fun (y, ss) -> 
	    let kind, _, info = Hashtbl.find unresolved y in
	    Hashtbl.replace unresolved y (kind, ss, info)) yss in

      let () = analyzer_dynamic_feature := List.length yss in

      if repeat_include then raise Reinclude
      else if n < !Options.loop_max && repeat then
	il_analyze unresolved include_env spec prog (n+1)
	else 
	if n < !Options.loop_max then 
	  let () = Inspect.inspect ilprog in
	  (rules, x)
	else failwith "Cannot resolve"

let analyze srcfiles =
  let spec =
    match !Options.opt_ispecfile with
      None -> Valuespec.spec_empty () 
    | Some ispecfile -> 
	Valuespec.merge_spec (parse_spec (open_in ispecfile)) in

  let () = 
    Options.show 2 
      (fun fmt -> Hashtbl.iter 
	  (fun x r -> Format.fprintf fmt "%s:%a@." x Valuespec.pp_vspec r) spec.Valuespec.vspec) in

  let result = List.fold_left (fun result srcfile -> result@Parse.parse_php srcfile) [] srcfiles in
  let () = Options.show 3 
      (fun fmt -> Format.fprintf fmt "PHP source@.%a@." Abssyn.pp_stmt_list result) in
  let srcfile = List.hd (List.rev srcfiles) in
  let include_env = Hashtbl.create 1000 in
  let rec analyze_source result =
    let result = Include.expand include_env srcfile result in  
    let result = Preprocess.exec_list result in 
    let unresolved_tbl = Hashtbl.create 1000 in
    try
      il_analyze unresolved_tbl include_env spec result 0 
    with Reinclude -> analyze_source result in
  let (rules, x) = analyze_source result in
  let cfg = Cfg.create rules x in

  let cfg = cfg_simplify cfg in
  let cfg = if !Options.simplify_mode then simplify_cfg cfg else cfg in
  let cfg = Cfg.useful cfg in
  let () =  printCFG cfg in 
  let () = 
    let (vsize, psize) = cfg_size cfg in
    if !analyzer_repetition != 0 then
      Format.printf "the number of analysis repetition: %d@." 
	(!analyzer_repetition);
(*    if !Abssyn2il.analyzer_variable_variable != 0 then
      Format.printf "the number of variable variable: %d@." 
	(!Abssyn2il.analyzer_variable_variable);
    if !analyzer_dynamic_include != 0 then
      Format.printf "the number of dynamic include: %d@." 
      (!analyzer_dynamic_include);
    if !analyzer_dynamic_feature != 0 then
      Format.printf "the number of dynamic feature: %d@." 
	(!analyzer_dynamic_feature); *)
    Format.printf "the number of variables: %d@."  vsize;
    Format.printf "the number of productions: %d@."  psize in
  cfg


let check_against_file cfg ofile =
  let text = get_fulltext ofile in
  let fa = string_fa text in
  let () = Format.printf "Checking...@?" in
  let b = Fa_cfg.is_disjoint fa cfg in 
  let () = Format.printf "DONE!@." in
  if b then 
    let () = Format.printf "FAIL: the file is NOT an example of the output.@." in
    let cfg' = Ft_cfg.inter Fts.prefix_ft cfg in
    let qs = Fa_cfg.is_disjoint' fa cfg' in
    let n = Basic.Q_set.max_elt qs in
    let () = Format.printf "The prefix of L(Prog) cannot be the following prefix of the file.@." in
    Format.printf "%s@." (String.sub text 0 n)
  else
    Format.printf "OK: the file is an example of the output approximation.@." 

let check_against_spec cfg specfile =
  let regtext = get_line specfile in
  let () = Format.printf "Regular exp: %s@." regtext in
  let r =  Pregparser.parse_reg regtext in
  if !Options.matching_mode 
  then
    let () = Format.printf "Checking...@?" in
    let cfg' = Ft_cfg.inter (Fts.matches_ft r) cfg in 
    let () = Format.printf "DONE!@." in
    let cfg' = cfg_simplify cfg' in
    let () = printCFG cfg' in
    let cfg' = chain_elim cfg' in
    let ss = words_of_cfg cfg' in
    List.iter Support.print_charlist ss
  else
    let () = Format.printf "Minimized DFA...@?" in
    let automaton = Minimize.minimize (Fa.nfa2dfa (Reg2fa.reg2nfa Charset.charset r)) in
    let automaton = if !Options.mode then automaton else Fa.neg automaton in
    let () = Format.printf "DONE!@." in
    let () = Format.printf "Checking...@?" in
    let b = Fa_cfg.is_disjoint automaton cfg in 
    let () = Format.printf "DONE!@." in
    if b then 
      if !Options.mode then Format.printf "L(Prog) and L(Spec) are disjoint.@." 
      else Format.printf "L(Prog) <= L(Spec).@." 
    else 
      let () = 
	if !Options.mode then Format.printf "L(Prog) and L(Spec) may NOT be disjoint.@." 
	else Format.printf "L(Prog) may NOT be a subset of L(Spec).@."  in
      let cfg' = Fa_cfg.inter automaton cfg in 
      let () = Format.printf "Obtaining the grammar..@?" in
      let () = printCFG cfg' in
      let cfg' = Cfg.useful cfg' in 
      let () = Format.printf "DONE@." in
      printCFG cfg';
      Format.printf "Counter example:@.";
      Support.print_charlist (word_of cfg')

let check cfg =
  match (!Options.opt_specfile, !Options.opt_ofile, 
	 !Options.tagchecking_mode || !Options.validate_mode, !Options.validate_attribute_mode) with
    (None, None, false, false) -> 
      let n = !Options.nexamples in
      if n > 0 then
	let _ = 
	  CharListSet.fold (fun cs n ->
	    let ochan = 
	      open_out (Format.sprintf "tmp/test%d.html" n) in
	    output_string ochan (Support.implode  cs);
	    close_out ochan; n+1) (nwords_of cfg n) 0 in
	()
  | (Some specfile, _, _,_) -> check_against_spec cfg specfile
  | (_, Some ofile, _,_) -> check_against_file cfg ofile
  | (_, _, true,_) -> validate cfg
  | (_, _, _, true) -> validate_attribute cfg

