  open Support
open Il

let find_fun x env = VarMap.find x env

let add_fun x d env = VarMap.add x d env

let count x env = 
  let xs, b, n = find_fun x env in
  add_fun x (xs, b, n+1) env

let rec fenv_of s =
  let rec fenv_of_stmt env s =
    match s with 
    | LocalFun (x, xs, b) -> 
	  fenv_of_block (add_fun x (xs, b, 0) env) b
    | s -> env
  and fenv_of_block env s =
    match s with 
    | If (e, x1, s1, x2, s2) -> 
	fenv_of_block (fenv_of_block env s1) s2
    | Switch (e, x, cs) ->
	let fenv_of_case env (g, y, b) = fenv_of_block env b in
	List.fold_left fenv_of_case env cs
    | Seq (s,b) -> 
	fenv_of_block (fenv_of_stmt env s) b
    | LocalCall (x, es) -> count x env
    | s -> env in
  fenv_of_block VarMap.empty s

let exec b = 
  let env = fenv_of b in

  let rec exec s =
    match s with 
(*    | Function (x, xs, b, zs, r) -> 
	Function (x, xs, exec_block b, zs, r)
    | Class (s, xs, ms) -> 
	let exec_method (x, xs, this, b, zs, r) =
	  (x, xs, this, exec_block b, zs, r) in
	Class (s, xs, List.map exec_method ms) *)
    | LocalFun (x, xs, b) -> failwith "LocalFun"
    | e -> e
  and exec_block b =
    match b with 
    | If (e, x1, s1, x2, s2) -> If (e, x1, exec_block s1, x2, exec_block s2)
    | Switch (e, x, cs) -> 
	let exec_case (g, y, b) = (g, y, exec_block b) in
	Switch (e, x, List.map exec_case cs) 
    | LocalCall (x, es) -> 
	let rec mk_assignments xs es b =
	  match (xs, es) with
	    ([], []) -> b
	  | (x::xs, e::es) -> Seq (Assign (x, e), mk_assignments xs es b)
	  | _ -> failwith "mk_assigns" in
	let xs,b',n = find_fun x env in  
	(match n with
	  1 -> mk_assignments xs es (exec_block b')
	| _ -> b)
    | Seq (LocalFun (x, xs, b0), b) ->
	let _,_,n = find_fun x env in  
	if n <= 1 then  exec_block b
	else
	  Seq (LocalFun (x, xs, exec_block b0), 
	       exec_block b)
    | Seq (s, b) -> Seq (exec s, exec_block b)
    | b -> b in
  exec_block b 

let exec program =
  let function_f (x, xs, b, zs, r) = (x, xs, exec b, zs, r) in
  let class_f (s, xs, ms) =
    let exec_method (x, xs, this, b, zs, r) =
      (x, xs, this, exec b, zs, r) in
    (s, xs, List.map exec_method ms) in
  map_program exec function_f class_f program

