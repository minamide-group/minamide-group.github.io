(*
 * PHP string analyzer
 * Copyright (C) 2006 Yasuhiko Minamide
 *)

let () =
  let set_maxsize s = Options.maxsize := int_of_string s in
  let set_debuglevel s = 
    let l = int_of_string s in 
    Basic.debug_level := l;
    Options.debug_level := l  in
  let set_nexamples s = Options.nexamples := int_of_string s in
  let set_specfile s = Options.opt_specfile := Some s in
  let set_ispecfile s = Options.opt_ispecfile := Some s in
  let set_ofile s = Options.opt_ofile := Some s in
  let set_dtdfile s = Options.dtdfile := s in
  let set_inline s = 
    Options.enable_inline := Support.StringSet.add s (!Options.enable_inline) in
  let set_lib s = Options.libs := s::!Options.libs in
  let set_include s = Options.include_path := s::!Options.include_path in
  let test_mode = ref false in
  let srcfiles = ref [] in
  let set_srcfiles s = srcfiles := s::!srcfiles in
  let argspec = 
    [("-spec", Arg.String set_specfile, "Specification file");
     ("-file", Arg.String set_ofile, "Checking whether the file is a member of L(Prog): (for debugging)");
     ("-ispec", Arg.String set_ispecfile, "Input specification file");
     ("-maxsize", Arg.String set_maxsize, "Th maximum size of printed CFGs");
     ("-level", Arg.String set_debuglevel, "Debug level");
     ("-nexamples", Arg.String set_nexamples, "Number of examples");
     ("-simplify", Arg.Set Options.simplify_mode, "Simplify mode");
     ("-symeval", Arg.Set Options.symeval_mode, "Symbolic evaluation mode");
     ("-localsymeval", Arg.Set Options.localsymeval_mode, "Local symbolic evaluation mode");
     ("-fullinline", Arg.Set Options.enable_fullinline, "Full inline expansion");
     ("-deadelim", Arg.Set Options.enable_deadelim, "Dead Code Elimination");
     ("-inline", Arg.String set_inline, "Enabling inline expansion");
     ("-lib", Arg.String set_lib, "PHP libraries");
     ("-include", Arg.String set_include, "additional directory where the analyzer searches PHP files");
(*     ("-matching", Arg.Set Options.matching_mode, "Matching mode"); *)
     ("-htmlvalidate", Arg.Set Options.tagchecking_mode, "HTML validation (experimental)");
     ("-validate-attribute", Arg.Set Options.validate_attribute_mode, "XML attribute validation (experimental)");
     ("-validate", Arg.Set Options.validate_mode, "XHTML validation");
     ("-exit-analysis", Arg.Set Options.exit_analysis_mode, "Analyzing the execution paths ending with explicit an exit command");
(*     ("-trace", Arg.Set Options.trace_mode, "Trace mode"); *)
     ("-inclusion", Arg.Clear Options.mode, "Mode of checking: L(srcfile) <= L(specfile)");
     ("-xml", Arg.Set Options.xml_mode, "XML Mode");
     ("-check-depth", Arg.Set Options.check_depth, "Display the maximum depth of the generated XML documents");
     ("-test", Arg.Set test_mode, "Run the tests in the test directory");
     ("-dtdfile", Arg.String set_dtdfile, "DTD file");
     ("-short-open-tag", Arg.Set Options.short_open_tag, "All short open tag (<?)");
     ("-mysql", Arg.Set Options.assert_mode, "Analyze query strings in mysql_query");
     ("-xmlstrict", Arg.Set Options.dtdstrict, "Strict checking of content model \"+\"")] in
  Arg.parse argspec set_srcfiles "Usage: phpsa <options> <php files>";
  if !test_mode then Test_phpsa.test ()
  else
    match !srcfiles with
      [] -> failwith "no php file"
    | srcfiles -> 
	let libs = List.map (fun n -> Filename.concat Options.lib_dir n) (List.rev (!Options.libs)) in
	Analyze.check (Analyze.analyze (libs@srcfiles))
