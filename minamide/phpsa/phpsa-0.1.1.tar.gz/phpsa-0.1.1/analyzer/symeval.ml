open Support
open Il
open Alias
open Phptype

type value = 
    Vstring 
  | Vstringval of string 
  | Vint
  | Vfloat
  | Vbool
  | Vboolval of bool
  | Vnull
  | Varray 
  | Vresource
  | Vobject 
  | Vbox

let string_of_value v =
  match v with
  | Vstring  -> "STRING"
  | Vstringval s -> s
  | Vint  -> "INT"
  | Vnull  -> "null"
  | Vfloat  -> "FLOAT"
  | Vbool  -> "BOOL"
  | Vboolval b -> if b then "TRUE" else "FALSE"
  | Varray -> "ARRAY"
  | Vresource -> "RESOURCE"
  | Vobject -> "OBJECT"
  | Vbox -> "BOX"

module ValueSet =
  Set.Make(struct 
    type t = value
    let compare = compare
  end)

let avalue2value w = 
  match w with
   Alias.Vbox _ -> Vbox
  | Alias.Vstring -> Vstring 
  | Alias.Vstringval s -> Vstringval s
  | Alias.Vint -> Vint
  | Alias.Vintval i -> Vint
  | Alias.Vfloat -> Vfloat
  | Alias.Vbool -> Vbool
  | Alias.Vboolval b  -> Vboolval b
  | Alias.Vnull -> Vnull
  | Alias.Varray _ -> Varray 
  | Alias.Vresource -> Vresource
  | Alias.Vobject _ -> Vobject 
  | _ -> failwith "avalue2value"

let lookup env x = 
  let ws = Alias.lookup_var env (Alias.Vvar x) in
  Vset.fold (fun w vs -> ValueSet.add (avalue2value w) vs) 
    ws ValueSet.empty 

let vset v = ValueSet.singleton v

type absbool =
    AbsBool
  | AbsTrue
  | AbsFalse
  | AbsBot

let value2bool v =
  match v with
  | Vstring  -> AbsBool
  | Vstringval s -> 
      (match s with
	"" | "0" -> AbsFalse
      |	_ -> AbsTrue)
  | Vint  -> AbsBool
  | Vnull  -> AbsFalse
  | Vfloat  -> AbsBool
  | Vbool  -> AbsBool
  | Vboolval b -> if b then AbsTrue else AbsFalse
  | Varray -> AbsBool
  | Vresource -> AbsTrue
  | Vobject -> AbsTrue
  | Vbox -> AbsBool


let vs2absbool vs =
  ValueSet.fold (fun v b ->
    match (value2bool v, b) with
      (AbsTrue, AbsTrue) -> AbsTrue 
    | (AbsTrue, AbsBot) -> AbsTrue 
    | (AbsFalse, AbsFalse) -> AbsFalse
    | (AbsFalse, AbsBot) -> AbsFalse
    | _ -> AbsBool) vs AbsBot

let absbool_not b =
    match b with
      AbsTrue -> AbsFalse
    | AbsFalse -> AbsTrue
    | AbsBot -> AbsBot
    | AbsBool -> AbsBool

let absbool2vs b =
    match b with
      AbsTrue -> vset (Vboolval true)
    | AbsFalse -> vset (Vboolval false)
    | AbsBot -> vset Vbool
    | AbsBool -> vset Vbool

let vs_equal vs1 vs2 =
  if ValueSet.is_empty vs1 || ValueSet.is_empty vs2 then AbsBool
  else
    let v1 = ValueSet.choose vs1 in
    let vs1 = ValueSet.remove v1 vs1 in
    let v2 = ValueSet.choose vs2 in
    let vs2 = ValueSet.remove v2 vs2 in
    if ValueSet.is_empty vs1 && ValueSet.is_empty vs2 then 
      match v1, v2 with
	Vstringval s1, Vstringval s2 when s1 = s2 -> AbsTrue
      | Vstringval s1, Vstringval s2 -> AbsFalse
      | Vboolval b1, Vboolval b2 when b1 = b2 -> AbsTrue
      | Vboolval b1, Vboolval b2 -> AbsFalse
      | Vnull, Vnull -> AbsTrue
      | _ -> AbsBool
    else AbsBool


let rec eval_const env const =
  match const with
    ConstInt i -> vset Vint
  | ConstBool b -> vset (Vboolval b)
  | ConstFloat f -> vset Vfloat
  | ConstString s -> vset (Vstringval s)
  | ConstArray _ -> vset Varray
  | ConstConst x -> lookup env x
  | ConstBox _ -> vset Vbox

let rec eval_vspec vspec =
  match vspec with
    Valuespec.Vregexp r -> vset Vstring
  | Valuespec.Vdtd _ -> vset Vstring
  | Valuespec.Vint -> vset Vint
  | Valuespec.Vfloat -> vset Vfloat
  | Valuespec.Vbool -> vset Vbool
  | Valuespec.Vboolval b -> vset (Vboolval b)
  | Valuespec.Vresource -> vset Vresource
  | Valuespec.Vnull -> vset Vnull
  | Valuespec.Varray (vspec,x,y,z) -> vset Varray
  | Valuespec.Varray2 (keyspec,vspec,x,y,z) -> vset Varray
  | Valuespec.Vor (vspec1,vspec2, x) -> 
      ValueSet.union (eval_vspec vspec1) (eval_vspec vspec2)
  | Valuespec.Vstring -> vset Vstring
  | Valuespec.Vobject _ -> vset Vobject
  | Valuespec.Vmixed -> failwith "mixed"
  | Valuespec.Varray0 -> failwith "array0"


let rec eval env exp =
  match exp with
    Var x -> lookup env x
  | Vspec vspec -> eval_vspec vspec
  | Dref (x,y) -> lookup env y
  | Const x -> lookup env x
  | ConstExp const -> eval_const env const
  | Null -> vset Vnull
  | Int i -> vset Vint
  | Float f -> vset Vfloat
  | Bool b -> vset (Vboolval b)
  | String s -> vset (Vstringval s)
  | Prim (p, es, (x,y,z,_)) -> 
      (match p with
	Concat | Cast StringTy -> vset Vstring
      | Cast FloatTy -> vset Vfloat
      | Plus | Minus | Times | Div | Mod | Cast IntTy -> vset Vint
      | Bitnot | Bitand | Bitor | Bitxor | Bitshiftl | Bitshiftr -> vset Vint
      | Eq ->
	  (match es with
	    [e1; e2] ->
	      let vs1, vs2 = eval env e1, eval env e2 in
	      absbool2vs (vs_equal vs1 vs2)
	  | _ -> failwith "eq")
      | Neq ->
	  (match es with
	    [e1; e2] ->
	      let vs1, vs2 = eval env e1, eval env e2 in
	      absbool2vs (absbool_not (vs_equal vs1 vs2))
	  | _ -> failwith "eq")
      | Lt | Le | Gt | Ge | Not | Xor | Cast BoolTy -> vset Vbool
      | Cast _ -> failwith "cast object or array"
      | NewRef -> vset Vbox
      | NewArray -> vset Varray
      | NewArrayL _ -> failwith "NewArrayL before symeval"
      | InitArray _ -> vset Varray
      | NewObj classname -> vset Vobject
      | InitObj _ -> vset Vobject
      | CheckFunction _ | CheckMethod _ -> vset Vbool
      | StringUpdate -> vset Vstring
      | ArrayDref -> lookup env z)
  | App (s, es, (x,y,z,_)) -> 
      match s with
	"explode" | "preg_split" | "str_split" -> vset Varray
      | "array_slice" ->
	  (match es with
	    e::_ -> eval env e
	  | _ -> failwith "array_slice")
      | "array_keys" -> vset Varray
      | "array_values" -> vset Varray
      | "array_chunk" -> vset Varray
      | "array_merge" -> vset Varray
      | "array_push" -> vset Vint
      | "array_pop" -> lookup env y
      | "array_count_values" -> vset Varray
      | "end" | "current" | "next" | "pos" | "prev" | "reset" -> lookup env z
      | "key" -> lookup env x
      | "each" -> vset Varray
      | "__preg_match_array" -> vset Varray 
      | "isset" -> 
	  (match es with
	    e::_ -> 
	      let v = eval env e in
	      vset 
	      (if ValueSet.for_all (fun x -> x = Vnull) v 
	      then 
		if ValueSet.mem Vnull v then Vboolval true
		else Vbool 
              else if ValueSet.mem Vnull v then Vbool else Vboolval false)
	  | _ -> failwith "isset") 
      | "empty" -> 
	  (match es with
	    e::_ -> 
	      let v = eval env e in
	      (match vs2absbool v with
		AbsTrue -> vset (Vboolval false)
	      |	AbsFalse -> vset (Vboolval true)
	      |	_ -> vset Vbool)
	  | _ -> failwith "empty")
      | _ ->
	  try
	    eval_vspec (Phpprim.find_type s)
	  with Not_found -> failwith s
and eval_list env es = List.map (fun e -> eval env e) es

let is_int_string s =
  if s = "0" then true 
  else
    let len = String.length s in
    if len = 0 then false
    else
      let n = 
	match String.get s 0 with
	  '-' -> 1
	| _ -> 0 in
      if len = n then false
      else
	let rec is_int_string' s n =
	  if n < len then
	    let c = String.get s n in
	    if c >= '1' && c <= '9' then is_int_string' s (n+1)
	    else false
	  else true  in
	is_int_string' s n

let exec ilenv env b = 
  let rec exec env s =
    match s with 
    | LocalFun (x, xs, b) -> 
	LocalFun (x, xs, exec_block env b)
    | Assign (x, Prim (InitArray y, [e], info)) ->
	let vs = eval env e in
	if ValueSet.exists (fun x -> not (x = Vnull)) vs
	then
	  if ValueSet.mem Vnull vs then s 
	  else Assign (x, e)  
	else 
	  if ValueSet.mem Vnull vs 
	  then (* Assign (x, Prim (NewArray, [], info)) *)
	    let y1, y2, y3,l = info in
	    let ws = Alias.lookup_var env (Alias.Vvar y2) in
	    let sxys = 
	      Vset.fold (fun w sxys -> 
		match w with
		  Alias.Vstringval s -> (s, fresh_var (), fresh_var ())::sxys
		| _ -> sxys) ws [] in
	    Assign (x, Prim (NewArrayL sxys, [], (y1,y2,y3,l)))
	  else Assign (x, e)  
    | Assign (x, Prim (InitObj y, [e], _)) ->
	let vs = eval env e in
	if ValueSet.exists (fun x -> not (x = Vnull)) vs
	then
	  if ValueSet.mem Vnull vs then s 
	  else Assign (x, e)  
	else 
	  if ValueSet.mem Vnull vs then
	    Assign (x, Prim (NewObj "stdclass", [], fresh_info' ()))
	  else s
    | Assign (x, Prim (NewArray, [], (y1,y2,y3,loc))) ->
	let ws = Alias.lookup_var env (Alias.Vvar y2) in
	let sxys = 
	  Vset.fold (fun w sxys -> 
	    match w with
	      Alias.Vstringval s -> (s, fresh_var (), fresh_var ())::sxys
	    | _ -> sxys) ws [] in
	Assign (x, Prim (NewArrayL sxys, [], (y1,y2,y3,loc)))
    | _ -> s
  and exec_block env s =
    match s with 
    | If (e, x1, s1, x2, s2) -> 
	let vs = eval env e in
	(match vs2absbool vs with
	  AbsTrue -> exec_block env s1
	| AbsFalse -> exec_block env s2
	| _ -> 
	    If (e, x1, exec_block env s1, x2, exec_block env s2))
    | Switch (e, x, cs) ->
	let vs = eval env e in
	let cs1, cs2 = List.fold_right (fun (g, y, b) (cs1, cs2) ->
	  match g with
	    Some g -> (g, y, b)::cs1, cs2
	  | None -> cs1, (y, b)::cs2) cs ([], []) in
	let ss1 = List.map (fun (g, _, _) -> g) cs1 in

	let exec_case (g, y, b) cs = 
	  let absb =
	    ValueSet.fold (fun v absb ->
	      match v with
		Vstringval s ->  
		  (match absb, String.lowercase s = g with
		    AbsBot,  b ->  if b then AbsTrue else AbsFalse 
		  | AbsTrue, true -> AbsTrue
		  | AbsFalse, false -> AbsFalse
		  | _ -> AbsBool)
	      | _ -> AbsBool ) vs AbsBot in
	  match absb with
	    AbsFalse -> cs
	  | _ -> (Some g, y, exec_block env b)::cs in
	let cs1 =  List.fold_right exec_case cs1 [] in
	let cs2 =  
	  let absb =
	    ValueSet.fold (fun v absb ->
	      match v with
		Vstringval s ->  
		  let b = List.exists (fun g -> s = g) ss1 in
		  (match absb, b with
		    AbsBot,  b ->  if b then AbsTrue else AbsFalse 
		  | AbsTrue, true -> AbsTrue
		  | AbsFalse, false -> AbsFalse
		  | _ -> AbsBool)
	      | _ -> AbsBool ) vs AbsBot in
	  match absb with
	    AbsTrue -> []
	  | _ -> List.map (fun (y, b) -> (None, y, exec_block env b)) cs2 in
	Switch (e, x, cs1@cs2)
    | LocalCall (x, es) -> LocalCall (x, es)
    | Seq (s,b) -> Seq (exec env s, exec_block env b) 
    | _ -> s in
  let function_f (x, xs, b, zs, r) = (x, xs, exec_block env b, zs, r) in
  let class_f (s, xs, ms) =
    let exec_method env (x, xs, this, b, zs, r) =
      (x, xs, this, exec_block env b, zs, r) in
    let _, _, _, c = Ilmisc.find_class ilenv s in
    let ws = Alias.lookup_var env (Alias.Vvar c) in
    let ys = Alias.Vset.fold (fun w ys ->
      match w with
	Alias.Vstringval s -> (s, None)::ys
      | _ -> ys) ws [] in
    (s, xs@ys, List.map (exec_method env) ms) in
  map_program (exec_block env) function_f class_f b
