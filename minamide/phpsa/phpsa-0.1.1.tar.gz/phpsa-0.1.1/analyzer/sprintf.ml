(*
 * PHP string analyzer
 * Copyright (C) 2006 Yasuhiko Minamide
 *)
open Flbasics

type fmttype =
    IBinary | IChar | IDecimal | IUnsigned | Float
  | IOctal | String | IHexadecimal | IUpperHexadecimal

type fmt =
    FmtString of char list 
  | FmtType of char * bool * int option * int * fmttype 
            (* pad    align * length       precision    type 
               precision default = 6                  *)

let cons_fmt_string cs fmts =
  match cs with
    [] -> fmts
  | _ -> FmtString (List.rev cs)::fmts

let compute_size nopt m =
  match nopt with
    None -> Some m
  | Some n -> Some (n * 10 + m)

let char2int c = Char.code c - Char.code '0'

let rec parse_nonfmt ds cs fmts =
  match cs with
    [] -> List.rev (cons_fmt_string ds fmts)
  | '%'::cs -> parse_pad cs (cons_fmt_string ds fmts)
  | c::cs -> parse_nonfmt (c::ds) cs fmts
and parse_pad cs fmts =
  match cs with
   '%'::cs -> parse_nonfmt ['%'] cs fmts
  |'0'::cs -> parse_alignment '0' None cs fmts
  |' '::cs -> parse_alignment ' ' None cs fmts
  |'\''::c::cs -> parse_alignment c None cs fmts
  | _ -> parse_alignment ' '  None  cs fmts
and parse_alignment pad n cs fmts =
  match cs with
   '-'::cs -> parse_size pad false None  cs fmts
  | _ -> parse_size pad true None  cs fmts
and parse_size pad alignment n cs fmts =
  match cs with
    c::cs when c >= '0' && c <= '9' -> 
      parse_size pad alignment (compute_size n  (char2int c)) cs fmts
  | '.'::c::cs when c >= '0' && c <= '9' -> 
      parse_precision pad alignment n (char2int c) cs fmts 
  | '.'::cs -> parse_type pad alignment n 6 cs fmts 
  | _ -> parse_type pad alignment n 6 cs fmts 
and parse_precision pad alignment n precision cs fmts =
  match cs with
    c::cs when c >= '0' && c <= '9' -> 
      parse_precision pad alignment n (precision * 10 + char2int c) cs fmts 
  | _ -> parse_type pad alignment n precision cs fmts 
and parse_type pad alignment n precision cs fmts =
  match cs with
    [] -> failwith "sprintf parse_type" 
  | c::cs ->
      let fmttype =
	match c with
	'b' ->  IBinary
      | 'c' ->  IChar
      | 'd' ->  IDecimal
      | 'u' ->  IUnsigned
      | 'f' ->  Float
      | 'o' ->  IOctal
      | 's' ->  String
      | 'x' ->  IHexadecimal
      | 'X' ->  IUpperHexadecimal
      | _ ->  failwith "sprintf parse_type" in
      parse_nonfmt [] cs (FmtType (pad, alignment, n, precision, fmttype)::fmts) 

let parse fmtcs = parse_nonfmt [] fmtcs []

let iunsigned_reg = Pregparser.parse_reg "/0|[1-9][0-9]*/" 
let idecimal_reg = Pregparser.parse_reg "/0|-{0,1}[1-9][0-9]*/"  
let ibinary_reg = Pregparser.parse_reg "/0|1[0-1]*/" 
let ioctal_reg = Pregparser.parse_reg "/0|[1-7][0-7]*/" 
let ihexadecimal_reg = Pregparser.parse_reg "/0|[1-9a-f][0-9a-f]*/" 
let iupperhexadecimal_reg = Pregparser.parse_reg "/0|[1-9A-F][0-9A-F]*/" 
let ichar_reg = Pregparser.parse_reg "/[^]/" 
let float_reg n = 
  Pregparser.parse_reg (Printf.sprintf "/(0|-{0,1}[1-9][0-9]*)\\.[0-9]{%d,%d}/" n n)


let fmttype2prod (pad,alignment,optlen,precision,fmttype) y prod =
  let app_pad len (x, p) =
    let s = fresh_var () in
    let p = 
      if alignment then prod_add (s,Cfg.Terminal Fts.mark_char ::x) p
      else prod_add (s,x@[Cfg.Terminal Fts.mark_char]) p in
    let cfg = Cfg.create p s in
    let ft = Fts.pad_ft pad len in
    let ft = if alignment then Ft.rev ft else ft in
    let {Cfg.prod = p; Cfg.start = s} = Ft_cfg.inter ft cfg in
    ([Cfg.Variable s], prod_union p prod) in
  let mkcfg reg = 
    match optlen with
      None -> reg2cfg reg prod
    | Some len -> app_pad len (reg2cfg reg Cfg.Prod.empty) in
  match fmttype with
    IBinary -> mkcfg ibinary_reg 
  | IChar -> mkcfg ichar_reg 
  | IDecimal -> mkcfg idecimal_reg 
  | IUnsigned -> mkcfg iunsigned_reg
  | Float -> 
      if precision = 0 then mkcfg idecimal_reg
      else 
	let reg = float_reg precision in
	(match optlen with
	  None -> reg2cfg reg prod
	| Some len -> app_pad (len+precision+1) (reg2cfg reg Cfg.Prod.empty))
  | IOctal -> mkcfg ioctal_reg
  | String -> 
      (match optlen with
	None -> ([Cfg.Variable y], prod)
      | Some len -> 
	  let x = fresh_var () in
	  let prod = prod_add (x,[]) prod in
	  let prod = prod_add (x, [Cfg.Variable x; Cfg.Terminal pad]) prod in
	  app_pad len ([Cfg.Variable x; Cfg.Variable y], prod))
  | IHexadecimal -> mkcfg ihexadecimal_reg
  | IUpperHexadecimal -> mkcfg iupperhexadecimal_reg

let rec fmts2prod fmts ys prod = 
  match fmts with
    [] -> 
      (match ys with 
	[] -> ([], prod)
      | _ -> failwith "fmts2prod")
  | FmtString cs::fmts -> 
      let rhs, prod = fmts2prod fmts ys prod in
      (List.map (fun x -> Cfg.Terminal x) cs@rhs, prod)
  | FmtType (pad, alignment, len, precision, fmttype)::fmts -> 
      (match ys with
	[] -> failwith "fmts2prod"
      | y::ys -> 
	  let rhs, prod = fmts2prod fmts ys prod in
	  let ss, prod = fmttype2prod (pad, alignment, len, precision, fmttype) y prod in
	  (ss@rhs, prod))

let fmtcs2prod ss ys prod = 
  let (rhs, prod) = fmts2prod (parse ss) ys prod in
  let x = fresh_var () in
  (x, prod_add (x, rhs) prod)

(* functions for vsprintf *)

let rec fmts2prod_v fmts y prod = 
  match fmts with
    [] -> ([], prod)
  | FmtString cs::fmts -> 
      let rhs, prod = fmts2prod_v fmts y prod in
      (List.map (fun x -> Cfg.Terminal x) cs@rhs, prod)
  | FmtType (pad, alignment, len, precision, fmttype)::fmts -> 
      let rhs, prod = fmts2prod_v fmts y prod in
      let ss, prod = fmttype2prod (pad, alignment, len, precision, fmttype) y prod in
      (ss@rhs, prod)

let fmtcs2prod_v ss y prod = 
  let (rhs, prod) = fmts2prod_v (parse ss) y prod in
  let x = fresh_var () in
  (x, prod_add (x, rhs) prod)
      

      

  
