(*
 * PHP string analyzer
 * Copyright (C) 2006 Yasuhiko Minamide
 *)

open Support

type prim = 
    Plus | Minus | Times | Div | Mod
  | Concat 
  | Eq | Neq | Le | Lt | Ge | Gt 
  | Andand | Oror | Xor | Print | Exit | Not | Pif 
  | Bitnot | Bitand | Bitor | Bitxor | Bitshiftl | Bitshiftr 
  | Cast of Phptype.phptype

type var = string

let current_id = ref 0;;
let fresh_id () =
  current_id := !current_id + 1;
  !current_id;;
let fresh_var () = "$___" ^ string_of_int (fresh_id ())

type fparam = var * Const.const option * bool
  (* true : if returning reference *)

type varinit = var * Const.const option

type exp =
    { exp_desc : exp_desc;
      exp_loc : Loc.loc }
and exp_desc = 
    Lvalue of lvalue
  | Null 
  | Const of string
  | Int of int
  | Float of float
  | String of string
  | Bool of bool
  | Prim of prim * exp list
  | App of string * exp list
  | AppVar of exp * exp list
  | NewArray of (exp * exp) list
  | ClassMethod of string * string * exp list 
    (* classname * methodname * arguments *) 
  | Method of exp * string * exp list
    (* object * methodname * arguments *) 
  | NewObj of string * exp list
  | RefAssign of lvalue * lexp
  | LAssign of lvalue * exp
  | LOpAssign of lvalue * prim * exp
  | ListAssign of lvalue option list * exp
  | UClassMethod of string * exp * exp list
  | UMethod of exp * exp * exp list
  | UNewObj of exp * exp list
  | IncludeExp of bool * exp  * Support.StringSet.t * 
	(string * stmt list) list
  | FileBlock of string * string * stmt list
  | Define of string * exp 
  | StmtExp of stmt list * exp
and lvalue =
    { lvalue_desc : lvalue_desc;
      lvalue_loc : Loc.loc }
and lvalue_desc =
  | LVar of var
  | LVarVar of exp
  | LArray1 of lvalue
  | LArray2 of lvalue * exp  
  | LObjRef of lvalue * string
  | LUObjRef of lvalue * exp
  | LStringRef of lvalue * exp
and lexp =
  | Lv of lvalue 
  | Exp of exp
and stmt =
    { stmt_desc : stmt_desc;
      stmt_loc : Loc.loc }
and stmt_desc = 
    ExpSt of  exp
  | Echo of  exp
  | Unset of lvalue
  | BlockSt of  stmt list
  | While of exp * stmt
  | DoWhile of stmt * exp
  | For of exp list * exp list * exp list * stmt
  | If of exp * stmt * stmt
  | Assert of  exp * string
  | Function of string * fparam list * stmt * bool 
    (* funcation name * formal prameters * body *   *
     * flag (true when returning reference)         *)
  | Return of exp
  | Break of int 
  | Continue of int
  | Skip
  | Global of var list
  | Static of varinit list  
  | Switch of exp * (exp option * stmt list) list 
  | Foreach of exp * var option * var * stmt
  | Class of string * string option * fparam list * (string * (fparam list) * stmt * bool) list 

let mkexp expdesc = { exp_desc = expdesc; exp_loc = Loc.dummy_loc () } 
let mkstmt stmtdesc = { stmt_desc = stmtdesc; stmt_loc = Loc.dummy_loc () } 
let mklvalue lvdesc = { lvalue_desc = lvdesc; lvalue_loc = Loc.dummy_loc () } 

let aloc_of_exp exp = exp.exp_loc.Loc.aloc 
let aloc_of_sttmt stmt = stmt.stmt_loc.Loc.aloc 

let string_of_prim p =
  match p with
    Plus -> "+"
  | Minus -> "-"
  | Times -> "*"
  | Div -> "/"
  | Concat -> "."
  | Eq -> "=="
  | Neq-> "!="
  | Le -> "<="
  | Lt -> "<"
  | Ge -> ">="
  | Gt -> ">" 
  | Andand -> "&&" 
  | Oror -> "||" 
  | Print -> "print" 
  | Exit -> "exit" 
  | Not -> "!" 
  | Xor -> "xor" 
  | Mod -> "%" 
  | Pif -> "pif" 
  | Bitnot -> "~"
  | Bitand -> "&"
  | Bitor -> "|"
  | Bitxor -> "^"
  | Bitshiftl -> "<<"
  | Bitshiftr -> ">>"
  | Cast t -> "(" ^ Phptype.string_of_phptype t ^ ")"

let pp_prim ff p = Format.pp_print_string ff (string_of_prim p)

let pp_fparam ff fparam =
  match fparam with
    (x, None, false) -> Format.fprintf ff "%s" x
  | (x, None, true) -> Format.fprintf ff "&%s" x
  | (x, Some const, _) -> 
      Format.fprintf ff "%s = %a" x Const.pp_const const

let rec pp_exp ff e =
  match e.exp_desc with 
    Lvalue lv -> pp_lvalue ff lv
  | Null -> Format.fprintf ff "NULL"
  | Const s -> Format.fprintf ff "%s" s
  | Int i -> Format.fprintf ff "%d" i
  | Float f -> Format.fprintf ff "%f" f
  | String s -> Format.fprintf ff "\"%s\"" (String.escaped s)
  | Bool b -> 
      let bs = if b then "TRUE" else "FALSE" in
      Format.fprintf ff "%s" bs
  | Prim (Concat, [e1; e2]) -> 
      Format.fprintf ff "(%a.%a)" pp_exp e1 pp_exp e2 
  | Prim (p, es) -> 
      Format.fprintf ff "%s(%a)" 
	(string_of_prim p) pp_exp_list es
  | App (p, es) -> 
      Format.fprintf ff "%s(%a)" p pp_exp_list es
  | AppVar (e, es) -> 
      Format.fprintf ff "%a(%a)" pp_exp e pp_exp_list es
  | NewArray _ -> Format.fprintf ff "newarray"
  | ClassMethod (cname, mname, es) -> 
      Format.fprintf ff "%s::%s(%a)" cname mname pp_exp_list es
  | Method (e, mname, es) -> 
      Format.fprintf ff "%a->%s(%a)" pp_exp e mname pp_exp_list es
  | NewObj (cname, es) -> 
      Format.fprintf ff "new %s(%a)" cname pp_exp_list es
  | UClassMethod (cname, e, es) -> 
      Format.fprintf ff "%s::%a(%a)" cname pp_exp e pp_exp_list es
  | UMethod (e1, e2, es) -> 
      Format.fprintf ff "%a->%a(%a)" pp_exp e1 pp_exp e2 pp_exp_list es
  | UNewObj (e, es) -> 
      Format.fprintf ff "new %a(%a)" pp_exp e pp_exp_list es
  | LAssign (lv, e) -> Format.fprintf ff "%a = %a" pp_lvalue lv pp_exp e
  | RefAssign (lv1, Lv lv2) -> Format.fprintf ff "%a =& %a" pp_lvalue lv1 pp_lvalue lv2
  | RefAssign (lv, Exp e) -> Format.fprintf ff "%a =& %a" pp_lvalue lv pp_exp e
  | LOpAssign (lv, p, e) -> Format.fprintf ff "%a =%s %a" pp_lvalue lv (string_of_prim p) pp_exp e
  | ListAssign (lvs, e) -> 
      let pp_optlv ff olv =
	match olv with
	  Some lv -> pp_lvalue ff lv
	| None -> Format.fprintf ff "" in
      Format.fprintf ff "list(%a) = %a" (pp_seq pp_optlv) lvs pp_exp e
  | IncludeExp (_, e, _, _) -> Format.fprintf ff "incude %a" pp_exp e
  | StmtExp (_, e) -> Format.fprintf ff "stmt {%a}" pp_exp e
  | FileBlock _ -> Format.fprintf ff "fileblock"
  | Define (s, e) -> Format.fprintf ff "define (%s,%a)" s pp_exp e
and pp_exp_list ff es = pp_seq pp_exp ff es
and pp_lvalue ff lv =
  match lv.lvalue_desc with
    LVar x -> Format.fprintf ff "%s" x
  | LVarVar e -> Format.fprintf ff "${%a}" pp_exp e
  | LArray1 (lv) -> Format.fprintf ff "%a[]" pp_lvalue lv
  | LArray2 (lv, e) -> Format.fprintf ff "%a[%a]" pp_lvalue lv pp_exp e
  | LObjRef (lv, m) -> Format.fprintf ff "%a->%s" pp_lvalue lv m
  | LUObjRef (lv, e) -> Format.fprintf ff "%a->%a" pp_lvalue lv pp_exp e
  | LStringRef (lv, e) -> Format.fprintf ff "%a{%a}" pp_lvalue lv pp_exp e
and pp_stmt ff stmt =
  match stmt.stmt_desc with
    ExpSt e -> Format.fprintf ff "%a;@," pp_exp e
  | Echo e -> Format.fprintf ff "echo %a;@," pp_exp e
  | Unset lv -> Format.fprintf ff "unset %a;@," pp_lvalue lv
  | BlockSt stmts -> Format.fprintf ff "{@[<v>%a@]}" (Basic.print_list "" pp_stmt) stmts
  | While (e, s) -> Format.fprintf ff "while (%a)%a" pp_exp e pp_stmt s
  | DoWhile (s, e) -> Format.fprintf ff "do %a while (%a)" pp_stmt s pp_exp e 
  | For (es1, es2, es3,s) ->
    Format.fprintf ff "for (%a; %a; %a) %a" 
	pp_exp_list es1	pp_exp_list es2	pp_exp_list es3	pp_stmt s 
  | If (e, s1, s2) ->
      Format.fprintf ff "if (%a) then@,%a@,else %a" pp_exp e pp_stmt s1 pp_stmt s2
  | Assert (e, s) -> Format.fprintf ff "assert (%a,%s)" pp_exp e s
  | Function (fname, xs, s, b) ->
      Format.fprintf ff "@[<v>function %s%s(%a)@,%a@]@." 
	(if b then "&" else "") fname (pp_seq pp_fparam) xs pp_stmt s
  | Return e ->
      Format.fprintf ff "return %a;@," pp_exp e
  | Break i -> Format.fprintf ff "break %d;@," i
  | Continue i -> Format.fprintf ff "continue %d;@," i
  | Skip -> Format.fprintf ff "skip;@." 
  | Global xs -> Format.fprintf ff "globals %a;@," (pp_seq Format.pp_print_string) xs
  | Static xis -> Format.fprintf ff "static;@," 
  | Switch (e, bs) ->
      let pp_branch ff (e_opt, ss) =
	let pp_case ff e_opt =
	  match e_opt with
	    None -> Format.fprintf ff "default:@."
	  | Some e -> Format.fprintf ff "case %a:@." pp_exp e in
	Format.fprintf ff "%a {%a}" pp_case e_opt (Basic.print_list "" pp_stmt) ss in
      Format.fprintf ff "switch (%a) {%a}@." pp_exp e (Basic.print_list "" pp_branch) bs
 | Foreach (e, Some x,  y, s) ->
     Format.fprintf ff "foreach (%a as %s => %s) %a" pp_exp e x y pp_stmt s
 | Foreach (e, None,  y, s) ->
     Format.fprintf ff "foreach (%a as %s) %a" pp_exp e y pp_stmt s
 | Class (cname, parent_opt, xs, ms) ->
     let pp_method ff (mname, xs, s, b) =
      Format.fprintf ff "function %s%s(%a) %a@." (if b then "&" else "")
	 mname (pp_seq pp_fparam) xs pp_stmt s in
     Format.fprintf ff "class %s {@[<v>var %a;@.%a@]}" cname (pp_seq pp_fparam) xs 
       (Basic.print_list "" pp_method) ms
and pp_stmt_list ff ss = Basic.print_list "" pp_stmt ff ss
       


