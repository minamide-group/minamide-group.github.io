(*
 * PHP string analyzer
 * Copyright (C) 2006 Yasuhiko Minamide
 *)
open Support

let impossible s = 
  Format.printf "@.Impossibleg: %s" s;
  failwith s

let warning loc f = 
  Format.printf "@.Warning: ";
  f Format.std_formatter;
  Format.printf " at %a.@." Loc.pp_loc loc

let unsupported loc f = 
  Format.printf "@.Unsuppored: ";
  f Format.std_formatter;
  Format.printf " at %a.@." Loc.pp_loc loc;
  failwith "Unsupported"

let unsupported_simple loc s = 
  Format.printf "@.Unsuppored: %s at %a.@." s Loc.pp_loc loc;
  failwith "Unsupported"

let phperror loc f = 
  Format.printf "@.Error in PHP: ";
  f Format.std_formatter;
  Format.printf " at %a.@." Loc.pp_loc loc;
  failwith "Error in PHP"

let phperror_simple loc s = 
  Format.printf "@.Error in PHP: %s at %a.@." s Loc.pp_loc loc;
  failwith "Error in PHP"

  
type var = Support.var
let fresh_var = Support.fresh_var 
let string_of_var = Support.string_of_var
let pp_var = Support.pp_var

type const = 
    ConstInt of int 
  | ConstBool of bool 
  | ConstFloat of float 
  | ConstString of string
  | ConstArray of (const * const) list * var * var * var
  | ConstConst of var
  | ConstBox of const * var 

let rec pp_const ff c =
  match c with 
    ConstInt i -> Format.fprintf ff "%d" i
  | ConstBool b -> 
      let bs = if b then "TRUE" else "FALSE" in
      Format.fprintf ff "%s" bs
  | ConstFloat f -> Format.fprintf ff "%f" f
  | ConstString s -> Format.fprintf ff "\"%s\"" (String.escaped s)
  | ConstArray (l,x,y, z) -> 
      let pp_arrayinit ff (x,y) = 
	Format.fprintf ff "%a => %a" pp_const x pp_const y in
      Format.fprintf ff "array(%a)"
      (Basic.print_list "," pp_arrayinit) l
  | ConstConst x -> Format.fprintf ff "%a" pp_var x
  | ConstBox (c, x) -> 
      Format.fprintf ff "vbox(%a,%a)" pp_const c  pp_var x

type classname = string
type methodname = var
type fieldname = string

type prim = Plus | Minus | Times | Div | Mod
| Concat 
| Eq | Neq | Le | Lt | Ge | Gt | Not | Xor 
| Bitnot | Bitand | Bitor | Bitxor | Bitshiftl | Bitshiftr 
| Cast of Phptype.phptype 
| NewArray | InitArray of var | InitObj of var 
| NewArrayL of (string * var * var) list
| NewObj of classname | NewRef 
| CheckFunction of string * bool list | CheckMethod of string * bool list
| StringUpdate | ArrayDref

let pp_prim ff p =
  match p with
    Plus -> Format.pp_print_string ff "+"
  | Minus -> Format.pp_print_string ff "-"
  | Times -> Format.pp_print_string ff "*"
  | Div -> Format.pp_print_string ff "/"
  | Concat -> Format.pp_print_string ff "."
  | Eq -> Format.pp_print_string ff "=="
  | Neq-> Format.pp_print_string ff "!="
  | Le -> Format.pp_print_string ff "<="
  | Lt -> Format.pp_print_string ff "<"
  | Ge -> Format.pp_print_string ff ">="
  | Gt -> Format.pp_print_string ff ">" 
  | Not -> Format.pp_print_string ff "!" 
  | Mod -> Format.pp_print_string ff "%" 
  | Xor -> Format.pp_print_string ff "xor" 
  | Bitnot -> Format.pp_print_string ff "~"
  | Bitand -> Format.pp_print_string ff "&"
  | Bitor -> Format.pp_print_string ff "|"
  | Bitxor -> Format.pp_print_string ff "^"
  | Bitshiftl -> Format.pp_print_string ff "<<"
  | Bitshiftr -> Format.pp_print_string ff ">>"
  | Cast t -> Format.fprintf ff "(%a)" Phptype.pp_phptype t 
  | NewObj c -> Format.fprintf ff "new %s" c
  | NewArray -> Format.pp_print_string ff "new_array"
  | NewArrayL sxys -> Format.fprintf ff "new_arrayl[%a]"
      (Basic.print_list "," (fun fmt (s,_,_) -> Format.pp_print_string fmt s))
	sxys
  | InitArray _ -> Format.pp_print_string ff "init_array"
  | InitObj _ -> Format.pp_print_string ff "init_object"
  | NewRef -> Format.pp_print_string ff "new_ref"
  | CheckFunction (s, bs) -> Format.pp_print_string ff "check_function"
  | CheckMethod (m, bs) -> Format.pp_print_string ff "check_method"
  | StringUpdate -> Format.pp_print_string ff "string_update"
  | ArrayDref -> Format.pp_print_string ff "array_dref"

type info = var * var * var * Loc.loc

type exp = 
    Var of var
  | Null
  | Dref of var * var (* LIL  : Dref(x,y) = *x, y is used for analysis *)
  | Const of var
  | ConstExp of const
  | Int of int
  | Float of float
  | String of string
  | Bool of bool
  | Prim of prim * exp list * info
  | App of string * exp list * info
  | Vspec of Valuespec.vspec

type lvalue =
    LVar of var
  | LArray1 of var 
  | LArray2 of var * exp 
  | LObjRef of var * fieldname

let is_nonvalue e =  
  match e with
   Prim _ | App _ ->  true
 | Dref _ -> failwith "is_nonvalue"
 | _ -> false

let fresh_info loc = (fresh_var (), fresh_var (), fresh_var (), loc)
let fresh_info' () = (fresh_var (), fresh_var (), fresh_var (), Loc.dummy_loc ())

let mklarray1 lv = LArray1 lv
let mklarray2 (lv, exp) = LArray2 (lv, exp)
let mklobjref (lv, exp) = LObjRef (lv, exp)

let mkprim loc (p, es) = Prim (p, es, fresh_info loc)
let mkprim' (p, es) = Prim (p, es, fresh_info' ())
let remkprim (p, es, (_,_,_,loc)) = Prim (p, es, fresh_info loc)
let mknewarray () = mkprim' (NewArray, [])
let mknewobj cname = mkprim' (NewObj cname, [])
let mkinitarray e = mkprim' (InitArray (fresh_var ()), [e])
let mkinitobj e = mkprim' (InitObj (fresh_var ()), [e])

let mkapp loc (s, es) = App (s, es, fresh_info loc)
let remkapp (s, es,(_,_,_,loc)) = App (s, es, fresh_info loc)
let mkapp' (s, es) = App (s, es, fresh_info' ())


type fparam = var * const option * bool
type ivar = string * const option  (* instance variable *)

type swguard = string option

type stmt = 
    ExpSt of exp
  | Define of var * exp
  | Assign of var * exp
  | RefAssign of lvalue * lvalue (* HIL and LIL *)
  | Unset of lvalue              (* HIL *)
  | DrefAssign of var * exp      (* LIL *)
  | Echo of exp                  (* HIL *) 
  | Assert of  exp * var * string
  | LocalFun of var * (var list) * block
  | FunCall of var list * var * exp list * bool * bool list 
           (* FunCall (xs, fname, es, b, bs) 
              b = true if returning reference 
              bs = [b0,..,bn]
              bn = true if passing reference *)
  | ClassMethodCall of var list * classname * methodname * exp list * bool * bool list
  | MethodCall of var list * var * methodname * exp list * bool * bool list
and block = 
  | Seq of stmt * block
  | If of exp * var * block * var * block
  | LocalCall of var * exp list
  | Stop of int * var option
  | Return of exp list
  | Switch of exp * var * (swguard * var * block) list

let mkif (e1,e2,e3) =
  let x, y = fresh_var (), fresh_var () in
  If (e1,x,e2,y,e3)

type function_decl = fparam list * block * var list * bool
type method_decl = var * fparam list * var * block * var list * bool
type class_decl = var * ivar list * method_decl list 

type program =
    { functions : (var, function_decl) Hashtbl.t;
      classes : (string, class_decl) Hashtbl.t;
      main : block }

let rebuild_program main functions classes =
  { main = main;
    functions = functions;
    classes = classes }


let map_program main_f function_f class_f program =
  let functions_tbl = Hashtbl.create 49 in
  let classes_tbl = Hashtbl.create 49 in
  Hashtbl.iter (fun x (xs, b, ys, r) -> 
    let (x, xs, b, ys, r) = function_f (x, xs, b, ys, r) in
    Hashtbl.add functions_tbl x (xs, b, ys, r)) program.functions;
  Hashtbl.iter (fun s (cname, xs, ms) -> 
    let (cname, xs, ms) = class_f (cname, xs, ms) in
    Hashtbl.add classes_tbl s (cname, xs, ms)) program.classes;
  rebuild_program (main_f program.main) functions_tbl classes_tbl 

let filter_program function_f class_f program =
  let functions_tbl = Hashtbl.create 49 in
  let classes_tbl = Hashtbl.create 49 in
  Hashtbl.iter (fun x (xs, b, ys, r) -> 
    if function_f (x, xs, b, ys, r) then Hashtbl.add functions_tbl x (xs, b, ys, r)) program.functions;
  Hashtbl.iter (fun s (cname, xs, ms) -> 
    if class_f (cname, xs, ms) then Hashtbl.add classes_tbl s (cname, xs, ms)) program.classes;
  rebuild_program program.main functions_tbl classes_tbl 

let iter_program main_f function_f class_f program =
  Hashtbl.iter (fun x (xs, b, ys, r) -> function_f (x, xs, b, ys, r)) program.functions;
  Hashtbl.iter (fun s (cname, xs, ms) -> class_f (cname, xs, ms)) program.classes;
  main_f program.main

let fold_program main_f function_f class_f program env =
  let env = Hashtbl.fold (fun x (xs, b, ys, r) env -> function_f env (x, xs, b, ys, r)) 
      program.functions env in
  let env = Hashtbl.fold (fun s (cname, xs, ms) env -> class_f env (cname, xs, ms)) 
      program.classes env in
  main_f env program.main

let pp_fparam ff fparam =
  match fparam with
    (x, None, false) -> Format.fprintf ff "%a" pp_var x
  | (x, None, true) -> Format.fprintf ff "&%a" pp_var x
  | (x, Some const, _) -> Format.fprintf ff "%a = %a" pp_var x pp_const const

let vars_of_fparam fparam = let x, _, _ = fparam in x
let vars_of_fparams fparams = List.map vars_of_fparam fparams 

let rec pp_exp ff e =
  match e with 
    Var x -> Format.fprintf ff "%a" pp_var x
  | Null -> Format.fprintf ff "null"
  | Dref (x,_) -> Format.fprintf ff "*%a" pp_var x
  | Const x -> Format.fprintf ff "%a" pp_var x
  | ConstExp const -> Format.fprintf ff "%a" pp_const const
  | Int i -> Format.fprintf ff "%d" i
  | Float f -> Format.fprintf ff "%f" f
  | String s -> Format.fprintf ff "\"%s\"" (String.escaped s)
  | Bool b -> 
      let bs = if b then "TRUE" else "FALSE" in
      Format.fprintf ff "%s" bs
  | Prim (NewRef, es, (x,_,_,_)) -> 
      Format.fprintf ff "new_ref(%a)" pp_var x
  | Prim (NewArrayL sxys as p, es, (x,y,z,_)) -> 
      Format.fprintf ff "%a(%a,%a,%a)" pp_prim p
	pp_var x pp_var y pp_var z
  | Prim (p, es, _) -> 
      Format.fprintf ff "%a(%a)" pp_prim p (pp_seq pp_exp) es
  | App (s, es, _) -> Format.fprintf ff "%s(%a)" s (pp_seq pp_exp) es
  | Vspec vspec -> Format.fprintf ff "%a" Valuespec.pp_vspec vspec

let pp_lvalue ff e =
  match e with
    LVar x -> Format.fprintf ff "%a" pp_var x
  | LArray1 a -> Format.fprintf ff "%a[]" pp_var a
  | LArray2 (a, e) -> Format.fprintf ff "%a[%a]" pp_var a pp_exp e
  | LObjRef (a, m) -> Format.fprintf ff "%a->%s" pp_var a m

let rec pp_stmt ff s =
  match s with 
    ExpSt e -> pp_exp ff e
  | Define (x, e) -> 
      Format.fprintf ff "define %a = %a" pp_var x pp_exp e
  | Assign (x, e) -> 
      Format.fprintf ff "%a = %a" pp_var x pp_exp e
  | DrefAssign (x, e) -> 
      Format.fprintf ff "*%a = %a" pp_var x pp_exp e
  | RefAssign (x, lv) -> 
      Format.fprintf ff "%a =& %a" pp_lvalue x pp_lvalue lv
  | Unset lv -> 
      Format.fprintf ff "unset(%a)" pp_lvalue lv
  | FunCall (xs, s, es, b, bs) -> 
      Format.fprintf ff "%a %s = %a(%a)%d" 
	(pp_seq pp_var) xs (if b then "&" else "")
	pp_var s (pp_seq pp_exp) es (List.length bs)
  | ClassMethodCall (xs, cname, mname, es, r, bs) -> 
      Format.fprintf ff "%a = %s %s::%a(%a)" 	
	(pp_seq pp_var) xs  
	(if r then "&" else "")
	cname pp_var mname (pp_seq pp_exp) es
  | MethodCall (xs, y, mname, es, r, bs) -> 
      Format.fprintf ff "%a = %s %a->%a(%a)" 	
	(pp_seq pp_var) xs  
	(if r then "&" else "")
	pp_var y pp_var mname (pp_seq pp_exp) es
  | Echo e -> Format.fprintf ff "echo %a" pp_exp e
  | Assert (e, x, str) -> Format.fprintf ff "assert %a %s" pp_exp e str
  | LocalFun (x, xs, ss) -> 
      Format.fprintf ff "%a@[<v>(%a)%a@]" pp_var x
	(pp_seq pp_var) xs  pp_block ss
and pp_block ff s =
  match s with 
    Stop (_,optx) -> 
      (match optx with
	None -> Format.fprintf ff "STOP"
      | Some x -> Format.fprintf ff "STOP(%a)" pp_var x)
  | Return es -> 
      Format.fprintf ff "return %a" (pp_seq pp_exp) es
  | If (e, x1, s1, x2, s2) -> 
      Format.fprintf ff "if@[<v> (%a)[%a] %a else[%a] %a@]" pp_exp e
	pp_var x1 pp_block s1 pp_var x2 pp_block s2
  | LocalCall (x, es) -> 
      Format.fprintf ff "%a(%a)" pp_var x (pp_seq pp_exp) es
  | s -> 
      Format.fprintf ff "{@,@[<v>%a@]}" pp_block' s
and pp_block' ff s =
  match s with 
    Stop (_,optx) -> 
      (match optx with
	None -> Format.fprintf ff "STOP"
      | Some x -> Format.fprintf ff "STOP(%a)" pp_var x)
  | Seq (s, b) -> 
      Format.fprintf ff "%a;@,%a" pp_stmt s pp_block' b
  | Return es -> 
      Format.fprintf ff "return %a" (pp_seq pp_exp) es
  | If (e, x1, s1, x2, s2) -> 
      Format.fprintf ff "if@[<v> (%a)[%a] %a else[%a] %a@]" pp_exp e
	pp_var x1 pp_block s1 pp_var x2 pp_block s2
  | LocalCall (x, es) -> 
      Format.fprintf ff "%a(%a)" 
	pp_var x (pp_seq pp_exp) es
  | Switch (e, x, cs) -> 
      let pp_case fmt (g,_,b) = 
	let pp_guard fmt g = 
	  match g with
	    Some x -> Format.fprintf fmt "%s:" x
	  | None -> Format.fprintf fmt "default:" in
	Format.fprintf fmt "%a %a@." pp_guard g pp_block b in
      Format.fprintf ff "switch (%a,%a){@,@[<v> %a@]}" pp_exp e pp_var x 
	(pp_seq pp_case) cs

let pp_program ff program = 
  let function_f (s, xs, ss, ys, b) =
    Format.fprintf ff "%s%a(%a)(%s)%a@," 
      (if b then "&" else "") pp_var s
      (pp_seq pp_fparam) xs
      (String.concat "," (List.map string_of_var ys))
      pp_block ss in
  let class_f (classname, vars, methods) =
    let pp_classvar ff (x, constopt) =
      match constopt with
	None -> Format.fprintf ff "var %s;" x 
      | Some c -> Format.fprintf ff "var %s=%a;" x pp_const c in
    let pp_classmethod ff (x, xs, this, ss, ys, r) =
      Format.fprintf ff "%s%a(%a)(%s)(%s)%a@." 
	(if r then "&" else "") pp_var x 
	(pp_seq pp_fparam) xs (string_of_var this)
	(String.concat "," (List.map string_of_var ys))
	pp_block ss in
    Format.fprintf ff "class %a {%a %a}@." pp_var classname
      (pp_seq pp_classvar) vars
      (pp_seq pp_classmethod) methods in 
  iter_program (fun b -> pp_block ff b) function_f class_f program






