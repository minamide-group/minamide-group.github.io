<html>
<head><title>test</title></head>
<body>
<?php
echo htmlspecialchars($_POST["name"]);
?>
</body>
</html>