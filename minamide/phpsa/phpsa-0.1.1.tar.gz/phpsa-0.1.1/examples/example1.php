<?php
for ($i = 0; $i < $n; $i++)
  $x = "0".$x."1";
echo str_replace("00","0",$x);
?>