<html>
<head><title>test</title></head>
<body>
<ul><p>
<?php
echo htmlspecialchars($_POST["name"]);
?>
</p></ul>
</body>
</html>