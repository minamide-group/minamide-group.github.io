<?php
class dir { 

function handle () { _dir_handle (); }
function read () { _dir_read (); }
function rewind () { _dir_rewind (); }
function close (){ _dir_close (); }

}

function dir ($x) { return new dir (); }
?>