<?php
function array_filter($a, $f) {
   $x = array();
   foreach ($a as $k => $v) {
      if ($f($v)) $x[$k] = $v;
   }
   return $x;
}

function array_map($a, $f) {
   $x = array();
   foreach ($a as $k => $v) {
      $x[$k] = $f($v);
   }
   return $x;
}

function array_walk($a, $f, $w) {
   foreach ($a as $k => $v) {
      $f($v, $k, $w);
   }
}
?>