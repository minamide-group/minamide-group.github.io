<?php
$x = array ("a" => "xx", "b" => "yy") ;
foreach ($x as $y => $z) {
  echo $y;
  echo $z;
}
// axxbyy
// (a|b|\epsilon)(xx|yy|\epsilon)*
?>