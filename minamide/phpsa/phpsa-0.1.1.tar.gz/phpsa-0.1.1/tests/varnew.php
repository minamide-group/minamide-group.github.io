<?php
class A {
   var $x = "xyz";
}
$a = "A";
$b =& new $a;
echo $b->x;
// "xyz"
?>