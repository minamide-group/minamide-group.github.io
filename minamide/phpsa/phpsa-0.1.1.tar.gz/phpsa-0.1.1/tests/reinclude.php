<?php
$x = "reinclude2.php";
if (file_exists ("reinclude2.php"))
 include $x;
// "", "abc"
?>