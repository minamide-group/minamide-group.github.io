<?php
for ($n = 0; $n < 10; $n++) {
    if ($n == 5) { echo "x"; continue; }
    echo "ab";
}
// (ab|x)* 
?>