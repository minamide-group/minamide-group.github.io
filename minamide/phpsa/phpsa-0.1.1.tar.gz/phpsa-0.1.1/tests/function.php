<?php
function foo ($n, $y) {
   if ($n == 0) return;
   echo $y;
   foo ($n - 1, $y);	
}
foo (10, "abc");
// (abc)*
?>
