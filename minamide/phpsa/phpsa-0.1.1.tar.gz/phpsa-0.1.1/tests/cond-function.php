<?php
if (0) {
   function foo($x) {return $x;}
}
else
{
  function foo($x) {return "xyz";}
}
echo foo ("abc");
?>