<?php
echo "a".$x."b";
?>