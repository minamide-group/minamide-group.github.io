<?php
class B {
   var $b = "bbb";
}
class A {
function &foo() {
  $x =& new B;
  return $x;
}
}
$y = A::foo ();
echo $y->b;
// "bbb"
?>