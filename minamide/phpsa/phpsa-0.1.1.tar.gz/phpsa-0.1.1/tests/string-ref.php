<?php
$n = 0;
if (4 < 5) $n = 1;
$x = "abc";
echo $x{$n};
// "a", "b", "c", ""
?>