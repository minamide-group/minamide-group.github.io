<?php
function &foo($x){
  return $x[0];
}
$a[0] = "a";
$b =& foo($a);
$b = "b";
echo $a[0];
//      This program outputs "b".
?>