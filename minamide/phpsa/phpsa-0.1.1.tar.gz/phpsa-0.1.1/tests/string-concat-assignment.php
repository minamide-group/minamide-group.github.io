<?php
$x = "abc";
if (1) $x = "aaa";
$x .= "zz";
echo $x;
?>