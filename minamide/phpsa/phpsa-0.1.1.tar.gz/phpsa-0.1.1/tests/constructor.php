<?php
class A {
   var $a, $b;
   function A ($x, $y) {
     $this->a = $x;
     $this->b = $y;
   }
}
$c = new A("aa","bb");
echo $c->a;
?>