<?php
echo htmlentities("\"'", 2);
echo htmlentities("\"'", 3);
echo htmlentities("\"'", 0);
/* The output should be &quote;'&quote;&#039;"' */
?>
