<?php
$x = 2;
if (4 < 3) $x = 3;
//echo substr("abcde", 0);
echo substr("abcde", $x, 1);
// The output should be {"", "a", "b", "c", "d", "e"}
?>