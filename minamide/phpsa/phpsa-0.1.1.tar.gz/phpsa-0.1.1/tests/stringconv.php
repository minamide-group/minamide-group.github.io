<?php
$a = array();
echo strtoupper($a);
// "ARRAY"
?>
