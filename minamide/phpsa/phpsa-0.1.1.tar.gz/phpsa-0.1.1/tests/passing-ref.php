<?php
function foo (&$x) {
  $x = "x";
}
$z = "z";
foo ($z);
echo $z;
// The ouput is "x".
// The approximation should be {"x","z"} .
?>