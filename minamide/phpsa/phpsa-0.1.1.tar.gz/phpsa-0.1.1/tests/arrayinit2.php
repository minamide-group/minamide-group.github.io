<?php
$x["a"] = "a";
$x["b"] = "b";
$x["c"] = "c";
echo $x["a"];
// the output is "a"
// the approximation should be {"", "a"}
?>
