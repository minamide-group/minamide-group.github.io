<?php
$GLOBALS['x']='y';
function bar () {
   $y = "abc";
   echo ${$GLOBALS['x']};
}
bar ();
// The ouput is "abc".
// The approximation should be {"", "abc"}
?>