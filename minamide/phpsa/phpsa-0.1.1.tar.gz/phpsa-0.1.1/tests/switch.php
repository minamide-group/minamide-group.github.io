<?php
$i = 1;
switch ($i) {
case 0:
    echo "A";
case 1:
    echo "B";
    break;
default: 
    echo "D";
case 2:
    echo "C";
}
// the approximation should be {"AB", "B", "C", "DC"}
?>