<?php
$x["xx"]="abc"; 
$y[4]="xx"; 
echo "{$x["{$y[1+3]}"]}";

// The output is "abc".
// The approximation should be {"","abc"}.
?>