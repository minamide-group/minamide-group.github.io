<?php
if (1) {
   function foo ($x, &$y){}
}
else {
   function foo ($x, &$y){}
}
function bar ($x){
  echo $x; 
  exit;
}
foo (bar ("abc"), "xyz") 
// The second argument is incompatible for 'foo'.
// The output is "abc".
// The output should be {"abc"} for exit_analysis_mode.
?>