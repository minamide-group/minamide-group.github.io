<?php
$y  = preg_match_all ("/a.c/","abcaac",$x);
echo $x[0][0];
// "", "abc", "aac"
?>