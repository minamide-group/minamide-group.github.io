<?php
$n = 10;
$x = "01";
for ($i = 0; $i < $n; $i++) {
  $x = str_replace ("0","x0y", $x); 
  $x = str_replace ("1","1z", $x); 
}
echo $x;
?>