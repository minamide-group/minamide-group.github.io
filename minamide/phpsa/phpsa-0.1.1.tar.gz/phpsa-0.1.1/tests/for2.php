<?php
for ($n = 0; $n < 2; $n++) {
    echo "ab";
    for ($m = 0; $m < 2; $m++) echo "x";
}
// (abx*)*
?>