<?php
class A {
   function foo () { return "A"; }
}
class B {
   function foo ($x) { return $x; }
}
$y = new A;
echo $y->foo()
// "A";
?>