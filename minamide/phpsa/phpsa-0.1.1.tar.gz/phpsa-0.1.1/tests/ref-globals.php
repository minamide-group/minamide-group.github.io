<?php
$y = "yyy";
$GLOBALS["x"] = "xxx";
$x =& $y;
function foo () {
  echo $GLOBALS["x"];
}
foo ();
// The output is "yyy".
// The approximation  is {"yyy"}.
?>