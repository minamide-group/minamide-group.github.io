<?php
class A{
function &foo(&$y){
  return $y;
}
}
$x = new A;
$a = "a";
$b =& $x->foo($x);
echo $b->foo($a);
// This program outputs "a".
// Approximation should be {"a"; "Object"};
?>