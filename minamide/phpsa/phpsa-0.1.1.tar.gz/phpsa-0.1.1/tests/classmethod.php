<?php
class A {
  function bar ($x) {
    return $x.$x;
  }
  function foo ($x) {
    return A::bar($x);
  }
}
echo A::foo ("bb");
// The output is "bbbb".
?>