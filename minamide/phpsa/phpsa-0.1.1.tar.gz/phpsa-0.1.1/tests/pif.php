<?php
echo 0 ? "abc" : "xyz";
?>