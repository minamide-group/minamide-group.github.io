<?php
$a = array("ab", "aaabaabc");
$b = str_replace ("ab","xxx", $a);
echo $b[0];
// The output is "xxx";
// The approximation shoud be {"","xxx","aaxxxaxxxc"};
?>