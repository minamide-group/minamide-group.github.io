<?php
$x = str_replace ("ab","xxx", "aaabaabc");
echo $x;
// The output is "aaxxxaxxxc";
// The approximation shoud be {"aaxxxaxxxc"};
?>