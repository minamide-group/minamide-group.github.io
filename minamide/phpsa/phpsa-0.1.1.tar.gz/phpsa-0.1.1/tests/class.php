<?php
class A {
  var $a;
  function foo ($x) {
    return $this->a.$x;
  }
}
$c = new A;
$c->a = "aa";
echo $c->foo ("bb");
// The output is "aabb".
// The approximation should be "aabb", "bb".
?>