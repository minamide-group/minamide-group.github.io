<?php
function foo ($x) {
   $y = func_get_args ();
   echo $y[0];
}
foo ("abc", "xyz");
// The output is "abc".
// The approxmiation should be {"", "abc", "xyz"}.
?>