<?php
$x[0] = "a";
$x[1] = "b";
$x[2] = "c";
echo $x[0];
// the output is "a"
// the approximation should be {"", "a", "b", "c"}
?>