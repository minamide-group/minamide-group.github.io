<?php
$x = "abc";
function foo () {
  $y = "yyy";
  if (0) $y =& $GLOBALS["x"]; 
  echo $y;
}
echo foo();
/* The output is "yyy" */
/* The approximation should be {"abc", "yyy"} */
?>