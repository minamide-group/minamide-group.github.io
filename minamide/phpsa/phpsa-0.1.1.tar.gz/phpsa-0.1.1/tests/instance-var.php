<?php
class A {
  var $x = "xxx";
  var $y = "yyy";
  function foo () {
    echo $this->x;
  }
}
class B {
  var $x = "bbb";
  var $y = "bbb";
  function foo () {
    echo $this->x;
  }
}
$a = new A;
$a->foo();
// "", "xxx"
?>