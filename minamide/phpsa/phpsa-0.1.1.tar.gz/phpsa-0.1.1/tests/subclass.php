<?php
class A {
  function foo ($x) {
    return $x."foo";
  }
}
class B extends A {
  function bar ($x) {
    return $this->foo($x."bar");
  }
}
$x = new B;
echo $x->bar("b");
// The output is "bbarfoo"
?>