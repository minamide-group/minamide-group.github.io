<?php
class A {
  function foo ($x) {
    return "foo".$x;
  }
}

class B extends A {
  function bar ($x) {
    return "bar".$this->foo($x);
  }
}
$c = new B;
echo $c->bar("abc");
?>