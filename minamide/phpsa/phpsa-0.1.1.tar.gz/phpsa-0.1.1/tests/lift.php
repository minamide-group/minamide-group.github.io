<?php
$x = "abc";
function foo(){
  global $x;
  $x = "xyz";
}
function bar(){
  foo();
}
function bar2(){
  global $x;
  bar();
  echo $x;
}
bar2 ();
// The output should be "xyz"
?>