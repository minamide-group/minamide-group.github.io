<?php
function bar(&$y){
   echo $y->x;
}
class A {
   var $x = "xxx";
   function foo() {
      bar($this);
   }
}
$a = new A;
$a->foo();
// "xxx"
?>