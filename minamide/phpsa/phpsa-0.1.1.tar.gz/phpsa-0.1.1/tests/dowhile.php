<?php
$x = 10;
do {
  echo "ab";
  $x--;
} while ($x) 
?>