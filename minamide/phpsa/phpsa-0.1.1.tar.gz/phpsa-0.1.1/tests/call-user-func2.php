<?php
class a {
  function foo () {
    echo "foo";
  }
}
$x = array("a", "foo");
call_user_func($x);
// The output is "foo".
// The approximation should be {"","foo"}.
?>