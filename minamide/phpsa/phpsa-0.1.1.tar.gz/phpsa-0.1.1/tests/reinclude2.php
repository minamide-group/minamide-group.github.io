<?php
echo "abc";
?>