<?php
$x = "x";
echo wordwrap ("abc  abcdef", 4, $x, 1);
// The output is "abc xabcdxef"
// The approxmiation should be is {"abc xabcdxef"}
?>