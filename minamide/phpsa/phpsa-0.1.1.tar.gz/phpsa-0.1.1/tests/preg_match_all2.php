<?php
preg_match_all("/([a-z])[a-z]/", "abcd",  $a);
echo $a[0][0];
// "", "ab", "bc", "cd", "a", "b", "c"
?>