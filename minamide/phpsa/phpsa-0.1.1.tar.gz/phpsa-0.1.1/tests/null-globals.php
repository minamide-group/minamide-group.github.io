<?php
function foo() {
$x = "x";
$GLOBALS[$x] = "abc";
echo $GLOBALS[$x];
}
foo ();
/* The output is "abc" 
   The approxmination should be {"", "abc"}
   Array for  superglobals */
?>