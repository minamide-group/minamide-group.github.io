<?php
$x = 10;
while ($x) {
  echo "ab";
  $x--;
}
?>