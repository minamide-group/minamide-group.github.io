<?php
class abc {
}
$x = new abc;
echo get_class($x);
// "", "abc"
?>