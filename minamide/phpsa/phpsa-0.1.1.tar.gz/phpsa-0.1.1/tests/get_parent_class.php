<?php
class a {}
class b {}
$b = new b;
echo get_parent_class($b);
// The output is "" because the value of get_parent_class($b) is false.
// The approximation should be {"", "a","b","stdclass"}.
?>