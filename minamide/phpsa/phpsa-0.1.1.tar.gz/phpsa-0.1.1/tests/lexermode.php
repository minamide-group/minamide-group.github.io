<?php
function foo (){ 
?>
abc
<?php
}
foo();
// This is the test to check whether &lt;?php and ?&gt; work.
// The approximation should be {"aaa\n"}.
?>
