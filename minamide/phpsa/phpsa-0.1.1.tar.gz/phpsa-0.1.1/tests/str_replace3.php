<?php
$a = array("foo" => "ab", 1 => "aaabaabc", "bar" => "bar");
$b = str_replace ("ab","xxx", $a);
echo key($b);
// The output is "foo";
// The approximation shoud be {"foo","1","bar"};
?>