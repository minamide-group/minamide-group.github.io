<?php
$a = array("ABC" => "a", "XyZ" => "x");
$b = array_change_key_case($a);
$b[2] = "c";
echo key($b);
?>