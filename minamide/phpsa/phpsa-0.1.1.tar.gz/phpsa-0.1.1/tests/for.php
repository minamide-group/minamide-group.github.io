<?php
for ($n = 0; $n < 10; $n++) 
    echo "ab";
//@regapprox "/(ab)*/"
?>