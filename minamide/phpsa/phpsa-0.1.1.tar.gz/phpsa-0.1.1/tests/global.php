<?php
$x = "abc";
function foo() {
   global $x;
   echo $x; 
}
foo();
// "abc";
?>