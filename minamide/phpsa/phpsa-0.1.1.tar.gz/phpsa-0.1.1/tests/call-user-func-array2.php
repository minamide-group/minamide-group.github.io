<?php
class a {
function foo ($x,$y) {
  echo "foo";
  echo $x;
  echo $y;
}
}
$x = array("a", "foo");
$y = array("y","z");
call_user_func_array($x,$y);
// The output is "fooyz".
// The approximation should be {"foo","fooy","fooz","fooyy", "fooyz", "foozy", "foozz"}.
?>