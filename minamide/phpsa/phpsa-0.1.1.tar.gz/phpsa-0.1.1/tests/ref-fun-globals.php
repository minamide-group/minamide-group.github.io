<?php
function foo () {
  echo $GLOBALS["x"];
}
function bar () {
  echo $GLOBALS["x"];
}
$y = "yyy";
$GLOBALS["x"] = "xxx";
foo ();
$x =& $y;
bar ();
// The output is "xxxyyy".
// The approximation  is {"xxxyyy"}.
?>