<?php
$x = "abc";
$y =& $x;
unset($x);
echo $y;
echo "-";
echo $x;
/* The output is "abc-". 
   The approximation should be {"abc-"} */
?>