<?php
function foo() {
  echo "foo";
}
function bar() {
  echo "bar";
}
$x = "foo";
if (0) $x = "bar";
$x();
// The output is "foo".
// The approximation should be {"foo", "bar"}.
?>