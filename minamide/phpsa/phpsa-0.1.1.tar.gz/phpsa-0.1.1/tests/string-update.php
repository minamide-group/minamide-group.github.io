<?php
$x = "abc";
$x{1} = "xy";
echo $x;
// The output is "axc".
// The approximation is {"abc", "xbc", "axc", "abx"} U  "abc *x".
?>
