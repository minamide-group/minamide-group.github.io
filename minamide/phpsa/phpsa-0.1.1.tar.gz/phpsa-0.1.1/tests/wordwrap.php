<?php
$x = "x";
if (1) $x = "y";
echo wordwrap ("abc   d ef", 4, $x);
// The output is "abc x dxef"
// The approxmiation should be is {"abc x dxef", "abc x dyef", "abc y dxef", "abc y dyef"}
?>