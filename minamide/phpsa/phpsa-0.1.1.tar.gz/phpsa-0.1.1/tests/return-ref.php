<?php
function &foo(&$x){
  return $x;
}
$a = "a";
$b =& foo($a);
$b = "b";
echo $a;
//      This program outputs "b".
//      This approximation should be {"a", "b"}.
?>