<?php
$x = 10;
echo $x[0];
echo "abc";
?>