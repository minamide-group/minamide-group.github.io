<?php
class a {
   function foo ($x) {
   $y = func_get_arg (0);
   echo $y;
}
}
$x = new a;
$x->foo ("abc", "xyz");
// The output is "abc".
// The approxmiation should be {"", "abc", "xyz"}.
?>