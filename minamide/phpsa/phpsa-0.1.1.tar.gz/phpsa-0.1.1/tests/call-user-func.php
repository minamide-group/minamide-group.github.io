<?php
function foo () {
  echo "foo";
}
$x = "foo";
call_user_func($x);
// The output is "foo".
// The approximation should be {"foo"}.
?>