<?php
$x = "abc";
function foo ()
{
   echo $GLOBALS['x'];
}
foo ();	
// "abc"
?>