open Reg
open Eregparser
open OUnit

module Fa = Charset.Fa

let test_charclass_cases =
  [['a'; 'b'; 'c'], "[abc]";
   ['a'; 'b'; 'c'], "[a-c]";
   ['a'; '-'], "[a-]";
   ['-'; 'a'], "[-a]";
   ['A'], "[\\A]";
   ['\\'], "[\\\\]";
   ['['; 'a'], "[[a]";
   digit_chars, "[[:digit:]]";
   digit_chars@['-'], "[[:digit:]-]" ]

let pp_charlist fmt cs  = Basic.print_list "" Format.pp_print_char fmt cs

let string_of_cs cs = 
  Format.fprintf Format.str_formatter "%a" pp_charlist cs;
  Format.flush_str_formatter ()

let test_charclass _ =
  let test (cs, str) =
    let cs = List.sort compare cs in
    let r = parse str in
    match r with
      Alphalist cs' ->
	let cs' = List.sort compare cs' in
	assert_equal ~printer:string_of_cs ~msg:str cs cs'
    | _ -> assert_failure ("non alphalist: "^str^" "^string_of_reg r) in
  List.iter test test_charclass_cases

let test_charclass_fail _ =
  assert_raises (Failure "parse_I''") (fun () -> parse "[a-b-c]");
  assert_raises (Failure "parse_I''") (fun () -> parse "[[:digit:]-c]")

let test_reg_cases =
  [Star (Alpha 'a'), "a*";
   Repetition (Alpha 'a', 1, None), "a+";
   Repetition (Alpha 'a', 0, Some 1), "a?";
   Repetition (Alpha 'a', 2, Some 2), "a{2}";
   Repetition (Alpha 'a', 2, None), "a{2,}";
   Repetition (Alpha 'a', 2, Some 4), "a{2,4}";
   App (Alpha '{', Alpha 'a'), "{a";
   Plus (App (Alpha 'a', Alpha 'b'),
	 App (Alpha 'c', Alpha 'd')), "ab|cd"; 
   Plus (App (Alpha 'a', Star (Alpha 'b')),
	 App (Alpha 'c', Alpha 'd')), "ab*|cd";
   App (Alpha 'a', Alphalist ['b']), "a[b]";  
   App (Alpha 'a', Negalphalist ['b']), "a[^b]"; 
   App (Alpha start_metachar, Alpha 'a'), "^a"; 
   App (Alpha 'a', Alpha end_metachar), "a$"; 
 ]

let test_reg =
  let test (r, str) =
    let r' = parse str in
    assert_equal ~printer:string_of_reg ~msg:str r r' in
  List.map (fun (r, str) -> TestCase (fun () -> test (r, str))) test_reg_cases
  
let suite = 
  "eregparser" >::: 
  ["test_charclass" >:: test_charclass;
   "test_charclass_fail" >:: test_charclass_fail;
   "test_reg" >::: test_reg]


