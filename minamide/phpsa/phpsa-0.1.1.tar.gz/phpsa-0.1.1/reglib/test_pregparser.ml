open Reg
open Pregparser
open OUnit
open Reg2fa

module Fa = Charset.Fa

(*
let reg_equal r1 r2 =
  let fa1 = reg2nfa Charset.fullcharset r1 in
  let fa1 = Fa.minimize fa1 in 
  let fa2 = reg2nfa Charset.fullcharset r2 in
  let fa2 = Fa.minimize fa2 in 
  Fa.dfa_equal fa1 fa2
*)

let test_char_cases =
  ['\000', "/\\x/";
   '\x0a', "/\\xa/";
   '\x0a', "/\\xA/";
   '\x1a', "/\\x1a/";
   '\x1a', "/\\x1A/";
   '\x1a', "/\\x1A/";
   '\000', "/\\0/";
   '\007', "/\\07/";
   '\018', "/\\022/";
   '\x07', "/\\a/";
   '\x1b', "/\\e/";
   '\x0c', "/\\f/";
   '\x0a', "/\\n/";
   '\x0d', "/\\r/";
   '\x09', "/\\t/";
 ]

let string_of_char c = String.make 1 c

let test_char _ =
  let test (c, str) =
    let r = parse_reg str in
    match r with
      Alpha c' ->
	assert_equal ~printer:string_of_char ~msg:str c c'
    | _ -> assert_failure "non alphalist" in
  List.iter test test_char_cases

let test_charclass_cases =
  [['a'; 'b'; 'c'], "/[abc]/";
   ['a'; 'b'; 'c'], "/[a-c]/";
   ['a'; '-'], "/[a-]/";
   ['-'; 'a'], "/[-a]/";
   ['a'; 'b'; 'c'; '-'; 'd'], "/[a-c-d]/";
   ['A'], "/[\\A]/";
   ['\\'], "/[\\\\]/";
   ['a'], "/[\\x61]/";
   ['a'; 'b'; 'c'], "/[\\x61-c]/";
   ['['; 'a'], "/[[a]/";
   digit_chars, "/[\\d]/";
   digit_chars@['-'; 'a'], "/[\\d-a]/"]

let pp_charlist fmt cs  = Basic.print_list "" Format.pp_print_char fmt cs

let string_of_cs cs = 
  Format.fprintf Format.str_formatter "%a" pp_charlist cs;
  Format.flush_str_formatter ()

let test_charclass _ =
  let test (cs, str) =
    let cs = List.sort compare cs in
    let r = parse_reg str in
    match r with
      Alphalist cs' ->
	let cs' = List.sort compare cs' in
	assert_equal ~printer:string_of_cs ~msg:str cs cs'
    | _ -> assert_failure "non alphalist" in
  List.iter test test_charclass_cases

let test_reg_cases =
  [Star (Alpha 'a'), "/a*/";
   Repetition (Alpha 'a', 1, None), "/a+/";
   Repetition (Alpha 'a', 0, Some 1), "/a?/";
   Repetition (Alpha 'a', 2, Some 2), "/a{2}/";
   Repetition (Alpha 'a', 2, None), "/a{2,}/";
   Repetition (Alpha 'a', 2, Some 4), "/a{2,4}/";
   Plus (App (Alpha 'a', Alpha 'b'),
	 App (Alpha 'c', Alpha 'd')), "/ab|cd/"; 
   Plus (App (Alpha 'a', Star (Alpha 'b')),
	 App (Alpha 'c', Alpha 'd')), "/ab*|cd/";
   App (Alpha 'a', Alphalist ['b']), "/a[b]/";  
   App (Alpha 'a', Negalphalist ['b']), "/a[^b]/"; 
   Alpha 'a', "/^a/"; 
   Alpha 'a', "/a$/"; 
   Alpha 'a', "/^a$/"; 
   App (Alpha 'a', Alpha '^'), "/a^/"; 
   App (Alpha '$', Alpha 'a'), "/$a/"; 
 ]

let test_reg _ =
  let test (r, str) =
    let r' = parse_reg str in
    assert_equal ~printer:string_of_reg ~msg:str r r' in
  List.iter test test_reg_cases

let suite = 
  "pregparser" >::: 
  ["test_char" >:: test_char;
   "test_charclass" >:: test_charclass;
   "test_reg" >:: test_reg]

(*
let _ =
  run_test_tt_main suite
*)
