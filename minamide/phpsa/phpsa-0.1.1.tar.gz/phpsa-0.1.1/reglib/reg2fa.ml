(*
 * PHP string analyzer
 * Copyright (C) 2005, 2006 Nobuo Otoi, Yasuhiko Minamide
 *)
open Basic
open Reg
module Fa = Charset.Fa
open Fa

module QMap = 
  Map.Make(struct type t = q let compare = compare end)

module AQ_set = 
  Set.Make(struct type t = alpha * q let compare = compare end)

module Arrow =
  struct 
    let empty = QMap.empty 
    let find x aset = try QMap.find x aset with Not_found -> AQ_set.empty
    let add x c y aset = QMap.add x (AQ_set.add (c,y) (find x aset)) aset
    let add' x cqs aset = QMap.add x (AQ_set.union cqs (find x aset)) aset
    let remove x aset = try QMap.remove x aset with Not_found -> aset
    let union' aset1 aset2 =
      QMap.fold (fun x cqs a -> QMap.add x cqs a) aset1 aset2
    let convert aset =
      QMap.fold (fun x cqs aset ->
	AQ_set.fold (fun (c,y) aset -> Fa.Arrow.add x c y aset) cqs aset) aset Fa.Arrow.empty
  end

(* The following functions assumes that the starting state has no incoming transitions *)

(* L(fa1)L(fa2) *)
let joinFA fa1 fa2 =
  let (q1,a1,s1,f1) = fa1 in
  let (q2,a2,s2,f2) = fa2 in
  let f = if Q_set.mem s2 f2 then Q_set.union f1 (Q_set.remove s2 f2) else f2 in
  let q = Q_set.union q1 (Q_set.remove s2 q2) in
  let cqs = Arrow.find s2 a2 in
  let a = Arrow.union' a1 (Arrow.remove s2 a2) in
  let a = Q_set.fold (fun x a -> Arrow.add' x cqs a) f1 a in
  (q,a,s1,f)

(* L(fa1) \/ L(fa1)L(fa2) *)
let joinFA' fa1 fa2 =
  let (q1,a1,s1,f1) = fa1 in
  let (q2,a2,s2,f2) = fa2 in
  let f = Q_set.union f1 (Q_set.remove s2 f2) in
  let q = Q_set.union q1 (Q_set.remove s2 q2) in
  let cqs = Arrow.find s2 a2 in
  let a = Arrow.union' a1 (Arrow.remove s2 a2) in
  let a = Q_set.fold (fun x a -> Arrow.add' x cqs a) f1 a in
  (q,a,s1,f)

(* L(fa1)L(fa1)...L(fa1) : n > 0 *)

(* Invariant : (fa, m1) = f m0 :  m0 <= states < m1 *)

let phiFA m = 
  ((setQ [m;m+1],Arrow.empty,m,setQ [m+1]), m+2)

let epsilonFA m = 
  ((setQ [m],Arrow.empty,m,setQ [m]), m+1)

let alphaFA a m = 
  ((setQ [m;m+1], Arrow.add m a (m+1) Arrow.empty, m, setQ [m+1]),
   m+2)

let allalphaFA ss m = 
  let arrow = Fa.Symbol_set.fold (fun c a -> Arrow.add m c (m+1) a) ss Arrow.empty in
  ((setQ [m;m+1], arrow, m,setQ [m+1]),
   m+2)

let alphalistFA al m = 
  ((setQ [m;m+1], 
    List.fold_right (fun a making -> Arrow.add m a (m+1) making)
      al Arrow.empty,
    m,setQ [m+1]),
   m+2)

let negalphalistFA ss al m = 
  let arrow = Fa.Symbol_set.fold (fun c a -> 
    if List.mem c al then a
    else Arrow.add m c (m+1) a) ss Arrow.empty in
  ((setQ [m;m+1], arrow, m, setQ [m+1]),
   m+2)

(*  m0 <= states < m1 *)
let renameFA (fa, min, max) m =
  (Fa.renameFA fa (m - min), m + max - min)

let reg2nfa' ss reg m = 
  let rec reg2nfa' reg m = 
    match reg with
      Phi      -> phiFA m
    | Epsilon  -> epsilonFA m
    | Alpha a  -> alphaFA a m
    | Allalpha -> allalphaFA ss m
    | Alphalist al -> alphalistFA al m
    | Negalphalist al -> negalphalistFA ss al m
    | Group a -> reg2nfa' a m
    | Plus(a,b)-> 
	let fa1, m = reg2nfa' a m in
	let (q1,a1,s1,f1) = fa1 in
	let fa2, m = reg2nfa' b m in
	let (q2,a2,s2,f2) = fa2 in
	let f = if Q_set.mem s2 f2 
	then Q_set.union (Q_set.add s1 f1) (Q_set.remove s2 f2) 
	else Q_set.union f1 f2 in
	let q = Q_set.union q1 (Q_set.remove s2 q2) in
	let a = Arrow.union' a1 (Arrow.remove s2 a2) in
	let a = Arrow.add' s1 (Arrow.find s2 a2) a in
	((q,a,s1,f), m)
    | App(a,b) -> 
	let fa1, m = reg2nfa' a m in
	let fa2, m = reg2nfa' b m in
	(joinFA fa1 fa2, m)
    | Star a  -> 
	let (q1,a1,s1,f1),m = reg2nfa' a m in
	let f = Q_set.add s1 f1 in
	let cqs = Arrow.find s1 a1 in
	let a = Q_set.fold (fun x a -> Arrow.add' x cqs a) f1 a1 in
	((q1,a,s1,f), m)
    | Repetition (a,i,None)  -> 
	if i < 0 then failwith "Repetition" 
	else 
	  let fa', m = reg2nfa' (Star a) m in
	  let rec repeat j m = 
	    let fa, m = reg2nfa' a m in
	    if j = 1 then (fa, m)
	    else 
	      let fa', m = repeat (j - 1) m in
	      (joinFA fa fa', m) in
	  let fa, m = if i = 0 then epsilonFA m else repeat i m in
	  (joinFA fa fa', m)
    | Repetition (a,i,Some j)  -> 
	if i < 0 then failwith "Repetition" 
	else 
	  let rec repeat j m = 
	    let fa, m = reg2nfa' a m in
	    if j = 1 then (fa, m)
	    else 
	      let fa', m = repeat (j - 1) m in
	      (joinFA fa fa', m) in
	  let fa1, m = if i = 0 then epsilonFA m else repeat i m in
	  if j < i then failwith "Repetition" 
	  else if i = j then (fa1, m)
	  else
	    let rec repeat' j m = 
	      let fa, m = reg2nfa' a m in
	      if j = 1 then (fa, m)
	      else 
		let fa', m = repeat' (j - 1) m in
		(joinFA' fa fa', m) in
	    let fa2, m = repeat' (j - i) m in
	    (joinFA' fa1 fa2, m) in
  reg2nfa' reg m

let reg2nfa ss reg = 
  let (qs,aset,s,fs),_ = reg2nfa' ss reg 0 in 
  {symbols = ss;
   states = qs;
   arrow = Arrow.convert aset;
   start = s;
   final = fs}

	

