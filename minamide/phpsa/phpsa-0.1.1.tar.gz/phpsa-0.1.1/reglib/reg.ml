(*
 * PHP string analyzer
 * Copyright (C) 2005, 2006 Nobuo Otoi, Yasuhiko Minamide
 *)
open Basic

let start_metachar = Charset.metachar1
let end_metachar = Charset.metachar2

type reg = 
    Plus of reg * reg
  | Star of reg
  | Repetition of reg * int * int option
  | App of reg * reg
  | Alpha of alpha
  | Epsilon
  | Phi 
  | Allalpha
  | Alphalist of alpha list
  | Negalphalist of alpha list
  | Group of reg

type preg = 
    {reg : reg; 
     greedy : bool ; 
     caseless : bool ; 
     multiline : bool ;
     match_start : bool ; 
     match_end :bool}

let match_start_end_reg preg =
  let reg = if preg.match_start then App (Alpha start_metachar, preg.reg) else preg.reg in
  let reg = if preg.match_end then App (reg, Alpha end_metachar) else reg in
  {preg with reg = reg}

let rec pp_reg fmt = function
    Plus (r1,r2) -> Format.fprintf fmt "(%a+%a)" pp_reg r1 pp_reg r2
  | Star r1      ->  Format.fprintf fmt "(%a)*" pp_reg r1
  | Group r1      -> Format.fprintf fmt "(%a)" pp_reg r1
  | App (r1,r2)  -> Format.fprintf fmt "%a%a" pp_reg r1 pp_reg r2
  | Alpha '['     -> Format.fprintf fmt "%s" "\\["
  | Alpha ']'     -> Format.fprintf fmt "%s" "\\]"
  | Alpha ch     -> Format.fprintf fmt "%s" (Char.escaped ch)
  | Epsilon      -> Format.pp_print_string fmt "()"  
  | Phi          -> Format.pp_print_string fmt "[]"
  | Allalpha     -> Format.pp_print_char fmt '.'
  | Alphalist cl -> Format.fprintf fmt "[%s]" (String.concat "" (List.map Char.escaped cl))
  | Negalphalist cl -> Format.fprintf fmt "[^%s]" (String.concat "" (List.map Char.escaped cl))
  | Repetition (r,i,None) -> Format.fprintf fmt "%a{%d,}" pp_reg r i
  | Repetition (r,i,Some j) -> Format.fprintf fmt "%a{%d,%d}" pp_reg r i j


let string_of_reg r =
  let buf = Buffer.create 100 in
  let fmt = Format.formatter_of_buffer buf in
  pp_reg fmt r;
  Format.pp_print_flush fmt ();
  Buffer.contents buf 

let print_of_reg reg =
  pp_reg Format.std_formatter reg

let rec rev reg = 
  match reg with
    Plus(a,b)-> Plus (rev a, rev b)
  | App(a, b) -> App(rev b, rev a)
  | Star a -> Star (rev a)
  | Repetition (a,i,j) -> Repetition (rev a,i,j)
  | Group a -> Group (rev a)
  | _ -> reg

let case_insensitive_charlist cs = 
  List.fold_right (fun c cs ->
    if ('a' <= c && c <= 'z') 
    then c::Char.uppercase c::cs
    else if ('A' <= c && c <= 'Z') 
    then c::Char.lowercase c::cs
    else c::cs) cs []

let rec case_insensitive = function
    Plus (r1,r2) -> 
      Plus (case_insensitive r1, case_insensitive r2)
  | Star r1 -> Star (case_insensitive r1)
  | Group r1 -> Group (case_insensitive r1)
  | App (r1,r2)  -> 
      App (case_insensitive r1, case_insensitive r2)
  | Alpha ch     -> 
      if ('a' <= ch && ch <= 'z') 
      then Alphalist [ch; Char.uppercase ch]
      else if ('A' <= ch && ch <= 'Z') 
      then Alphalist [ch; Char.lowercase ch]
      else Alpha ch
  | Epsilon -> Epsilon
  | Phi -> Phi
  | Allalpha -> Allalpha
  | Alphalist cl -> Alphalist (case_insensitive_charlist cl)
  | Negalphalist cl -> 
      Negalphalist (case_insensitive_charlist cl)
  | Repetition (r,i,j) -> Repetition (case_insensitive r, i, j)


let rec subreg reg =
  match reg with
    Plus(a,b)-> subreg a @ subreg b
  | App(a, b) -> subreg a @ subreg b
  | Star a -> subreg a
  | Repetition (a,i,j) -> subreg a
  | Group a -> a :: subreg a
  | _ -> []


let rec subreg_c (l,reg,r) =
  match reg with
    Plus(a,b)-> subreg_c (l,a,r) @ subreg_c (l,b,r)
  | App(a, b) -> subreg_c (l,a,App(b,r)) @ subreg_c (App (l,a),b,r)
  | Star a -> subreg_c (App (l,reg),a,App(reg,r))
(* Can be improved *)
  | Repetition (a,i,None) -> 
      let i' = if i = 0 then 0 else i - 1 in
      let reg' = Repetition (a,i',None) in
      subreg_c (App (l,reg'), a, App (reg',r))
  | Repetition (a,i,Some j) -> 
      let i' = if i = 0 then 0 else i - 1 in
      let j' = if j = 0 then 0 else j - 1 in
      let reg' = Repetition (a,i',Some j') in
      subreg_c (App (l,reg'), a, App (reg',r))
  | Group a -> (l,a,r) :: subreg_c (l,a,r)
  | _ -> []

let any_string = Star Allalpha

let string_reg s = 
  string_fold_right 
    (fun c reg -> App (Alpha c, reg)) s Epsilon

let rec has_start_metachar = function
    Plus (r1,r2) -> has_start_metachar r1 || has_start_metachar r2
  | Star r1 -> has_start_metachar r1
  | Group r1 -> has_start_metachar r1
  | App (r1,r2)  -> has_start_metachar r1 || has_start_metachar r2
  | Alpha c -> c = start_metachar
  | Repetition (r,i,j) -> has_start_metachar r
  | _ -> false

let rec has_end_metachar = function
    Plus (r1,r2) -> has_end_metachar r1 || has_end_metachar r2
  | Star r1 -> has_end_metachar r1
  | Group r1 -> has_end_metachar r1
  | App (r1,r2)  -> has_end_metachar r1 || has_end_metachar r2
  | Alpha c -> c = end_metachar 
  | Repetition (r,i,j) -> has_end_metachar r
  | _ -> false

