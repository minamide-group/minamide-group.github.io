(*
 * PHP string analyzer
 * Copyright (C) 2005, 2006 Yasuhiko Minamide
 *)
open Simplelexer
open Reg 

let implode cs =
  let n = List.length cs in
  let s = String.create n in
  let rec loop i cs = 
    match cs with
      [] -> () 
    | c::cs -> String.set s i c; loop (i+1) cs in
  loop 0 cs; s
 
let rec mkcharlist n m =
  if n > m then [] else Char.chr n :: mkcharlist (n+1) m 

let digit_chars = mkcharlist (Char.code '0') (Char.code '9')

let lower_chars =  mkcharlist (Char.code 'a') (Char.code 'z')

let upper_chars =  mkcharlist (Char.code 'A') (Char.code 'Z')

let alpha_chars =  lower_chars @ upper_chars 

let alphanum_chars =  digit_chars @ alpha_chars

let blank_chars =  [' '; '\t']
let space_chars =  ['\n'; '\r'] @ blank_chars


let sym_chars = 
  ['!'; '"'; '#'; '$'; '%'; '\''; '('; ')'; '*'; '+'; ',';
   '-'; '.'; '/'; ':'; ';'; '<'; '='; '>'; '?'; '@'; 
   '['; '\\'; ']'; '^'; '_'; '`'; 
   '{'; '|'; '}'; '~']

let graph_chars = sym_chars@alphanum_chars

let print_chars = ' '::graph_chars

let xdigit_chars = mkcharlist (Char.code 'a') (Char.code 'f') @
  mkcharlist (Char.code 'A') (Char.code 'F') @ digit_chars

let charclass_tbl = Hashtbl.create 19 
let _ =
  List.iter (fun (kwd, charclass) -> Hashtbl.add charclass_tbl kwd charclass)
    ["digit", digit_chars;
     "lower", lower_chars;
     "upper", upper_chars;
     "alpha", alpha_chars;
     "alphanum", alphanum_chars;
     "blank", blank_chars;
     "space", space_chars;
     "graph", graph_chars;
     "print", print_chars;
     "xdigit", xdigit_chars]

(*
 * C -> id
 * C -> \B
 * I -> ]
 * I -> CI'
 * I -> -I'
 * I' -> -CI
 * I' -> -]
 * I' -> I
 * F -> id
 * F -> ( E )
 * F -> [I 
 * F -> [^I 
 * T -> \epsilon
 * T -> FUT  
 * U -> \epsilon
 * U -> +
 * U -> *
 * U -> {d,d}
 * U -> {d,}
 * U -> {d}
 * E -> T
 * E -> T|E
 * S -> xEx where x is not alphanumeric or backslash
 *)

let reg_app (e1, e2) =
  match (e1, e2) with
    Epsilon, e2_ -> e2
  | e1, Epsilon -> e1
  | _ -> App (e1, e2) 

module Make(SL : SIMPLE_LEXER) = 
  struct
    open SL
    let advance = SL.advance 
    let next_tok' lexbuf = SL.next_tok_n lexbuf 0

    let next_tok lexbuf = next_tok' lexbuf

    let eat lexbuf c =
      match next_tok lexbuf with
	ID c' -> if c = c' then advance lexbuf else failwith "eat"
      | _ -> failwith "eat"
	    
    let rec parse_num lexbuf head n =
      let cont () = if head then failwith "digit" else n in
      let digit2int c = Char.code c - Char.code '0' in
      match next_tok lexbuf with
	ID c -> 
	  if c >= '0' && c <= '9' 
	  then (advance lexbuf; parse_num lexbuf false (n*10 + digit2int c))
	  else cont ()
      | _ -> cont ()

    let parse_B lexbuf =
      match next_tok' lexbuf with
      | ID c -> advance lexbuf; c
      | EOF -> failwith "backslash"     

    let rec parse_CT lexbuf cs =
      match cs, next_tok lexbuf  with
	':'::cs', ID ']' -> 
	  (advance lexbuf;
	   try Hashtbl.find charclass_tbl (implode (List.rev cs'))
	  with _ -> failwith "bracket expression")
      | _, ID c -> advance lexbuf; parse_CT lexbuf (c::cs)
      | _, EOF -> failwith "brack expression" 

    let rec parse_I lexbuf cs =
      match next_tok lexbuf, SL.next_tok_n lexbuf 1  with
      | ID '[', ID ':' -> 
	  let () =  advance lexbuf in
	  let () =  advance lexbuf in
	  let cs' = parse_CT lexbuf [] in
	  parse_I'' lexbuf (cs'@cs)
      | ID ']', _ -> cs
      | ID '\\', _ -> 
	  let () = advance lexbuf in
	  let c = parse_B lexbuf in
	  parse_I' lexbuf c cs
      | ID c, _ -> advance lexbuf; parse_I' lexbuf c cs
      | EOF, _ -> failwith "parse_I"
    and parse_I' lexbuf c cs =
      match next_tok lexbuf with
      | ID ']' -> c::cs
      | ID '-' -> 
	  let () = advance lexbuf in
	  (match next_tok lexbuf with
	    ID ']' -> '-'::c::cs
	  | ID '\\' -> 
	      let () = advance lexbuf in
	      let c' = parse_B lexbuf in
	      let cs = mkcharlist (Char.code c) (Char.code c') @ cs in
	      parse_I'' lexbuf cs
	  | ID c' -> 
	      let () = advance lexbuf in
	      let cs = mkcharlist (Char.code c) (Char.code c') @ cs in
	      parse_I'' lexbuf cs
	  | EOF -> failwith "parse_I'") 
      | _ -> parse_I lexbuf (c::cs)
    and parse_I'' lexbuf cs =
      match next_tok lexbuf, SL.next_tok_n lexbuf 1  with
      | ID '[', ID ':' -> 
	  let () =  advance lexbuf in
	  let () =  advance lexbuf in
	  let cs' = parse_CT lexbuf [] in
	  parse_I lexbuf (cs'@cs)
      | ID ']', _ -> cs
      | ID '\\', _ -> 
	  let () = advance lexbuf in
	  let c = parse_B lexbuf in
	  parse_I' lexbuf c cs
      | ID '-', ID ']' -> advance lexbuf; '-'::cs
      | ID '-', _ -> failwith "parse_I''"
      | ID c, _ -> advance lexbuf; parse_I' lexbuf c cs
      | EOF, _ -> failwith "parse_I"

    let rec parse_F lexbuf =
      match next_tok lexbuf with
	ID '.' -> 
	  let () = advance lexbuf in
	  Allalpha
      | ID '\\' -> 
	  let () = advance lexbuf in
	  Alpha (parse_B lexbuf)
      | ID '[' -> 
	  let () = advance lexbuf in
	  let b = 
	    match next_tok lexbuf with
	      ID '^' -> advance lexbuf; true
	    | _ -> false  in
	  let cs = parse_I lexbuf [] in
	  eat lexbuf ']'; 
	  if b then Negalphalist cs else Alphalist cs
      | ID '(' -> 
	  let () = advance lexbuf in
	  let e = parse_E lexbuf in
	  (match next_tok lexbuf with
	    ID ')' -> advance lexbuf; Group e
	  | ID c -> failwith (String.make 1 c)
	  | _ -> failwith "Right parenthesis is expected!\n")
      | ID '^' -> (advance lexbuf; Alpha start_metachar)
      | ID '$' -> (advance lexbuf; Alpha end_metachar)
      | ID s-> (advance lexbuf; Alpha s)
      | _ -> failwith "Id or Right parenthesis is expected!\n"

    and parse_T lexbuf =
      match next_tok lexbuf with
	EOF | ID '|' | ID ')' -> Epsilon
      | _ ->
	  let e = parse_F lexbuf in
	  let e = parse_U lexbuf e in
	  let es = parse_T lexbuf in
	  reg_app (e, es)

    and parse_U lexbuf e =
      match next_tok lexbuf with
      | ID '+' -> 
	  advance lexbuf; 
	  (match next_tok lexbuf with
	  | ID '?' ->  advance lexbuf 
	  | _ -> ());
	  parse_U lexbuf (Repetition (e, 1, None))
      | ID '*' -> 
	  advance lexbuf; 
	  (match next_tok lexbuf with
	  | ID '?' ->  advance lexbuf 
	  | _ -> ());
	  parse_U lexbuf (Star e)
      | ID '?' -> 
	  advance lexbuf; 
	  parse_U lexbuf (Repetition (e, 0, Some 1))
      | ID '{' -> 
	  (match SL.next_tok_n lexbuf 1 with
	    ID c when c >= '0' && c <= '9' ->
	      let () = advance lexbuf in
	      let n = parse_num lexbuf true 0 in
	      (match next_tok lexbuf with
		ID '}' -> 
		  advance lexbuf; 
		  parse_U lexbuf (Repetition (e, n, Some n))
	      | ID ',' -> 
		  let () = advance lexbuf in
		  (match next_tok lexbuf with
		    ID '}' -> 
		      advance lexbuf; 
		      parse_U lexbuf (Repetition (e, n, None))
		  | _ -> 
		      let m = parse_num lexbuf true 0 in
		      eat lexbuf '}'; 
		      parse_U lexbuf (Repetition (e, n, Some m)))
	      | _ -> failwith "Camma or right brace")
	  | _ -> e)
      | _  -> e

    and parse_E lexbuf =
      let e = parse_T lexbuf in
      match next_tok lexbuf with
	ID '|' -> advance lexbuf; Plus (e, parse_E lexbuf)
      | _ -> e

    let parse str =
      let lexbuf = SL.create str in
      parse_E lexbuf
  end

module StringParser = Make(SLString)
let parse = StringParser.parse

module CharListParser = Make(SLCharList)
let parse_charlist = CharListParser.parse


