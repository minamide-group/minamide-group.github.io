(*
 * PHP string analyzer
 * Copyright (C) 2005, 2006 Yasuhiko Minamide
 *)
open Simplelexer
open Reg 

let rec mkcharlist n m =
  if n > m then [] else Char.chr n :: mkcharlist (n+1) m 

let digit_chars = mkcharlist (Char.code '0') (Char.code '9')

let word_chars =
  '_' :: digit_chars @
  mkcharlist (Char.code 'a') (Char.code 'z') @
  mkcharlist (Char.code 'A') (Char.code 'Z')

let space_chars = [' '; '\t'; '\n'; '\r'; '\028']

let rec process_modelist reg cs =
  match cs with
    [] -> reg
  | 'i'::cs -> process_modelist {reg with caseless = true } cs
  | 'm'::cs -> process_modelist {reg with multiline = true } cs
  | 'U'::cs -> process_modelist {reg with greedy = false } cs
  | c::cs -> failwith 
	("Unknown (or unimplemented) regular expression modifier : "^String.make 1 c)

let mkreg (reg, match_start, match_end) modelist =
  process_modelist
    { reg = reg; 
      greedy = true;
      caseless = false;
      multiline = false;
      match_start = match_start;
      match_end = match_end } modelist

(*
 * C -> id
 * C -> \B
 * I -> ]
 * I -> CI'
 * I -> -I'
 * I' -> -CI
 * I' -> -]
 * I' -> I
 * F -> id
 * F -> ( E )
 * F -> [I 
 * F -> [^I 
 * T -> \epsilon
 * T -> FUT  
 * U -> \epsilon
 * U -> +
 * U -> *
 * U -> {d,d}
 * U -> {d,}
 * U -> {d}
 * E -> T
 * E -> T|E
 * S -> xEx where x is not alphanumeric or backslash
 *)

let reg_app (e1, e2) =
  match (e1, e2) with
    Epsilon, e2_ -> e2
  | e1, Epsilon -> e1
  | _ -> App (e1, e2) 

let check_delimiter c =
  if (c >= '0' && c <= '9') ||
  (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')
  then failwith "bad delimiter"
  else c  


module Make(SL : SIMPLE_LEXER) = 
  struct
    type token = 
	EOF
      | DELIMIT 
      | DOLLAR (* $ before delimiter *)
      | ID of char 

    let advance = SL.advance 
    let next_tok' lexbuf = SL.next_tok_n lexbuf 0

    let next_tok delimit lexbuf =
      match next_tok' lexbuf with
	SL.ID c when c = delimit -> DELIMIT 
      | SL.ID '$' -> 
	  if SL.next_tok_n lexbuf 1 = SL.ID delimit then DOLLAR
	  else ID '$'
      | SL.ID c -> ID c
      | SL.EOF -> EOF

    let eat delimit lexbuf c =
      match next_tok delimit lexbuf with
	ID c' -> if c = c' then advance lexbuf else failwith "eat"
      | _ -> failwith "eat"
	    
    let rec parse_num delimit lexbuf head n =
      let cont () = if head then failwith "digit" else n in
      let digit2int c = Char.code c - Char.code '0' in
      match next_tok delimit lexbuf with
	ID c -> 
	  if c >= '0' && c <= '9' 
	  then (advance lexbuf; parse_num delimit lexbuf false (n*10 + digit2int c))
	  else cont ()
      | _ -> cont ()

    let rec parse_hex delimit lexbuf head n =
      let cont n = if head then parse_hex delimit lexbuf false n else n in
      let char2int c c' = Char.code c - Char.code c' in
      match next_tok delimit lexbuf with
	ID c -> 
	  if c >= '0' && c <= '9' 
	  then (advance lexbuf; cont (n*16 + char2int c '0'))
	  else if c >= 'a' && c <= 'f'  then
	    (advance lexbuf; cont (n*16 + char2int c 'a' + 10))
	  else if c >= 'A' && c <= 'F'  then
	    (advance lexbuf; cont (n*16 + char2int c 'A' + 10))
	  else n
      | _ -> n
      
    let rec parse_octal delimit lexbuf head n =
      let cont n = if head then parse_octal delimit lexbuf false n else n in
      let char2int c c' = Char.code c - Char.code c' in
      match next_tok delimit lexbuf with
	ID c -> 
	  if c >= '0' && c <= '7' 
	  then (advance lexbuf; cont (n*8 + char2int c '0'))
	  else n
      | _ -> n

    let parse_B delimit lexbuf =
      match next_tok' lexbuf with
      | SL.ID 'd' -> advance lexbuf; Alphalist digit_chars
      | SL.ID 'D' -> advance lexbuf; Negalphalist digit_chars
      | SL.ID 's' -> advance lexbuf; Alphalist space_chars
      | SL.ID 'S' -> advance lexbuf; Negalphalist space_chars
      | SL.ID 'w' -> advance lexbuf; Alphalist word_chars
      | SL.ID 'W' -> advance lexbuf; Negalphalist word_chars
      | SL.ID 'x' -> advance lexbuf; Alpha (Char.chr (parse_hex delimit lexbuf true 0))
      | SL.ID 'a' -> advance lexbuf; Alpha '\x07'
      | SL.ID 'c' -> failwith "unsupported backslash"
      | SL.ID 'e' -> advance lexbuf; Alpha '\x1B'
      | SL.ID 'f' -> advance lexbuf; Alpha '\x0C'
      | SL.ID 'n' -> advance lexbuf; Alpha '\n'
      | SL.ID 'r' -> advance lexbuf; Alpha '\r'
      | SL.ID 't' -> advance lexbuf; Alpha '\t'
      | SL.ID '0' -> advance lexbuf; Alpha (Char.chr (parse_octal delimit lexbuf true 0))
      | SL.ID c -> 
	  if c >= '1' &&  c <= '9'  then 
	    failwith "unsupported backslash"
	  else (advance lexbuf; Alpha c)
      | SL.EOF -> failwith "backslash"     

    let rec parse_I delimit lexbuf cs =
      match next_tok delimit lexbuf with
      | ID ']' -> cs
      | ID '\\' -> 
	  (advance lexbuf;
	   match parse_B delimit lexbuf with
	   | Alphalist cs' -> parse_I delimit lexbuf (cs'@cs)
	   | Alpha c -> parse_I' delimit lexbuf c cs
	   | Negalphalist cs' -> failwith "Negalphalist"
	   | _  -> failwith "parse_I")
      | ID c -> advance lexbuf; parse_I' delimit lexbuf c cs
      | EOF -> failwith "parse_I"
      | DELIMIT -> failwith "parse_I"
      | DOLLAR -> failwith "parse_I"
    and parse_I' delimit lexbuf c cs =
      match next_tok delimit lexbuf with
      | ID ']' -> c::cs
      | ID '-' -> 
	  let () = advance lexbuf in
	  (match next_tok delimit lexbuf with
	    ID ']' -> '-'::c::cs
	  | ID '\\' -> 
	      let () = advance lexbuf in
	      let cs =
		match parse_B delimit lexbuf with
		| Alphalist cs' -> c::'-'::cs'@cs
		| Alpha c' -> mkcharlist (Char.code c) (Char.code c') @ cs
		| Negalphalist cs' -> failwith "Negalphalist"
		| _  -> failwith "parse_I'" in
	      parse_I delimit lexbuf cs
	  | ID c' -> 
	      let () = advance lexbuf in
	      let cs = mkcharlist (Char.code c) (Char.code c') @ cs in
	      parse_I delimit lexbuf cs
	  | DELIMIT -> failwith "parse_I'"
	  | DOLLAR -> failwith "parse_I'"
	  | EOF -> failwith "parse_I'") 
      | _ -> parse_I delimit lexbuf (c::cs)

    let rec parse_F delimit lexbuf =
      match next_tok delimit lexbuf with
	ID '.' -> 
	  let () = advance lexbuf in
	  Allalpha
      | ID '\\' -> 
	  let () = advance lexbuf in
	  parse_B delimit lexbuf
      | ID '[' -> 
	  let () = advance lexbuf in
	  let b = 
	    match next_tok delimit lexbuf with
	      ID '^' -> advance lexbuf; true
	    | _ -> false  in
	  let cs = parse_I delimit lexbuf [] in
	  eat delimit lexbuf ']'; 
	  if b then Negalphalist cs else Alphalist cs
      | ID '(' -> 
	  let () = advance lexbuf in
	  let e = parse_E delimit lexbuf in
	  (match next_tok delimit lexbuf with
	    ID ')' -> advance lexbuf; Group e
	  | ID c -> failwith (String.make 1 c)
	  | _ -> failwith "Right parenthesis is expected!\n")
      | ID s-> (advance lexbuf; Alpha s)
      | _ -> failwith "Id or Right parenthesis is expected!\n"

    and parse_T delimit lexbuf =
      match next_tok delimit lexbuf with
	EOF | ID '|' | ID ')' | DELIMIT | DOLLAR -> Epsilon
      | _ ->
	  let e = parse_F delimit lexbuf in
	  let e = parse_U delimit lexbuf e in
	  let es = parse_T delimit lexbuf in
	  reg_app (e, es)

    and parse_U delimit lexbuf e =
      match next_tok delimit lexbuf with
      | ID '+' -> 
	  advance lexbuf; 
	  (match next_tok delimit lexbuf with
	  | ID '?' ->  advance lexbuf 
	  | _ -> ());
	  parse_U delimit lexbuf (Repetition (e, 1, None))
      | ID '*' -> 
	  advance lexbuf; 
	  (match next_tok delimit lexbuf with
	  | ID '?' ->  advance lexbuf 
	  | _ -> ());
	  parse_U delimit lexbuf (Star e)
      | ID '?' -> 
	  advance lexbuf; 
	  parse_U delimit lexbuf (Repetition (e, 0, Some 1))
      | ID '{' -> 
	  let () = advance lexbuf in
	  let n = parse_num delimit lexbuf true 0 in
	  (match next_tok delimit lexbuf with
	    ID '}' -> 
	      advance lexbuf; 
	      parse_U delimit lexbuf (Repetition (e, n, Some n))
	  | ID ',' -> 
	      let () = advance lexbuf in
	      (match next_tok delimit lexbuf with
		ID '}' -> 
		  advance lexbuf; 
		  parse_U delimit lexbuf (Repetition (e, n, None))
	      | _ -> 
		  let m = parse_num delimit lexbuf true 0 in
		  eat delimit lexbuf '}'; 
		  parse_U delimit lexbuf (Repetition (e, n, Some m)))
	  | _ -> failwith "Camma or right brace")
      | _  -> e

    and parse_E delimit lexbuf =
      let e = parse_T delimit lexbuf in
      match next_tok delimit lexbuf with
	ID '|' -> advance lexbuf; Plus (e, parse_E delimit lexbuf)
      | _ -> e

    let rec parse_mode lexbuf cs =
      match next_tok' lexbuf with
	SL.EOF -> cs
      | SL.ID c -> advance lexbuf; parse_mode lexbuf (c::cs)

    let parse str =
      let lexbuf = SL.create str in
      let delimit = 
	match next_tok' lexbuf with
	  SL.ID c -> advance lexbuf; check_delimiter c
	| _ -> failwith "empty regular expression" in
      let match_start =
	match next_tok delimit lexbuf with
	  ID '^' -> advance lexbuf; true
	| _ -> false in
      let reg = parse_E delimit lexbuf in
      let match_end  =
	match next_tok delimit lexbuf with
	  DELIMIT -> advance lexbuf; false
	| DOLLAR -> 
	    (advance lexbuf; 
	     match next_tok delimit lexbuf with
	       DELIMIT -> advance lexbuf; true
	     | _ -> failwith "no delimiter")
	| _ -> failwith "no delimiter" in
      let modelist = parse_mode lexbuf [] in
      mkreg (reg, match_start, match_end) modelist
  end

module StringParser = Make(SLString)
let parse = StringParser.parse

let parse_reg str = 
  let reg = parse str in
  if reg.greedy <> true ||
      reg.caseless <> false ||
      reg.multiline <> false then failwith "parse_reg";
  reg.reg


module CharListParser = Make(SLCharList)
let parse_charlist = CharListParser.parse

let parse_reg_charlist cs = 
  let reg = parse_charlist cs in
  if reg.greedy <> true ||
      reg.caseless <> false ||
      reg.multiline <> false then failwith "parse_reg";
  reg.reg

