(*
 * PHP string analyzer
 * Copyright (C) 2006 Yasuhiko Minamide
 *)
module Charset =
  Set.Make(struct 
    type t = char
    let compare = compare end)

module Fa = Fa.Make(
  struct
    type symbol = char 
    let string_of = Char.escaped
    let pp_print = Format.pp_print_char 
    let compare = compare
    module Symbol_set = Charset
  end)

let metachar0 = '\253' 
let metachar1 = '\254' 
let metachar2 = '\255' 

let fullcharset =
  let rec int_fold n a = 
    if n >= 0 then int_fold (n-1) (Charset.add (Char.chr n) a)
    else a in
  int_fold 0xFF Charset.empty

let charset =
  let cs = Charset.remove metachar0 fullcharset in
  let cs = Charset.remove metachar1 cs in
  Charset.remove metachar2 cs

  

