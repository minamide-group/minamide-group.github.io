(*
 * PHP string analyzer
 * Copyright (C) 2006 Yasuhiko Minamide
 *)
module type SIMPLE_LEXER =
  sig
    type token = ID of char | EOF
    type t
    type lexbuf
    val create : t -> lexbuf
    val next_tok_n : lexbuf -> int -> token
    val advance : lexbuf -> unit
  end

module SLString =
  struct
    type token = ID of char | EOF
    type t = string
    type lexbuf = string * int ref

    let create s = (s, ref 0)

    let next_tok_n lexbuf n =
      let str, pos = lexbuf in
      let pos' = !pos + n in
      if pos' < String.length str then
	ID (String.get str pos')
      else EOF

    let advance lexbuf =
      let str, pos = lexbuf in incr pos

  end

module SLCharList =
  struct
    type token = ID of char | EOF
    type t = char list
    type lexbuf = char list ref

    let create cs = ref cs

    let next_tok_n (lexbuf:lexbuf) n =
      try ID(List.nth (!lexbuf) n) with Failure _ -> EOF 

    let advance lexbuf =
      let cs = lexbuf in
      match !cs with
	[] -> failwith "advance"
      | _::ds -> cs := ds

  end
