(*
 * PHP string analyzer
 * Copyright (C) 2005, 2006 Nobuo Otoi, Yasuhiko Minamide
 *)
open Basic

module Make (F:Fa.S) =
struct
open F

module IntPairMap = 
  Map.Make(struct 
    type t = Q_set.elt * Q_set.elt 
    let compare = compare end)

module IntPairSet = 
  Set.Make(struct 
    type t = Q_set.elt * Q_set.elt 
    let compare = compare end)

module QMap = 
  Map.Make(struct 
    type t = Q_set.elt 
    let compare = compare end)

let set_map_add a v m =
  let w = try IntPairMap.find a m with _ -> IntPairSet.empty in
  IntPairMap.add a (IntPairSet.add v w) m

let qmap_find x m =
  try QMap.find x m with Not_found -> []

let qpair_fold f qs base = 
  Q_set.fold 
    (fun q making -> 
      Q_set.fold (fun r making -> 
	if q < r then f (q,r) making else making) qs making) qs base

let process_worklist isFinal delta delta_list qs =
  let process_state (p,q) ((pmap,qqs) as making) = 
    let rec process_alpha cqs (pmap, qqs) = 
      match cqs with
	[] -> (pmap, qqs)
      | (a,r')::cqs ->
	  if not (ArrowMap.mem (q,a) delta) then
	    (pmap, IntPairSet.add (p,q) qqs)
	  else
	    let s' = ArrowMap.find (q,a) delta in
	    if r' = s' then process_alpha cqs (pmap,qqs) else 
	    let (r,s) = if r' < s' then (r',s') else (s',r') in
	    if IntPairSet.mem (r,s) qqs then
	      (pmap, IntPairSet.add (p,q) qqs)
	    else
	      process_alpha cqs 
		(set_map_add (r,s) (p,q) pmap,qqs) in
    if isFinal p = isFinal q then 
      process_alpha (QMap.find p delta_list) making
    else (pmap, IntPairSet.add (p,q) qqs) in
  qpair_fold process_state qs
    (IntPairMap.empty, IntPairSet.empty)

let find' x pmap =
  try 
    IntPairMap.find x pmap
  with
    _ -> IntPairSet.empty

let rec pmap_dfs pmap xs rs =
  if IntPairSet.is_empty xs then rs else
  let x = IntPairSet.choose xs in
  let xs = IntPairSet.remove x xs in
  if IntPairSet.mem x rs then pmap_dfs pmap xs rs
  else pmap_dfs pmap (IntPairSet.union xs (find' x pmap)) 
      (IntPairSet.add x rs)

let mk_delta aset =
  ArrowMap.fold (fun (xFrom,xBy) xTo making -> 
    ArrowMap.add (xFrom,xBy) (Q_set.choose xTo) making)
    aset ArrowMap.empty

let mk_delta_list aset =
  ArrowMap.fold (fun (xFrom,xBy) xTo making -> 
    QMap.add xFrom ((xBy,xTo)::qmap_find xFrom making)  making)
    aset QMap.empty

let marking fa = 
  let isFinal elm = Q_set.mem elm fa.final in
  let delta = mk_delta fa.arrow in
  let delta_list = mk_delta_list delta in
  let pmap,eqList = 
    process_worklist isFinal delta delta_list fa.states in
  let uneq = pmap_dfs pmap eqList IntPairSet.empty in
  qpair_fold (fun (p,q) making -> 
    if IntPairSet.mem (p,q) uneq then making
    else 
      try 
	let r = QMap.find q making in
	if p < r then QMap.add q p making else making
      with Not_found -> QMap.add q p making) fa.states QMap.empty

let minimize fa = 
  let rmap = marking fa in
  let rename q = try QMap.find q rmap with Not_found -> q in
  F.image rename fa

end







