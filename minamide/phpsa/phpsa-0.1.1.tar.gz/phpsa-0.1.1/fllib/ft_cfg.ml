(*
 * PHP string analyzer
 * Copyright (C) 2005, 2006 Nobuo Otoi, Yasuhiko Minamide
 *)
open Basic

module Make (C: Cfg.S)(F:Ft.S with type symbol = C.terminal and type symbol_t = C.symbol)  =
  struct
    module F = F
    module C = C
    type cfg = C.cfg
	  
    type symbol = C.symbol
	    
    module TerminalMap =
      Map.Make(struct 
	type t = C.terminal
	let compare = compare
      end)

    let normalize1_prod from xs (pset, cmap) = 
      match xs with
	| [] | [_] -> (C.prod_add (from, xs) pset, cmap)  
	| _ -> 
	    let xs', pset, cmap =
	      List.fold_right (fun x (xs', pset, cmap) ->
		match x with
		  C.Terminal t -> 
		    (try
		      (C.Variable (TerminalMap.find t cmap)::xs', pset,
		       cmap)
		    with Not_found ->
		      let y = C.fresh_variable () in
	    	      let cmap = TerminalMap.add t y cmap in
		      (C.Variable y::xs', C.prod_add (y, [x]) pset, cmap))

		| C.Variable _ -> (x::xs', pset, cmap)) xs 
		([],pset,cmap) in
	    (C.prod_add (from, xs') pset, cmap)

    let normalize1 cfg =
      let cmap = C.Prod.fold 
	  (fun x rhss cmap -> 
	    if C.SententialForm_set.cardinal rhss = 1
	    then
	      match C.SententialForm_set.choose rhss with
		[C.Terminal c] -> TerminalMap.add c x cmap
	      | _ -> cmap
	    else 
	      cmap)
	  cfg.C.prod TerminalMap.empty in
      let pset, cmap= C.prod_fold normalize1_prod cfg.C.prod
	  (C.Prod.empty, cmap) in
      let vset = TerminalMap.fold (fun _ x vset ->
	C.Variable_set.add x vset) cmap (C.vars_of cfg) in
      C.create3 vset pset cfg.C.start

    module VVMap =
      Map.Make(struct 
	type t = C.variable * C.variable
	let compare = compare
      end)

    let rec normalize2_prod from rhs (pset, vmap) = 
      let rec normalize_vv y zs (vmap, pset) = 
	match zs with
	  [] -> failwith "normalize"
	| [z] -> (y, z, (vmap, pset))
	| C.Variable z::zs ->
	    (try 
	      normalize_vv (VVMap.find (y,z) vmap) zs (vmap, pset)
	    with Not_found ->
	      let y' = C.fresh_variable () in
	      let vmap = VVMap.add (y,z) y' vmap in
	      let pset = C.prod_add (y', [C.Variable y; C.Variable z]) pset in
	      normalize_vv y' zs (vmap, pset)) 
	| _ -> failwith "normalize" in
      match rhs with
	[] | [_]  -> (C.prod_add (from, rhs) pset, vmap)
      | [C.Variable x;C.Variable y] -> 
	  (try 
	    let z = VVMap.find (x,y) vmap in
	    if from = z then 
	      (C.prod_add (from, rhs) pset, vmap)
	    else
	      (C.prod_add (from, [C.Variable z]) pset, vmap)  
	  with Not_found -> (C.prod_add (from, rhs) pset, vmap))
      | [_;_]  -> failwith "tc"
      | C.Variable x::xs -> 
	  let y,z,(vmap, pset) = 
	    normalize_vv x xs (vmap, pset) in
	    (C.prod_add (from, [C.Variable y;z]) pset, vmap)
	| _ -> failwith "normalize" 

    let normalize2 cfg =
      let vmap = C.Prod.fold 
	  (fun x rhss vmap -> 
	    if C.SententialForm_set.cardinal rhss = 1
	    then
	      match C.SententialForm_set.choose rhss with
		[C.Variable y; C.Variable z] -> VVMap.add (y,z) x vmap
	      | _ -> vmap
	    else 
	      vmap)
	  cfg.C.prod VVMap.empty in
      let pset, vmap = 
	C.prod_fold (fun from sent making ->
	  normalize2_prod from sent making) cfg.C.prod
	  (C.Prod.empty, vmap) in
      let vset = VVMap.fold (fun _ x vset ->
	C.Variable_set.add x vset) vmap (C.vars_of cfg) in
      C.create3 vset pset cfg.C.start

    module Symbol_set = 
      Set.Make (struct 
	type t = symbol
	let compare = compare 
      end)

(* A -> BC, A -> BC' => A -> BD, D -> C, D -> C' *) 

    let rec compact_rhss from rhss (pset,vset) = 
      let find x m = try C.Prod.find x m with Not_found -> C.Variable_set.empty  in
      let add x y m = C.Prod.add x (C.Variable_set.add y (find x m)) m in
      let pset, m =
	C.SententialForm_set.fold (fun rhs (pset, m) ->
	  match rhs with
	    [] | [_]  -> (C.prod_add (from, rhs) pset, m)
	  | [C.Variable x; C.Variable y] -> (pset, add x y m)
	  | _ -> failwith "compact") rhss (pset, C.Prod.empty) in
      C.Prod.fold (fun x ys (pset,vset) ->
	match C.Variable_set.cardinal ys with
	  0 -> failwith "compact" 
	| 1 -> 
	    let y = C.Variable_set.choose ys in
	    (C.prod_add (from, [C.Variable x; C.Variable y]) pset, vset)
	| _ -> 
	    let x' = C.fresh_variable () in
	    let (ys:Symbol_set.t) = C.Variable_set.fold (fun y making -> Symbol_set.add (C.Variable y) making) ys Symbol_set.empty in 
	    let pset = 
	      Symbol_set.fold
		(fun y pset-> C.prod_add (x', [y]) pset) ys pset in
	    (C.prod_add (from, [C.Variable x; C.Variable x']) pset,
	     C.Variable_set.add x' vset)) m (pset, vset)

    let compact cfg =
      let pset, vset = 
	C.Prod.fold (fun x rhss making -> compact_rhss x rhss making) 
	  cfg.C.prod (C.Prod.empty, C.vars_of cfg) in
      C.create3 vset pset cfg.C.start

    let compact' cfg  =
      let zs = C.Prod.fold (fun x rhss making ->
	if C.SententialForm_set.cardinal rhss > 50 then
	  rhss::making else making) cfg.C.prod [] in
      let yss = List.fold_left 
	  (fun yss rhss ->
	    let rec find_approx yss =
	      match yss with
		[] -> [(1,rhss)]
	      | (i,ys)::yss -> 
		  let xs = C.SententialForm_set.inter
		      rhss ys in
		  if C.SententialForm_set.cardinal xs > 50
		  then (i+1,xs)::yss
		  else (i,ys)::(find_approx yss) in
	    find_approx yss) [] zs in
      let yss = List.filter (fun (i,ys) -> i > 1) yss in
      let env = List.map (fun (i,ys) -> (ys, C.fresh_variable ())) yss in
      
      let rec find_approx rhss env =
	match env with
	  [] -> None
	| (ys,y)::env ->
	    if C.SententialForm_set.subset ys rhss then
	      Some (ys,y) else find_approx rhss env in

      let newpset = List.fold_left (fun newpset (ys,y) ->
	C.Prod.add y ys newpset) C.Prod.empty env in 

      let pset =
	C.Prod.fold (fun x rhss pset ->
	  if C.SententialForm_set.cardinal rhss > 80 
	  then 
	    match find_approx rhss env with
	      Some (ys, y) ->
		let rhss' = C.SententialForm_set.diff rhss ys in
		let rhss' = C.SententialForm_set.add [C.Variable y] rhss' in
		C.Prod.add x rhss' pset
	    | None -> C.Prod.add x rhss pset
	  else
	    C.Prod.add x rhss pset) cfg.C.prod newpset in
      C.create3 (C.vars_of cfg) pset cfg.C.start

    module SententialFormSetMap =
      Map.Make(struct 
	type t = C.SententialForm_set.t
	let compare = C.SententialForm_set.compare
      end)


    let cfg_size cfg =
      (C.Variable_set.cardinal (C.vars_of cfg),
       C.Prod.fold (fun x rhss size ->
	 C.SententialForm_set.cardinal rhss + size) cfg.C.prod 0)
	
    let normalize cfg =
      let () = Basic.show 1 (fun () -> Format.printf "normalize@.") in
      let cfg = try normalize1 cfg with _ -> failwith "normalize1" in
      let () = Basic.show 1 (fun () -> Format.printf "end normalize1@.") in
(*      let cfg = C.toUseful cfg in *)
      let cfg = try normalize2 cfg with _ -> failwith "normalize2" in
      let (vsize, psize) = cfg_size cfg in
      let () = Basic.show 1 (fun () -> Format.printf 
	  "CFG size after normlization: %d %d@." vsize psize) in
      let cfg = compact cfg in
      let () = Basic.show 1 (fun () -> Format.printf "compat@.") in
      let cfg = C.compact cfg in  
      let () = Basic.show 1 (fun () -> Format.printf "compat1@.") in
      let cfg = compact' cfg in 
      let (vsize, psize) = cfg_size cfg in
      let () = Basic.show 1 (fun () ->  Format.printf 
	  "CFG size after compaction: %d %d@." vsize psize) in
      cfg
	
    module Arrow = 
      struct
	let find' x m = 
	  try Hashtbl.find m x with Not_found -> Q_set.empty
	let add' x v m = (Hashtbl.replace m x (Q_set.add v (find' x m)); m) 

	let find x (m, inv_m) = find' x m
	let invfind x (m, inv_m) = find' x inv_m
	let add (i, _A, j) (m, inv_m) = (add' (i, _A) j m, add' (j, _A) i inv_m)
	let mem (i, _A, j) (m, inv_m) = Q_set.mem j (find' (i, _A) m)
	let create ()  = (Hashtbl.create 1000, Hashtbl.create 1000)
      end

    module Symbol_map = 
      Map.Make (struct 
	type t = symbol
	let compare = compare 
      end)

    module SymMap =
      struct
	let create () = Hashtbl.create 1000 

	let find x m = 
	  try Hashtbl.find m x with Not_found -> []

	let add x v m  = (Hashtbl.replace m x (v :: find x m); m)
      end

(* ((qset,aset,fa_s,f) as fa) *)
    let disjoint ft cfg =

      let toElist = 
	C.Prod.fold (fun from toSentSet making -> 
	  if C.SententialForm_set.mem [] toSentSet
	  then from::making else making) cfg.C.prod [] in 

      let newFa delt (aset,works) =
	if Arrow.mem delt aset then (aset,works)
	else
	  (Arrow.add delt aset, delt::works) in

      let addEdgeForE aset = 
	let (aset, works) = 
	  F.Arrow.fold (fun from by toOne _ making ->
	      newFa (from,C.Terminal by,toOne) making)
	    aset (Arrow.create (), []) in 
	Q_set.fold (fun q making ->
	  (List.fold_left (fun making a -> 
	    newFa (q,C.Variable a,q) making) making toElist)) ft.F.states (aset, works) in

      let mapAtoB = C.prod_fold 
	  (fun from ss making -> 
	    match ss with
	      [_B] -> SymMap.add _B from making
	    | _ -> making) cfg.C.prod (SymMap.create ()) in 

      let addEdgeForAtoB aset (i,_B,j) works =  
	let fromAset = SymMap.find _B mapAtoB in
	List.fold_left (fun making fA -> newFa (i, C.Variable fA, j) making) (aset,works) fromAset in
	  
      let mapAtoBC =
	C.prod_fold
	  (fun from ss making -> 
	    match ss with
	      [_B; _C] -> SymMap.add _B (from, _C) making
	    | _ -> making) cfg.C.prod (SymMap.create ()) in
	
      let addEdgeForAtoBC aset (i,_B,j) works = 
	let _AC_set = SymMap.find _B mapAtoBC in
	List.fold_left
	  (fun making  (_A, _C) ->
	    Q_set.fold (fun  k making -> newFa (i, C.Variable _A, k) making)
	      (Arrow.find (j, _C) aset) making)
	  (aset,works) _AC_set in

      let mapAtoCB =
	C.prod_fold (fun from ss making -> 
	  match ss with
	    [_C; _B] -> SymMap.add _B (from, _C) making 
	  | _ -> making) cfg.C.prod (SymMap.create ()) in

      let addEdgeForAtoCB aset (i,_B,j) works = 
	let _AC_set = SymMap.find _B mapAtoCB in
	List.fold_left 
	  (fun making (_A, _C) ->
	    Q_set.fold 
	      (fun  k making -> newFa (k, C.Variable _A, j) making)
	      (Arrow.invfind (i, _C) aset) making)
	  (aset,works) _AC_set in

      let rec loop (aset,works) = 
	match works with
	  [] -> aset 
	| work::works -> 
	    let (aset,works) = addEdgeForAtoB aset work works in
	    let (aset,works) = addEdgeForAtoBC aset work works in
	    loop (addEdgeForAtoCB aset work works) in

      let (aset, works) = addEdgeForE ft.F.arrow in
      loop (aset, works)
	
   (* map from q * C.symbol * q to C.symbol *)
	module FromSent =
	  struct
	    let create () = Hashtbl.create 1000
	    let add x y m = (Hashtbl.replace m x y; m)
	    let find x m = Hashtbl.find m x
	  end

    type state = 
	{vmap : (q * C.symbol * q, C.symbol) Hashtbl.t; 
	 prod : C.SententialForm_set.t C.Prod.t;
	 xs : C.Variable_set.t;
	 nullxs : C.Variable_set.t;
	 invprod : C.symbol SententialFormSetMap.t;
       size : int}
              (* xs : the set of variables 
                      which may occur recursively *) 

    let add_rhss' from rhss state =
	{state with prod = C.Prod.add from rhss state.prod}

    let var_rhss rhss = 
      if C.SententialForm_set.cardinal rhss = 1 then
	match C.SententialForm_set.choose rhss with
	  [C.Variable x as sym] -> Some sym
	| _ -> None
      else None

    let check x rhss =
      C.SententialForm_set.exists (fun rhs ->
	List.exists (fun s -> 
	  match s with 
	    C.Variable y -> x =y
	  | _ -> false) rhs) rhss 


    let add_rhss from' from rhss isnull state =
      if C.Variable_set.mem from' state.xs then  
	let from_sym = C.Variable from' in
	let invprod = 
	  SententialFormSetMap.add rhss from_sym state.invprod in 
	let () = Basic.show 1 (fun () ->  if state.size mod 10000 = 0 then
	    Format.printf "%d@." state.size) in
	(C.Variable from', false,
	 {state with 
	  prod = C.Prod.add from' rhss state.prod;
	  invprod = invprod; 
	  size = state.size + 1})
      else
	match var_rhss rhss with
	  Some sym ->
	  (sym, isnull, 
	   {state with vmap = FromSent.add from sym state.vmap })
	| None -> 
	try 
	  let x = SententialFormSetMap.find rhss state.invprod in
	  (x, isnull,
	   {state with vmap = FromSent.add from x state.vmap })
	with Not_found -> 
	  let nullxs = if isnull then C.Variable_set.add from' state.nullxs else state.nullxs in
	  let from_sym  = C.Variable from' in
	  let invprod = 
	    SententialFormSetMap.add rhss from_sym state.invprod in 
	  let () = Basic.show 1 (fun () -> if state.size mod 10000 = 0 then
	    Format.printf "%d@." state.size) in

	(from_sym, isnull,
	 {state with prod = C.Prod.add from' rhss state.prod;
	  invprod = invprod; 
	  nullxs = nullxs;
	  size = state.size + 1})

    let add_rhs rhs rhss isnull state =
      (C.SententialForm_set.add rhs rhss, 
       isnull && rhs = [], 
       state)
	  
    let mark from state =
      let cv = C.fresh_variable () in
      cv, { state with vmap = FromSent.add from (C.Variable cv) state.vmap }

    let mark_of (q1,from,q3) state =     
      try Some (FromSent.find (q1,from,q3) state.vmap)
      with Not_found -> None

    let visit from state =     
      match from with
	C.Terminal s -> state
      | C.Variable x -> 
	  { state with xs = C.Variable_set.add x state.xs }

    let is_null x state = C.Variable_set.mem x state.nullxs    

    let rec facfg2Prod fa fa' pset = 
      let rec facfg2Prod2 (q1,from,q3) making = 
	match from with
	  C.Terminal _ -> (from, false, making)
	| C.Variable v ->
	    match mark_of (q1,from,q3) making with
	      Some (C.Variable x as s) -> 
		(s, is_null x making, visit s making)
	    | Some _ -> failwith "facfg2Prod2" 
	    | None ->
		let from', making = mark (q1,from,q3) making in
	      let rhss, isnull, making =
		C.SententialForm_set.fold 
		  (fun toSent (rhss, isnull, making) ->
		    facfg2Prod_elm (q1,from,q3) toSent (rhss, isnull, making))
		  (C.prod_find v pset) 
		  (C.SententialForm_set.empty, true, making) in
	      add_rhss from' (q1, from, q3) rhss isnull making

      and facfg2Prod_elm (q1,from,q3) toSent (rhss, isnull, making) =
	match toSent with
	| [_A;_B] -> 
	    Q_set.fold 
	      (fun q2 (rhss, isnull, making) -> 
		if Arrow.mem (q2,_B,q3) fa'
		then 
		  let a, anull, making = facfg2Prod2 (q1,_A,q2) making in
		  let b, bnull, making = facfg2Prod2 (q2,_B,q3) making in
		  let rhs = 
		    match (anull, bnull) with
		      (true, true) -> []
		    | (true, false) -> [b]
		    | (false, true) -> [a]
		    | (false, false) -> [a; b] in
		  add_rhs rhs rhss isnull making
		else (rhss, isnull, making))		
	      (Arrow.find (q1,_A) fa') (rhss, isnull, making)
	| [_C]  -> 
	    if Arrow.mem (q1, _C, q3) fa'
	    then
	      match _C with
	      | C.Variable _ -> 
		  let c, cnull, making = facfg2Prod2 (q1, _C,q3) making in
		  if cnull then add_rhs [] rhss isnull making 
		  else add_rhs [c] rhss isnull making 
	      | C.Terminal c ->
		  let qss = F.delta fa (q1,c) in
		  F.QSLset.fold (fun (q,ss) (rhss, isnull, making) ->
		    if q = q3 
		    then add_rhs ss rhss isnull making 
		    else (rhss, isnull, making)) qss (rhss, isnull, making)
	    else (rhss, isnull, making)
	| [] -> 
	    if q1 = q3 then add_rhs [] rhss isnull making
	    else (rhss, isnull, making) 
	| _ -> failwith "transducer_cfg" in 
      facfg2Prod2 

    let inter' ft cfg =
      let vsize, psize = cfg_size cfg in
      let () = Basic.show 1 (fun () ->  Format.printf 
	"FT CFG intersection: %d %d %d@." (Q_set.cardinal ft.F.states) 
	  vsize psize) in
      let m = disjoint ft cfg in
      let () = Basic.show 1 (fun () -> Format.printf "inter@.") in
      let start' = C.fresh_variable () in
      let init_state =
	{vmap = FromSent.create (); 
	 prod = C.Prod.empty;
	 xs = C.Variable_set.empty;
	 nullxs = C.Variable_set.empty;
	 invprod = SententialFormSetMap.empty;
	 size = 0} in
      let rhss, state =
	Q_set.fold (fun qend (rhss, making) -> 
	  let x, _, making = facfg2Prod ft m cfg.C.prod (ft.F.start,C.Variable cfg.C.start,qend) making in
	  (C.SententialForm_set.add [x] rhss, making))
	    ft.F.final (C.SententialForm_set.empty,init_state) in
      let state = add_rhss' start' rhss state in
      let prod = state.prod in
      let cfg = C.create prod start' in
      let vsize, psize = cfg_size cfg in
      let () = Basic.show 1 (fun () -> Format.printf 
	"FT CFG intersection done!: %d %d@." vsize psize) in
      cfg, m

    let inter_with_check ft cfg = 
      let cfg, aset = inter' ft (normalize cfg) in
      let b = Q_set.subset (Arrow.find (ft.F.start, C.Variable cfg.C.start) aset) ft.F.final in
      cfg, b

    let inter' ft cfg = 
      let cfg, m = inter' ft cfg in
      cfg 

    let inter ft cfg = inter' ft (normalize cfg)

  end
