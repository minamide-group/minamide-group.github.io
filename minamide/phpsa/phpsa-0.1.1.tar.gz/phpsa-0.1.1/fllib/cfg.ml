(*
 * PHP string analyzer
 * Copyright (C) 2005, 2006 Nobuo Otoi, Yasuhiko Minamide
 *)
open Basic

module type VARIABLE_TYPE =
  sig
    type variable
    val string_of : variable -> string
    val fresh_variable : unit -> variable
    val compare: variable -> variable -> int
  end;;

module type TERMINAL_TYPE =
  sig
    type terminal
    val string_of : terminal -> string
    val compare: terminal -> terminal -> int
    module Terminal_set : Set.S with type elt = terminal
  end;;

module type S  =
  sig
    type variable
    type terminal
    type start = variable
    type symbol = Variable of variable | Terminal of terminal
    module SententialForm_set : Set.S with type elt = symbol list
    module Variable_set : Set.S with type elt = variable
    module Terminal_set : Set.S with type elt = terminal
    module Prod : Map.S with type key = variable
    type prod = SententialForm_set.t Prod.t 
    type cfg = {vset: Variable_set.t; prod: prod; start: variable }
    val fresh_variable : unit -> variable

    val prod_swap : variable -> symbol list -> symbol list -> prod -> prod 
    val prod_fold : (variable -> symbol list -> 'a -> 'a) -> prod -> 'a -> 'a
    val prod_find : variable -> prod -> SententialForm_set.t
    val prod_add : variable * symbol list -> prod -> prod
    val prod_union : prod -> prod -> prod
    val vars_of_prod : prod -> Variable_set.t
    val terminals_of_prod : prod -> Terminal_set.t

    val string_of_v : variable -> string
    val string_of_t : terminal -> string
    val string_of_symbol : symbol -> string
    val pp_sym : Format.formatter -> symbol -> unit
    val create3 : Variable_set.t -> prod -> start -> cfg
    val create : prod -> start -> cfg
    val create_from_lists : variable list -> (variable * symbol list list) list -> start -> cfg
    val pp_cfg : Format.formatter -> cfg -> unit

    val vars_of : cfg -> Variable_set.t
    val prod_reachableVar : prod -> Variable_set.t -> Variable_set.t
    val prod_reachable : prod -> Variable_set.t -> prod
    val reachableVar : cfg -> Variable_set.t
    val reachableCFG : cfg -> cfg
    val generating : cfg -> Variable_set.t
    val nullable : cfg -> Variable_set.t
    val generatingCFG : cfg -> cfg
    val useful : cfg -> cfg
    val compact : cfg -> cfg
    val generating_with_witness : cfg -> terminal list Prod.t
    val reachable_with_witness : cfg -> (symbol list * symbol list) Prod.t
    val useful_with_witness : cfg -> (terminal list * terminal list) Prod.t
    val prod_homo : prod -> (terminal -> terminal list) -> prod
    val homo : cfg -> (terminal -> terminal list) -> cfg

  end;;

module Make (V: VARIABLE_TYPE)(T:TERMINAL_TYPE) =
  struct
    type variable = V.variable
    type terminal = T.terminal
    type symbol = Variable of variable | Terminal of terminal
	    
    module SententialForm_set = 
      Set.Make(struct type t = symbol list let compare = compare end)

    type start = variable
    module Variable_set = Set.Make(struct type t = variable let compare = compare end)
    module Terminal_set = T.Terminal_set
    module Prod = Map.Make(struct type t = variable let compare = compare end)
    type prod = SententialForm_set.t Prod.t 
    type cfg = {vset: Variable_set.t; prod: prod; start: variable }

    let string_of_v = V.string_of
    let string_of_t = T.string_of
    let string_of_symbol = function
	Variable v -> V.string_of v
      | Terminal t -> T.string_of t
    let fresh_variable = V.fresh_variable

    let pp_var fmt x = Format.fprintf fmt "%s" (V.string_of x)
    let pp_vset fmt vset =
      print_iter Variable_set.iter "," pp_var fmt vset

    let pp_sym fmt sym = Format.fprintf fmt "%s" (string_of_symbol sym)

    let pp_cfg fmt cfg = 
      let pp_syms fmt syms = print_list "" pp_sym fmt syms in
      let pp_symss fmt symss =
	print_iter SententialForm_set.iter "|" pp_syms fmt symss in
      let pp_prod fmt x symss =
	Format.fprintf fmt "%s -> %a" (V.string_of x) pp_symss symss in
      let pp_prods fmt ps = print_iter2 Prod.iter ",@," pp_prod fmt ps in
      Format.fprintf fmt "(@[{%a},@ {@[%a@]},@ %a@])@."
	pp_vset cfg.vset pp_prods cfg.prod pp_var cfg.start
	  

    let prod_union prod1 prod2 =
      Prod.fold (fun from toLst making -> Prod.add from toLst making ) prod1 prod2

    let prod_swap from newElm oldElm prod =
      Prod.add from (SententialForm_set.add newElm (SententialForm_set.remove oldElm (Prod.find from prod))) prod

    let prod_fold f prod making =
      Prod.fold (fun from sentSet making ->
	SententialForm_set.fold (fun sent making ->
	  f from sent making) sentSet making) prod making

    let prod_find x ps =
      try Prod.find x ps with Not_found -> SententialForm_set.empty


    let prod_add (x, rhs) prod  =
      let ss = prod_find x prod in Prod.add x (SententialForm_set.add rhs ss) prod
 
    let vars_of_prod rules = 
      Prod.fold 
	(fun x rs making ->
	  SententialForm_set.fold 
	    (fun r making ->
	      List.fold_left 
		(fun making s ->
		  match s with
		    Variable y -> Variable_set.add y making
		  | _ -> making) making r)
	    rs (Variable_set.add x making)) rules Variable_set.empty

    let create3 vs p s = {vset = vs; prod = p; start = s}
    let create p s = create3 (vars_of_prod p) p s

    let create_from_lists vlst plst s = 
      let vset = List.fold_right 
	  (fun velm making -> Variable_set.add velm making) vlst Variable_set.empty in
      let slst2sSet slst = List.fold_right (fun selm making -> SententialForm_set.add selm making) slst SententialForm_set.empty in
      let pset = List.fold_right (fun (velm,sentenceLst) making -> Prod.add velm (slst2sSet sentenceLst) making) plst Prod.empty in
      create3 vset pset s

    let terminals_of_prod rules = 
      Prod.fold (fun x rs making ->
	SententialForm_set.fold (fun r making ->
	  List.fold_left (fun making s ->
	    match s with
	      Terminal y -> Terminal_set.add y making
	    | _ -> making) making r) rs making)
	rules Terminal_set.empty

    let vars_of cfg = cfg.vset
    let vset_size_of cfg = Variable_set.cardinal (vars_of cfg)

    let generating cfg =
      let variable_of_rhs rhs =
	List.fold_left (fun vs s -> 
	  match s with
	    Variable x -> Variable_set.add x vs
	  | _ -> vs) Variable_set.empty rhs in
      let add x y gmap =
	let ys = try Prod.find x gmap with Not_found -> [] in
	Prod.add x (y::ys) gmap in
      let () = Basic.show 1 
	  (fun () -> Format.printf "Calculation of generating variables@.") in
      let rec dfs (visitedV, rs) x =
	if Prod.mem x cfg.prod then
	  let rhss = Prod.find x cfg.prod in
	  SententialForm_set.fold 
	    (fun rhs (visitedV, rs, b) ->
	      let (visitedV, rs, b') =
		List.fold_left 
		  (fun (visitedV, rs, b) s ->
		    match s with 
		      Variable y -> 
			if Variable_set.mem y visitedV then
			  (visitedV, rs, b && Variable_set.mem y rs)
			else
			  let visitedV = Variable_set.add y visitedV in
			  let visitedV, rs, b' = dfs (visitedV, rs) y in
			  (visitedV, rs, b && b')
		    | Terminal t -> 
			(visitedV, rs, b))
		  (visitedV, rs, true) rhs in
	      (visitedV, rs, b || b'))
	    rhss (visitedV, rs, false)
	else (visitedV, rs, false) in

      let _,vs,_ = dfs (Variable_set.empty, Variable_set.empty) cfg.start in 

      let vs, gmap = prod_fold (fun x rhs (vs, gmap) ->
	if Variable_set.mem x vs then (vs, gmap)
	else
	  let ys = variable_of_rhs rhs in
	  let ys = Variable_set.filter (fun x -> not (Variable_set.mem x vs)) ys in
	  if Variable_set.is_empty ys 
	  then (Variable_set.add x vs, gmap)
	  else 
	    let nref = ref (Variable_set.cardinal ys) in
	    (vs, 
	     Variable_set.fold 
	       (fun y gmap ->  add y (x, nref) gmap) ys gmap)) cfg.prod
	  (vs, Prod.empty) in 
(*      (Variable_set.empty, Prod.empty) in *)

      let () = Basic.show 1 (fun () -> Format.printf 
	  " (after graph generation)@.") in
      let rec loop xs rs =
	match xs with
	  [] -> rs
	| x::xs -> 
	    let xs,rs = List.fold_left (fun (xs,rs) (y,nref) ->
	      decr nref;
	      if !nref = 0 && not (Variable_set.mem y rs) 
	      then (y::xs, Variable_set.add y rs) else (xs,rs)) 
		(xs,rs)
		(try Prod.find x gmap with Not_found -> []) in
	    loop xs rs in
      let vs = loop (Variable_set.elements vs) vs in
      vs

    let generatingCFG cfg =
      let genV = generating cfg in
      let () = Basic.show 1 (fun () -> Format.printf "Generating %d %d@."
	  (vset_size_of cfg) (Variable_set.cardinal genV))  in
      if Variable_set.cardinal genV < vset_size_of cfg
      then
	let newprod =
	  Prod.fold (fun x rhss making ->
	    if  Variable_set.mem x genV then
	      Prod.add x (SententialForm_set.filter (fun rhs ->
		List.for_all (fun s ->
		  match s with
		    Variable y -> Variable_set.mem y genV
		  | _ -> true) rhs) rhss) making
	    else 
	      making) cfg.prod Prod.empty in
	create3 (Variable_set.add cfg.start genV) newprod cfg.start
      else
	cfg

    let prod_reachableVar prod xs =
      let rec dfs visitedV x =
	if Prod.mem x prod then
	  let rhss = Prod.find x prod in
	  SententialForm_set.fold 
	    (fun rhs visitedV ->
	    List.fold_left 
		(fun visitedV s ->
		  match s with 
		    Variable y -> 
		      if Variable_set.mem y visitedV then
			visitedV
		      else
			let visitedV = Variable_set.add y visitedV in
			dfs visitedV y
		  | Terminal t -> visitedV)
		visitedV rhs)
	    rhss visitedV
	else visitedV in
      Variable_set.fold (fun x ys -> dfs ys x) xs xs

    let prod_reachable prod xs  =
      let genV = prod_reachableVar prod xs in
      Prod.fold 
	(fun x rhss making ->
	  if Variable_set.mem x genV then Prod.add x rhss making
	  else making) prod Prod.empty 

    let reachableVar cfg =
      let () = show 1 (fun () -> Format.printf "Reachable %d@." (vset_size_of cfg)) in
      prod_reachableVar cfg.prod (Variable_set.singleton cfg.start)

    let reachableCFG cfg =
      let genV = reachableVar cfg in
      let () = Basic.show 1 (fun () -> Format.printf "ReachableCFG %d %d@."
	  (vset_size_of cfg)
	  (Variable_set.cardinal genV))  in
      if Variable_set.cardinal genV < vset_size_of cfg
      then
	let newprod =
	  Prod.fold (fun x rhss making ->
	    if  Variable_set.mem x genV then
	      Prod.add x rhss making
	    else 
	      making) cfg.prod Prod.empty in
	create3 genV newprod cfg.start
      else
	cfg
	
    let useful cfg = reachableCFG (generatingCFG cfg) 

    (* The set of variables from which the empty string can be derived. *)
    let nullable cfg =
      let getV condition = Prod.fold (fun from sentSet making -> 
	if SententialForm_set.exists(
	  fun xs -> List.for_all condition xs
	 ) sentSet then Variable_set.add from making else making) cfg.prod Variable_set.empty in
      let newv = getV(
	function Variable _ -> false
	  |      Terminal _ -> false
       )in
      let rec addNewV oldV newV = 
	if Variable_set.equal oldV newV then newV else
	let adding = getV(
	  function Terminal _ -> false
	    |      Variable v -> Variable_set.mem v newV
	 )in
	addNewV newV (Variable_set.union newV adding) in
      addNewV Variable_set.empty newv	


    module SententialFormSetMap =
      Map.Make(struct 
	type t = SententialForm_set.t
	let compare = SententialForm_set.compare
      end)

    let compact cfg =
      (* checking whether production (x, rhss) is recursive  *)
      let check x rhss =
	SententialForm_set.exists (fun rhs ->
	  List.exists (fun s -> 
	    match s with 
	      Variable y -> x=y
	    | _ -> false) rhs) rhss in 
	
      let rec loop cfg =
	let () = Basic.show 1 
	    (fun () -> Format.printf "xloop %d@." (Variable_set.cardinal cfg.vset)) in
	let env = Prod.fold (fun x rhss env ->
	  if check x rhss && not (SententialFormSetMap.mem rhss env)
	  then SententialFormSetMap.add rhss x env else env) cfg.prod
	    SententialFormSetMap.empty in

	let env, venv, flag = 
	  Prod.fold (fun x rhss (env,venv,flag) ->
	    try 
	      let y = SententialFormSetMap.find rhss env in
	      if x = y then (env,venv,flag) 
	      else (env, Prod.add x y venv, true)
	    with Not_found ->
	      (SententialFormSetMap.add rhss x env, venv, flag)) cfg.prod
	    (env,Prod.empty,false) in

	let trans_var x = try Prod.find x venv with Not_found -> x in

	if not flag then cfg
	else
	  let pset =
	    Prod.fold (fun x rhss pset ->
	      if Prod.mem x venv then pset
	      else
		let rhss = SententialForm_set.fold 
		    (fun rhs rhss ->
		      let rhs =
			List.map (fun s ->
			  match s with
			    Variable y -> Variable (trans_var y)
			  | _ -> s) rhs in
		      SententialForm_set.add rhs rhss)
		    rhss SententialForm_set.empty in
		Prod.add x rhss pset) cfg.prod Prod.empty in
	  let vset = Variable_set.filter 
	      (fun x -> not (Prod.mem x venv)) cfg.vset in 
	  loop (create3 vset pset (trans_var cfg.start)) in 

      let cfg = loop cfg in
      cfg

    let ss2ts vs ss = 
      List.fold_right 
	(fun s ts -> 
	  match s with 
	    (Terminal c) -> c::ts
	  | (Variable x) ->  Prod.find x vs@ts) ss []

    let generating_with_witness cfg =
      let variable_of_rhs rhs =
	List.fold_left (fun vs s -> 
	  match s with
	    Variable x -> Variable_set.add x vs
	  | _ -> vs) Variable_set.empty rhs in
      let add x y gmap =
	let ys = try Prod.find x gmap with Not_found -> [] in
	Prod.add x (y::ys) gmap in
      let () = Basic.show 1 
	  (fun () -> Format.printf "Calculation of generating variables@.") in

      let vs, gmap = prod_fold (fun x rhs (vs, gmap) ->
	if Prod.mem x vs then (vs, gmap)
	else
	  let ys = variable_of_rhs rhs in
	  let ys = Variable_set.filter (fun x -> not (Prod.mem x vs)) ys in
	  if Variable_set.is_empty ys 
	  then (Prod.add x (ss2ts vs rhs) vs, gmap)
	  else 
	    let nref = ref (Variable_set.cardinal ys) in
	    (vs, 
	     Variable_set.fold 
	       (fun y gmap ->  add y (x, nref, rhs) gmap) ys gmap)) cfg.prod
      (Prod.empty, Prod.empty) in 

      let () = Basic.show 1 (fun () -> Format.printf 
	  " (after graph generation)@.") in
      let rec loop xs rs =
	match xs with
	  [] -> rs
	| x::xs -> 
	    let xs,rs = List.fold_left (fun (xs,rs) (y,nref,rhs) ->
	      decr nref;
	      if !nref = 0 && not (Prod.mem y rs) 
	      then (y::xs, Prod.add y (ss2ts rs rhs) rs) else (xs,rs)) 
		(xs,rs)
		(try Prod.find x gmap with Not_found -> []) in
	    loop xs rs in
      let vs_list = Prod.fold (fun v _ vs_list -> v::vs_list) vs [] in
      let vs = loop vs_list vs in
      vs

    let context_fold f xs b =
      let rec loop xs b ys =
      match xs with
	[] -> b
      | x::xs -> f (ys, x, xs) (loop xs b (x::ys)) in
      loop xs b []

    let reachable_with_witness cfg =
      let () = show 1 (fun () -> Format.printf "Reachable %d@." (vset_size_of cfg)) in
      let rec dfs visitedV x ls rs =
	if Prod.mem x cfg.prod then
	  let rhss = Prod.find x cfg.prod in
	  SententialForm_set.fold 
	    (fun rhs visitedV ->
	    context_fold
		(fun (ls',s,rs') visitedV ->
		  match s with 
		    Variable y -> 
		      if Prod.mem y visitedV then
			visitedV
		      else
			let ls, rs = ls'@ls, rs'@rs in
			let visitedV = Prod.add y (List.rev ls, rs) visitedV in
			dfs visitedV y ls rs
		  | Terminal t -> visitedV)
		rhs visitedV)
	    rhss visitedV
	else visitedV in
	dfs (Prod.add cfg.start ([],[]) Prod.empty) cfg.start [] []

    let useful_with_witness cfg =
      let gv_map = generating_with_witness cfg in
      let rv_map = reachable_with_witness cfg in
      Prod.fold (fun x (ls, rs) uwitness ->
	Prod.add x (ss2ts gv_map ls, ss2ts gv_map rs) uwitness)
	rv_map Prod.empty

    let rhs_map f rhss =
      SententialForm_set.fold (fun rhs s -> 
	SententialForm_set.add  (f rhs) s) rhss SententialForm_set.empty

    let prod_homo p f =
      Prod.map (fun rhss ->
	rhs_map 
	  (fun rhs -> List.fold_right
	      (fun sym rhs ->
		match sym with
		  Terminal c ->  List.map (fun x -> Terminal x) (f c)@rhs
		| _ -> sym::rhs) rhs []) rhss) p

    let homo cfg f =
      create3 (vars_of cfg) (prod_homo cfg.prod f) cfg.start
  end;;
