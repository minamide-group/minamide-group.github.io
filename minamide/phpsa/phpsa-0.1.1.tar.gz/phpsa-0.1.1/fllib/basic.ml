(*
 * PHP string analyzer
 * Copyright (C) 2005, 2006 Nobuo Otoi, Yasuhiko Minamide
 *)
open Format

let debug_level = ref 0
let show n f  = if !debug_level >= n then f ()

type alpha = char
type q = int

module Q_set = 
  Set.Make(struct type t = q let compare = compare end)

let setQ xs = List.fold_left (fun qs x -> Q_set.add x qs) Q_set.empty xs

let image f qs = 
  Q_set.fold (fun q qs -> Q_set.add (f q) qs) qs Q_set.empty
let rename oldS gain = image (fun q -> q + gain) oldS

let rec print_list sep print fmt = function
    [] -> ()
  | [x] -> print fmt x
  | x::xs -> print fmt x; fprintf fmt sep; print_list sep print fmt xs

let rec print_iter iter sep print fmt xs = 
  let start = ref true in
  iter (fun x ->
    if not (!start) then fprintf fmt sep;
    print fmt x;
    start := false) xs

let rec print_iter2 iter sep print fmt xs = 
  let start = ref true in
  iter (fun x y ->
    if not (!start) then fprintf fmt sep;
    print fmt x y;
    start := false) xs

let print_state fmt q = fprintf fmt "%d" q

let print_states fmt qs =
  fprintf fmt "{ %a }" (print_list "," print_state) 
    (Q_set.elements qs)

module QGraph =
  struct
    module QMap = 
      Map.Make(struct type t = q let compare = compare end)

    let empty = QMap.empty

    let find x grpah = 
      try QMap.find x grpah with Not_found -> [] 

    let add x y graph = 
      QMap.add x (y::find x graph) graph 

    let rec dfs graph xs ys =
      match xs with
	[] -> ys
      | x::xs -> 
	  if Q_set.mem x ys then dfs graph xs ys
	  else dfs graph (find x graph @ xs) (Q_set.add x ys) 

    let rec is_reachable graph zs xs ys =
      match xs with
	[] -> false
      | x::xs -> 
	  if Q_set.mem x zs then true
	  else if Q_set.mem x ys then is_reachable graph zs xs ys
	  else is_reachable graph zs (find x graph @ xs) (Q_set.add x ys)
  end

let string_fold_right f s b =
  let rec g b i = if i >= 0 then g (f (String.get s i) b) (i - 1)
                            else b in
  g b (String.length s - 1)

let explode s = string_fold_right (fun x b -> x::b) s []

