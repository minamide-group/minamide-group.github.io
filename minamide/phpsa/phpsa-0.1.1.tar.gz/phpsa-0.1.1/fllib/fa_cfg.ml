(*
 * PHP string analyzer
 * Copyright (C) 2005, 2006 Nobuo Otoi, Yasuhiko Minamide
 *)
open Basic

module type S  =
  sig
    type fa
    type cfg	  
    val is_disjoint: fa -> cfg -> bool
    val inter: fa -> cfg -> cfg
    val is_disjoint': fa -> cfg -> Q_set.t
  end
      
module Make (F:Fa.S)(C: Cfg.S with type terminal= F.symbol) =
  struct
    type cfg = C.cfg
    type fa = F.fa
    type symbol = C.symbol
	    
    let sDot = C.SententialForm_set.singleton

    let is_string xs = 
      List.for_all (fun x ->
	match x with
	  C.Terminal _ -> true
	| _ -> false) xs

    let to_string xs = 
      List.map (fun x ->
	match x with
	  C.Terminal x -> x
	| _ -> failwith "to_string") xs

   (*  Normalize CFG so that each production has one of the following forms 
         A -> 
         A -> B
         A -> BC  
         A -> a1a2....an
       where B and C are terminal or nonterminal symbols and 
       ai is a terminal symbol *)

    module SententialFormMap =
      Map.Make(struct 
	type t = C.symbol list
	let compare = compare
      end)

    let rec toNormalize_elm from toOne (pset, vset) = 
      match toOne with
	[] | [_] | [_;_]  -> (C.prod_add (from, toOne) pset, vset)
      | xs when is_string xs -> (C.prod_add (from, toOne) pset, vset)
      | x::xs -> 
	  let y = C.fresh_variable () in 
	  toNormalize_elm y xs 
	    (C.prod_add (from, [x; C.Variable y]) pset, C.Variable_set.add y vset)

    let normalize cfg =
      let pset, vset  = C.prod_fold toNormalize_elm cfg.C.prod (C.Prod.empty, C.vars_of cfg) in
      let cfg = C.create3 vset pset cfg.C.start in
      C.compact cfg
	
    module ArrowMap = Map.Make(struct type t = q * C.symbol  let compare = compare end)
(*
    module Arrow = 
      struct
	let find' x m = 
	  try ArrowMap.find x m with Not_found -> Q_set.empty
	let add' x v m = ArrowMap.add x (Q_set.add v (find' x m)) m

	let find x (m, inv_m) = find' x m
	let invfind x (m, inv_m) = find' x inv_m
	let add (i, _A, j) (m, inv_m) = (add' (i, _A) j m, add' (j, _A) i inv_m)
	let mem (i, _A, j) (m, inv_m) = Q_set.mem j (find' (i, _A) m)
	let empty = (ArrowMap.empty, ArrowMap.empty)
      end
*)

    module Arrow = 
      struct
	let find' x m = 
	  try Hashtbl.find m x with Not_found -> Q_set.empty
	let add' x v m = (Hashtbl.replace m x (Q_set.add v (find' x m)); m) 

	let find x (m, inv_m) = find' x m
	let invfind x (m, inv_m) = find' x inv_m
	let add (i, _A, j) (m, inv_m) = (add' (i, _A) j m, add' (j, _A) i inv_m)
	let mem (i, _A, j) (m, inv_m) = Q_set.mem j (find' (i, _A) m)
(*	let empty = (ArrowMap.empty, ArrowMap.empty) *)
	let create ()  = (Hashtbl.create 1000, Hashtbl.create 1000)
      end


    module Symbol_map = 
      Map.Make (struct 
	type t = symbol
	let compare = compare 
      end)

    let symbol_find x m = 
      try Symbol_map.find x m with Not_found -> []

    let symbol_add x v m  = Symbol_map.add x (v :: symbol_find x m) m

(* (vset,pset,cfg_s)  *)
    let disjoint fa cfg =
      let newFa delt (aset,works) =
	if Arrow.mem delt aset then (aset,works)
	else
	  (Arrow.add delt aset, delt::works) in

      let addEdgeForE aset = 
	let (aset, works) = 
	  F.Arrow.fold (fun from by toOne making ->
	      newFa (from,C.Terminal by,toOne) making)
	    aset (Arrow.create (), []) in 
	Q_set.fold (fun q making ->
	  C.prod_fold 
	    (fun from toSent making -> 
	      if is_string toSent then 
		let s = to_string toSent in
		Q_set.fold (fun q' making ->
		  newFa (q,C.Variable from, q') making)
		  (F.deltaHat fa (q,s)) making
	      else making)
	    cfg.C.prod making) fa.F.states (aset, works) in

      let mapAtoB = C.prod_fold 
	  (fun from ss making -> 
	    match ss with
	      [_B] -> symbol_add _B from making
	    | _ -> making) cfg.C.prod Symbol_map.empty in

      let addEdgeForAtoB aset (i,_B,j) works =  
	let fromAset = symbol_find _B mapAtoB in
	List.fold_left (fun making fA -> newFa (i, C.Variable fA, j) making) (aset,works) fromAset in
	  
      let mapAtoBC =
	C.prod_fold
	  (fun from ss making -> 
	    match ss with
	      [_B; _C] -> symbol_add _B (from, _C) making
	    | _ -> making) cfg.C.prod Symbol_map.empty in
	
      let addEdgeForAtoBC aset (i,_B,j) works = 
	let _AC_set = symbol_find _B mapAtoBC in
	List.fold_left 
	  (fun making (_A, _C) ->
	    Q_set.fold (fun  k making -> newFa (i, C.Variable _A, k) making)
	      (Arrow.find (j, _C) aset) making)
	  (aset,works) _AC_set in

      let mapAtoCB =
	C.prod_fold (fun from ss making -> 
	  match ss with
	    [_C; _B] -> symbol_add _B (from, _C) making 
	  | _ -> making) cfg.C.prod Symbol_map.empty in

	
      let addEdgeForAtoCB aset (i,_B,j) works = 
	let _AC_set = symbol_find _B mapAtoCB in
	List.fold_left 
	  (fun making (_A, _C) ->
	    Q_set.fold 
	      (fun  k making -> newFa (k, C.Variable _A, j) making)
	      (Arrow.invfind (i, _C) aset) making)
	  (aset,works) _AC_set in

      let rec loop (aset,works) = 
	match works with
	  [] -> aset 
	| work::works -> 
	    let (aset,works) = addEdgeForAtoB aset work works in
	    let (aset,works) = addEdgeForAtoBC aset work works in
	    loop (addEdgeForAtoCB aset work works) in

      let (aset, works) = addEdgeForE fa.F.arrow in
      loop (aset, works)
	


    let is_disjoint fa cfg =
      let cfg = normalize cfg in
      let aset = disjoint fa cfg in
      Q_set.is_empty (Q_set.inter (Arrow.find (fa.F.start, C.Variable cfg.C.start) aset) fa.F.final)


    module FromSent = 
      Map.Make(struct 
	type t = q * C.symbol * q
	let compare = compare end)

    let trans_var from (current_variable, variable_map, prod) =
      FromSent.find from variable_map

    let trans_sent elm (current_variable, variable_map, prod) =
      List.map 
	(function (q1, C.Terminal c, q2) -> C.Terminal c
	  | x -> C.Variable (FromSent.find x variable_map)) elm

    let prod_addElm' from sent (current_variable, variable_map, prod) =     
      try
	(current_variable, variable_map, C.Prod.add from (C.SententialForm_set.add sent (C.Prod.find from prod)) prod)
      with Not_found -> 
	(current_variable, variable_map, 
	 C.Prod.add from (C.SententialForm_set.singleton sent) prod)

    let prod_addElm from sent (current_variable, variable_map, prod) =     
      let from = trans_var from (current_variable, variable_map, prod) in
      let sent = trans_sent sent (current_variable, variable_map, prod) in
      (current_variable, variable_map, C.Prod.add from (C.SententialForm_set.add sent (C.prod_find from prod)) prod)

    let is_marked (q1,from,q3) (current_variable, variable_map, prod) =     
      match from with
	C.Terminal s -> true
      | C.Variable v -> FromSent.mem (q1,from,q3) variable_map 
	  
    let mark from (current_variable, variable_map, prod) =     
      let current_variable = C.fresh_variable () in
      (current_variable, FromSent.add from current_variable variable_map, 
       prod)


    let rec facfg2Prod fa fa' pset = 
      let rec facfg2Prod2 (q1,from,q3) making = 
	if is_marked (q1,from,q3) making then making
	else
	  let making = mark (q1,from,q3) making in
	  match from with
	    C.Terminal s -> making
	  | C.Variable v ->
	      C.SententialForm_set.fold 
		(fun toSent making ->facfg2Prod_elm (q1,from,q3) toSent making)
		(C.prod_find v pset) making
      and facfg2Prod_elm (q1,from,q3) toSent making =
	match toSent with
	| [_A;_B] -> 
	    Q_set.fold 
	      (fun q2 making -> 
		if Arrow.mem (q2,_B,q3) fa'
		then 
		  let making = facfg2Prod2 (q1,_A,q2) making in
		  let making = facfg2Prod2 (q2,_B,q3) making in
		  prod_addElm (q1, from,q3) [(q1,_A,q2);(q2,_B,q3)] making 
		else making)		
	      (Arrow.find (q1,_A) fa') making
	| [_C]  -> 
	    if Arrow.mem (q1, _C, q3) fa'
	    then
	      prod_addElm (q1, from,q3) [(q1,_C,q3)]
		(facfg2Prod2 (q1, _C,q3) making)
	    else making
	| [] -> 
	    if q1 = q3 then prod_addElm (q1,from,q3) [] making
	    else making
	| ss -> 
	    let s = to_string ss in
	    if Q_set.mem q3 (F.deltaHat fa (q1,s)) then
	      prod_addElm' (trans_var (q1,from,q3) making) ss making
	    else making in
      facfg2Prod2 

    let inter fa cfg =
      let () = Basic.show 1 (fun () -> Format.printf "fa cfg inter@.") in
      let cfg = normalize cfg in
      let m = disjoint fa cfg in
      let () = Basic.show 1 (fun () -> Format.printf "done: fa cfg inter@.") in
      let start' = C.fresh_variable () in
      let _,_,prod =
	Q_set.fold (fun qend making -> 
	  let making = facfg2Prod fa m cfg.C.prod (fa.F.start,C.Variable cfg.C.start,qend) making in
	  prod_addElm' start' (trans_sent [(fa.F.start,C.Variable cfg.C.start,qend)] making) making)
	    fa.F.final (C.fresh_variable (), FromSent.empty, C.Prod.empty) in
      C.create prod start'

    let is_disjoint' fa cfg =
      let cfg = normalize cfg in
      let aset = disjoint fa cfg in
      Arrow.find (fa.F.start, C.Variable cfg.C.start) aset

	
  end
