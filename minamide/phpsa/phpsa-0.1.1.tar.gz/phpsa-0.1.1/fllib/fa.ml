(*
 * PHP string analyzer
 * Copyright (C) 2005, 2006 Nobuo Otoi, Yasuhiko Minamide
 *)
open Basic

module type SYMBOL_TYPE =
  sig
    type symbol
    val string_of : symbol -> string
    val pp_print : Format.formatter -> symbol -> unit
    val compare: symbol -> symbol -> int
    module Symbol_set : Set.S with type elt = symbol
  end;;

module type S  =
  sig
    type symbol
    val string_of : symbol -> string
    module Symbol_set : Set.S with type elt = symbol
    module ArrowMap : Map.S with type key = q * symbol
    type arrow = Q_set.t ArrowMap.t
    module Arrow :
      sig
	val empty : arrow
	val delta : q -> symbol -> arrow -> Q_set.t
	val deltaSet : Q_set.t -> symbol -> arrow -> Q_set.t
	val deltaHat : q -> symbol list -> arrow -> Q_set.t
	val deltaHatSet : Q_set.t ->  symbol list -> arrow -> Q_set.t
	val add : q -> symbol -> q -> arrow -> arrow
	val add' : q -> symbol -> Q_set.t -> arrow -> arrow
	val fold : (q -> symbol -> q -> 'a -> 'a) -> arrow -> 'a -> 'a
	val union : arrow -> arrow -> arrow
	val inverse : arrow -> arrow
	val print_arrow : Format.formatter -> arrow -> unit
	val rename : arrow -> int -> arrow
      end

    type fa = {symbols : Symbol_set.t; states : Q_set.t; arrow : arrow; start : q; final : Q_set.t}
    val delta : fa -> q * symbol -> Q_set.t
    val deltaSet : fa -> Q_set.t * symbol -> Q_set.t
    val deltaHat : fa -> q * symbol list -> Q_set.t
    val deltaHatSet : fa -> Q_set.t * symbol list -> Q_set.t
    val pp_fa :  Format.formatter -> fa -> unit 
    val minimize : fa -> fa
    val renameFA : fa -> int -> fa 
    val nfa2dfa : fa -> fa
    val neg : fa -> fa
    val isDFA : fa -> bool
    val image : (q -> q) -> fa -> fa
    val is_empty : fa -> bool
    val prod : fa -> fa -> fa
    val dfa_subset : fa -> fa -> bool
    val dfa_equal : fa -> fa -> bool
    val accessible : fa -> fa
    val coaccessible : fa -> fa
  end;;


module Make(SY:SYMBOL_TYPE) =
  struct
    type symbol = SY.symbol
    let string_of = SY.string_of

    module Symbol_set = SY.Symbol_set 

    module ArrowMap = 
      Map.Make(struct 
	type t = q * symbol  
	let compare = compare end)

    type arrow = Q_set.t ArrowMap.t

    module Arrow = 
      struct
	type t = arrow

	let empty = ArrowMap.empty 

	let delta from by aset = 
	  try ArrowMap.find (from,by) aset
	  with Not_found -> Q_set.empty

	let add x c y aset = 
	  ArrowMap.add (x,c) (Q_set.add y (delta x c aset)) aset

	let add' x c ys aset = 
	  ArrowMap.add (x,c) (Q_set.union ys (delta x c aset)) aset

	let fold f aset base =
	  ArrowMap.fold (fun (x,c) ys making -> 
	    Q_set.fold (fun y making -> f x c y making) ys making) 
	    aset base

	let filter f aset =
	  fold (fun x c y making -> if f x c y then add x c y making else making)
	    aset empty

	let deltaSet fromSet by aset = 
	  Q_set.fold 
	    (fun q making -> Q_set.union (delta q by aset) making) 
	    fromSet Q_set.empty

	let rec deltaHatSet from byL aset = 
	  match byL with
	    [] -> from
	  | x::xs -> deltaHatSet (deltaSet from x aset) xs aset

	let deltaHat from byL aset  = 
	  deltaHatSet (Q_set.singleton from) byL aset

	let deltaDFA from by aset = 
	  try 
	    Q_set.choose (ArrowMap.find (from,by) aset)
	  with Not_found -> 
	    failwith (Printf.sprintf "%i %s" from (string_of by))

	let rec deltaHatDFA from byL aset = 
	  match byL with
	    [] -> from
	  | x::xs -> deltaHatDFA (deltaDFA from x aset) xs aset

	let inverse aset =
	  fold (fun x c y making -> add y c x making)
	    aset ArrowMap.empty 

	let union aset1 aset2 =
	  ArrowMap.fold (fun (x,c) ys making -> add' x c ys making) aset1 aset2

	let print_arrow fmt aset =
	  ArrowMap.iter 
	    (fun (x,c) ys -> 
	      Format.fprintf fmt "(%d) -%a-> %a@." 
		x SY.pp_print c print_states ys) aset

	let image f aset = 
	  ArrowMap.fold (fun (x,c) ys making -> 
	    add' (f x) c (image f  ys) making) aset empty

	let rename oldA gain = 
	  ArrowMap.fold (fun (x,c) ys making -> 
	    ArrowMap.add (x + gain, c) (Basic.rename ys gain) making) oldA empty
      end

    type fa = {symbols : Symbol_set.t; states : Q_set.t; arrow : arrow; start : q; final : Q_set.t}

    let pp_fa fmt fa =
      Format.fprintf fmt "states = %a, start = %a, final = %a@."
      print_states fa.states print_state fa.start print_states fa.final;
      Arrow.print_arrow fmt fa.arrow

    let delta fa (x, c) = Arrow.delta x c fa.arrow
    let deltaSet fa (xs, c) = Arrow.deltaSet xs c fa.arrow
    let deltaHat fa (x, cs) = Arrow.deltaHat x cs fa.arrow
    let deltaHatSet fa (xs, cs) = Arrow.deltaHatSet xs cs fa.arrow

    let image f fa =
      {symbols = fa.symbols;
       states = image f fa.states;
       arrow = Arrow.image f fa.arrow;
       start = f fa.start;
       final = image f fa.final}

    let renameFA fa gain = 
      {symbols = fa.symbols;
       states = Basic.rename fa.states gain;
       arrow = Arrow.rename fa.arrow gain;
       start = fa.start + gain;
       final = Basic.rename fa.final gain}

    let accessible fa =
      let graph =
	Arrow.fold (fun q c q' graph -> QGraph.add q q' graph) 
	  fa.arrow QGraph.empty in
      let qs = QGraph.dfs graph [fa.start] Q_set.empty in
      let arrow = Arrow.filter (fun x c y -> Q_set.mem x qs && Q_set.mem y qs) fa.arrow in
      {symbols = fa.symbols;
       states = qs;
       arrow = arrow;
       start = fa.start;
       final = Q_set.inter fa.final qs}

    let coaccessible fa =
      let graph =
	Arrow.fold (fun q c q' graph -> QGraph.add q' q graph) 
	  fa.arrow QGraph.empty in
      let qs = QGraph.dfs graph (Q_set.elements fa.final) Q_set.empty in
      let qs = Q_set.add fa.start qs in
      let arrow = Arrow.filter (fun x c y -> Q_set.mem x qs && Q_set.mem y qs) fa.arrow in
      {symbols = fa.symbols;
       states = qs;
       arrow = arrow; 
       start = fa.start;
       final = qs}

    module Q_set2int = Map.Make(struct type t = Q_set.t let compare = Q_set.compare end)

    let nfa2dfa' symbols (qs, aset, ss, fs) = 
      let rec dfs xs ys n =
	match xs with
	  [] -> (ys, n)
	| x::xs -> 
	    if Q_set2int.mem x ys then dfs xs ys n
	    else
	      let ys = Q_set2int.add x n ys in
	      let xs = Symbol_set.fold (fun c zs -> Arrow.deltaSet x c aset::zs) symbols xs in
	      dfs xs ys (n+1) in
      let ys, _  = dfs [ss] Q_set2int.empty 0 in
      let qs', aset', fs' = Q_set2int.fold 
	  (fun ps n (qs', aset', fs') -> 
	    let fs' = if Q_set.is_empty (Q_set.inter fs ps) then fs' else Q_set.add n fs' in
	    let aset' = Symbol_set.fold 
		(fun c aset' -> 
		  let m = Q_set2int.find (Arrow.deltaSet ps c aset) ys in
		  Arrow.add n c m aset') symbols aset' in
	    (Q_set.add n qs', aset', fs')) ys (Q_set.empty, Arrow.empty, Q_set.empty) in
      {symbols = symbols;
       states = qs';
       arrow = aset';
       start = Q_set2int.find ss ys;
       final = fs'}


    let nfa2dfa fa = nfa2dfa' fa.symbols
	(fa.states, fa.arrow, Q_set.singleton fa.start, fa.final) 

    (* Brzozowski minimization : NFA -> DFA *)
    let minimize {symbols = symbols; states = qs; arrow = aset; start = s; final = fs} = 
      let aset = Arrow.inverse aset in
      let fa = nfa2dfa' symbols (qs, aset, fs, Q_set.singleton s) in
      let aset = Arrow.inverse fa.arrow in
      nfa2dfa' symbols (fa.states, aset, fa.final, Q_set.singleton fa.start)

    let isDFA fa = 
      Q_set.for_all 
	(fun q -> Symbol_set.for_all 
	    (fun c ->
	      try
		Q_set.cardinal (Arrow.delta q c fa.arrow) = 1
	      with Not_found -> false) fa.symbols)
	fa.states

    let neg fa = 
      let () = assert (isDFA fa) in
      {fa with final = Q_set.diff fa.states fa.final}

    let is_empty fa = 
      let graph =
	Arrow.fold (fun q c q' graph -> QGraph.add q q' graph) 
	  fa.arrow QGraph.empty in
      not (QGraph.is_reachable graph fa.final [fa.start] Q_set.empty)

  let prod {symbols = ss1; states = q1; arrow = a1; start = s1; final = f1} 
      {symbols = ss2; states = q2; arrow = a2; start = s2; final = f2} =
    let m = Q_set.max_elt q1 + 1 in
    let compute_state x1 x2 = x2 * m + x1 in
    let q = 
      Q_set.fold (fun x1 making -> 
	Q_set.fold (fun x2 making -> Q_set.add (compute_state x1 x2) making)
	  q2 making) q1 Q_set.empty in
    let f = 
      Q_set.fold (fun x1 making -> 
	Q_set.fold (fun x2 making -> Q_set.add (compute_state x1 x2) making)
	  f2 making) f1 Q_set.empty in
    let a = 
      Arrow.fold (fun x1 c1 y1 making ->
	Q_set.fold (fun x2 making ->
	let qs = Arrow.delta x2 c1 a2 in
	Q_set.fold (fun y2 making ->
	  Arrow.add (compute_state x1 x2) c1 (compute_state y1 y2) making) qs making) q2 making)
	a1 Arrow.empty in
    let () = assert (Symbol_set.equal ss1 ss2) in 
    {symbols = ss1; states = q; arrow = a; start = compute_state s1 s2; final = f}

    let dfa_subset fa1 fa2 =
      let fa2' = neg fa2 in
      is_empty (prod fa1 fa2')

    let dfa_equal fa1 fa2 = dfa_subset fa1 fa2 && dfa_subset fa2 fa1

  end;;

