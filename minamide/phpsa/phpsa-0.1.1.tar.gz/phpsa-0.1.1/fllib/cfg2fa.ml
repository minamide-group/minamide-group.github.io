(*
 * PHP string analyzer
 * Copyright (C) 2005, 2006 Nobuo Otoi, Yasuhiko Minamide
 *)
open Basic

module Make (F:Fa.S)(C: Cfg.S with type terminal= F.symbol and module Terminal_set = F.Symbol_set) =
  struct
    open F

    let eclosure xs g =
      let rec dfs xs rs =
	match xs with
	  [] -> rs
	| x::xs ->  if Q_set.mem x rs then dfs xs rs
	else  dfs (QGraph.find x g@xs) (Q_set.add x rs) in
      dfs (Q_set.elements xs) Q_set.empty 

    let compose_etransition all_symbols qs earrow arrow =
      Q_set.fold (fun q nfa_arrow ->
	Symbol_set.fold (fun c nfa_arrow ->
	  let qs = eclosure (Q_set.singleton q) earrow in
	  let qs = Arrow.deltaSet qs c arrow in
	  let qs = eclosure qs earrow in
	  if Q_set.is_empty qs then nfa_arrow 
	  else ArrowMap.add (q,c) qs nfa_arrow) all_symbols nfa_arrow) qs Arrow.empty

    let rec add_string_transition nfa_map s1 w s2 (n, earrow, arrow) =
      match w with
	[] -> n, QGraph.add s1 s2 earrow, arrow
      | [C.Terminal c] -> n, earrow, Arrow.add s1 c s2 arrow
      | C.Terminal c::w -> 
	  let arrow = Arrow.add s1 c n arrow in
	  add_string_transition nfa_map n w s2 (n+1, earrow, arrow)
      | C.Variable x::w ->
	  let rename q = q + n in 
	  let size, q1, q2, earrow', arrow' = C.Prod.find x nfa_map in
	  let q1 = rename q1 in
	  let q2 = rename q2 in
	  let earrow =  
	    QGraph.QMap.fold (fun q qs earrow -> 
	      QGraph.QMap.add (rename q) (List.map rename qs) earrow) earrow' earrow in
	  let earrow = QGraph.add s1 q1 earrow in
	  let arrow = 
	    ArrowMap.fold (fun (x,c) ys making -> 
	      ArrowMap.add (rename x, c) (Basic.rename ys n) making) arrow' arrow in
	  add_string_transition nfa_map q2 w s2 (n+size, earrow, arrow)

    let left_linear_cfg2fa nfa_map prod xs =
      let size, vmap = C.Variable_set.fold (fun x (n, vmap) -> (n+1, C.Prod.add x n vmap)) xs 
	  (0, C.Prod.empty) in
      let size = size+1 in
      let n, earrow, arrow =
	C.prod_fold (fun x ss enfa ->
	  if C.Variable_set.mem x xs then
	    match ss with
	      C.Variable y::ss when C.Variable_set.mem y xs -> 
		add_string_transition nfa_map (C.Prod.find y vmap) ss (C.Prod.find x vmap) enfa
	    | ss -> add_string_transition nfa_map size ss (C.Prod.find x vmap) enfa
	  else enfa) prod 
	  (size+1, QGraph.empty, Arrow.empty) in
      (vmap, n, size, earrow, arrow)

    let right_linear_cfg2fa nfa_map prod xs =
      let size, vmap = C.Variable_set.fold (fun x (n, vmap) -> (n+1, C.Prod.add x n vmap)) xs 
	  (0, C.Prod.empty) in
      let size = size+1 in
      let n, earrow, arrow =
	C.prod_fold (fun x ss enfa ->
	  if C.Variable_set.mem x xs then
	    let ss' = List.rev ss in
	    match ss' with
	      C.Variable y::ss when C.Variable_set.mem y xs -> 
		add_string_transition nfa_map (C.Prod.find x vmap) (List.rev ss) (C.Prod.find y vmap) enfa
	    | ss -> add_string_transition nfa_map (C.Prod.find x vmap) ss size enfa
	  else enfa) prod 
	  (size+1, QGraph.empty, Arrow.empty) in
      (vmap, n, size, earrow, arrow)

    let is_left_linear xs prod =
      let check s =
	match s with
	  C.Variable x -> not (C.Variable_set.mem x xs)
	| _ -> true in
      C.Variable_set.for_all (fun x ->
	let sss = C.prod_find x prod in
	C.SententialForm_set.for_all (fun ss ->
	  match ss with
	    C.Variable y::ss when C.Variable_set.mem y xs -> List.for_all check ss
	  | ss -> List.for_all check ss) sss) xs 

    let is_right_linear xs prod =
      let check s =
	match s with
	  C.Variable x -> not (C.Variable_set.mem x xs)
	| _ -> true in
      C.Variable_set.for_all (fun x ->
	let sss = C.prod_find x prod in
	C.SententialForm_set.for_all (fun ss ->
	  match List.rev ss with
	    C.Variable y::ss when C.Variable_set.mem y xs -> List.for_all check ss
	  | ss -> List.for_all check ss) sss) xs 

    let cfg2fa_scc scc prod =
      List.fold_left (fun nfa_map xs -> 
	if is_left_linear xs prod then
	  let vmap, n, size, earrow, arrow = left_linear_cfg2fa nfa_map prod xs in
	  C.Prod.fold (fun x m nfa_map  ->
	    C.Prod.add x (n, size, m, earrow, arrow) nfa_map) vmap nfa_map
	else if is_right_linear xs prod then
	  let vmap, n, size, earrow, arrow = right_linear_cfg2fa nfa_map prod xs in
	  C.Prod.fold (fun x m nfa_map  ->
	    C.Prod.add x (n, m, size, earrow, arrow) nfa_map) vmap nfa_map 
	else failwith "Cannot convert the CFG into FA") C.Prod.empty scc

    let find x map =
      try C.Prod.find x map with Not_found -> []

    let add x y map =
      C.Prod.add x (y::find x map) map

    open Absgraph
    module NodeGraph =
      Make(struct 
	type t = C.variable
	type g = C.Variable_set.t * C.variable list C.Prod.t * C.variable list C.Prod.t
	module NodeSet = C.Variable_set
	let nexts (ns, g1, g2) x = find x g1
	let nexts_r (ns, g1, g2) x = find x g2
	let nodes_of (ns, g1, g2) = ns
      end)

    let scc_of cfg =
      let fmap, bmap =
	C.prod_fold (fun x ss (fmap, bmap) ->
	  List.fold_left (fun (fmap, bmap) s ->
	    match s with
	      C.Variable y -> (add x y fmap, add y x bmap)
	    | _ -> (fmap, bmap))
	    (fmap, bmap) ss) cfg.C.prod (C.Prod.empty, C.Prod.empty) in
      let g = C.vars_of cfg, fmap, bmap in
      let scc =  NodeGraph.sc g in
      scc

    let cfg2fa cs cfg =
      let scc = scc_of cfg in
      let () = List.iter (fun xs -> C.Variable_set.iter (fun x -> Format.printf "%s," (C.string_of_v x)) xs;
	Format.printf "@.") scc in
      let nfa_map = cfg2fa_scc scc cfg.C.prod in
      let n, q1, q2, earrow, arrow = C.Prod.find cfg.C.start nfa_map in
      let qs = 
	let rec loop i qs =
	  if i < n then loop (i + 1) (Q_set.add i qs) else qs in
	loop 0 Q_set.empty in
      let fs = Q_set.singleton q2 in
      let fs = if Q_set.mem q2 (eclosure (Q_set.singleton q1) earrow) then Q_set.add q1 fs else fs in
      let ts = C.terminals_of_prod cfg.C.prod in
      let () = assert (F.Symbol_set.subset ts cs) in
      {symbols = cs;
       states = qs;
       arrow = compose_etransition ts qs earrow arrow;
       start = q1;
       final = fs}
  end
