(*
 * PHP string analyzer
 * Copyright (C) 2005, 2006 Yasuhiko Minamide
 *)
module type AbsGraphType =
  sig
    type t
    type g
    module NodeSet : Set.S with type elt = t
    val nexts: g -> t -> t list
    val nodes_of: g -> NodeSet.t
  end

module Make(G: AbsGraphType) =
  struct

    module NodeSet = G.NodeSet

    let absdfs g nexts  =
      let rec dfs xs rs =
	match xs with
	  [] -> rs
	| ys::xs ->  
	    List.fold_left (fun rs x ->
	      if NodeSet.mem x rs then rs
	      else  dfs (nexts g x::xs) (NodeSet.add x rs)) 
	      rs ys in
      dfs

    let dfs g xs = absdfs g G.nexts [xs]

    (* 
     *   Results : the list of componets [C1; C2; ....; Cn]
     *             where there is no edge from Ci to Cj for i < j 
     *)

    let sc graph =
      let i = ref 0 in
      let sccs = ref [] in
      let stack = Stack.create () in
      let stacked = Hashtbl.create 1000 in
      let dfsnum = Hashtbl.create 1000 in
      let rec dfsscc v =
	let vi = !i in
	Hashtbl.add dfsnum v vi;
	incr i;
	Stack.push v stack; Hashtbl.add stacked v ();
	let low = 
	  List.fold_left (fun low w ->
	    if not (Hashtbl.mem dfsnum w) then
	      min low (dfsscc w)
	    else
	      if Hashtbl.mem stacked w && Hashtbl.find dfsnum w < vi then
		min low (Hashtbl.find dfsnum w)
	      else
		low)
	    vi (G.nexts graph v) in
	if low = vi then
	  (let component = ref NodeSet.empty in
	  while not (Stack.is_empty stack) && 
	    Hashtbl.find dfsnum (Stack.top stack) >= vi do
	    let w = Stack.pop stack in
	    Hashtbl.remove stacked w;
	    component := NodeSet.add w (!component)
	  done;
	  sccs := !component::!sccs);
	low in
      NodeSet.iter 
	(fun v -> if not (Hashtbl.mem dfsnum v) then let _ = dfsscc v in ())
	(G.nodes_of graph);
      List.rev (!sccs)

    let scc_of graph xs =
      let i = ref 0 in
      let sccs = ref [] in
      let stack = Stack.create () in
      let stacked = Hashtbl.create 1000 in
      let dfsnum = Hashtbl.create 1000 in
      let rec dfsscc v =
	let vi = !i in
	Hashtbl.add dfsnum v vi;
	incr i;
	Stack.push v stack; Hashtbl.add stacked v ();
	let low = 
	  List.fold_left (fun low w ->
	    if not (Hashtbl.mem dfsnum w) then
	      min low (dfsscc w)
	    else
	      if Hashtbl.mem stacked w then
		min low (Hashtbl.find dfsnum w)
	      else
		low)
	    vi (G.nexts graph v) in
	if low = Hashtbl.find dfsnum v then
	  (let component = ref [] in
	  while not (Stack.is_empty stack) && 
	    Hashtbl.find dfsnum (Stack.top stack) >= vi do
	    let w = Stack.pop stack in
	    Hashtbl.remove stacked w;
	    component := w::!component
	  done;
	  sccs := !component::!sccs);
	low in
      NodeSet.iter 
	(fun v -> if not (Hashtbl.mem dfsnum v) then let _ = dfsscc v in ())
	xs;
      !sccs
  end

module Test =
  Make(
  struct 
    type t = int
    type g = (int * int) list
    module NodeSet =
      Set.Make
	(struct 
	  type t = int
	  let compare = compare  
	end)
    let rec nexts ns x =
      match ns with
	[] -> []
      | (y,z)::ns -> if y = x then z::nexts ns x else nexts ns x

    let rec nexts_r ns x =
      match ns with
	[] -> []
      | (y,z)::ns -> if z = x then y::nexts_r ns x else nexts_r ns x

    let nodes_of ns =
      List.fold_left (fun xs (y,z) -> NodeSet.add y (NodeSet.add z xs)) NodeSet.empty ns 
  end)
