(*
 * PHP string analyzer
 * Copyright (C) 2005, 2006 Nobuo Otoi, Yasuhiko Minamide
 *)
(* Finite Transducers *)
 
open Basic
 
module type SYMBOL_TYPE =
  sig
    type symbol
    val string_of : symbol -> string
    val pp_print : Format.formatter -> symbol -> unit
  end

module type S  =
  sig
    type symbol
    type symbol_t
    val string_of : symbol -> string
    module QSLset : Set.S with type elt = q * symbol_t list
    module ArrowMap : Map.S with type key = q * symbol
    type arrow = QSLset.t ArrowMap.t
    module Arrow :
      sig
	val empty : arrow
	val delta : q -> symbol -> arrow -> QSLset.t
	val deltaHat : q -> symbol list -> arrow -> QSLset.t
	val add : q -> symbol -> q -> symbol_t list -> arrow -> arrow
	val add' : q -> symbol -> QSLset.t -> arrow -> arrow
	val fold : (q -> symbol -> q -> symbol_t list -> 'a -> 'a) -> arrow -> 'a -> 'a
	val union : arrow -> arrow -> arrow
	val print_arrow : Format.formatter -> arrow -> unit
	val rev : arrow -> arrow
      end
    type ft = {states: Q_set.t; arrow: arrow; start: q; final: Q_set.t}
    val pp_ft :  Format.formatter -> ft -> unit 
    val create : Q_set.t -> arrow ->  q -> Q_set.t -> ft
    val delta : ft -> q * symbol -> QSLset.t
    val deltaHat : ft -> q * symbol list -> QSLset.t
    val rev : ft -> ft
    val quasi_determinize : ft -> ft
    val accessible : ft -> ft
    val coaccessible : ft -> ft
    val join : ft -> ft -> ft
    val output : ft -> symbol list -> symbol_t list list
  end

module Make(SY:SYMBOL_TYPE)(SYT:SYMBOL_TYPE) =
  struct
    type symbol = SY.symbol
    type symbol_t = SYT.symbol
    let string_of = SY.string_of

    module ArrowMap = 
      Map.Make(struct 
	type t = q * symbol  
	let compare = compare 
      end)

    module QSLset =
      Set.Make(struct 
	type t = q * symbol_t list
	let compare = compare
      end)

    type arrow = QSLset.t ArrowMap.t

    module Arrow =
      struct 
	type t = arrow

	let empty = ArrowMap.empty 

	let delta from by aset = 
	  try ArrowMap.find (from,by) aset with Not_found -> QSLset.empty

	let deltaSet from by aset =
	  Q_set.fold (fun from making -> QSLset.union making (delta from by aset)) from QSLset.empty

	let deltaSet' qsss by aset =
	  QSLset.fold (fun (from,ss) making -> 
	    QSLset.fold (fun (q,ss') making -> QSLset.add (q,ss@ss') making)
	      (delta from by aset) making) qsss QSLset.empty

	let rec deltaHatSet' from byL aset =
	  match byL with
	    [] -> from
	  | x::xs -> deltaHatSet' (deltaSet' from x aset) xs aset
		
	let deltaHat from byL aset = 
	  deltaHatSet' (QSLset.singleton (from,[])) byL aset
	    
	let add x c y cs aset = 
	  ArrowMap.add (x,c) (QSLset.add (y, cs) (delta x c aset)) aset

	let add' x c ys aset = 
	  ArrowMap.add (x,c) (QSLset.union ys (delta x c aset)) aset

	let union aset1 aset2 =
	  ArrowMap.fold (fun (x,c) ys making -> add' x c ys making) aset1 aset2

	let print_arrow fmt aset =
	  ArrowMap.iter 
	    (fun (x,c) qss -> 
	      QSLset.iter (fun (y, cs) ->
		Format.fprintf fmt "(%d) -%a/%a-> %d@." 
		  x SY.pp_print c (Basic.print_list "" SYT.pp_print) cs y) qss)
	    aset

	let fold g arrow making =
	  ArrowMap.fold (fun (f,c) q making ->
	    QSLset.fold (fun (t,cs) making -> g f c t cs making) q making) arrow making

	let filter f aset =
	  fold (fun x c y cs making -> 
	    if f x c y cs then add x c y cs making else making)
	    aset ArrowMap.empty

	let rev arrow =
	  fold (fun q c q' ts arrow -> add q' c q (List.rev ts) arrow)
	    arrow ArrowMap.empty 
      end

    type ft = {states: Q_set.t; arrow: arrow; start: q; final: Q_set.t}

    let create qs aset s f = 
      {states = qs; arrow = aset; start = s; final = f}

    let pp_ft fmt ft =
      Format.fprintf fmt "states = %a, start = %a, final = %a@."
      print_states ft.states print_state ft.start print_states ft.final;
      Arrow.print_arrow fmt ft.arrow

    let delta ft (q,c) = Arrow.delta q c ft.arrow 
    let deltaHat ft (qs,cs) = Arrow.deltaHat qs cs ft.arrow 

    module SLset =
      Set.Make(struct 
	type t = symbol_t list
	let compare = compare
      end)

    let output ft byL =
      let qsls = deltaHat ft (ft.start, byL) in
      SLset.elements 
	(QSLset.fold (fun (q,cs) ss -> if Q_set.mem q ft.final then SLset.add cs ss else ss)
	   qsls SLset.empty)

    let rev ft =
      let arrow = Arrow.rev ft.arrow in
      let n = Q_set.max_elt ft.states + 1 in
      let arrow = Arrow.fold
	  (fun q c q' ts arrow -> 
	    if Q_set.mem q ft.final then Arrow.add n c q' ts arrow
	    else arrow) arrow arrow in
      let f' = Q_set.singleton ft.start in
      let f' = if Q_set.mem ft.start ft.final then Q_set.add n f' else f' in
      create (Q_set.add n ft.states) arrow n f'

    let rec max_prefix xs ys =
      match (xs, ys) with
	([],_) | (_,[]) -> []
      | (x::xs, y::ys) ->
	  if x = y then x::max_prefix xs ys else []

    let max_prefix_list xss =
      match xss with
	[] -> []
      | [xs] -> xs
      | xs::xss -> List.fold_left 
	    (fun ys xs -> max_prefix xs ys) xs xss 

    let rec cut_prefix xs ys =
      match (xs, ys) with
	([],ys) -> ys
      | (_,[]) -> failwith "cut_prefix"
      | (x::xs, y::ys) ->
	  if x = y then cut_prefix xs ys 
	  else failwith "cut_prefix"

    module QMap = 
      Map.Make(struct type t = q let compare = compare end)

    let quasi_determinize ft =
      let find q map = 
	try QMap.find q map with Not_found -> [] in
      let omap = 
	Arrow.fold (fun q c q' cs omap ->
	  QMap.add q ((q',cs)::find q omap) omap) ft.arrow
	  QMap.empty in
      let init_prefixmap = Q_set.fold (fun q prefixmap ->
	QMap.add q [] prefixmap) ft.states QMap.empty in
      let eval prefixmap =
	QMap.fold (fun q qcs newmap ->
	  if Q_set.mem q ft.final then QMap.add q [] newmap
	  else
	    let css =
	      List.map (fun (q',cs) ->
		cs@
		    try QMap.find q' newmap 
		    with Not_found ->  find q' prefixmap) qcs in
	    let cs = max_prefix_list css in
	    QMap.add q cs newmap) omap QMap.empty in
      let rec loop prefixmap =
	let newmap = eval prefixmap in
	if Q_set.fold (fun q b ->
	  b && find q prefixmap = find q newmap) ft.states true
	then prefixmap else loop newmap in
      let prefixmap = loop init_prefixmap in
      let arrow = Arrow.fold (fun q c q' cs making ->
	let cs1 = find q prefixmap in
	let cs2 = find q' prefixmap in
	Arrow.add q c q' (cut_prefix cs1 (cs@cs2))
	  making) ft.arrow ArrowMap.empty in
      create ft.states arrow ft.start ft.final

    let accessible ft =
      let graph =
	Arrow.fold (fun q c q' cs graph -> QGraph.add q q' graph) 
	  ft.arrow QGraph.empty in
      let qs = QGraph.dfs graph [ft.start] Q_set.empty in
      let arrow = Arrow.filter (fun q c q' cs -> Q_set.mem q qs && Q_set.mem q' qs) ft.arrow in 
      create qs arrow ft.start (Q_set.inter ft.final qs)
    
    let coaccessible ft =
      let graph =
	Arrow.fold (fun q c q' cs graph -> QGraph.add q' q graph) 
	  ft.arrow QGraph.empty in
      let qs = QGraph.dfs graph (Q_set.elements ft.final) Q_set.empty in
      let qs = Q_set.add ft.start qs in
      let arrow = Arrow.filter (fun q c q' cs -> Q_set.mem q qs && Q_set.mem q' qs) ft.arrow in 
      create qs arrow ft.start ft.final

    let join ft1 ft2 =
      let f = if Q_set.mem ft2.start ft2.final then Q_set.union ft1.final ft2.final else ft2.final in
      let arrow =
	Arrow.fold (fun q1 c q2 cs arrow ->
	  let arrow = Arrow.add q1 c q2 cs arrow in
	  if q1 = ft2.start then
	    Q_set.fold (fun q1' arrow ->
	      Arrow.add q1' c q2 cs arrow) ft1.final arrow
	  else 	
	    arrow) ft2.arrow ft1.arrow in
      create (Q_set.union ft1.states ft2.states) arrow ft1.start f
  end

