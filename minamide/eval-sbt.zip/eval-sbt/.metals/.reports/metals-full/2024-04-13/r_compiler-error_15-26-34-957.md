file://<WORKSPACE>/test/EvalTest.scala
### scala.reflect.internal.FatalError: 
  bad constant pool index: 0 at pos: 49180
     while compiling: <no file>
        during phase: globalPhase=<no phase>, enteringPhase=<some phase>
     library version: version 2.13.7
    compiler version: version 2.13.7
  reconstructed args: -classpath <HOME>/Library/Caches/Coursier/v1/https/repo1.maven.org/maven2/org/scala-lang/scala-library/2.13.7/scala-library-2.13.7.jar -Ymacro-expand:discard -Ycache-plugin-class-loader:last-modified -Ypresentation-any-thread

  last tree to typer: EmptyTree
       tree position: <unknown>
            tree tpe: <notype>
              symbol: null
           call site: <none> in <none>

== Source file context for tree position ==



occurred in the presentation compiler.

presentation compiler configuration:
Scala version: 2.13.7
Classpath:
<HOME>/Library/Caches/Coursier/v1/https/repo1.maven.org/maven2/org/scala-lang/scala-library/2.13.7/scala-library-2.13.7.jar [exists ]
Options:



action parameters:
uri: file://<WORKSPACE>/test/EvalTest.scala
text:
```scala
package nonscala

import org.scalatest._
import flatspec._
import matchers._

import Base._
import Abssyn._
import Oper._
import Eval._
import Parser._


class EvalTest extends AnyFlatSpec with should.Matchers {
  "1" should "be 1" in
  {
    assert(eval(Map(), Map(), IntExp(1))== IntVal(1))
  }
  

  "x under Map(x->1)" should "be 1" in
  {
    assert(eval(Map(), Map("x"->IntVal(1)), VarExp("x"))== IntVal(1))
  }

  "1+x under Map(x->1)" should "be 2" in
  {
    assert(eval(Map(), Map("x"->IntVal(1)),
      BOpExp(PlusOp, IntExp(1), VarExp("x")))== IntVal(2))
  }


  "x.isEmpty under Map(x->Nil)" should "be true" in
  {
    assert(eval(Map(), Map("x"->ListVal(Nil)),
      UOpExp(IsEmptyOp, VarExp("x")))== BoolVal(true))
  }

  "x.isEmpty under Map(x->List(1,2l))" should "be false" in
  {
    assert(eval(Map(), Map("x"->ListVal(List(1,2))),
      UOpExp(IsEmptyOp, VarExp("x")))== BoolVal(false))
  }

  "if (0 == 0) Nil else Nil.head" should "be Nil; then 節のみ評価" in
  {
    assert(eval(Map(), Map(),
      IfExp(BOpExp(EqOp, IntExp(0), IntExp(0)),
        NilExp, UOpExp(HeadOp, NilExp))) == ListVal(Nil))
  }
  

  "f(1,x) under Map(f-> (x,y) => x::y) and Map(x->List(2))" should "be List(1,2)" in
  {
    assert(
      eval(Map("f"->FValue(List("x","y"), BOpExp(ConsOp, VarExp("x"), VarExp("y")))),
        Map("x"->ListVal(List(2))),
        AppExp("f", List(IntExp(1), VarExp("x"))))== ListVal(List(1,2)))
  }

  "例: sort(List(3,2,1))" should "be List(1,2,3)" in
  {
    val ds = parseFileDefs("examples/sort.scala")
    val fenv = defs2env(ds)
    assert(
      eval(fenv, Map("x"->ListVal(List(3,2,1))), AppExp("sort", List(VarExp("x")))) == ListVal(List(1,2,3)))

  }

  "例: qsort(List(3,2,1,3,5,3,1,4))" should "be List(1,1,2,3,3,3,4,5)" in
  {
    val ds = parseFileDefs("examples/qsort.scala")
    val fenv = defs2env(ds)
    assert(
      eval(fenv, Map("x"->ListVal(List(3,2,1,3,5,3,1,4))), AppExp("qsort", List(VarExp("x")))) == ListVal(List(1,1,2,3,3,3,4,5)))

  }

  "例: primes(20)" should "be List(2,3,5,7,11,13,17,19)" in
  {
    val ds = parseFileDefs("examples/primes.scala")
    val fenv = defs2env(ds)
    assert(
      eval(fenv, Map(), AppExp("primes", List(IntExp(20)))) ==
        ListVal(List(2,3,5,7,11,13,17,19)))

  }

  behavior of "自作のテスト"

  /* テストを追加する場合は，この下に追加してください．*/  

}

```



#### Error stacktrace:

```
scala.reflect.internal.Reporting.abort(Reporting.scala:69)
	scala.reflect.internal.Reporting.abort$(Reporting.scala:65)
	scala.reflect.internal.SymbolTable.abort(SymbolTable.scala:28)
	scala.tools.nsc.symtab.classfile.ClassfileParser$ConstantPool.errorBadIndex(ClassfileParser.scala:407)
	scala.tools.nsc.symtab.classfile.ClassfileParser$ConstantPool.getExternalName(ClassfileParser.scala:262)
	scala.tools.nsc.symtab.classfile.ClassfileParser.readParamNames$1(ClassfileParser.scala:853)
	scala.tools.nsc.symtab.classfile.ClassfileParser.parseAttribute$1(ClassfileParser.scala:859)
	scala.tools.nsc.symtab.classfile.ClassfileParser.$anonfun$parseAttributes$6(ClassfileParser.scala:936)
	scala.tools.nsc.symtab.classfile.ClassfileParser.parseAttributes(ClassfileParser.scala:936)
	scala.tools.nsc.symtab.classfile.ClassfileParser.parseMethod(ClassfileParser.scala:635)
	scala.tools.nsc.symtab.classfile.ClassfileParser.parseClass(ClassfileParser.scala:548)
	scala.tools.nsc.symtab.classfile.ClassfileParser.$anonfun$parse$2(ClassfileParser.scala:174)
	scala.tools.nsc.symtab.classfile.ClassfileParser.$anonfun$parse$1(ClassfileParser.scala:159)
	scala.tools.nsc.symtab.classfile.ClassfileParser.parse(ClassfileParser.scala:142)
	scala.tools.nsc.symtab.SymbolLoaders$ClassfileLoader.doComplete(SymbolLoaders.scala:342)
	scala.tools.nsc.symtab.SymbolLoaders$SymbolLoader.$anonfun$complete$2(SymbolLoaders.scala:249)
	scala.tools.nsc.symtab.SymbolLoaders$SymbolLoader.complete(SymbolLoaders.scala:247)
	scala.reflect.internal.Symbols$Symbol.completeInfo(Symbols.scala:1561)
	scala.reflect.internal.Symbols$Symbol.info(Symbols.scala:1533)
	scala.reflect.internal.Definitions.scala$reflect$internal$Definitions$$enterNewMethod(Definitions.scala:47)
	scala.reflect.internal.Definitions$DefinitionsClass.String_$plus$lzycompute(Definitions.scala:1256)
	scala.reflect.internal.Definitions$DefinitionsClass.String_$plus(Definitions.scala:1256)
	scala.reflect.internal.Definitions$DefinitionsClass.syntheticCoreMethods$lzycompute(Definitions.scala:1577)
	scala.reflect.internal.Definitions$DefinitionsClass.syntheticCoreMethods(Definitions.scala:1559)
	scala.reflect.internal.Definitions$DefinitionsClass.symbolsNotPresentInBytecode$lzycompute(Definitions.scala:1590)
	scala.reflect.internal.Definitions$DefinitionsClass.symbolsNotPresentInBytecode(Definitions.scala:1590)
	scala.reflect.internal.Definitions$DefinitionsClass.init(Definitions.scala:1646)
	scala.tools.nsc.Global$Run.<init>(Global.scala:1226)
	scala.tools.nsc.interactive.Global$TyperRun.<init>(Global.scala:1331)
	scala.tools.nsc.interactive.Global.newTyperRun(Global.scala:1354)
	scala.tools.nsc.interactive.Global.<init>(Global.scala:294)
	scala.meta.internal.pc.MetalsGlobal.<init>(MetalsGlobal.scala:40)
	scala.meta.internal.pc.ScalaPresentationCompiler.newCompiler(ScalaPresentationCompiler.scala:434)
```
#### Short summary: 

scala.reflect.internal.FatalError: 
  bad constant pool index: 0 at pos: 49180
     while compiling: <no file>
        during phase: globalPhase=<no phase>, enteringPhase=<some phase>
     library version: version 2.13.7
    compiler version: version 2.13.7
  reconstructed args: -classpath <HOME>/Library/Caches/Coursier/v1/https/repo1.maven.org/maven2/org/scala-lang/scala-library/2.13.7/scala-library-2.13.7.jar -Ymacro-expand:discard -Ycache-plugin-class-loader:last-modified -Ypresentation-any-thread

  last tree to typer: EmptyTree
       tree position: <unknown>
            tree tpe: <notype>
              symbol: null
           call site: <none> in <none>

== Source file context for tree position ==

