file://<WORKSPACE>/src/Eval.scala
### scala.reflect.internal.FatalError: 
  bad constant pool index: 0 at pos: 49180
     while compiling: <no file>
        during phase: globalPhase=<no phase>, enteringPhase=<some phase>
     library version: version 2.13.7
    compiler version: version 2.13.7
  reconstructed args: -classpath <HOME>/Library/Caches/Coursier/v1/https/repo1.maven.org/maven2/org/scala-lang/scala-library/2.13.7/scala-library-2.13.7.jar -Ymacro-expand:discard -Ycache-plugin-class-loader:last-modified -Ypresentation-any-thread

  last tree to typer: EmptyTree
       tree position: <unknown>
            tree tpe: <notype>
              symbol: null
           call site: <none> in <none>

== Source file context for tree position ==



occurred in the presentation compiler.

presentation compiler configuration:
Scala version: 2.13.7
Classpath:
<HOME>/Library/Caches/Coursier/v1/https/repo1.maven.org/maven2/org/scala-lang/scala-library/2.13.7/scala-library-2.13.7.jar [exists ]
Options:



action parameters:
uri: file://<WORKSPACE>/src/Eval.scala
text:
```scala
package nonscala

import Base.*
import Abssyn.*
import Oper.*

object Eval {

  case class EvalError(s: String) extends Throwable
  def error(s: String) = throw(EvalError(s))

  // 値  
  enum Value:
    case IntVal(i: Int)
    case BoolVal(b: Boolean)
    case ListVal(l: List[Int])
  export Value.*

  // 関数
  case class FValue(xs: List[Var], e: Exp)

  def eval (fenv: Map[Var, FValue], env: Map[Var, Value], e: Exp): Value =
    e match {
      case VarExp(x) => env(x) 
      case IntExp(i) => IntVal(i)
      case NilExp => ListVal(Nil)
      case BOpExp(o, e1, e2) => {
        val v1 = eval (fenv, env, e1)
        val v2 = eval (fenv, env, e2)
        (o, v1, v2) match {
          case (PlusOp, IntVal(i1), IntVal(i2)) => IntVal (i1+i2)
          case (MinusOp, IntVal(i1), IntVal(i2)) => IntVal (i1-i2)
          case (MulOp, IntVal(i1), IntVal(i2)) => IntVal (i1*i2)
          case (DivOp, IntVal(i1), IntVal(i2)) => IntVal (i1/i2)
          case (EqOp, IntVal(i1), IntVal(i2)) => BoolVal (i1 == i2)
          case (LtOp, IntVal(i1), IntVal(i2)) => BoolVal (i1 < i2)
          case (ConsOp, IntVal(i), ListVal(l)) =>ListVal(i::l)
          case _ => error("impossible if the program is well-typed")            
        }
      }
      case UOpExp(o, e1) => {
        val v1 = eval (fenv, env, e1)
        (o, v1) match {
          case (IsEmptyOp, ListVal(Nil)) => BoolVal(true)
          case (IsEmptyOp, ListVal(_::_)) => BoolVal(false)
          case (HeadOp, ListVal(h::t)) => IntVal(h)
          case (HeadOp, ListVal(Nil)) => error("head is applied to Nil")
          case (TailOp, ListVal(h::t)) => ListVal(t)
          case (TailOp, ListVal(Nil)) => error("tail is applied to Nil")
          case _ => error("impossible if the program is well-typed")
        }
      }
      case IfExp(e, e1, e2) =>
        eval(fenv, env, e) match  {
          case BoolVal(b) =>
            if (b) eval(fenv, env, e1) else eval(fenv, env, e2)
          case _ => error("impossible if the program is well-typed")
        } 
/*      case IfExp(e, e1, e2) => {
        val v =  eval(fenv, env, e)
        val v1 = eval(fenv, env, e1)
        val v2 = eval(fenv, env, e2)                 
        v match  {
          case BoolVal(b) =>
            if (b) v1 else v2
          case _ => error("impossible if the program is well-typed")
        }
      } */
      case AppExp(f, es) => {
        val FValue(xs,body) = fenv(f)
        val vs = es.map(e => eval(fenv, env, e))
        eval(fenv, xs.zip(vs).toMap, body)
      }
      case LetExp(x, e1, e2) => {
        val v1 = eval (fenv, env, e1)
        eval(fenv, env + (x -> v1), e2)
      }
    }

  def defs2env (ds: List[Def]): Map[Var, FValue] =
    ds.map(d => (d.name, FValue(d.args.map(_._1), d.body))).toMap
}



```



#### Error stacktrace:

```
scala.reflect.internal.Reporting.abort(Reporting.scala:69)
	scala.reflect.internal.Reporting.abort$(Reporting.scala:65)
	scala.reflect.internal.SymbolTable.abort(SymbolTable.scala:28)
	scala.tools.nsc.symtab.classfile.ClassfileParser$ConstantPool.errorBadIndex(ClassfileParser.scala:407)
	scala.tools.nsc.symtab.classfile.ClassfileParser$ConstantPool.getExternalName(ClassfileParser.scala:262)
	scala.tools.nsc.symtab.classfile.ClassfileParser.readParamNames$1(ClassfileParser.scala:853)
	scala.tools.nsc.symtab.classfile.ClassfileParser.parseAttribute$1(ClassfileParser.scala:859)
	scala.tools.nsc.symtab.classfile.ClassfileParser.$anonfun$parseAttributes$6(ClassfileParser.scala:936)
	scala.tools.nsc.symtab.classfile.ClassfileParser.parseAttributes(ClassfileParser.scala:936)
	scala.tools.nsc.symtab.classfile.ClassfileParser.parseMethod(ClassfileParser.scala:635)
	scala.tools.nsc.symtab.classfile.ClassfileParser.parseClass(ClassfileParser.scala:548)
	scala.tools.nsc.symtab.classfile.ClassfileParser.$anonfun$parse$2(ClassfileParser.scala:174)
	scala.tools.nsc.symtab.classfile.ClassfileParser.$anonfun$parse$1(ClassfileParser.scala:159)
	scala.tools.nsc.symtab.classfile.ClassfileParser.parse(ClassfileParser.scala:142)
	scala.tools.nsc.symtab.SymbolLoaders$ClassfileLoader.doComplete(SymbolLoaders.scala:342)
	scala.tools.nsc.symtab.SymbolLoaders$SymbolLoader.$anonfun$complete$2(SymbolLoaders.scala:249)
	scala.tools.nsc.symtab.SymbolLoaders$SymbolLoader.complete(SymbolLoaders.scala:247)
	scala.reflect.internal.Symbols$Symbol.completeInfo(Symbols.scala:1561)
	scala.reflect.internal.Symbols$Symbol.info(Symbols.scala:1533)
	scala.reflect.internal.Definitions.scala$reflect$internal$Definitions$$enterNewMethod(Definitions.scala:47)
	scala.reflect.internal.Definitions$DefinitionsClass.String_$plus$lzycompute(Definitions.scala:1256)
	scala.reflect.internal.Definitions$DefinitionsClass.String_$plus(Definitions.scala:1256)
	scala.reflect.internal.Definitions$DefinitionsClass.syntheticCoreMethods$lzycompute(Definitions.scala:1577)
	scala.reflect.internal.Definitions$DefinitionsClass.syntheticCoreMethods(Definitions.scala:1559)
	scala.reflect.internal.Definitions$DefinitionsClass.symbolsNotPresentInBytecode$lzycompute(Definitions.scala:1590)
	scala.reflect.internal.Definitions$DefinitionsClass.symbolsNotPresentInBytecode(Definitions.scala:1590)
	scala.reflect.internal.Definitions$DefinitionsClass.init(Definitions.scala:1646)
	scala.tools.nsc.Global$Run.<init>(Global.scala:1226)
	scala.tools.nsc.interactive.Global$TyperRun.<init>(Global.scala:1331)
	scala.tools.nsc.interactive.Global.newTyperRun(Global.scala:1354)
	scala.tools.nsc.interactive.Global.<init>(Global.scala:294)
	scala.meta.internal.pc.MetalsGlobal.<init>(MetalsGlobal.scala:40)
	scala.meta.internal.pc.ScalaPresentationCompiler.newCompiler(ScalaPresentationCompiler.scala:434)
```
#### Short summary: 

scala.reflect.internal.FatalError: 
  bad constant pool index: 0 at pos: 49180
     while compiling: <no file>
        during phase: globalPhase=<no phase>, enteringPhase=<some phase>
     library version: version 2.13.7
    compiler version: version 2.13.7
  reconstructed args: -classpath <HOME>/Library/Caches/Coursier/v1/https/repo1.maven.org/maven2/org/scala-lang/scala-library/2.13.7/scala-library-2.13.7.jar -Ymacro-expand:discard -Ycache-plugin-class-loader:last-modified -Ypresentation-any-thread

  last tree to typer: EmptyTree
       tree position: <unknown>
            tree tpe: <notype>
              symbol: null
           call site: <none> in <none>

== Source file context for tree position ==

