package nonscala

import Base.*
import Abssyn.*
import Oper.*

object Eval {

  case class EvalError(s: String) extends Throwable
  def error(s: String) = throw(EvalError(s))

  // 値  
  enum Value:
    case IntVal(i: Int)
    case BoolVal(b: Boolean)
    case ListVal(l: List[Int])
  export Value.*

  // 関数
  case class FValue(xs: List[Var], e: Exp)

  def eval (fenv: Map[Var, FValue], env: Map[Var, Value], e: Exp): Value =
    e match {
      case VarExp(x) => env(x) 
      case IntExp(i) => IntVal(i)
      case NilExp => ListVal(Nil)
      case BOpExp(o, e1, e2) => {
        val v1 = eval (fenv, env, e1)
        val v2 = eval (fenv, env, e2)
        (o, v1, v2) match {
          case (PlusOp, IntVal(i1), IntVal(i2)) => IntVal (i1+i2)
          case (MinusOp, IntVal(i1), IntVal(i2)) => IntVal (i1-i2)
          case (MulOp, IntVal(i1), IntVal(i2)) => IntVal (i1*i2)
          case (DivOp, IntVal(i1), IntVal(i2)) => IntVal (i1/i2)
          case (EqOp, IntVal(i1), IntVal(i2)) => BoolVal (i1 == i2)
          case (LtOp, IntVal(i1), IntVal(i2)) => BoolVal (i1 < i2)
          case (ConsOp, IntVal(i), ListVal(l)) =>ListVal(i::l)
          case _ => error("impossible if the program is well-typed")            
        }
      }
      case UOpExp(o, e1) => {
        val v1 = eval (fenv, env, e1)
        (o, v1) match {
          case (IsEmptyOp, ListVal(Nil)) => BoolVal(true)
          case (IsEmptyOp, ListVal(_::_)) => BoolVal(false)
          case (HeadOp, ListVal(h::t)) => IntVal(h)
          case (HeadOp, ListVal(Nil)) => error("head is applied to Nil")
          case (TailOp, ListVal(h::t)) => ListVal(t)
          case (TailOp, ListVal(Nil)) => error("tail is applied to Nil")
          case _ => error("impossible if the program is well-typed")
        }
      }
      case IfExp(e, e1, e2) =>
        eval(fenv, env, e) match  {
          case BoolVal(b) =>
            if (b) eval(fenv, env, e1) else eval(fenv, env, e2)
          case _ => error("impossible if the program is well-typed")
        } 
/*      case IfExp(e, e1, e2) => {
        val v =  eval(fenv, env, e)
        val v1 = eval(fenv, env, e1)
        val v2 = eval(fenv, env, e2)                 
        v match  {
          case BoolVal(b) =>
            if (b) v1 else v2
          case _ => error("impossible if the program is well-typed")
        }
      } */
      case AppExp(f, es) => {
        val FValue(xs,body) = fenv(f)
        val vs = es.map(e => eval(fenv, env, e))
        eval(fenv, xs.zip(vs).toMap, body)
      }
      case LetExp(x, e1, e2) => {
        val v1 = eval (fenv, env, e1)
        eval(fenv, env + (x -> v1), e2)
      }
    }

  def defs2env (ds: List[Def]): Map[Var, FValue] =
    ds.map(d => (d.name, FValue(d.args.map(_._1), d.body))).toMap
}


