package nonscala

import Base.*
import Abssyn.*
import Oper.*

object Eval {

  case class EvalError(s: String) extends Throwable
  def error(s: String) = throw(EvalError(s))

  // 値  
  enum Value:
    case IntVal(i: Int)
    case BoolVal(b: Boolean)
    case ListVal(l: List[Int])
  export Value.*

  // 関数
  case class FValue(xs: List[Var], e: Exp)


  def eval (fenv: Map[Var, FValue], env: Map[Var, Value], e: Exp): Value =
    e match {
//      case VarExp(x) => 
      case IntExp(i) => IntVal(i)
      case NilExp => ListVal(Nil)
//      case BOpExp(o, e1, e2) => 
      case UOpExp(o, e1) => {
        val v1 = eval (fenv, env, e1)
        (o, v1) match {
          case (IsEmptyOp, ListVal(Nil)) => BoolVal(true)
          case (IsEmptyOp, ListVal(_::_)) => BoolVal(false)
          case (HeadOp, ListVal(h::t)) => IntVal(h)
          case (HeadOp, ListVal(Nil)) => error("head is applied to Nil")
          case (TailOp, ListVal(h::t)) => ListVal(t)
          case (TailOp, ListVal(Nil)) => error("tail is applied to Nil")
          case _ => error("impossible if the program is well-typed")
        }
      }
//      case IfExp(e, e1, e2) =>
      case AppExp(f, es) => {
        val FValue(xs,body) = fenv(f)
        val vs = Nil // Nil を正しいプログラムに置き換える必要がある
                     // map を使うと簡単
        eval(fenv, xs.zip(vs).toMap, body)
      }
      case LetExp(x, e1, e2) => {
        val v1 = eval (fenv, env, e1)
        eval(fenv, env + (x -> v1), e2)
      }
    }

  def defs2env (ds: List[Def]): Map[Var, FValue] =
    ds.map(d => (d.name, FValue(d.args.map(_._1), d.body))).toMap
}


