package nonscala
import Base._
import Abssyn._
import Oper._
import Ty._

import Parser._


object Main {
  def main(args: Array[String]): Unit = {
    if(args.size == 2) {
      val file = args(0)
      val method = args(1)
      val ds = parseFileDefs(file)
      val fenv = Eval.defs2env(ds)
      val v =  Eval.eval(fenv, Map(), AppExp(method, Nil))
      printf("%s\n",v)
    } else {
      printf("Invalid args.\n")
    }
  }
}
