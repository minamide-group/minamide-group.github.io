package nonscala

import org.scalatest._
import flatspec._
import matchers._

import Base._
import Abssyn._
import Oper._
import Eval._
import Parser._


class EvalTest extends AnyFlatSpec with should.Matchers {
  "1" should "be 1" in
  {
    assert(eval(Map(), Map(), IntExp(1))== IntVal(1))
  }
  

  "x under Map(x->1)" should "be 1" in
  {
    assert(eval(Map(), Map("x"->IntVal(1)), VarExp("x"))== IntVal(1))
  }

  "1+x under Map(x->1)" should "be 2" in
  {
    assert(eval(Map(), Map("x"->IntVal(1)),
      BOpExp(PlusOp, IntExp(1), VarExp("x")))== IntVal(2))
  }


  "x.isEmpty under Map(x->Nil)" should "be true" in
  {
    assert(eval(Map(), Map("x"->ListVal(Nil)),
      UOpExp(IsEmptyOp, VarExp("x")))== BoolVal(true))
  }

  "x.isEmpty under Map(x->List(1,2l))" should "be false" in
  {
    assert(eval(Map(), Map("x"->ListVal(List(1,2))),
      UOpExp(IsEmptyOp, VarExp("x")))== BoolVal(false))
  }

  "if (0 == 0) Nil else Nil.head" should "be Nil; then 節のみ評価" in
  {
    assert(eval(Map(), Map(),
      IfExp(BOpExp(EqOp, IntExp(0), IntExp(0)),
        NilExp, UOpExp(HeadOp, NilExp))) == ListVal(Nil))
  }
  

  "f(1,x) under Map(f-> (x,y) => x::y) and Map(x->List(2))" should "be List(1,2)" in
  {
    assert(
      eval(Map("f"->FValue(List("x","y"), BOpExp(ConsOp, VarExp("x"), VarExp("y")))),
        Map("x"->ListVal(List(2))),
        AppExp("f", List(IntExp(1), VarExp("x"))))== ListVal(List(1,2)))
  }

  "例: sort(List(3,2,1))" should "be List(1,2,3)" in
  {
    val ds = parseFileDefs("examples/sort.scala")
    val fenv = defs2env(ds)
    assert(
      eval(fenv, Map("x"->ListVal(List(3,2,1))), AppExp("sort", List(VarExp("x")))) == ListVal(List(1,2,3)))

  }

  "例: qsort(List(3,2,1,3,5,3,1,4))" should "be List(1,1,2,3,3,3,4,5)" in
  {
    val ds = parseFileDefs("examples/qsort.scala")
    val fenv = defs2env(ds)
    assert(
      eval(fenv, Map("x"->ListVal(List(3,2,1,3,5,3,1,4))), AppExp("qsort", List(VarExp("x")))) == ListVal(List(1,1,2,3,3,3,4,5)))

  }

  "例: primes(20)" should "be List(2,3,5,7,11,13,17,19)" in
  {
    val ds = parseFileDefs("examples/primes.scala")
    val fenv = defs2env(ds)
    assert(
      eval(fenv, Map(), AppExp("primes", List(IntExp(20)))) ==
        ListVal(List(2,3,5,7,11,13,17,19)))

  }

  behavior of "自作のテスト"

  /* テストを追加する場合は，この下に追加してください．*/  

}
