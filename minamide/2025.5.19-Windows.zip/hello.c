#include<stdio.h>

int main() {
  printf("Hello!\n");
  printf("My name is Yasuhiko Minamide.\n");    
}  
