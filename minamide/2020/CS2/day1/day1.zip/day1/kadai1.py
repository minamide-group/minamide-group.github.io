#####################
# 課題１
#####################


# サブルーチン writeX(a)
# 働き：文字 X をa個横に並べて書いて改行する

def writeX(a):
    for i in range(a):
        print("X", end="")
    print()

# writeX の定義ここまで

# サブルーチン figure(n)

def figure(n):
  if n == 1:
      writeX(1)
  elif n == 2:
      writeX(2)
  else:
      figure(n - 1)
      figure(n - 2)
      writeX(n)

# figure の定義ここまで

# 以下本文
i = int(input())
figure(i)
