# 階乗の再帰的な定義
def kaijou(n):
    if n <= 1:
        return 1
    else:
        return n*kaijou(n-1)

# ここからプログラム本体
x = int(input())
print(kaijou(x))
