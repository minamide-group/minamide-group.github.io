def fib(n):
    global calls
    calls = calls + 1
    if n == 0:
        return 0
    elif n == 1:
        return 1
    else:
        return fib(n-2)+fib(n-1)

n = int(input())
calls = 0
print(fib(n))
print(calls)
    



