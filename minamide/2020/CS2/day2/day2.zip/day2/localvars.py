def test(a):
    a = 100
    b = 200
    print(a, b)

a = 1
b = 2
test(a)
print(a, b)
