def rev(a):
    r = []             # 空の配列
    i = len(a) - 1
    while i >= 0:
        r.append(a[i])
        i = i - 1
    return r

