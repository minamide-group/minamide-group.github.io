def quick_sort(a):
    if len(a) <= 1:
        return a
    else:
        b = []
        c = []
        for i in range(1, len(a)):   # 配列aをa[0]で分割
            if a[i] < a[0]:
                b.append(a[i])
            else:
                c.append(a[i])
        return quick_sort(b)+[a[0]]+quick_sort(c)
