# 配列a のi番目とj番目の要素を交換
def swap(a, i, j):
    tmp = a[i]
    a[i] = a[j]
    a[j] = tmp
    return a

# 配列a をバブルソートで整列
def bubble_sort(a):
    k = len(a)
    while k > 1:
        for i in range(k-1):
            if a[i] > a[i+1]:
                swap(a, i, i+1)
        k = k - 1
    return a
