# 配列a のi番目とj番目の要素を交換
def swap(a, i, j):
    tmp = a[i]
    a[i] = a[j]
    a[j] = tmp
    return a

# a[k] 〜 a[n-1] の最小値のインデックスを返す
# ただし，n = len(a)
def find_min(a, k):
    min = a[k]
    index = k
    for i in range(k+1, len(a)):
        # ここを埋める
    return index

# 配列aを選択ソートで整列する
def selection_sort(a):
    for k in range(0, len(a)-1):
        # ここを埋める
    return a

