# hindo.py
# 入力: 非負整数 m と 整数配列 a
# 出力: 0 〜 m-1 が配列に現れる頻度 

print("非負整数を入力して下さい")
m = int(input())

print("0 から n-1 の整数配列を入力して下さい")
a = list(map(int, input().split()))
n =len(a)

hindo = [0] * m  # 整数 0 で初期化された大きさ m の配列

for i in range(n):
    hindo[a[i]] = hindo[a[i]] + 1

for j in range(m):
    print(j, ": ", hindo[j], "個")
    
    



