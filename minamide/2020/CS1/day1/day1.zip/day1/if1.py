# if1.py
# 入力: 整数 a, b

a = int(input())      # 入力された整数を a に代入
b = int(input())      # 入力された整数を b に代入
if a == b:
    print("A")
else:
    print("B")
    print("C")
    
