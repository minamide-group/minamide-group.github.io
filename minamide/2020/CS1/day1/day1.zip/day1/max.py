# max.py
# 入力: 整数 a, b
# 出力: a と b の最大値

a = int(input())      # 入力された整数を a に代入
b = int(input())      # 入力された整数を b に代入
if a > b:
    max = a
else:
    max = b
print(max)             
