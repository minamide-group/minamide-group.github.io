# abcPrint.py
# 文字列処理の練習プログラム，小文字だけ出力
# 入力: 文字列
# 出力: 文字列の文字で小文字のみ出力する

print("文字列を入力しよう")
ss = input()             # 入力文字列を ss に格納
leng = len(ss)           # 文字列の長さを変数 leng に格納
for i in range(leng):
    if ???:
        print(ss[i])
