def merge(a, b)
  alen = a.length
  blen = b.length
  c = []
  i = 0
  j = 0
  while i < alen && j < blen
    if a[i] <= b[j]
      c.push(a[i])
      i = i + 1
    else
      c.push(b[j])
      j = j + 1
    end
  end
  while i < alen
    c.push(a[i])
    i = i + 1
  end
  while j < blen
    c.push(b[j])
    j = j + 1
  end
  return c
end

def merge_sort(a)
  len = a.length
  if len <= 1
    return a
  else
    return merge(merge_sort(a[0,len/2]),
                 merge_sort(a[len/2,len - len/2]))
  end
end
