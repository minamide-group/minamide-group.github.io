# coding: utf-8

def rev(a)
  r = []             # 空の配列
  i = a.length - 1
  while i >= 0
    r.push(a[i])
    i = i - 1
  end
  return r
end    
