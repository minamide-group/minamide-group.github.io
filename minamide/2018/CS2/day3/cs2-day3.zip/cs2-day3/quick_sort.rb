# coding: utf-8
def qsort(a)
  if a.length <= 1
    return a
  else
    b = []
    c = []
    for i in 1..a.length-1    # 配列aをa[0]で分割
      if a[i] < a[0]
        b.push(a[i])
      else
        c.push(a[i])
      end
    end
    return quick_sort(b)+[a[0]]+quick_sort(c)
  end
end
