# coding: utf-8

$ncomp = 0

# a[0] 〜 a[k-2] が整列済み，a[k-1] を挿入
def insert(a, k)
  tmp = a[k-1]
  i = k-2
  stop = 0
  while i >=0 && stop == 0 
    $ncomp = $ncomp + 1
    if a[i] > tmp
      a[i+1] = a[i]
      i = i - 1
    else
      stop = 1
    end
  end
  a[i+1] = tmp
  return a
end


# 配列aを挿入ソートで整列する
def insertion_sort(a)
  for k in 1..a.length
    insert(a, k)
  end
  return a
end

# 引数：配列[n_0, n_1, ... ,n_(k-1)]
# 挿入ソートを大きさ n_i 配列に対してテストする
def test_insertion_inc(test_array)
  puts("挿入ソート: 正順")
  k = test_array.length
  for i in 0..k-1
    n = test_array[i]
    a = increasing_array(n)    
    $ncomp = 0 
    start_time = Time.now
    b = insertion_sort(a)
    puts "大きさ #{n}"
    puts "実行時間 #{Time.now - start_time}秒"
    puts "比較回数 #{$ncomp}"    
    sorted(b)
  end
  return
end

def test_insertion_dec(test_array)
  puts("挿入ソート: 逆順")  
  k = test_array.length
  for i in 0..k-1
    n = test_array[i]
    a = decreasing_array(n)    
    $ncomp = 0 
    start_time = Time.now
    b = insertion_sort(a)
    puts "大きさ #{n}"
    puts "実行時間 #{Time.now - start_time}秒"
    puts "比較回数 #{$ncomp}"    
    sorted(b)
  end
  return
end

def test_insertion_random(test_array)
  puts("挿入ソート: 乱数列")  
  k = test_array.length
  for i in 0..k-1
    n = test_array[i]
    a = random_array(n)
    $ncomp = 0 
    start_time = Time.now
    b = insertion_sort(a)
    puts "大きさ #{n}"
    puts "実行時間 #{Time.now - start_time}秒"
    puts "比較回数 #{$ncomp}"    
    sorted(b)
  end
  return
end


