# coding: utf-8

# 大きさnの正順（昇順）に整列された配列
def increasing_array(n)
  a = Array.new(n)
  for i in 0..n-1
    a[i] = i
  end
  return a
end

# 大きさnの逆順（降順）に整列された配列
def decreasing_array(n)
  a = Array.new(n)
  for i in 0..n-1
    a[i] = (n-1)-i
  end
  return a
end

# 大きさnの乱数列の配列
def random_array(n)
  a = Array.new(n)
  for i in 0..n-1
    a[i] = rand(n)
  end
  return a
end

# 整列できているかの判定
def sorted(a)
  for i in 0..a.length-2
    if a[i] > a[i+1]
      puts("整列できていません")
      return
    end
  end
end
