# coding: utf-8

$ncomp = 0

# 配列a のi番目とj番目の要素を交換
def swap(a, i, j)
  tmp = a[i]
  a[i] = a[j]
  a[j] = tmp
  return a
end

# a[0] 〜 a[k-1] にバブル手続きを行う
def bubble(a, k)
  for i in 0..(k-2)
    $ncomp = $ncomp + 1
    if a[i] > a[i+1]
      swap(a, i, i+1)
    end
  end
  return a  
end

# 配列a をバブルソートで整列
def bubble_sort(a)
  k = a.length
  while (k > 1)
    bubble(a, k)
    k = k - 1
  end
  return a
end

# 引数：配列[n_0, n_1, ... ,n_(k-1)]
# バブルソートを大きさ n_i 配列に対してテストする
def test_bubble_inc(test_array)
  puts("バブルソート: 正順")
  k = test_array.length
  for i in 0..k-1
    n = test_array[i]
    a = increasing_array(n)   
    $ncomp = 0 
    start_time = Time.now
    b = bubble_sort(a)
    puts "大きさ #{n}"
    puts "実行時間 #{Time.now - start_time}秒"
    puts "比較回数 #{$ncomp}"    
    sorted(b)
  end
  return
end


def test_bubble_dec(test_array)
  puts("バブルソート: 逆順")
  k = test_array.length
  for i in 0..k-1
    n = test_array[i]
    a = decreasing_array(n)    
    $ncomp = 0 
    start_time = Time.now
    b = bubble_sort(a)
    puts "大きさ #{n}"
    puts "実行時間 #{Time.now - start_time}秒"
    puts "比較回数 #{$ncomp}"    
    sorted(b)
  end
  return
end

def test_bubble_random(test_array)
  puts("バブルソート: 乱数列")
  k = test_array.length
  for i in 0..k-1
    n = test_array[i]
    a = random_array(n)
    $ncomp = 0 
    start_time = Time.now
    b = bubble_sort(a)
    puts "大きさ #{n}"
    puts "実行時間 #{Time.now - start_time}秒"
    puts "比較回数 #{$ncomp}"    
    sorted(b)
  end
  return
end


