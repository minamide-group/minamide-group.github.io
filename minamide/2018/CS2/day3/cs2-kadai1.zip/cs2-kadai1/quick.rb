# coding: utf-8

$ncomp = 0

def quick_sort(a)
  if a.length <= 1
    return a
  else
    b = []
    c = []
    for i in 1..a.length-1    # 配列aをa[0]で分割
      $ncomp = $ncomp + 1
      if a[i] < a[0]
        b.push(a[i])
      else
        c.push(a[i])
      end
    end
    return quick_sort(b)+[a[0]]+quick_sort(c)
  end
end

# 引数：配列[n_0, n_1, ... ,n_(k-1)]
# クイックソートを大きさ n_i 配列に対してテストする
def test_quick_inc(test_array)
  puts "クイックソート: 正順"
  k = test_array.length
  for i in 0..k-1
    n = test_array[i]
    a = increasing_array(n)
    $ncomp = 0 
    start_time = Time.now
    b = quick_sort(a)
    puts "大きさ #{n}"
    puts "実行時間 #{Time.now - start_time}秒"
    puts "比較回数 #{$ncomp}"    
    sorted(b)
  end
  return
end

def test_quick_dec(test_array)
  puts "クイックソート: 逆順"
  k = test_array.length
  for i in 0..k-1
    n = test_array[i]
    a = decreasing_array(n)        
    $ncomp = 0 
    start_time = Time.now
    b = quick_sort(a)
    puts "大きさ #{n}"
    puts "実行時間 #{Time.now - start_time}秒"
    puts "比較回数 #{$ncomp}"    
    sorted(b)
  end
  return
end

def test_quick_random(test_array)
  puts "クイックソート: 乱数列"
  k = test_array.length
  for i in 0..k-1
    n = test_array[i]
    a = random_array(n)
    $ncomp = 0 
    start_time = Time.now
    b = quick_sort(a)
    puts "大きさ #{n}"
    puts "実行時間 #{Time.now - start_time}秒"
    puts "比較回数 #{$ncomp}"    
    sorted(b)
  end
  return
end




