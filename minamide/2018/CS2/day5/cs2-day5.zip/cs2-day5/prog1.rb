# coding: utf-8
################
## プログラム１ ##
################

x = 2.0
i = 1
while (x > (x-1))
  x = x * 2
  i = i + 1;
  print("(2.0)^", i, " - 1.0 = ", sprintf("%.2f", x-1.0), "\n")
  print("(2.0)^", i, "       = ", sprintf("%.2f", x), "\n")
  print("(2.0)^", i, " + 1.0 = ",  sprintf("%.2f", x+1.0), "\n")
  print("(2.0)^", i, " + 1.5 = ",  sprintf("%.2f", x+1.5), "\n")
  print("(2.0)^", i, " + 2.0 = ",  sprintf("%.2f", x+2.0), "\n")
  print("\n")
end
