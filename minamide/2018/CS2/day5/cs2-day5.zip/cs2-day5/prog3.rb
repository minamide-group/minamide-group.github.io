################
## プログラム３ ##
################


# サブルーチン
# t(n) = 1/(2^n) (ただし n は0以上）

def t(n)
  a = 1
  for i in 1..n   # nが0のときには何もしない
    a = a * 2
  end
  return(1.0/a)
end

# サブルーチン
# g(n) = t(0) + t(1) + ... + t(n)

def g(n)
  a = 0.0
  for i in 0..n
    a = a + t(i)
  end
  return a
end

### 以下本文 ###

n = 1
while g(n-1)!=g(n)
  print("g(", n, ")= ", sprintf("%.60f", g(n)), "\n")  
  n = n + 1
end
print("g(", n, ")= ", sprintf("%.60f", g(n)), "\n")  

