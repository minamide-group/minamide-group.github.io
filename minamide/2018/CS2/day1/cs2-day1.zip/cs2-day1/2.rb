
# サブルーチン writeX(a) # 働き：文字 X をa個横に並べて書いて改行する

def writeX(a)
  for i in 1..a
    print("X")
  end
  print("\n")
end

# writeX の定義ここまで

# ここからプログラム本体

n = gets().to_i
writeX(n)

