#####################
# 練習問題：このプログラムの出力結果を、コンピュータで実行するのではなく机上で考えよ。
#####################


# サブルーチン writeX(a) # 働き：文字 X をa個横に並べて書いて改行する

def writeX(a)
  for i in 1..a
    print("X")
  end
  print("\n")
end

# writeX の定義ここまで

# サブルーチン test(n)

def test(n)
  if n == 1
    writeX(1)
  end
  if n == 2
    writeX(2)
  end
  if n > 2
    test(n - 1)
    test(n - 2)
    writeX(n)
  end
end

# test の定義ここまで

# 以下本文
test(5)
