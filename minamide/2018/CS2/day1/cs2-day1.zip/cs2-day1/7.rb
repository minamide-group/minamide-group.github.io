
# サブルーチン writeX(a) # 働き：文字 X をa個横に並べて書いて改行する

def writeX(a)
  for i in 1..a
    print("X")
  end
  print("\n")
end

# writeX の定義ここまで

# サブルーチン figure(n)
# 働き：大きさnの三角形を文字 X で描く

def figure(n)
  if n >= 2
    figure(n-1)
  end
  writeX(n)
end

# figure の定義ここまで

# ここからプログラム本体

n = gets().to_i
figure(n)
