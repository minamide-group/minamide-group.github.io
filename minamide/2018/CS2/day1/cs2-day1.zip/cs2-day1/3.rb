
def test(a)
  a = 100
  b = 200
  puts(a, b)
end

a = 1
b = 2
test(a)
puts(a, b)
