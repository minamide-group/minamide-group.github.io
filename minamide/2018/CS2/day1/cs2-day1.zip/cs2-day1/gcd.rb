# coding: utf-8
# 関数 gcd(m,n)（mとn の最大公約数)
# ただし，m >= n

def gcd(m,n)
  $calls = $calls + 1
  if n == 0
    m
  else
    return gcd(n, m % n)
  end
end

m = gets().to_i
n = gets().to_i
$calls = 0
puts(gcd(m,n))
puts($calls)
