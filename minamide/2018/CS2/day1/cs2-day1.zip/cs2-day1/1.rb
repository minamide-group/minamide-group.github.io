
# 関数 kaijou(n)（n の階乗）

def kaijou(n)
  ans = 1
  for i in 1..n
    ans = ans * i
  end
  return(ans)
end

# kaijou の定義ここまで

# ここからプログラム本体

x = gets().to_i
puts(kaijou(x))

