# coding: utf-8
# 関数 exp(n,k) == n ** k (in ruby)

def exp(n,k)
  if k == 0
    return 1
  else
     # この部分を埋める if 文 と 剰余 % を使う

  end
end

# ここからプログラム本体

n = gets().to_i
k = gets().to_i

puts(exp(n,k))
