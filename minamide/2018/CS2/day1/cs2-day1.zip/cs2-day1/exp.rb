# coding: utf-8
# 関数 exp(n,k) == n ** k (in ruby)

def exp(n,k)
  if k == 0
    return 1
  else
    if k % 2 == 0
      return           # ここに式を埋める
    else
      return           # ここに式を埋める
    end
  end
end

# ここからプログラム本体

n = gets().to_i
k = gets().to_i

puts(exp(n,k))
