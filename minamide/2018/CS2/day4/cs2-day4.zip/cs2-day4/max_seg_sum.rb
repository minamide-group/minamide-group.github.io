# coding: utf-8

# 大きさnの乱数列の配列
# -n <= 要素 < n-1
def random_array(n)
  a = Array.new(n)
  for i in 0..n-1
    a[i] = rand(2*n) - n
  end
  return a
end

# 部分和: a[i] + ... + a[j]
def sum(a,i,j)
  n = a.length
  r = 0
  for k in i..j
    r = r + a[k]
  end
  return r
end

# 最大値：a[0], ...,  a[n-1]
def array_max(a)
  n = a.length
  r = a[0]
  for k in 1..n-1
    if (a[k] > r)
      r = a[k]
    end
  end
  return r
end

# 最大部分和
def max_seg_sum(a)
  n = a.length
  max = 0
  for i in 0..n-1
    for j in 0..n-1
      s = sum(a,i,j)     # a[i] + ... + a[j]
      if s > max then
        max = s
      end
    end
  end
  return max
end

# 動的計画法：最大部分和
def max_seg_sum2(a)
  n = a.length
  b = Array.new(n+1)  
  b[0] = 0
  for j in 0..n-1
    # この部分を埋める
  end
  return array_max(b)
end

# 動的計画法：最大部分和
def max_seg_sum3(a)
  n = a.length
  max = 0
  bj = 0
  for j in 0..n-1
    # この部分を埋める
  end
  return max
end

  
