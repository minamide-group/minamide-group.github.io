# coding: utf-8

$ncomp = 0

def qsort(a, left, right)
  if left < right 
    pivot = a[left]
    p = left
    for i in (left+1)..right
      $ncomp = $ncomp + 1
      if pivot > a[i]
        a[p] = a[i]
        a[i] = a[p+1]
        p = p+1
      end
    end
    a[p] = pivot

    qsort(a, left, p-1)
    qsort(a, p+1, right)
  end
end


def quick_sort(a)
  qsort(a,0,a.length - 1)
  return a
end

# 引数：配列[n_0, n_1, ... ,n_(k-1)]
# クイックソートを大きさ n_i 配列に対してテストする
def test_quick_inc(test_array)
  puts "クイックソート: 正順"
  k = test_array.length
  for i in 0..k-1
    n = test_array[i]
    a = increasing_array(n)
    $ncomp = 0 
    start_time = Time.now
    b = quick_sort(a)
    puts "大きさ #{n}"
    puts "実行時間 #{Time.now - start_time}秒"
    puts "比較回数 #{$ncomp}"    
    sorted(b)
  end
  return
end

def test_quick_dec(test_array)
  puts "クイックソート: 逆順"
  k = test_array.length
  for i in 0..k-1
    n = test_array[i]
    a = decreasing_array(n)        
    $ncomp = 0 
    start_time = Time.now
    b = quick_sort(a)
    puts "大きさ #{n}"
    puts "実行時間 #{Time.now - start_time}秒"
    puts "比較回数 #{$ncomp}"    
    sorted(b)
  end
  return
end

def test_quick_random(test_array)
  puts "クイックソート: 乱数列"
  k = test_array.length
  for i in 0..k-1
    n = test_array[i]
    a = random_array(n)
    $ncomp = 0 
    start_time = Time.now
    b = quick_sort(a)
    puts "大きさ #{n}"
    puts "実行時間 #{Time.now - start_time}秒"
    puts "比較回数 #{$ncomp}"    
    sorted(b)
  end
  return
end




