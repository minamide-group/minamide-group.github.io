# coding: utf-8

$ncomp = 0

def merge(a, b)
  alen = a.length
  blen = b.length
  c = []
  i = 0
  j = 0
  while i < alen && j < blen
    $ncomp = $ncomp + 1
    if a[i] <= b[j]
      c.push(a[i])
      i = i + 1
    else
      c.push(b[j])
      j = j + 1
    end
  end
  while i < alen
    c.push(a[i])
    i = i + 1
  end
  while j < blen
    c.push(b[j])
    j = j + 1
  end
  return c
end

def merge_sort(a)
  len = a.length
  if len <= 1
    return a
  else
    return merge(merge_sort(a[0,len/2]),
                 merge_sort(a[len/2,len - len/2]))
  end
end

# 引数：配列[n_0, n_1, ... ,n_(k-1)]
# マージソートを大きさ n_i 配列に対してテストする
def test_merge_inc(test_array)
  puts "マージソート: 正順"
  k = test_array.length
  for i in 0..k-1
    n = test_array[i]
    a = increasing_array(n)
    $ncomp = 0 
    start_time = Time.now
    b = merge_sort(a)
    puts "大きさ #{n}"
    puts "実行時間 #{Time.now - start_time}秒"
    puts "比較回数 #{$ncomp}"    
    sorted(b)
  end
  return
end

def test_merge_dec(test_array)
  puts "マージソート: 逆順"
  k = test_array.length
  for i in 0..k-1
    n = test_array[i]
    a = decreasing_array(n)    
    $ncomp = 0 
    start_time = Time.now
    b = merge_sort(a)
    puts "大きさ #{n}"
    puts "実行時間 #{Time.now - start_time}秒"
    puts "比較回数 #{$ncomp}"    
    sorted(b)
  end
  return
end

def test_merge_random(test_array)
  puts "マージソート: 乱数列"
  k = test_array.length
  for i in 0..k-1
    n = test_array[i]
    a = random_array(n)
    $ncomp = 0 
    start_time = Time.now
    b = merge_sort(a)
    puts "大きさ #{n}"
    puts "実行時間 #{Time.now - start_time}秒"
    puts "比較回数 #{$ncomp}"    
    sorted(b)
  end
  return
end

