# coding: utf-8

# 配列a のi番目とj番目の要素を交換
def swap (a, i, j)
  tmp = a[i]
  a[i] = a[j]
  a[j] = tmp
  return a
end

# a[0] 〜 a[k-1] にバブル手続きを行う
def bubble(a, k)
  for i in 0..(k-2)
    if a[i] > a[i+1]
      swap(a, i, i+1)
    end
  end
  return a  
end

# 配列a をバブルソートで整列
def bubble_sort(a)
  k = a.length
  while (k > 1)
    bubble(a, k)
    k = k - 1
  end
  return a
end

    
