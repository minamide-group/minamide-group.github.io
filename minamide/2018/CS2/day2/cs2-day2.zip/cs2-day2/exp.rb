# coding: utf-8

def exp1(n,k)
  r = 1
  for i in 1..k
    r = n * r 
  end
  return r
end


def exp2(n,k)
  if k == 0
    return 1
  else
    if k % 2 == 0
      exp2(n*n, k/2)
    else
      n * exp2(n*n, k/2)
    end
  end
end

