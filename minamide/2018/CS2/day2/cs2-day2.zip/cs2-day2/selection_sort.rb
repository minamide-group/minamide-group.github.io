# coding: utf-8

# 配列a のi番目とj番目の要素を交換
def swap (a, i, j)
  tmp = a[i]
  a[i] = a[j]
  a[j] = tmp
  return a
end

# a[k] 〜 a[n-1] の最小値のインデックスを返す
# ただし，n = a.length
def find_min(a, k)
  min = a[k]
  index = k
  for i in k+1..a.length-1
    # ここを埋める
  end
  return index
end

# 配列aを選択ソートで整列する
def selection_sort(a)
  for k in 0..a.length-2
    # ここを埋める
  end
  return a
end
