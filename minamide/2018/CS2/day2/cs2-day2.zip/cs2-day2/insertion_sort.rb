# coding: utf-8


# a[0] 〜 a[k-2] が整列済み，a[k-1] を挿入
def insert(a, k)
  tmp = a[k-1]
  i = k-2
  while i >=0 && a[i] > tmp
    a[i+1] = a[i]
    i = i - 1
  end
  a[i+1] = tmp
  return a
end


# 配列aを挿入ソートで整列する
def insertion_sort(a)
  for k in 1..a.length
    insert(a, k)
  end
  return a
end
