# div.rb
# 入力: 自然数 x, y
# 出力: x ÷ y の商と余り

x = gets().to_i       # 入力された自然数を x に代入
y = gets().to_i       # 入力された自然数を y に代入
shou = 
amari = 
while 
  shou = 
  amari = amari - y
end
puts(shou)            # shou の値を出力
puts(amari)           # amari の値を出力

