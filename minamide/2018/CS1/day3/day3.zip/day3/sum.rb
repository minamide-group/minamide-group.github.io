# coding: utf-8
# sum.rb
# 入力: 整数の総和
# 出力: 最大値

a = gets().split.map(&:to_i)
n = a.length
# 以下が総和の計算部分
s = 0
for  k in 0..(n-1)
   s = s + a[ k ]
end
puts(s)

