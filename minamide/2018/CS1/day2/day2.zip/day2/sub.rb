# sub.rb
# 入力: 自然数 a, b
# 出力: a - b

a = gets().to_i       # 入力された自然数を x に代入
b = gets().to_i       # 入力された自然数を y に代入
sa = a                # x の値を sa に代入
while 
  sa = 
  b = 
end                   # 繰り返しの終わり
puts(sa)              # sa の値を出力
