# coding: utf-8
# maxmin3.rb
# 入力: 自然数 x, y, z
# 出力: x, y, z の最大値，最小値

x = gets().to_i       # 入力された自然数を x に代入
y = gets().to_i       # 入力された自然数を y に代入
z = gets().to_i       # 入力された自然数を z に代入
if x >= y
  max = x
  min = y
else
  min = x
  max = y
end
                      # ここにプログラムを書く

puts(max)             # 最大値を出力
puts(min)             # 最小値を出力
