# coding: utf-8
# maxmin.rb
# 入力: 自然数 x, y
# 出力: x と y の最大値と最小値

x = gets().to_i       # 入力された自然数を x に代入
y = gets().to_i       # 入力された自然数を y に代入
if x >= y
  max = x
  min = y
else
  min = x
  max = y
end                   
puts(max)             # 最大値を出力
puts(min)             # 最小値を出力
