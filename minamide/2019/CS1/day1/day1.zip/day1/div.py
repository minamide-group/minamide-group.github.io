# div.py
# 入力: 自然数 x, y
# 出力: x ÷ y の商と余り

x = int(input())      # 入力された自然数を x に代入
y = int(input())      # 入力された自然数を y に代入
shou = ...
amari = ... 
while ???:
    shou = ...
    amari = amari - y
print(shou)            # shou の値を出力
print(amari)           # amari の値を出力
