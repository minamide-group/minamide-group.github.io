# average.py
# 入力: 整数の列
# 出力: 平均（切り捨て）

# 配列の要素の総和を計算する関数
def sum(a):
    n = len(a)
    # 以下が総和の計算部分
    return s

a = list(map(int, input().split()))
print(sum(a) // len(a))
