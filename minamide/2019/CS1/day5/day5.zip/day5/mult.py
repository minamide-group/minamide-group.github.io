# mult.py

def mult(x, y):
    seki = 0              
    while y > 0:          
        seki = seki + x     
        y = y - 1           
    return seki
