# code2string.py
# 入力: 整数の列
# 出力: 各整数を文字に変換した文字列

a = list(map(int, input().split())) # 整数の列を配列 a に入力
s = ""
n = len(a)
for i in range(n):
    s = s + chr(a[i]) # i 番目の整数を文字に変換し文字列sの最後に連結
print(s)    
