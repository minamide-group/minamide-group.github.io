# loop.py
# 止まらない

while True:         # 無限ループ
    pass            # 何もしない文      
print("Stopped!")
