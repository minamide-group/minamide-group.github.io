# sub.py
# 入力: 自然数 a, b
# 出力: a - b

a = int(input())      # 入力された自然数を a に代入
b = int(input())      # 入力された自然数を b に代入
sa = a                # x の値を sa に代入
while ???:
    sa = ...
    b =  ...
print(sa)              # sa の値を出力
