# max.py
# 入力: 整数の列
# 出力: 最大値

a = list(map(int, input().split()))
n = len(a)

max = -100000      # マイナス無限大と言える数
maxj = -1          # 最大値のインデックス
for j in range(n):
    if ???: 
        max = 
        maxj = 
print(max)
print(maxj)
