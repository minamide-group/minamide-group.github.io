def exp1(n,k):
    r = 1
    for i in range(k):
        r = n * r 
    return r

def exp2(n,k):
    if k == 0:
        return 1
    elif k % 2 == 0:
        return exp2(n * n, k // 2)
    else:
        return n * exp2(n * n, k // 2)

