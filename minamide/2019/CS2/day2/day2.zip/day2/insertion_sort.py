# a[0] 〜 a[k-1] が整列済み，a[k] を挿入
def insert(a, k):
    tmp = a[k]
    i = k-1
    while i >=0 and a[i] > tmp:
        a[i+1] = a[i]
        i = i - 1
    a[i+1] = tmp
    return a


# 配列aを挿入ソートで整列する
def insertion_sort(a):
    for k in range(1, len(a)):
        insert(a, k)
    return a

