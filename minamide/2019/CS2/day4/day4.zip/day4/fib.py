# フィボナッチ数
def fib(n):
    if n == 0:
        return 0
    elif n == 1:
        return 1
    else:
        return fib(n-1) + fib(n-2)


# フィボナッチ数：動的計画法
def fib2(n):
    a = [0] * (n+1)  # a[i] = fib(i)
    a[0] = 0
    a[1] = 1
    for i in range(2,n+1):
        a[i] = a[i-1] + a[i-2]
    return a[n]

# フィボナッチ数：動的計画法
def fib3(n):
    k = 0 
    f = 0         # f = fib(k)
    g = 1         # g = fib(k+1)
    while k < n:
        f, g = g, f + g
        k = k + 1
    return f


