import random

# 大きさnの乱数列の配列
# -n <= 要素 < n-1
def random_array(n):
    a = [0] * n
    for i in range(n):
        a[i] = random.randrange(2*n) - n
    return a

# 部分和: a[i] + ... + a[j]
def sum(a,i,j):
    r = 0
    for k in range(i,j+1):
        r = r + a[k]
    return r

# 最大値：a[0], ...,  a[n-1]
def array_max(a):
    n = len(a)
    r = a[0]
    for k in range(1,n):
        if a[k] > r:
            r = a[k]
    return r

# 最大部分和
def max_seg_sum(a):
    n = len(a)
    max = 0
    for i in range(n):
        for j in range(n):
            s = sum(a,i,j)     # a[i] + ... + a[j]
            if s > max:
                max = s
    return max

# 動的計画法：最大部分和
def max_seg_sum2(a):
    n = len(a)
    b = [0] * (n+1)  
    b[0] = 0
    for j in range(n):
        # この部分を埋める
    return array_max(b)


# 動的計画法：最大部分和
def max_seg_sum3(a):
    n = len(a)
    max = 0
    bj = 0
    for j in range(n):
        # この部分を埋める
    return max

  
