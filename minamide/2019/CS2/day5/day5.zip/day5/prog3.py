################
## プログラム３ ##
################


# サブルーチン
# t(n) = 1/(2^n) (ただし n は0以上）

def t(n):
    a = 1
    for i in range(1,n+1):   # nが0のときには何もしない
        a = a * 2
    return(1.0/a)


# サブルーチン
# g(n) = t(0) + t(1) + ... + t(n)

def g(n):
    a = 0.0
    for i in range(n+1):
        a = a + t(i)
    return a

### 以下本文 ###

n = 1
while g(n-1) != g(n):
    print(f"g({n})= {g(n): .60f}")  
    n = n + 1
print(f"g({n})= {g(n): .60f}")  


