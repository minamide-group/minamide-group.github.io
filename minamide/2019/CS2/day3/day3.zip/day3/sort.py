import time
import random

# 大きさnの正順（昇順）に整列された配列
def increasing_array(n):
    a = [0] * n
    for i in range(n):
        a[i] = i
    return a

# 大きさnの逆順（降順）に整列された配列
def decreasing_array(n):
    a = [0] * n
    for i in range(n):
        a[i] = (n-1)-i
    return a

# 大きさnの乱数列（ 0 から n - 1 )の配列
def random_array(n):
    a = [0] * n
    for i in range(n):
        a[i] = random.randrange(n)
    return a

# 整列できているかの判定
def sorted(a):
    for i in range(len(a)-1):
        if a[i] > a[i+1]:
            print("整列できていません")
            return


# グローバル変数：比較回数の記録
ncomp = 0

# 整列関数 sortf を mkarray(n) によってできる配列に対してテストする．
def test_sort(sortf, mkarray, n):
    global ncomp
    ncomp = 0               # 比較回数をリセット
    a = mkarray(n)   
    start_time = time.time()
    b = sortf(a)
    print(f"長さ {n}")
    print(f"実行時間 {time.time() - start_time:.4f}秒")
    print(f"比較回数 {ncomp} 回")    
    sorted(b)               # 整列できているか確認
    
# 配列a のi番目とj番目の要素を交換
def swap(a, i, j):
    tmp = a[i]
    a[i] = a[j]
    a[j] = tmp
    return a

# バブルソート

# a[0] 〜 a[k-1] にバブル手続きを行う
def bubble(a, k):
    global ncomp
    for i in range(k-1):
        ncomp = ncomp + 1
        if a[i] > a[i+1]:
            swap(a, i, i+1)
    return a  

# 配列a をバブルソートで整列
def bubble_sort(a):
    k = len(a)
    while k > 1:
        bubble(a, k)
        k = k - 1
    return a

# 挿入ソート

# a[0] 〜 a[k-1] が整列済み，a[k] を挿入
def insert(a, k):
    global ncomp
    tmp = a[k]
    i = k-1
    stop = False
    while i >=0 and not stop:
        ncomp = ncomp + 1
        if a[i] > tmp:
            a[i+1] = a[i]
            i = i - 1
        else:
            stop = True
    a[i+1] = tmp
    return a


# 配列aを挿入ソートで整列する
def insertion_sort(a):
    for k in range(1, len(a)):
        insert(a, k)
    return a

# マージソート

def merge(a, b):
    global ncomp
    alen = len(a)
    blen = len(b)
    c = []
    i = 0
    j = 0
    while i < alen and j < blen:
        ncomp = ncomp + 1
        if a[i] <= b[j]:
            c.append(a[i])
            i = i + 1
        else:
            c.append(b[j])
            j = j + 1
    while i < alen:
        c.append(a[i])
        i = i + 1
    while j < blen:
        c.append(b[j])
        j = j + 1
    return c

def merge_sort(a):
    alen = len(a)
    if alen <= 1:
        return a
    else:
        return merge(merge_sort(a[0 : alen//2]),
                     merge_sort(a[alen//2 : alen]))

# クイックソート
    
def quick_sort(a):
    global ncomp
    if len(a) <= 1:
        return a
    else:
        b = []
        c = []
        for i in range(1, len(a)):   # 配列aをa[0]で分割
            ncomp = ncomp + 1
            if a[i] < a[0]:
                b.append(a[i])
            else:
                c.append(a[i])
        return quick_sort(b)+[a[0]]+quick_sort(c)


# 整列関数 sortf を mkarray(n) によってできる配列に対してテストする．
# CSV 形式（カンマ区切り）で出力する．
def test_sort_csv(sortf, mkarray, n):
    global ncomp
    ncomp = 0               # 比較回数をリセット
    a = mkarray(n)   
    start_time = time.time()
    b = sortf(a)
    print(f"{n},{ncomp},{time.time() - start_time:.4f}")
    sorted(b)               # 整列できているか確認

# バブルソートを昇順配列に対してテストする関数の雛形
def test_bubble_increasing():
    test_sort_csv(bubble_sort, increasing_array, 100)
    test_sort_csv(bubble_sort, increasing_array, 200)
    test_sort_csv(bubble_sort, increasing_array, 300)


      
