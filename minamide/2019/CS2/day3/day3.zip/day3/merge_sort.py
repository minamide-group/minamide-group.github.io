def merge(a, b):
    alen = len(a)
    blen = len(b)
    c = []
    i = 0
    j = 0
    while i < alen and j < blen:
        if a[i] <= b[j]:
            c.append(a[i])
            i = i + 1
        else:
            c.append(b[j])
            j = j + 1
    while i < alen:
        c.append(a[i])
        i = i + 1
    while j < blen:
        c.append(b[j])
        j = j + 1
    return c

def merge_sort(a):
    alen = len(a)
    if alen <= 1:
        return a
    else:
        return merge(merge_sort(a[0 : alen//2]),
                     merge_sort(a[alen//2 : alen]))
