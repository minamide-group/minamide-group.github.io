# サブルーチン writeX(a)
# 働き：文字 X をa個横に並べて書いて改行する

def writeX(a):
    for i in range(a):
        print("X", end="")
    print()

# writeX の定義ここまで

# ここからプログラム本体

n = int(input())
writeX(n)

