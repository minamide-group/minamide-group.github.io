# 関数 exp(n,k) == n ** k (in python)

def exp(n,k):
    if k == 0:
        return 1
    else:
        # この部分を埋める if 文 と 剰余 % を使う

# ここからプログラム本体

n = int(input())
k = int(input())

print(exp(n,k))
print(n ** k)
