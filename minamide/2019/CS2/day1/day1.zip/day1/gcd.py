# 関数 gcd(m,n)（mとn の最大公約数)
# ただし，m >= n

def gcd(m,n):
    global calls
    calls = calls + 1
    if n == 0:
        return m
    else:
        return gcd(n, m % n)

m = int(input())
n = int(input())
calls = 0
print(gcd(m,n))
print(calls)
