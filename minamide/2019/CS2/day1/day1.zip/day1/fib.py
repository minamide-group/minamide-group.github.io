# 関数 fib(n)（n 番目のフィボナッチ数）

def fib(n):
    if n == 0:
        return 0
    elif n == 1:
        return 1
    else:
      return           # ここに式を埋める

# ここからプログラム本体

x = int(input())
print(fib(x))
