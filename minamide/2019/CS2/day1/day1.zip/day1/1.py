# 関数 kaijou(n)（n の階乗）

def kaijou(n):
    ans = 1
    for i in range(1,n+1):
        ans = ans * i
    return(ans)

# kaijou の定義ここまで

# ここからプログラム本体

x = int(input())
print(kaijou(x))

